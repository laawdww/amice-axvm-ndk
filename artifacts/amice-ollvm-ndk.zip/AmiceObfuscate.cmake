﻿# Optional: load AMICE as clang pass plugin (Linux/Android NDK with matching libamice.so).
# Windows NDK clang cannot load amice.dll — use protect-amice-ndk.ps1 + opt.exe instead.
#
#   set(AMICE_PLUGIN /path/to/libamice.so)
#   include(AmiceObfuscate.cmake)
#   amice_apply_obfuscation(mylib)

function(amice_apply_obfuscation target)
    if(NOT AMICE_PLUGIN)
        if(DEFINED ENV{AMICE_PLUGIN})
            set(AMICE_PLUGIN "$ENV{AMICE_PLUGIN}")
        endif()
    endif()
    if(NOT AMICE_PLUGIN OR NOT EXISTS "${AMICE_PLUGIN}")
        message(WARNING "amice_apply_obfuscation(${target}): AMICE_PLUGIN not set; skip")
        return()
    endif()
    if(WIN32 AND AMICE_PLUGIN MATCHES "\\.dll$")
        message(WARNING "amice_apply_obfuscation: Windows DLL cannot be loaded by NDK clang -fpass-plugin; use protect-amice-ndk.ps1")
        return()
    endif()
    target_compile_options(${target} PRIVATE "-fpass-plugin=${AMICE_PLUGIN}")
    message(STATUS "AMICE: ${target} <= ${AMICE_PLUGIN}")
endfunction()
