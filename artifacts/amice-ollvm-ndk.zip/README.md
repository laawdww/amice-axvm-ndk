﻿# AMICE / OLLVM-style NDK Pack (Windows)

独立 OLLVM/AMICE 混淆包，**不含 AXVM**。

流程：`NDK clang -emit-llvm` → `opt.exe -load-pass-plugin=amice.dll` → `NDK clang -shared`

## 依赖

| 组件 | 说明 |
|------|------|
| `amice.dll` | 本包自带（Windows LLVM opt 插件） |
| Android NDK | `ANDROID_NDK_HOME` 或 SDK `ndk\*` |
| LLVM `opt.exe` | 与 amice.dll 匹配的 LLVM（设 `LLVM_HOME`） |

> Windows 上 **不能** 把 `amice.dll` 直接塞给 NDK `clang -fpass-plugin`。  
> Linux/CI 可用上游 [fuqiuluo/amice](https://github.com/fuqiuluo/amice) 的 `libamice.so` + `AmiceObfuscate.cmake`。

## 一键

```powershell
# 推荐常用组合
.\protect-amice-ndk.ps1 -Source .\hello_amice.c -Out .\libhello.so -All

# 或逐项开启
.\protect-amice-ndk.ps1 -Source .\foo.c -Out .\libfoo.so `
  -Flatten -MBA -BogusControlFlow -StringEncryption -IndirectCall

# 指定路径
.\protect-amice-ndk.ps1 -Source .\foo.c -Out .\libfoo.so -All `
  -NdkRoot C:\Android\Sdk\ndk\21.3.6528147 `
  -LlvmRoot C:\path\to\llvm
```

## 开关对照

| 参数 | AMICE 环境变量 |
|------|----------------|
| `-StringEncryption` | `AMICE_STRING_ENCRYPTION` |
| `-Flatten` | `AMICE_FLATTEN` |
| `-MBA` | `AMICE_MBA` |
| `-BogusControlFlow` | `AMICE_BOGUS_CONTROL_FLOW` |
| `-IndirectCall` / `-IndirectBranch` | 对应 INDIRECT_* |
| `-VmFlatten` / `-VmVirtualize` | AMICE VM 类 pass |
| `-All` | flatten+MBA+bogus+string+间接调用/分支+split+wrapper+shuffle |

额外环境变量可用 `-ExtraAmiceEnv @{ AMICE_MBA_REWRITE_OPS = "8" }`。

## 文件

- `protect-amice-ndk.ps1` — 一键脚本
- `amice.dll` — 插件
- `hello_amice.c` — 示例
- `AmiceObfuscate.cmake` — Linux `-fpass-plugin` 辅助
- `libhello_amice.sample.so` — 参考产物（若有）

上游项目：https://github.com/fuqiuluo/amice
