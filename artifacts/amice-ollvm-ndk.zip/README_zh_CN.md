﻿# AMICE OLLVM NDK 独立包

不含 AXVM，只做源码/IR 混淆。

```powershell
.\protect-amice-ndk.ps1 -Source .\hello_amice.c -Out .\libhello.so -All
```

需要本机 LLVM（`LLVM_HOME`，含 `opt.exe`）和 Android NDK。详见 README.md。
