extern int puts(const char *);

__attribute__((visibility("default")))
int amice_test(void) {
    return puts("AMICE_WINDOWS_SO_STRING_TEST_20260709");
}
