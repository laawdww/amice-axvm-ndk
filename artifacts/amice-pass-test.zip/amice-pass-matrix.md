﻿# AMICE pass matrix

## Summary

- Result: all individual pass tests produced Android arm64 shared libraries successfully.
- Combined test: `AllEnabled` also produced an Android arm64 shared library successfully.
- String marker check: `StringEncryption.so` and `AllEnabled.so` do not contain `AMICE_ALL_PASS_STRING_MARKER_20260709`.
- ELF check: `AllEnabled.so` is `ELF64`, type `DYN`, machine `AArch64`.
- Note: `CustomCallingConv` loads and runs without error, but it does not currently rewrite IR in this build. The source code has `obf_calling_conv = [0u32; 0]`, so the implementation is effectively a no-op.
- Note: `LowerSwitch` creates `lower_switch_branch` blocks. The final optimized IR still contains some `switch` instructions, so this is recorded as pass execution rather than complete switch elimination after the whole LLVM optimization pipeline.
- Source: `C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\work\amice-pass-test\amice_all_passes.c`
- Baseline raw IR: `C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll`
- Baseline optimized IR: `C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.opt.ll`
- Baseline SO: `C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\so\baseline.so`

| Pass | Status | Opt | Link | IR changed | SO size | Checks |
| --- | --- | ---: | ---: | --- | ---: | --- |
| StringEncryption | PASS | 0 | 0 | True | 9920 | marker_hidden=True |
| IndirectCall | PASS | 0 | 0 | True | 7032 | ir_changed=True |
| IndirectBranch | PASS | 0 | 0 | True | 7936 | contains_indirectbr=True |
| SplitBasicBlock | PASS | 0 | 0 | True | 7072 | ir_changed=True |
| LowerSwitch | PASS | 0 | 0 | True | 7072 | lower_switch_blocks=True;switch_removed=False |
| VmFlatten | PASS | 0 | 0 | True | 8160 | ir_changed=True |
| VmVirtualize | PASS | 0 | 0 | True | 58576 | vmp_marker=True;ir_changed=True |
| FlattenBasic | PASS | 0 | 0 | True | 7520 | ir_changed=True |
| FlattenDominator | PASS | 0 | 0 | True | 10216 | ir_changed=True |
| MBA | PASS | 0 | 0 | True | 7264 | ir_changed=True |
| BogusControlFlowBasic | PASS | 0 | 0 | True | 7424 | ir_changed=True |
| BogusControlFlowPolaris | PASS | 0 | 0 | True | 7072 | ir_changed=True |
| FunctionWrapper | PASS | 0 | 0 | True | 7752 | ir_changed=True |
| CloneFunction | PASS | 0 | 0 | True | 7256 | ir_changed=True |
| AliasAccess | PASS | 0 | 0 | True | 7056 | ir_changed=True |
| CustomCallingConv | PASS | 0 | 0 | False | 7072 | ir_changed=False |
| DelayOffsetLoading | PASS | 0 | 0 | True | 7448 | ir_changed=True |
| ParamAggregate | PASS | 0 | 0 | True | 7256 | ir_changed=True |
| BasicBlockOutlining | PASS | 0 | 0 | True | 8184 | ir_changed=True |
| ShuffleBlocks | PASS | 0 | 0 | True | 7088 | ir_changed=True |
| AllEnabled | PASS | 0 | 0 | True | 138592 | marker_hidden=True; vmp_marker=True;ir_changed=True |

## Failures

