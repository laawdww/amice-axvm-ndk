extern int puts(const char *);

volatile int amice_sink = 7;

__attribute__((noinline))
int helper_add(int a, int b) {
    return (a + b) ^ 0x13579bdf;
}

__attribute__((noinline, annotate("+custom_calling_conv")))
int custom_cc_target(int a, int b) {
    return (a * 3) - (b * 5) + 11;
}

__attribute__((noinline))
int vm_target(int x) {
    int y = x;
    y = (y * 7) ^ 0x55;
    y = (y + 13) - (x & 3);
    return y;
}

__attribute__((noinline))
int branch_switch_array(int x) {
    int local[8];
    int acc = 0;

    for (int i = 0; i < 8; ++i) {
        local[i] = x + i * 3 + amice_sink;
        acc += local[i] ^ (x << (i & 3));
    }

    switch (x & 7) {
    case 0:
        acc += local[0] * 17;
        break;
    case 1:
        acc ^= local[1] + 29;
        break;
    case 2:
        acc -= local[2] * 31;
        break;
    case 3:
        acc += local[3] ^ 0x44;
        break;
    case 4:
        acc ^= local[4] * 5;
        break;
    case 5:
        acc += local[5] - 97;
        break;
    case 6:
        acc -= local[6] ^ 0x1234;
        break;
    default:
        acc += local[7] + 123;
        break;
    }

    if (acc & 1) {
        acc = helper_add(acc, x);
    } else {
        acc = helper_add(x, acc);
    }

    puts("AMICE_ALL_PASS_STRING_MARKER_20260709");
    return acc + custom_cc_target(x, acc) + vm_target(x);
}

__attribute__((visibility("default")))
int amice_all_passes_entry(int x) {
    return branch_switch_array(x) + helper_add(x, 42);
}
