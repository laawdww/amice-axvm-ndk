; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

%amice.alias.st.3 = type { [8 x i32], ptr, i32 }

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
  %raw_box1 = alloca %amice.alias.st.3, align 8
  %field38 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 40
  store i32 0, ptr %field38, align 8
  br label %2

2:                                                ; preds = %1, %2
  %storemerge62 = phi i32 [ 0, %1 ], [ %17, %2 ]
  %raw_box.sroa.8.061 = phi i32 [ 0, %1 ], [ %16, %2 ]
  %3 = mul nsw i32 %storemerge62, 3
  %4 = add nsw i32 %3, %0
  %5 = load volatile i32, ptr @amice_sink, align 4
  %6 = add nsw i32 %4, %5
  %7 = sext i32 %storemerge62 to i64
  %8 = getelementptr inbounds [8 x i32], ptr %raw_box1, i64 0, i64 %7
  store i32 %6, ptr %8, align 4
  %9 = load i32, ptr %field38, align 8
  %10 = sext i32 %9 to i64
  %11 = getelementptr inbounds [8 x i32], ptr %raw_box1, i64 0, i64 %10
  %12 = load i32, ptr %11, align 4
  %13 = and i32 %9, 3
  %14 = shl i32 %0, %13
  %15 = xor i32 %14, %12
  %16 = add nsw i32 %15, %raw_box.sroa.8.061
  %17 = add nsw i32 %9, 1
  store i32 %17, ptr %field38, align 8
  %18 = icmp slt i32 %9, 7
  br i1 %18, label %2, label %19, !llvm.loop !5

19:                                               ; preds = %2
  %20 = and i32 %0, 7
  switch i32 %20, label %default.unreachable63 [
    i32 0, label %21
    i32 1, label %25
    i32 2, label %30
    i32 3, label %34
    i32 4, label %39
    i32 5, label %44
    i32 6, label %49
    i32 7, label %54
  ]

21:                                               ; preds = %19
  %22 = load i32, ptr %raw_box1, align 8
  %23 = mul nsw i32 %22, 17
  %24 = add nsw i32 %23, %16
  br label %59

25:                                               ; preds = %19
  %26 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 4
  %27 = load i32, ptr %26, align 4
  %28 = add nsw i32 %27, 29
  %29 = xor i32 %28, %16
  br label %59

30:                                               ; preds = %19
  %31 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 8
  %32 = load i32, ptr %31, align 8
  %.neg = mul i32 %32, -31
  %33 = add i32 %.neg, %16
  br label %59

34:                                               ; preds = %19
  %35 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = xor i32 %36, 68
  %38 = add nsw i32 %37, %16
  br label %59

39:                                               ; preds = %19
  %40 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 16
  %41 = load i32, ptr %40, align 8
  %42 = mul nsw i32 %41, 5
  %43 = xor i32 %42, %16
  br label %59

44:                                               ; preds = %19
  %45 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = add i32 %16, -97
  %48 = add i32 %47, %46
  br label %59

49:                                               ; preds = %19
  %50 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 24
  %51 = load i32, ptr %50, align 8
  %52 = xor i32 %51, 4660
  %53 = sub nsw i32 %16, %52
  br label %59

default.unreachable63:                            ; preds = %19
  unreachable

54:                                               ; preds = %19
  %55 = getelementptr inbounds nuw i8, ptr %raw_box1, i64 28
  %56 = load i32, ptr %55, align 4
  %57 = add i32 %16, 123
  %58 = add i32 %57, %56
  br label %59

59:                                               ; preds = %54, %49, %44, %39, %34, %30, %25, %21
  %raw_box.sroa.8.1 = phi i32 [ %58, %54 ], [ %53, %49 ], [ %48, %44 ], [ %43, %39 ], [ %38, %34 ], [ %33, %30 ], [ %29, %25 ], [ %24, %21 ]
  %60 = and i32 %raw_box.sroa.8.1, 1
  %.not = icmp eq i32 %60, 0
  br i1 %.not, label %63, label %61

61:                                               ; preds = %59
  %62 = tail call i32 @helper_add(i32 noundef %raw_box.sroa.8.1, i32 noundef %0)
  br label %65

63:                                               ; preds = %59
  %64 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %raw_box.sroa.8.1)
  br label %65

65:                                               ; preds = %63, %61
  %storemerge39 = phi i32 [ %64, %63 ], [ %62, %61 ]
  %66 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %67 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %storemerge39)
  %68 = add nsw i32 %67, %storemerge39
  %69 = tail call i32 @vm_target(i32 noundef %0)
  %70 = add nsw i32 %68, %69
  ret i32 %70
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
!5 = distinct !{!5, !6}
!6 = !{!"llvm.loop.mustprogress"}
