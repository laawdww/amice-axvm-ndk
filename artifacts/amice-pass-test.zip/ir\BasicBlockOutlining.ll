; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
codeRepl:
  %.loc = alloca i32, align 4
  %1 = alloca i32, align 4
  %2 = alloca [8 x i32], align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %1, align 4
  store i32 0, ptr %3, align 4
  store i32 0, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 1, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 2, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 3, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 4, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 5, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 6, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 7, ptr %4, align 4
  call fastcc void @branch_switch_array.extracted(ptr %1, ptr %4, ptr %2, ptr %3)
  store i32 8, ptr %4, align 4
  %5 = and i32 %0, 7
  switch i32 %5, label %default.unreachable10 [
    i32 0, label %codeRepl2
    i32 1, label %codeRepl3
    i32 2, label %codeRepl4
    i32 3, label %codeRepl5
    i32 4, label %codeRepl6
    i32 5, label %codeRepl7
    i32 6, label %6
    i32 7, label %12
  ]

codeRepl2:                                        ; preds = %codeRepl
  call fastcc void @branch_switch_array.extracted.2(ptr %2, ptr %3)
  br label %18

codeRepl3:                                        ; preds = %codeRepl
  call fastcc void @branch_switch_array.extracted.3(ptr %2, ptr %3)
  br label %18

codeRepl4:                                        ; preds = %codeRepl
  call fastcc void @branch_switch_array.extracted.4(ptr %2, ptr %3)
  br label %18

codeRepl5:                                        ; preds = %codeRepl
  call fastcc void @branch_switch_array.extracted.5(ptr %2, ptr %3)
  br label %18

codeRepl6:                                        ; preds = %codeRepl
  call fastcc void @branch_switch_array.extracted.6(ptr %2, ptr %3)
  br label %18

codeRepl7:                                        ; preds = %codeRepl
  call fastcc void @branch_switch_array.extracted.7(ptr %2, ptr %3)
  br label %18

6:                                                ; preds = %codeRepl
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %8 = load i32, ptr %7, align 4
  %9 = xor i32 %8, 4660
  %10 = load i32, ptr %3, align 4
  %11 = sub nsw i32 %10, %9
  store i32 %11, ptr %3, align 4
  br label %18

default.unreachable10:                            ; preds = %codeRepl
  unreachable

12:                                               ; preds = %codeRepl
  %13 = getelementptr inbounds nuw i8, ptr %2, i64 28
  %14 = load i32, ptr %13, align 4
  %15 = add nsw i32 %14, 123
  %16 = load i32, ptr %3, align 4
  %17 = add nsw i32 %15, %16
  store i32 %17, ptr %3, align 4
  br label %18

18:                                               ; preds = %codeRepl7, %codeRepl6, %codeRepl5, %codeRepl4, %codeRepl3, %codeRepl2, %12, %6
  %19 = load i32, ptr %3, align 4
  %20 = and i32 %19, 1
  %.not = icmp eq i32 %20, 0
  br i1 %.not, label %23, label %21

21:                                               ; preds = %18
  %22 = tail call i32 @helper_add(i32 noundef %19, i32 noundef %0)
  br label %codeRepl1

23:                                               ; preds = %18
  %24 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %19)
  br label %codeRepl1

codeRepl1:                                        ; preds = %21, %23
  %storemerge8 = phi i32 [ %24, %23 ], [ %22, %21 ]
  store i32 %storemerge8, ptr %3, align 4
  call void @llvm.lifetime.start.p0(i64 -1, ptr nonnull %.loc)
  call fastcc void @branch_switch_array.extracted.1(ptr %3, ptr %1, ptr %.loc)
  %.reload = load i32, ptr %.loc, align 4
  call void @llvm.lifetime.end.p0(i64 -1, ptr nonnull %.loc)
  ret i32 %.reload
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nounwind willreturn uwtable
define internal fastcc void @branch_switch_array.extracted(ptr nocapture nonnull readonly %0, ptr nocapture nonnull readonly %1, ptr nocapture nonnull %2, ptr nocapture nonnull %3) unnamed_addr #3 {
newFuncRoot:
  %4 = load i32, ptr %0, align 4
  %5 = load i32, ptr %1, align 4
  %6 = mul nsw i32 %5, 3
  %7 = add nsw i32 %6, %4
  %8 = load volatile i32, ptr @amice_sink, align 4
  %9 = add nsw i32 %7, %8
  %10 = sext i32 %5 to i64
  %11 = getelementptr inbounds [8 x i32], ptr %2, i64 0, i64 %10
  store i32 %9, ptr %11, align 4
  %12 = load i32, ptr %1, align 4
  %13 = sext i32 %12 to i64
  %14 = getelementptr inbounds [8 x i32], ptr %2, i64 0, i64 %13
  %15 = load i32, ptr %14, align 4
  %16 = load i32, ptr %0, align 4
  %17 = and i32 %12, 3
  %18 = shl i32 %16, %17
  %19 = xor i32 %18, %15
  %20 = load i32, ptr %3, align 4
  %21 = add nsw i32 %19, %20
  store i32 %21, ptr %3, align 4
  ret void
}

; Function Attrs: nofree noinline nounwind uwtable
define internal fastcc void @branch_switch_array.extracted.1(ptr nocapture nonnull readonly %0, ptr nocapture nonnull readonly %1, ptr nocapture nonnull writeonly initializes((0, 4)) %.out) unnamed_addr #1 {
newFuncRoot:
  %2 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %3 = load i32, ptr %0, align 4
  %4 = load i32, ptr %1, align 4
  %5 = tail call i32 @custom_cc_target(i32 noundef %4, i32 noundef %3)
  %6 = add nsw i32 %5, %3
  %7 = tail call i32 @vm_target(i32 noundef %4)
  %8 = add nsw i32 %6, %7
  store i32 %8, ptr %.out, align 4
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @branch_switch_array.extracted.2(ptr nocapture nonnull readonly %0, ptr nocapture nonnull %1) unnamed_addr #5 {
newFuncRoot:
  %2 = load i32, ptr %0, align 4
  %3 = mul nsw i32 %2, 17
  %4 = load i32, ptr %1, align 4
  %5 = add nsw i32 %4, %3
  store i32 %5, ptr %1, align 4
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @branch_switch_array.extracted.3(ptr nocapture nonnull readonly %0, ptr nocapture nonnull %1) unnamed_addr #5 {
newFuncRoot:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, 29
  %5 = load i32, ptr %1, align 4
  %6 = xor i32 %5, %4
  store i32 %6, ptr %1, align 4
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @branch_switch_array.extracted.4(ptr nocapture nonnull readonly %0, ptr nocapture nonnull %1) unnamed_addr #5 {
newFuncRoot:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i32, ptr %2, align 4
  %.neg = mul i32 %3, -31
  %4 = load i32, ptr %1, align 4
  %5 = add i32 %.neg, %4
  store i32 %5, ptr %1, align 4
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @branch_switch_array.extracted.5(ptr nocapture nonnull readonly %0, ptr nocapture nonnull %1) unnamed_addr #5 {
newFuncRoot:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %3 = load i32, ptr %2, align 4
  %4 = xor i32 %3, 68
  %5 = load i32, ptr %1, align 4
  %6 = add nsw i32 %5, %4
  store i32 %6, ptr %1, align 4
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @branch_switch_array.extracted.6(ptr nocapture nonnull readonly %0, ptr nocapture nonnull %1) unnamed_addr #5 {
newFuncRoot:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %3 = load i32, ptr %2, align 4
  %4 = mul nsw i32 %3, 5
  %5 = load i32, ptr %1, align 4
  %6 = xor i32 %5, %4
  store i32 %6, ptr %1, align 4
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @branch_switch_array.extracted.7(ptr nocapture nonnull readonly %0, ptr nocapture nonnull %1) unnamed_addr #5 {
newFuncRoot:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, -97
  %5 = load i32, ptr %1, align 4
  %6 = add nsw i32 %4, %5
  store i32 %6, ptr %1, align 4
  ret void
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #3 = { mustprogress nofree noinline norecurse nounwind willreturn uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
