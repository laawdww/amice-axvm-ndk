; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@0 = internal global i32 2012801300
@1 = internal global i32 96036301

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
bogus_cond:
  %.x = alloca i32, align 4
  %.y = alloca i32, align 4
  store i32 2012801300, ptr %.x, align 4
  store i32 96036301, ptr %.y, align 4
  %1 = load volatile i32, ptr @amice_sink, align 4
  %2 = add nsw i32 %0, %1
  %3 = xor i32 %2, %0
  %x_val = load volatile i32, ptr @0, align 4
  %y_val = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4 = load volatile i32, ptr %.y, align 4
  %x_sq = mul i32 %.x.0..x.0..x.0..x.0.x_val3, %.x.0..x.0..x.0..x.0.x_val3
  %x_sq_m1 = add i32 %x_sq, -1
  %x_m1 = add i32 %.x.0..x.0..x.0..x.0.x_val3, -1
  %x_p1 = add i32 %.x.0..x.0..x.0..x.0.x_val3, 1
  %diff_sq = mul i32 %x_m1, %x_p1
  %id_diffsq = icmp eq i32 %x_sq_m1, %diff_sq
  tail call void @llvm.assume(i1 %id_diffsq)
  %4 = add i32 %0, 3
  %5 = load volatile i32, ptr @amice_sink, align 4
  %6 = add nsw i32 %4, %5
  %7 = shl i32 %0, 1
  %8 = xor i32 %6, %7
  %9 = add nsw i32 %8, %3
  %x_val.1 = load volatile i32, ptr @0, align 4
  %y_val.1 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.1 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.1 = load volatile i32, ptr %.y, align 4
  %x_sq.1 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.1, %.x.0..x.0..x.0..x.0.x_val3.1
  %x_sq_m1.1 = add i32 %x_sq.1, -1
  %x_m1.1 = add i32 %.x.0..x.0..x.0..x.0.x_val3.1, -1
  %x_p1.1 = add i32 %.x.0..x.0..x.0..x.0.x_val3.1, 1
  %diff_sq.1 = mul i32 %x_m1.1, %x_p1.1
  %id_diffsq.1 = icmp eq i32 %x_sq_m1.1, %diff_sq.1
  tail call void @llvm.assume(i1 %id_diffsq.1)
  %10 = add i32 %0, 6
  %11 = load volatile i32, ptr @amice_sink, align 4
  %12 = add nsw i32 %10, %11
  %13 = shl i32 %0, 2
  %14 = xor i32 %12, %13
  %15 = add nsw i32 %14, %9
  %x_val.2 = load volatile i32, ptr @0, align 4
  %y_val.2 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.2 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.2 = load volatile i32, ptr %.y, align 4
  %x_sq.2 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.2, %.x.0..x.0..x.0..x.0.x_val3.2
  %x_sq_m1.2 = add i32 %x_sq.2, -1
  %x_m1.2 = add i32 %.x.0..x.0..x.0..x.0.x_val3.2, -1
  %x_p1.2 = add i32 %.x.0..x.0..x.0..x.0.x_val3.2, 1
  %diff_sq.2 = mul i32 %x_m1.2, %x_p1.2
  %id_diffsq.2 = icmp eq i32 %x_sq_m1.2, %diff_sq.2
  tail call void @llvm.assume(i1 %id_diffsq.2)
  %16 = add i32 %0, 9
  %17 = load volatile i32, ptr @amice_sink, align 4
  %18 = add nsw i32 %16, %17
  %19 = shl i32 %0, 3
  %20 = xor i32 %18, %19
  %21 = add nsw i32 %20, %15
  %x_val.3 = load volatile i32, ptr @0, align 4
  %y_val.3 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.3 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.3 = load volatile i32, ptr %.y, align 4
  %x_sq.3 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.3, %.x.0..x.0..x.0..x.0.x_val3.3
  %x_sq_m1.3 = add i32 %x_sq.3, -1
  %x_m1.3 = add i32 %.x.0..x.0..x.0..x.0.x_val3.3, -1
  %x_p1.3 = add i32 %.x.0..x.0..x.0..x.0.x_val3.3, 1
  %diff_sq.3 = mul i32 %x_m1.3, %x_p1.3
  %id_diffsq.3 = icmp eq i32 %x_sq_m1.3, %diff_sq.3
  tail call void @llvm.assume(i1 %id_diffsq.3)
  %22 = add i32 %0, 12
  %23 = load volatile i32, ptr @amice_sink, align 4
  %24 = add nsw i32 %22, %23
  %25 = xor i32 %24, %0
  %26 = add nsw i32 %25, %21
  %x_val.4 = load volatile i32, ptr @0, align 4
  %y_val.4 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.4 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.4 = load volatile i32, ptr %.y, align 4
  %x_sq.4 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.4, %.x.0..x.0..x.0..x.0.x_val3.4
  %x_sq_m1.4 = add i32 %x_sq.4, -1
  %x_m1.4 = add i32 %.x.0..x.0..x.0..x.0.x_val3.4, -1
  %x_p1.4 = add i32 %.x.0..x.0..x.0..x.0.x_val3.4, 1
  %diff_sq.4 = mul i32 %x_m1.4, %x_p1.4
  %id_diffsq.4 = icmp eq i32 %x_sq_m1.4, %diff_sq.4
  tail call void @llvm.assume(i1 %id_diffsq.4)
  %27 = add i32 %0, 15
  %28 = load volatile i32, ptr @amice_sink, align 4
  %29 = add nsw i32 %27, %28
  %30 = shl i32 %0, 1
  %31 = xor i32 %29, %30
  %32 = add nsw i32 %31, %26
  %x_val.5 = load volatile i32, ptr @0, align 4
  %y_val.5 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.5 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.5 = load volatile i32, ptr %.y, align 4
  %x_sq.5 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.5, %.x.0..x.0..x.0..x.0.x_val3.5
  %x_sq_m1.5 = add i32 %x_sq.5, -1
  %x_m1.5 = add i32 %.x.0..x.0..x.0..x.0.x_val3.5, -1
  %x_p1.5 = add i32 %.x.0..x.0..x.0..x.0.x_val3.5, 1
  %diff_sq.5 = mul i32 %x_m1.5, %x_p1.5
  %id_diffsq.5 = icmp eq i32 %x_sq_m1.5, %diff_sq.5
  tail call void @llvm.assume(i1 %id_diffsq.5)
  %33 = add i32 %0, 18
  %34 = load volatile i32, ptr @amice_sink, align 4
  %35 = add nsw i32 %33, %34
  %36 = shl i32 %0, 2
  %37 = xor i32 %35, %36
  %38 = add nsw i32 %37, %32
  %x_val.6 = load volatile i32, ptr @0, align 4
  %y_val.6 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.6 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.6 = load volatile i32, ptr %.y, align 4
  %x_sq.6 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.6, %.x.0..x.0..x.0..x.0.x_val3.6
  %x_sq_m1.6 = add i32 %x_sq.6, -1
  %x_m1.6 = add i32 %.x.0..x.0..x.0..x.0.x_val3.6, -1
  %x_p1.6 = add i32 %.x.0..x.0..x.0..x.0.x_val3.6, 1
  %diff_sq.6 = mul i32 %x_m1.6, %x_p1.6
  %id_diffsq.6 = icmp eq i32 %x_sq_m1.6, %diff_sq.6
  tail call void @llvm.assume(i1 %id_diffsq.6)
  %39 = add i32 %0, 21
  %40 = load volatile i32, ptr @amice_sink, align 4
  %41 = add nsw i32 %39, %40
  %42 = shl i32 %0, 3
  %43 = xor i32 %41, %42
  %44 = add nsw i32 %43, %38
  %x_val.7 = load volatile i32, ptr @0, align 4
  %y_val.7 = load volatile i32, ptr @1, align 4
  %.x.0..x.0..x.0..x.0.x_val3.7 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val4.7 = load volatile i32, ptr %.y, align 4
  %x_sq.7 = mul i32 %.x.0..x.0..x.0..x.0.x_val3.7, %.x.0..x.0..x.0..x.0.x_val3.7
  %x_sq_m1.7 = add i32 %x_sq.7, -1
  %x_m1.7 = add i32 %.x.0..x.0..x.0..x.0.x_val3.7, -1
  %x_p1.7 = add i32 %.x.0..x.0..x.0..x.0.x_val3.7, 1
  %diff_sq.7 = mul i32 %x_m1.7, %x_p1.7
  %id_diffsq.7 = icmp eq i32 %x_sq_m1.7, %diff_sq.7
  tail call void @llvm.assume(i1 %id_diffsq.7)
  %45 = and i32 %0, 7
  switch i32 %45, label %default.unreachable118 [
    i32 0, label %bogus_cond5
    i32 1, label %bogus_cond10
    i32 2, label %bogus_cond19
    i32 3, label %bogus_cond28
    i32 4, label %bogus_cond38
    i32 5, label %bogus_cond42
    i32 6, label %bogus_cond51
    i32 7, label %bogus_cond61
  ]

bogus_cond5:                                      ; preds = %bogus_cond
  %46 = mul nsw i32 %2, 17
  %47 = add nsw i32 %46, %44
  %.x.0..x.0..x.0..x.0.x_val7 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val8 = load volatile i32, ptr %.y, align 4
  br label %61

bogus_cond10:                                     ; preds = %bogus_cond
  %48 = add nsw i32 %6, 29
  %49 = xor i32 %48, %44
  %.x.0..x.0..x.0..x.0.x_val12 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val13 = load volatile i32, ptr %.y, align 4
  br label %61

bogus_cond19:                                     ; preds = %bogus_cond
  %.neg = mul i32 %12, -31
  %50 = add i32 %.neg, %44
  %x_val21 = load volatile i32, ptr @0, align 4
  %y_val22 = load volatile i32, ptr @1, align 4
  br label %61

bogus_cond28:                                     ; preds = %bogus_cond
  %51 = xor i32 %18, 68
  %52 = add nsw i32 %51, %44
  %x_val30 = load volatile i32, ptr @0, align 4
  %y_val31 = load volatile i32, ptr @1, align 4
  %x_sq32 = mul i32 %y_val31, %y_val31
  %x_sq_m133 = add i32 %x_sq32, -1
  %x_m134 = add i32 %y_val31, -1
  %x_p135 = add i32 %y_val31, 1
  %diff_sq36 = mul i32 %x_m134, %x_p135
  %id_diffsq37.not = icmp eq i32 %x_sq_m133, %diff_sq36
  tail call void @llvm.assume(i1 %id_diffsq37.not)
  br label %61

bogus_cond38:                                     ; preds = %bogus_cond
  %53 = mul nsw i32 %24, 5
  %54 = xor i32 %53, %44
  %.x.0..x.0..x.0..x.0.x_val40 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val41 = load volatile i32, ptr %.y, align 4
  br label %61

bogus_cond42:                                     ; preds = %bogus_cond
  %55 = add i32 %44, -97
  %56 = add i32 %55, %29
  %x_val44 = load volatile i32, ptr @0, align 4
  %y_val45 = load volatile i32, ptr @1, align 4
  br label %61

bogus_cond51:                                     ; preds = %bogus_cond
  %57 = xor i32 %35, 4660
  %58 = sub nsw i32 %44, %57
  %.x.0..x.0..x.0..x.0.x_val53 = load volatile i32, ptr %.x, align 4
  %.y.0..y.0..y.0..y.0.y_val54 = load volatile i32, ptr %.y, align 4
  %x_sq55 = mul i32 %.x.0..x.0..x.0..x.0.x_val53, %.x.0..x.0..x.0..x.0.x_val53
  %x_sq_m156 = add i32 %x_sq55, -1
  %x_m157 = add i32 %.x.0..x.0..x.0..x.0.x_val53, -1
  %x_p158 = add i32 %.x.0..x.0..x.0..x.0.x_val53, 1
  %diff_sq59 = mul i32 %x_m157, %x_p158
  %id_diffsq60 = icmp eq i32 %x_sq_m156, %diff_sq59
  tail call void @llvm.assume(i1 %id_diffsq60)
  br label %61

default.unreachable118:                           ; preds = %bogus_cond
  unreachable

bogus_cond61:                                     ; preds = %bogus_cond
  %59 = add i32 %44, 123
  %60 = add i32 %59, %41
  %x_val63 = load volatile i32, ptr @0, align 4
  %y_val64 = load volatile i32, ptr @1, align 4
  br label %61

61:                                               ; preds = %bogus_cond61, %bogus_cond51, %bogus_cond42, %bogus_cond38, %bogus_cond28, %bogus_cond19, %bogus_cond10, %bogus_cond5
  %.1 = phi i32 [ %60, %bogus_cond61 ], [ %58, %bogus_cond51 ], [ %56, %bogus_cond42 ], [ %54, %bogus_cond38 ], [ %52, %bogus_cond28 ], [ %50, %bogus_cond19 ], [ %49, %bogus_cond10 ], [ %47, %bogus_cond5 ]
  %62 = and i32 %.1, 1
  %.not = icmp eq i32 %62, 0
  br i1 %.not, label %bogus_cond78, label %bogus_cond68

bogus_cond68:                                     ; preds = %61
  %63 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %65

bogus_cond78:                                     ; preds = %61
  %64 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %65

65:                                               ; preds = %bogus_cond78, %bogus_cond68
  %.x.sink = phi ptr [ %.x, %bogus_cond78 ], [ @0, %bogus_cond68 ]
  %.y.sink = phi ptr [ %.y, %bogus_cond78 ], [ @1, %bogus_cond68 ]
  %.2 = phi i32 [ %64, %bogus_cond78 ], [ %63, %bogus_cond68 ]
  %.x.0..x.0..x.0.x_val80 = load volatile i32, ptr %.x.sink, align 4
  %.y.0..y.0..y.0.y_val81 = load volatile i32, ptr %.y.sink, align 4
  %x_sq82 = mul i32 %.x.0..x.0..x.0.x_val80, %.x.0..x.0..x.0.x_val80
  %x_sq_m183 = add i32 %x_sq82, -1
  %x_m184 = add i32 %.x.0..x.0..x.0.x_val80, -1
  %x_p185 = add i32 %.x.0..x.0..x.0.x_val80, 1
  %diff_sq86 = mul i32 %x_m184, %x_p185
  %id_diffsq87 = icmp eq i32 %x_sq_m183, %diff_sq86
  tail call void @llvm.assume(i1 %id_diffsq87)
  %66 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %67 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %68 = add nsw i32 %67, %.2
  %69 = tail call i32 @vm_target(i32 noundef %0)
  %70 = add nsw i32 %68, %69
  ret i32 %70
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #3

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
