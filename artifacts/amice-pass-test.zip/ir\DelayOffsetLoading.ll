; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@.ama.offset.4 = private global i64 4525076882932885166
@.ama.offset.8 = private global i64 -6762255331789583989
@.ama.offset.12 = private global i64 -5053835604199120058
@.ama.offset.16 = private global i64 4627226485239541244
@.ama.offset.20 = private global i64 -3707303205734893122
@.ama.offset.24 = private global i64 889310038741936744
@.ama.offset.28 = private global i64 8613955252363325915

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
  %2 = alloca [8 x i32], align 4
  %3 = load volatile i32, ptr @amice_sink, align 4
  %4 = add nsw i32 %0, %3
  store i32 %4, ptr %2, align 4
  %5 = xor i32 %4, %0
  %6 = add i32 %0, 3
  %7 = load volatile i32, ptr @amice_sink, align 4
  %8 = add nsw i32 %6, %7
  %9 = getelementptr inbounds nuw i8, ptr %2, i64 4
  store i32 %8, ptr %9, align 4
  %10 = shl i32 %0, 1
  %11 = xor i32 %8, %10
  %12 = add nsw i32 %11, %5
  %13 = add i32 %0, 6
  %14 = load volatile i32, ptr @amice_sink, align 4
  %15 = add nsw i32 %13, %14
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i32 %15, ptr %16, align 4
  %17 = shl i32 %0, 2
  %18 = xor i32 %15, %17
  %19 = add nsw i32 %18, %12
  %20 = add i32 %0, 9
  %21 = load volatile i32, ptr @amice_sink, align 4
  %22 = add nsw i32 %20, %21
  %23 = getelementptr inbounds nuw i8, ptr %2, i64 12
  store i32 %22, ptr %23, align 4
  %24 = shl i32 %0, 3
  %25 = xor i32 %22, %24
  %26 = add nsw i32 %25, %19
  %27 = add i32 %0, 12
  %28 = load volatile i32, ptr @amice_sink, align 4
  %29 = add nsw i32 %27, %28
  %30 = getelementptr inbounds nuw i8, ptr %2, i64 16
  store i32 %29, ptr %30, align 4
  %31 = xor i32 %29, %0
  %32 = add nsw i32 %31, %26
  %33 = add i32 %0, 15
  %34 = load volatile i32, ptr @amice_sink, align 4
  %35 = add nsw i32 %33, %34
  %36 = getelementptr inbounds nuw i8, ptr %2, i64 20
  store i32 %35, ptr %36, align 4
  %37 = shl i32 %0, 1
  %38 = xor i32 %35, %37
  %39 = add nsw i32 %38, %32
  %40 = add i32 %0, 18
  %41 = load volatile i32, ptr @amice_sink, align 4
  %42 = add nsw i32 %40, %41
  %43 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 %42, ptr %43, align 4
  %44 = shl i32 %0, 2
  %45 = xor i32 %42, %44
  %46 = add nsw i32 %45, %39
  %47 = add i32 %0, 21
  %48 = load volatile i32, ptr @amice_sink, align 4
  %49 = add nsw i32 %47, %48
  %50 = getelementptr inbounds nuw i8, ptr %2, i64 28
  store i32 %49, ptr %50, align 4
  %51 = shl i32 %0, 3
  %52 = xor i32 %49, %51
  %53 = add nsw i32 %52, %46
  %54 = and i32 %0, 7
  switch i32 %54, label %default.unreachable49 [
    i32 0, label %55
    i32 1, label %59
    i32 2, label %63
    i32 3, label %66
    i32 4, label %70
    i32 5, label %74
    i32 6, label %78
    i32 7, label %82
  ]

55:                                               ; preds = %1
  %56 = load i32, ptr %2, align 4
  %57 = mul nsw i32 %56, 17
  %58 = add nsw i32 %57, %53
  br label %86

59:                                               ; preds = %1
  %offset_val = load volatile i64, ptr @.ama.offset.4, align 8
  %offset_val_no_xor = xor i64 %offset_val, 4525076882932885162
  %st_ptr_to_gep_ptr = getelementptr i8, ptr %2, i64 %offset_val_no_xor
  %60 = load i32, ptr %st_ptr_to_gep_ptr, align 4
  %61 = add nsw i32 %60, 29
  %62 = xor i32 %61, %53
  br label %86

63:                                               ; preds = %1
  %offset_val1 = load volatile i64, ptr @.ama.offset.8, align 8
  %offset_val_no_xor2 = xor i64 %offset_val1, -6762255331789583997
  %st_ptr_to_gep_ptr3 = getelementptr i8, ptr %2, i64 %offset_val_no_xor2
  %64 = load i32, ptr %st_ptr_to_gep_ptr3, align 4
  %.neg = mul i32 %64, -31
  %65 = add i32 %.neg, %53
  br label %86

66:                                               ; preds = %1
  %offset_val4 = load volatile i64, ptr @.ama.offset.12, align 8
  %offset_val_no_xor5 = xor i64 %offset_val4, -5053835604199120054
  %st_ptr_to_gep_ptr6 = getelementptr i8, ptr %2, i64 %offset_val_no_xor5
  %67 = load i32, ptr %st_ptr_to_gep_ptr6, align 4
  %68 = xor i32 %67, 68
  %69 = add nsw i32 %68, %53
  br label %86

70:                                               ; preds = %1
  %offset_val7 = load volatile i64, ptr @.ama.offset.16, align 8
  %offset_val_no_xor8 = xor i64 %offset_val7, 4627226485239541228
  %st_ptr_to_gep_ptr9 = getelementptr i8, ptr %2, i64 %offset_val_no_xor8
  %71 = load i32, ptr %st_ptr_to_gep_ptr9, align 4
  %72 = mul nsw i32 %71, 5
  %73 = xor i32 %72, %53
  br label %86

74:                                               ; preds = %1
  %offset_val10 = load volatile i64, ptr @.ama.offset.20, align 8
  %offset_val_no_xor11 = xor i64 %offset_val10, -3707303205734893142
  %st_ptr_to_gep_ptr12 = getelementptr i8, ptr %2, i64 %offset_val_no_xor11
  %75 = load i32, ptr %st_ptr_to_gep_ptr12, align 4
  %76 = add i32 %53, -97
  %77 = add i32 %76, %75
  br label %86

78:                                               ; preds = %1
  %offset_val13 = load volatile i64, ptr @.ama.offset.24, align 8
  %offset_val_no_xor14 = xor i64 %offset_val13, 889310038741936752
  %st_ptr_to_gep_ptr15 = getelementptr i8, ptr %2, i64 %offset_val_no_xor14
  %79 = load i32, ptr %st_ptr_to_gep_ptr15, align 4
  %80 = xor i32 %79, 4660
  %81 = sub nsw i32 %53, %80
  br label %86

default.unreachable49:                            ; preds = %1
  unreachable

82:                                               ; preds = %1
  %offset_val16 = load volatile i64, ptr @.ama.offset.28, align 8
  %offset_val_no_xor17 = xor i64 %offset_val16, 8613955252363325895
  %st_ptr_to_gep_ptr18 = getelementptr i8, ptr %2, i64 %offset_val_no_xor17
  %83 = load i32, ptr %st_ptr_to_gep_ptr18, align 4
  %84 = add i32 %53, 123
  %85 = add i32 %84, %83
  br label %86

86:                                               ; preds = %82, %78, %74, %70, %66, %63, %59, %55
  %.1 = phi i32 [ %85, %82 ], [ %81, %78 ], [ %77, %74 ], [ %73, %70 ], [ %69, %66 ], [ %65, %63 ], [ %62, %59 ], [ %58, %55 ]
  %87 = and i32 %.1, 1
  %.not = icmp eq i32 %87, 0
  br i1 %.not, label %90, label %88

88:                                               ; preds = %86
  %89 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %92

90:                                               ; preds = %86
  %91 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %92

92:                                               ; preds = %90, %88
  %.2 = phi i32 [ %89, %88 ], [ %91, %90 ]
  %93 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %94 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %95 = add nsw i32 %94, %.2
  %96 = tail call i32 @vm_target(i32 noundef %0)
  %97 = add nsw i32 %95, %96
  ret i32 %97
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
