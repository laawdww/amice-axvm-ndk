; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
  %2 = alloca [8 x i32], align 4
  %3 = and i32 %0, 7
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 28
  %5 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 20
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %9 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %10 = getelementptr inbounds nuw i8, ptr %2, i64 4
  br label %dispatcher

11:                                               ; preds = %dispatcher
  %12 = icmp slt i32 %.0, 8
  %13 = select i1 %12, i32 -370052274, i32 1066420470
  br label %dispatcher.backedge

14:                                               ; preds = %dispatcher
  %15 = mul nsw i32 %.0, 3
  %16 = add nsw i32 %15, %0
  %17 = load volatile i32, ptr @amice_sink, align 4
  %18 = add nsw i32 %16, %17
  %19 = sext i32 %.0 to i64
  %20 = getelementptr inbounds [8 x i32], ptr %2, i64 0, i64 %19
  store i32 %18, ptr %20, align 4
  %21 = and i32 %.0, 3
  %22 = shl i32 %0, %21
  %23 = xor i32 %18, %22
  %24 = add nsw i32 %23, %.047
  br label %dispatcher.backedge

dispatcher.backedge:                              ; preds = %14, %25, %27, %31, %35, %38, %42, %46, %50, %lower_switch_branch7, %60, %62, %11, %57, %dispatcher
  %.048.be = phi i32 [ %.048, %dispatcher ], [ 1128649377, %62 ], [ 53703481, %42 ], [ 1128649377, %60 ], [ 1908784306, %14 ], [ 1827606691, %25 ], [ 53703481, %50 ], [ 53703481, %31 ], [ 53703481, %lower_switch_branch7 ], [ 53703481, %35 ], [ 53703481, %46 ], [ %59, %57 ], [ 53703481, %38 ], [ 53703481, %27 ], [ %13, %11 ]
  %.047.be = phi i32 [ %.047, %dispatcher ], [ %63, %62 ], [ %45, %42 ], [ %61, %60 ], [ %24, %14 ], [ %.047, %25 ], [ %53, %50 ], [ %34, %31 ], [ %56, %lower_switch_branch7 ], [ %37, %35 ], [ %49, %46 ], [ %.047, %57 ], [ %41, %38 ], [ %30, %27 ], [ %.047, %11 ]
  %.0.be = phi i32 [ %.0, %dispatcher ], [ %.0, %62 ], [ %.0, %42 ], [ %.0, %60 ], [ %.0, %14 ], [ %26, %25 ], [ %.0, %50 ], [ %.0, %31 ], [ %.0, %lower_switch_branch7 ], [ %.0, %35 ], [ %.0, %46 ], [ %.0, %57 ], [ %.0, %38 ], [ %.0, %27 ], [ %.0, %11 ]
  br label %dispatcher

25:                                               ; preds = %dispatcher
  %26 = add nsw i32 %.0, 1
  br label %dispatcher.backedge

lower_switch_branch:                              ; preds = %dispatcher
  switch i32 %3, label %default.unreachable [
    i32 0, label %27
    i32 1, label %31
    i32 2, label %35
    i32 3, label %38
    i32 4, label %42
    i32 5, label %46
    i32 6, label %50
    i32 7, label %lower_switch_branch7
  ]

27:                                               ; preds = %lower_switch_branch, %dispatcher
  %28 = load i32, ptr %2, align 4
  %29 = mul nsw i32 %28, 17
  %30 = add nsw i32 %29, %.047
  br label %dispatcher.backedge

31:                                               ; preds = %lower_switch_branch
  %32 = load i32, ptr %10, align 4
  %33 = add nsw i32 %32, 29
  %34 = xor i32 %33, %.047
  br label %dispatcher.backedge

35:                                               ; preds = %lower_switch_branch, %dispatcher
  %36 = load i32, ptr %9, align 4
  %.neg = mul i32 %36, -31
  %37 = add i32 %.neg, %.047
  br label %dispatcher.backedge

38:                                               ; preds = %lower_switch_branch, %dispatcher
  %39 = load i32, ptr %8, align 4
  %40 = xor i32 %39, 68
  %41 = add nsw i32 %40, %.047
  br label %dispatcher.backedge

42:                                               ; preds = %lower_switch_branch, %dispatcher
  %43 = load i32, ptr %7, align 4
  %44 = mul nsw i32 %43, 5
  %45 = xor i32 %44, %.047
  br label %dispatcher.backedge

46:                                               ; preds = %lower_switch_branch, %dispatcher
  %47 = load i32, ptr %6, align 4
  %48 = add i32 %.047, -97
  %49 = add i32 %48, %47
  br label %dispatcher.backedge

50:                                               ; preds = %lower_switch_branch, %dispatcher
  %51 = load i32, ptr %5, align 4
  %52 = xor i32 %51, 4660
  %53 = sub nsw i32 %.047, %52
  br label %dispatcher.backedge

default.unreachable:                              ; preds = %lower_switch_branch
  unreachable

lower_switch_branch7:                             ; preds = %lower_switch_branch, %dispatcher
  %54 = load i32, ptr %4, align 4
  %55 = add i32 %.047, 123
  %56 = add i32 %55, %54
  br label %dispatcher.backedge

57:                                               ; preds = %dispatcher
  %58 = and i32 %.047, 1
  %.not = icmp eq i32 %58, 0
  %59 = select i1 %.not, i32 -171501415, i32 324684807
  br label %dispatcher.backedge

60:                                               ; preds = %dispatcher
  %61 = tail call i32 @helper_add(i32 noundef %.047, i32 noundef %0)
  br label %dispatcher.backedge

62:                                               ; preds = %dispatcher
  %63 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.047)
  br label %dispatcher.backedge

64:                                               ; preds = %dispatcher
  %65 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %66 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.047)
  %67 = add nsw i32 %66, %.047
  %68 = tail call i32 @vm_target(i32 noundef %0)
  %69 = add nsw i32 %67, %68
  ret i32 %69

dispatcher:                                       ; preds = %dispatcher.backedge, %1
  %.048 = phi i32 [ 1827606691, %1 ], [ %.048.be, %dispatcher.backedge ]
  %.047 = phi i32 [ 0, %1 ], [ %.047.be, %dispatcher.backedge ]
  %.0 = phi i32 [ 0, %1 ], [ %.0.be, %dispatcher.backedge ]
  switch i32 %.048, label %dispatcher.backedge [
    i32 1066420470, label %lower_switch_branch
    i32 1827606691, label %11
    i32 1642398644, label %27
    i32 -534743302, label %38
    i32 53703481, label %57
    i32 97515636, label %46
    i32 -1335916274, label %35
    i32 -323750665, label %lower_switch_branch7
    i32 -171501415, label %62
    i32 -1178090999, label %50
    i32 1128649377, label %64
    i32 1908784306, label %25
    i32 -370052274, label %14
    i32 324684807, label %60
    i32 -777796512, label %42
  ]
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
