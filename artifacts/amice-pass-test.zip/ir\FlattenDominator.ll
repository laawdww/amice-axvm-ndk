; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@0 = private constant [24 x i32] [i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 12, i32 13, i32 14, i32 15, i32 16, i32 17, i32 18, i32 19, i32 20, i32 21, i32 22, i32 23, i32 24]
@1 = private constant [2 x i32] [i32 2, i32 16]
@2 = private constant [1 x i32] [i32 16]
@3 = private constant [21 x i32] [i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 12, i32 13, i32 14, i32 15, i32 16, i32 17, i32 18, i32 19, i32 20, i32 21, i32 22, i32 23, i32 24]
@4 = private constant [1 x i32] [i32 16]
@5 = private constant [1 x i32] [i32 16]
@6 = private constant [1 x i32] [i32 16]
@7 = private constant [1 x i32] [i32 16]
@8 = private constant [1 x i32] [i32 16]
@9 = private constant [1 x i32] [i32 16]
@10 = private constant [1 x i32] [i32 16]
@11 = private constant [1 x i32] [i32 16]
@12 = private constant [4 x i32] [i32 13, i32 14, i32 15, i32 16]
@13 = private constant [1 x i32] [i32 16]
@14 = private constant [1 x i32] [i32 16]
@15 = private constant [1 x i32] [i32 16]
@16 = private constant [20 x i32] [i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 12, i32 13, i32 14, i32 15, i32 16, i32 18, i32 19, i32 20, i32 21, i32 22, i32 23, i32 24]
@17 = private constant [14 x i32] [i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 19, i32 20, i32 21, i32 22, i32 23, i32 24]
@18 = private constant [12 x i32] [i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 20, i32 21, i32 22, i32 23, i32 24]
@19 = private constant [10 x i32] [i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 21, i32 22, i32 23, i32 24]
@20 = private constant [8 x i32] [i32 8, i32 9, i32 10, i32 11, i32 16, i32 22, i32 23, i32 24]
@21 = private constant [6 x i32] [i32 9, i32 10, i32 11, i32 16, i32 23, i32 24]
@22 = private constant [4 x i32] [i32 10, i32 11, i32 16, i32 24]
@23 = private constant [2 x i32] [i32 11, i32 16]

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
  %visited80 = alloca [25 x i8], align 4
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(25) %visited80, i8 0, i32 25, i1 false)
  %key_array81 = alloca [25 x i64], align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(200) %key_array81, i8 0, i64 200, i1 false)
  %2 = alloca [8 x i32], align 4
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %4 = getelementptr inbounds nuw i8, ptr %key_array81, i64 56
  %5 = getelementptr inbounds nuw i8, ptr %key_array81, i64 144
  %6 = getelementptr inbounds nuw i8, ptr %key_array81, i64 168
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %8 = getelementptr inbounds nuw i8, ptr %key_array81, i64 40
  %9 = getelementptr inbounds nuw i8, ptr %key_array81, i64 176
  %10 = getelementptr inbounds nuw i8, ptr %2, i64 28
  %11 = getelementptr inbounds nuw i8, ptr %key_array81, i64 88
  %12 = getelementptr inbounds nuw i8, ptr %key_array81, i64 96
  %13 = getelementptr inbounds nuw i8, ptr %key_array81, i64 16
  %14 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %15 = getelementptr inbounds nuw i8, ptr %key_array81, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %key_array81, i64 136
  %17 = getelementptr inbounds nuw i8, ptr %key_array81, i64 8
  %18 = getelementptr inbounds nuw i8, ptr %key_array81, i64 192
  %19 = getelementptr inbounds nuw i8, ptr %key_array81, i64 184
  %20 = getelementptr inbounds nuw i8, ptr %key_array81, i64 32
  %21 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %22 = getelementptr inbounds nuw i8, ptr %key_array81, i64 48
  %23 = and i32 %0, 7
  %24 = getelementptr inbounds nuw i8, ptr %key_array81, i64 24
  %25 = getelementptr inbounds nuw i8, ptr %key_array81, i64 104
  %26 = getelementptr inbounds nuw i8, ptr %key_array81, i64 160
  %27 = getelementptr inbounds nuw i8, ptr %key_array81, i64 152
  %28 = getelementptr inbounds nuw i8, ptr %key_array81, i64 112
  %29 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %30 = getelementptr inbounds nuw i8, ptr %key_array81, i64 80
  %31 = getelementptr inbounds nuw i8, ptr %2, i64 20
  %32 = getelementptr inbounds nuw i8, ptr %key_array81, i64 72
  %33 = icmp eq i32 %23, 1
  %dispatch_id28 = select i1 %33, i64 -3603961672227446277, i64 4285567754093453671
  %34 = icmp eq i32 %23, 4
  %dispatch_id34 = select i1 %34, i64 3778183070382751874, i64 7493891934716822146
  %35 = icmp eq i32 %23, 5
  %dispatch_id36 = select i1 %35, i64 -8122204175303672963, i64 4158973855851306028
  %36 = icmp eq i32 %23, 0
  %dispatch_id26 = select i1 %36, i64 9165582759542409542, i64 830461956579870483
  %37 = icmp eq i32 %23, 6
  %dispatch_id38 = select i1 %37, i64 -4684844550872811773, i64 -7962824893779564853
  %38 = icmp eq i32 %23, 3
  %dispatch_id32 = select i1 %38, i64 -2386664559772800245, i64 6105982859087510231
  %39 = icmp eq i32 %23, 2
  %dispatch_id30 = select i1 %39, i64 462403592185854490, i64 -8092893297650275940
  br label %bb.dispatcher

bb.dispatcher:                                    ; preds = %bb.dispatcher.backedge, %1
  %.079 = phi i32 [ 0, %1 ], [ %.079.be, %bb.dispatcher.backedge ]
  %.0 = phi i32 [ 0, %1 ], [ %.0.be, %bb.dispatcher.backedge ]
  %dispatch_id.0 = phi i64 [ -5242269815650585878, %1 ], [ %dispatch_id.0.be, %bb.dispatcher.backedge ]
  switch i64 %dispatch_id.0, label %bb.dispatcher.default [
    i64 -5242269815650585878, label %40
    i64 -4961014976247792641, label %84
    i64 -2358414999127623248, label %89
    i64 8651219903076634936, label %108
    i64 6937093628655944696, label %105
    i64 5878150715960406495, label %lower_switch_branch2
    i64 -9177974394584661448, label %lower_switch_branch3
    i64 -2830743305999779079, label %102
    i64 7348479595413256988, label %58
    i64 683356491559129534, label %70
    i64 2063618581952874560, label %60
    i64 997945150932540590, label %lower_switch_branch6
    i64 -1096784509822048136, label %lower_switch_branch7
    i64 450195310375521109, label %43
    i64 -4943822537245750343, label %lower_switch_branch
    i64 8132570937993300199, label %79
    i64 -1576400206124696519, label %55
    i64 -1365450622054605149, label %99
    i64 -6725576470392050961, label %94
    i64 2543927205641620199, label %lower_switch_branch5
    i64 -6406898029149916861, label %65
    i64 -6094861484299126517, label %lower_switch_branch4
    i64 7500646635884594709, label %lower_switch_branch1
    i64 2393278307464472791, label %74
  ]

bb.dispatcher.default:                            ; preds = %bb.dispatcher
  unreachable

40:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @0, i32 24, ptr %key_array81, i64 -2830743305999779079, ptr %visited80, i32 0) #5
  %41 = icmp slt i32 %.0, 8
  %42 = load i64, ptr %key_array81, align 8
  %dispatch_id9 = select i1 %41, i64 450195310375521109, i64 7348479595413256988
  %dispatch_id10 = xor i64 %42, %dispatch_id9
  br label %bb.dispatcher.backedge

bb.dispatcher.backedge:                           ; preds = %40, %43, %55, %58, %60, %65, %70, %74, %79, %84, %89, %94, %99, %102, %105, %lower_switch_branch, %lower_switch_branch1, %lower_switch_branch2, %lower_switch_branch3, %lower_switch_branch4, %lower_switch_branch5, %lower_switch_branch6, %lower_switch_branch7
  %.079.be = phi i32 [ %77, %74 ], [ %.079, %lower_switch_branch1 ], [ %.079, %lower_switch_branch4 ], [ %68, %65 ], [ %.079, %lower_switch_branch5 ], [ %97, %94 ], [ %.079, %99 ], [ %.079, %55 ], [ %82, %79 ], [ %.079, %lower_switch_branch ], [ %53, %43 ], [ %.079, %lower_switch_branch7 ], [ %.079, %lower_switch_branch6 ], [ %63, %60 ], [ %72, %70 ], [ %.079, %58 ], [ %103, %102 ], [ %.079, %lower_switch_branch3 ], [ %.079, %lower_switch_branch2 ], [ %106, %105 ], [ %92, %89 ], [ %87, %84 ], [ %.079, %40 ]
  %.0.be = phi i32 [ %.0, %74 ], [ %.0, %lower_switch_branch1 ], [ %.0, %lower_switch_branch4 ], [ %.0, %65 ], [ %.0, %lower_switch_branch5 ], [ %.0, %94 ], [ %.0, %99 ], [ %56, %55 ], [ %.0, %79 ], [ %.0, %lower_switch_branch ], [ %.0, %43 ], [ %.0, %lower_switch_branch7 ], [ %.0, %lower_switch_branch6 ], [ %.0, %60 ], [ %.0, %70 ], [ %.0, %58 ], [ %.0, %102 ], [ %.0, %lower_switch_branch3 ], [ %.0, %lower_switch_branch2 ], [ %.0, %105 ], [ %.0, %89 ], [ %.0, %84 ], [ %.0, %40 ]
  %dispatch_id.0.be = phi i64 [ %dispatch_id17, %74 ], [ %dispatch_id29, %lower_switch_branch1 ], [ %dispatch_id35, %lower_switch_branch4 ], [ %dispatch_id15, %65 ], [ %dispatch_id37, %lower_switch_branch5 ], [ %dispatch_id21, %94 ], [ %dispatch_id23, %99 ], [ %dispatch_id12, %55 ], [ %dispatch_id18, %79 ], [ %dispatch_id27, %lower_switch_branch ], [ %dispatch_id11, %43 ], [ %dispatch_id40, %lower_switch_branch7 ], [ %dispatch_id39, %lower_switch_branch6 ], [ %dispatch_id14, %60 ], [ %dispatch_id16, %70 ], [ %dispatch_id13, %58 ], [ %dispatch_id24, %102 ], [ %dispatch_id33, %lower_switch_branch3 ], [ %dispatch_id31, %lower_switch_branch2 ], [ %dispatch_id25, %105 ], [ %dispatch_id20, %89 ], [ %dispatch_id19, %84 ], [ %dispatch_id10, %40 ]
  br label %bb.dispatcher

43:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @1, i32 2, ptr %key_array81, i64 -6094861484299126517, ptr %visited80, i32 1) #5
  %44 = mul nsw i32 %.0, 3
  %45 = add nsw i32 %44, %0
  %46 = load volatile i32, ptr @amice_sink, align 4
  %47 = add nsw i32 %45, %46
  %48 = sext i32 %.0 to i64
  %49 = getelementptr inbounds [8 x i32], ptr %2, i64 0, i64 %48
  store i32 %47, ptr %49, align 4
  %50 = and i32 %.0, 3
  %51 = shl i32 %0, %50
  %52 = xor i32 %47, %51
  %53 = add nsw i32 %52, %.079
  %54 = load i64, ptr %17, align 8
  %dispatch_id11 = xor i64 %54, 3650358449302456000
  br label %bb.dispatcher.backedge

55:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @2, i32 1, ptr %key_array81, i64 8651219903076634936, ptr %visited80, i32 2) #5
  %56 = add nsw i32 %.0, 1
  %57 = load i64, ptr %13, align 8
  %dispatch_id12 = xor i64 %57, -4259796860143242984
  br label %bb.dispatcher.backedge

58:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @3, i32 21, ptr %key_array81, i64 -4961014976247792641, ptr %visited80, i32 3) #5
  %59 = load i64, ptr %24, align 8
  %dispatch_id13 = xor i64 %59, 7193144081994019136
  br label %bb.dispatcher.backedge

60:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @4, i32 1, ptr %key_array81, i64 997945150932540590, ptr %visited80, i32 4) #5
  %61 = load i32, ptr %2, align 4
  %62 = mul nsw i32 %61, 17
  %63 = add nsw i32 %62, %.079
  %64 = load i64, ptr %20, align 8
  %dispatch_id14 = xor i64 %64, -8653959012879593957
  br label %bb.dispatcher.backedge

65:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @5, i32 1, ptr %key_array81, i64 5878150715960406495, ptr %visited80, i32 5) #5
  %66 = load i32, ptr %7, align 4
  %67 = add nsw i32 %66, 29
  %68 = xor i32 %67, %.079
  %69 = load i64, ptr %8, align 8
  %dispatch_id15 = xor i64 %69, -2153286445382126329
  br label %bb.dispatcher.backedge

70:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @6, i32 1, ptr %key_array81, i64 -9177974394584661448, ptr %visited80, i32 6) #5
  %71 = load i32, ptr %21, align 4
  %.neg = mul i32 %71, -31
  %72 = add i32 %.neg, %.079
  %73 = load i64, ptr %22, align 8
  %dispatch_id16 = xor i64 %73, 1358553467717836159
  br label %bb.dispatcher.backedge

74:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @7, i32 1, ptr %key_array81, i64 -1365450622054605149, ptr %visited80, i32 7) #5
  %75 = load i32, ptr %3, align 4
  %76 = xor i32 %75, 68
  %77 = add nsw i32 %76, %.079
  %78 = load i64, ptr %4, align 8
  %dispatch_id17 = xor i64 %78, -6215373519743101242
  br label %bb.dispatcher.backedge

79:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @8, i32 1, ptr %key_array81, i64 -1576400206124696519, ptr %visited80, i32 8) #5
  %80 = load i32, ptr %14, align 4
  %81 = mul nsw i32 %80, 5
  %82 = xor i32 %81, %.079
  %83 = load i64, ptr %15, align 8
  %dispatch_id18 = xor i64 %83, -2782594992662225375
  br label %bb.dispatcher.backedge

84:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @9, i32 1, ptr %key_array81, i64 2063618581952874560, ptr %visited80, i32 9) #5
  %85 = load i32, ptr %31, align 4
  %86 = add i32 %.079, -97
  %87 = add i32 %86, %85
  %88 = load i64, ptr %32, align 8
  %dispatch_id19 = xor i64 %88, -8307490555653320688
  br label %bb.dispatcher.backedge

89:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @10, i32 1, ptr %key_array81, i64 2543927205641620199, ptr %visited80, i32 10) #5
  %90 = load i32, ptr %29, align 4
  %91 = xor i32 %90, 4660
  %92 = sub nsw i32 %.079, %91
  %93 = load i64, ptr %30, align 8
  %dispatch_id20 = xor i64 %93, -1971878194390870523
  br label %bb.dispatcher.backedge

94:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @11, i32 1, ptr %key_array81, i64 -2358414999127623248, ptr %visited80, i32 11) #5
  %95 = load i32, ptr %10, align 4
  %96 = add i32 %.079, 123
  %97 = add i32 %96, %95
  %98 = load i64, ptr %11, align 8
  %dispatch_id21 = xor i64 %98, -4209499190298984750
  br label %bb.dispatcher.backedge

99:                                               ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @12, i32 4, ptr %key_array81, i64 6937093628655944696, ptr %visited80, i32 12) #5
  %100 = and i32 %.079, 1
  %.not = icmp eq i32 %100, 0
  %101 = load i64, ptr %12, align 8
  %dispatch_id22 = select i1 %.not, i64 769981544293274432, i64 -5594268767333012927
  %dispatch_id23 = xor i64 %101, %dispatch_id22
  br label %bb.dispatcher.backedge

102:                                              ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @13, i32 1, ptr %key_array81, i64 -6725576470392050961, ptr %visited80, i32 13) #5
  %103 = tail call i32 @helper_add(i32 noundef %.079, i32 noundef %0)
  %104 = load i64, ptr %25, align 8
  %dispatch_id24 = xor i64 %104, 8259822206857052792
  br label %bb.dispatcher.backedge

105:                                              ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @14, i32 1, ptr %key_array81, i64 -5242269815650585878, ptr %visited80, i32 14) #5
  %106 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.079)
  %107 = load i64, ptr %28, align 8
  %dispatch_id25 = xor i64 %107, 8259822206857052792
  br label %bb.dispatcher.backedge

108:                                              ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @15, i32 1, ptr %key_array81, i64 450195310375521109, ptr %visited80, i32 15) #5
  %109 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %110 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.079)
  %111 = add nsw i32 %110, %.079
  %112 = tail call i32 @vm_target(i32 noundef %0)
  %113 = add nsw i32 %111, %112
  ret i32 %113

lower_switch_branch:                              ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @16, i32 20, ptr %key_array81, i64 683356491559129534, ptr %visited80, i32 17) #5
  %114 = load i64, ptr %16, align 8
  %dispatch_id27 = xor i64 %114, %dispatch_id26
  br label %bb.dispatcher.backedge

lower_switch_branch1:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @17, i32 14, ptr %key_array81, i64 7348479595413256988, ptr %visited80, i32 18) #5
  %115 = load i64, ptr %5, align 8
  %dispatch_id29 = xor i64 %115, %dispatch_id28
  br label %bb.dispatcher.backedge

lower_switch_branch2:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @18, i32 12, ptr %key_array81, i64 -1096784509822048136, ptr %visited80, i32 19) #5
  %116 = load i64, ptr %27, align 8
  %dispatch_id31 = xor i64 %116, %dispatch_id30
  br label %bb.dispatcher.backedge

lower_switch_branch3:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @19, i32 10, ptr %key_array81, i64 -4943822537245750343, ptr %visited80, i32 20) #5
  %117 = load i64, ptr %26, align 8
  %dispatch_id33 = xor i64 %117, %dispatch_id32
  br label %bb.dispatcher.backedge

lower_switch_branch4:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @20, i32 8, ptr %key_array81, i64 8132570937993300199, ptr %visited80, i32 21) #5
  %118 = load i64, ptr %6, align 8
  %dispatch_id35 = xor i64 %118, %dispatch_id34
  br label %bb.dispatcher.backedge

lower_switch_branch5:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @21, i32 6, ptr %key_array81, i64 6185660836888530481, ptr %visited80, i32 22) #5
  %119 = load i64, ptr %9, align 8
  %dispatch_id37 = xor i64 %119, %dispatch_id36
  br label %bb.dispatcher.backedge

lower_switch_branch6:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @22, i32 4, ptr %key_array81, i64 7500646635884594709, ptr %visited80, i32 23) #5
  %120 = load i64, ptr %19, align 8
  %dispatch_id39 = xor i64 %120, %dispatch_id38
  br label %bb.dispatcher.backedge

lower_switch_branch7:                             ; preds = %bb.dispatcher
  call fastcc void @.amice.flatten_dominator.update_key_arr(ptr nonnull @23, i32 2, ptr %key_array81, i64 2393278307464472791, ptr %visited80, i32 24) #5
  %121 = load i64, ptr %18, align 8
  %dispatch_id40 = xor i64 %121, -6122792078282235319
  br label %bb.dispatcher.backedge
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc void @.amice.flatten_dominator.update_key_arr(ptr nocapture readonly %0, i32 range(i32 1, 25) %1, ptr nocapture nonnull %2, i64 range(i64 -6725576470392050961, -9177974394584661447) %3, ptr nocapture nonnull %4, i32 range(i32 0, 25) %5) unnamed_addr #3 {
update_fn.entry:
  %6 = zext nneg i32 %5 to i64
  %7 = getelementptr inbounds nuw i8, ptr %4, i64 %6
  %visited = load i8, ptr %7, align 1
  %visited_cond = icmp eq i8 %visited, 0
  br i1 %visited_cond, label %update_fn.for.body.preheader, label %update_fn.ret

update_fn.for.body.preheader:                     ; preds = %update_fn.entry
  %wide.trip.count = zext nneg i32 %1 to i64
  br label %update_fn.for.body

update_fn.for.body:                               ; preds = %update_fn.for.body.preheader, %update_fn.for.body
  %indvars.iv = phi i64 [ 0, %update_fn.for.body.preheader ], [ %indvars.iv.next, %update_fn.for.body ]
  %8 = getelementptr inbounds nuw i32, ptr %0, i64 %indvars.iv
  %dom_block_index = load i32, ptr %8, align 4
  %9 = sext i32 %dom_block_index to i64
  %10 = getelementptr inbounds i64, ptr %2, i64 %9
  %dom_key_val = load i64, ptr %10, align 8
  %updated_key = xor i64 %dom_key_val, %3
  store i64 %updated_key, ptr %10, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %update_fn.for.end, label %update_fn.for.body

update_fn.for.end:                                ; preds = %update_fn.for.body
  store i8 1, ptr %7, align 1
  br label %update_fn.ret

update_fn.ret:                                    ; preds = %update_fn.for.end, %update_fn.entry
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr nocapture writeonly, i8, i32, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #3 = { nofree noinline norecurse nosync nounwind memory(argmem: readwrite) }
attributes #4 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
