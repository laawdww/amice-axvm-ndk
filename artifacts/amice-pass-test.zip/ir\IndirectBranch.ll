; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@global_indirect_branch_table = internal constant [16 x ptr] [ptr blockaddress(@branch_switch_array, %64), ptr blockaddress(@branch_switch_array, %31), ptr blockaddress(@branch_switch_array, %14), ptr blockaddress(@branch_switch_array, %20), ptr blockaddress(@branch_switch_array, %45), ptr blockaddress(@branch_switch_array, %60), ptr blockaddress(@branch_switch_array, %35), ptr blockaddress(@branch_switch_array, %26), ptr blockaddress(@branch_switch_array, %66), ptr blockaddress(@branch_switch_array, %22), ptr blockaddress(@branch_switch_array, %55), ptr blockaddress(@branch_switch_array, %40), ptr blockaddress(@branch_switch_array, %68), ptr blockaddress(@branch_switch_array, %7), ptr blockaddress(@branch_switch_array, %50), ptr blockaddress(@branch_switch_array, %3)]
@.amice.indirect_branch_key = private constant [4 x i32] [i32 -2078137387, i32 -1361358125, i32 2142432313, i32 -2020918039]
@.amice.indirect_branch = private constant [2 x ptr] [ptr blockaddress(@branch_switch_array, %20), ptr blockaddress(@branch_switch_array, %7)]
@.amice.indirect_branch.1 = private constant [2 x ptr] [ptr blockaddress(@branch_switch_array, %66), ptr blockaddress(@branch_switch_array, %64)]
@llvm.compiler.used = appending global [4 x ptr] [ptr @.amice.indirect_branch, ptr @.amice.indirect_branch.1, ptr @.amice.indirect_branch_key, ptr @global_indirect_branch_table], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) #1 {
  %2 = alloca [8 x i32], align 4
  br label %3

3:                                                ; preds = %14, %1
  %indvars.iv = phi i64 [ %indvars.iv.next, %14 ], [ 0, %1 ]
  %.066 = phi i32 [ %19, %14 ], [ 0, %1 ]
  %4 = icmp samesign ult i64 %indvars.iv, 8
  %5 = zext i1 %4 to i64
  %6 = getelementptr inbounds nuw [2 x ptr], ptr @.amice.indirect_branch, i64 0, i64 %5
  %IndirectBranchingTargetAddress2 = load ptr, ptr %6, align 8
  indirectbr ptr %IndirectBranchingTargetAddress2, [label %20, label %7]

7:                                                ; preds = %3
  %8 = trunc i64 %indvars.iv to i32
  %9 = mul i32 %8, 3
  %10 = add nsw i32 %9, %0
  %11 = load volatile i32, ptr @amice_sink, align 4
  %12 = add nsw i32 %10, %11
  %13 = getelementptr inbounds nuw [8 x i32], ptr %2, i64 0, i64 %indvars.iv
  store i32 %12, ptr %13, align 4
  br label %14

14:                                               ; preds = %7
  %15 = trunc nuw nsw i64 %indvars.iv to i32
  %16 = and i32 %15, 3
  %17 = shl i32 %0, %16
  %18 = xor i32 %12, %17
  %19 = add nsw i32 %18, %.066
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  br label %3

20:                                               ; preds = %3
  %21 = and i32 %0, 7
  switch i32 %21, label %default.unreachable68 [
    i32 0, label %22
    i32 1, label %26
    i32 2, label %31
    i32 3, label %35
    i32 4, label %40
    i32 5, label %45
    i32 6, label %50
    i32 7, label %55
  ]

22:                                               ; preds = %20
  %23 = load i32, ptr %2, align 4
  %24 = mul nsw i32 %23, 17
  %25 = add nsw i32 %24, %.066
  br label %60

26:                                               ; preds = %20
  %27 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %28 = load i32, ptr %27, align 4
  %29 = add nsw i32 %28, 29
  %30 = xor i32 %29, %.066
  br label %60

31:                                               ; preds = %20
  %32 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %33 = load i32, ptr %32, align 4
  %.neg = mul i32 %33, -31
  %34 = add i32 %.neg, %.066
  br label %60

35:                                               ; preds = %20
  %36 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %37 = load i32, ptr %36, align 4
  %38 = xor i32 %37, 68
  %39 = add nsw i32 %38, %.066
  br label %60

40:                                               ; preds = %20
  %41 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = mul nsw i32 %42, 5
  %44 = xor i32 %43, %.066
  br label %60

45:                                               ; preds = %20
  %46 = getelementptr inbounds nuw i8, ptr %2, i64 20
  %47 = load i32, ptr %46, align 4
  %48 = add i32 %.066, -97
  %49 = add i32 %48, %47
  br label %60

50:                                               ; preds = %20
  %51 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %52 = load i32, ptr %51, align 4
  %53 = xor i32 %52, 4660
  %54 = sub nsw i32 %.066, %53
  br label %60

default.unreachable68:                            ; preds = %20
  unreachable

55:                                               ; preds = %20
  %56 = getelementptr inbounds nuw i8, ptr %2, i64 28
  %57 = load i32, ptr %56, align 4
  %58 = add i32 %.066, 123
  %59 = add i32 %58, %57
  br label %60

60:                                               ; preds = %55, %50, %45, %40, %35, %31, %26, %22
  %.1 = phi i32 [ %59, %55 ], [ %54, %50 ], [ %49, %45 ], [ %44, %40 ], [ %39, %35 ], [ %34, %31 ], [ %30, %26 ], [ %25, %22 ]
  %61 = and i32 %.1, 1
  %62 = zext nneg i32 %61 to i64
  %63 = getelementptr inbounds nuw [2 x ptr], ptr @.amice.indirect_branch.1, i64 0, i64 %62
  %IndirectBranchingTargetAddress33 = load ptr, ptr %63, align 8
  indirectbr ptr %IndirectBranchingTargetAddress33, [label %66, label %64]

64:                                               ; preds = %60
  %65 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %68

66:                                               ; preds = %60
  %67 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %68

68:                                               ; preds = %66, %64
  %.2 = phi i32 [ %67, %66 ], [ %65, %64 ]
  %69 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %70 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %71 = add nsw i32 %70, %.2
  %72 = tail call i32 @vm_target(i32 noundef %0)
  %73 = add nsw i32 %71, %72
  ret i32 %73
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
