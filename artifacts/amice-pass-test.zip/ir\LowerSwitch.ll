; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
lower_switch_branch:
  %1 = load volatile i32, ptr @amice_sink, align 4
  %2 = add nsw i32 %0, %1
  %3 = xor i32 %2, %0
  %4 = add i32 %0, 3
  %5 = load volatile i32, ptr @amice_sink, align 4
  %6 = add nsw i32 %4, %5
  %7 = shl i32 %0, 1
  %8 = xor i32 %6, %7
  %9 = add nsw i32 %8, %3
  %10 = add i32 %0, 6
  %11 = load volatile i32, ptr @amice_sink, align 4
  %12 = add nsw i32 %10, %11
  %13 = shl i32 %0, 2
  %14 = xor i32 %12, %13
  %15 = add nsw i32 %14, %9
  %16 = add i32 %0, 9
  %17 = load volatile i32, ptr @amice_sink, align 4
  %18 = add nsw i32 %16, %17
  %19 = shl i32 %0, 3
  %20 = xor i32 %18, %19
  %21 = add nsw i32 %20, %15
  %22 = add i32 %0, 12
  %23 = load volatile i32, ptr @amice_sink, align 4
  %24 = add nsw i32 %22, %23
  %25 = xor i32 %24, %0
  %26 = add nsw i32 %25, %21
  %27 = add i32 %0, 15
  %28 = load volatile i32, ptr @amice_sink, align 4
  %29 = add nsw i32 %27, %28
  %30 = shl i32 %0, 1
  %31 = xor i32 %29, %30
  %32 = add nsw i32 %31, %26
  %33 = add i32 %0, 18
  %34 = load volatile i32, ptr @amice_sink, align 4
  %35 = add nsw i32 %33, %34
  %36 = shl i32 %0, 2
  %37 = xor i32 %35, %36
  %38 = add nsw i32 %37, %32
  %39 = add i32 %0, 21
  %40 = load volatile i32, ptr @amice_sink, align 4
  %41 = add nsw i32 %39, %40
  %42 = shl i32 %0, 3
  %43 = xor i32 %41, %42
  %44 = add nsw i32 %43, %38
  %45 = and i32 %0, 7
  switch i32 %45, label %default.unreachable38 [
    i32 0, label %46
    i32 1, label %49
    i32 2, label %52
    i32 3, label %54
    i32 4, label %57
    i32 5, label %60
    i32 6, label %63
    i32 7, label %lower_switch_branch7
  ]

46:                                               ; preds = %lower_switch_branch
  %47 = mul nsw i32 %2, 17
  %48 = add nsw i32 %47, %44
  br label %66

49:                                               ; preds = %lower_switch_branch
  %50 = add nsw i32 %6, 29
  %51 = xor i32 %50, %44
  br label %66

52:                                               ; preds = %lower_switch_branch
  %.neg = mul i32 %12, -31
  %53 = add i32 %.neg, %44
  br label %66

54:                                               ; preds = %lower_switch_branch
  %55 = xor i32 %18, 68
  %56 = add nsw i32 %55, %44
  br label %66

57:                                               ; preds = %lower_switch_branch
  %58 = mul nsw i32 %24, 5
  %59 = xor i32 %58, %44
  br label %66

60:                                               ; preds = %lower_switch_branch
  %61 = add i32 %44, -97
  %62 = add i32 %61, %29
  br label %66

63:                                               ; preds = %lower_switch_branch
  %64 = xor i32 %35, 4660
  %65 = sub nsw i32 %44, %64
  br label %66

66:                                               ; preds = %lower_switch_branch7, %63, %60, %57, %54, %52, %49, %46
  %.1 = phi i32 [ %79, %lower_switch_branch7 ], [ %65, %63 ], [ %62, %60 ], [ %59, %57 ], [ %56, %54 ], [ %53, %52 ], [ %51, %49 ], [ %48, %46 ]
  %67 = and i32 %.1, 1
  %.not = icmp eq i32 %67, 0
  br i1 %.not, label %70, label %68

68:                                               ; preds = %66
  %69 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %72

70:                                               ; preds = %66
  %71 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %72

72:                                               ; preds = %70, %68
  %.2 = phi i32 [ %69, %68 ], [ %71, %70 ]
  %73 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %74 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %75 = add nsw i32 %74, %.2
  %76 = tail call i32 @vm_target(i32 noundef %0)
  %77 = add nsw i32 %75, %76
  ret i32 %77

default.unreachable38:                            ; preds = %lower_switch_branch
  unreachable

lower_switch_branch7:                             ; preds = %lower_switch_branch
  %78 = add i32 %44, 123
  %79 = add i32 %78, %41
  br label %66
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
