; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
.split_0:
  %2 = add nsw i32 %1, %0
  br label %.split_02

.split_02:                                        ; preds = %.split_0
  %3 = xor i32 %2, 324508639
  ret i32 %3
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
.split_0:
  %2 = mul nsw i32 %0, 3
  br label %.split_02

.split_02:                                        ; preds = %.split_0
  %.neg = mul i32 %1, -5
  br label %.split_1

.split_1:                                         ; preds = %.split_02
  %3 = add i32 %2, 11
  %4 = add i32 %3, %.neg
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
.split_0:
  %1 = mul nsw i32 %0, 7
  %2 = xor i32 %1, 85
  %3 = and i32 %0, 3
  br label %.split_05

.split_05:                                        ; preds = %.split_0
  %reass.sub = sub i32 %2, %3
  br label %.split_1

.split_1:                                         ; preds = %.split_05
  %4 = add i32 %reass.sub, 13
  ret i32 %4
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
.split_0:
  %1 = load volatile i32, ptr @amice_sink, align 4
  %2 = add nsw i32 %0, %1
  %3 = xor i32 %2, %0
  %4 = add i32 %0, 3
  %5 = load volatile i32, ptr @amice_sink, align 4
  %6 = add nsw i32 %4, %5
  %7 = shl i32 %0, 1
  %8 = xor i32 %6, %7
  %9 = add nsw i32 %8, %3
  %10 = add i32 %0, 6
  %11 = load volatile i32, ptr @amice_sink, align 4
  %12 = add nsw i32 %10, %11
  %13 = shl i32 %0, 2
  %14 = xor i32 %12, %13
  %15 = add nsw i32 %14, %9
  %16 = add i32 %0, 9
  %17 = load volatile i32, ptr @amice_sink, align 4
  %18 = add nsw i32 %16, %17
  %19 = shl i32 %0, 3
  %20 = xor i32 %18, %19
  %21 = add nsw i32 %20, %15
  %22 = add i32 %0, 12
  %23 = load volatile i32, ptr @amice_sink, align 4
  %24 = add nsw i32 %22, %23
  %25 = xor i32 %24, %0
  %26 = add nsw i32 %25, %21
  %27 = add i32 %0, 15
  %28 = load volatile i32, ptr @amice_sink, align 4
  %29 = add nsw i32 %27, %28
  %30 = shl i32 %0, 1
  %31 = xor i32 %29, %30
  %32 = add nsw i32 %31, %26
  %33 = add i32 %0, 18
  %34 = load volatile i32, ptr @amice_sink, align 4
  %35 = add nsw i32 %33, %34
  %36 = shl i32 %0, 2
  %37 = xor i32 %35, %36
  %38 = add nsw i32 %37, %32
  %39 = add i32 %0, 21
  %40 = load volatile i32, ptr @amice_sink, align 4
  %41 = add nsw i32 %39, %40
  %42 = shl i32 %0, 3
  %43 = xor i32 %41, %42
  %44 = add nsw i32 %43, %38
  %45 = and i32 %0, 7
  switch i32 %45, label %default.unreachable60 [
    i32 0, label %.split_06
    i32 1, label %.split_08
    i32 2, label %.split_010
    i32 3, label %.split_012
    i32 4, label %.split_014
    i32 5, label %.split_016
    i32 6, label %.split_018
    i32 7, label %.split_020
  ]

.split_06:                                        ; preds = %.split_0
  %46 = mul nsw i32 %2, 17
  br label %.split_061

.split_061:                                       ; preds = %.split_06
  %47 = add nsw i32 %46, %44
  br label %.split_022

.split_08:                                        ; preds = %.split_0
  %48 = add nsw i32 %6, 29
  br label %.split_062

.split_062:                                       ; preds = %.split_08
  %49 = xor i32 %48, %44
  br label %.split_022

.split_010:                                       ; preds = %.split_0
  %.neg = mul i32 %12, -31
  br label %.split_063

.split_063:                                       ; preds = %.split_010
  %50 = add i32 %.neg, %44
  br label %.split_022

.split_012:                                       ; preds = %.split_0
  %51 = xor i32 %18, 68
  br label %.split_064

.split_064:                                       ; preds = %.split_012
  %52 = add nsw i32 %51, %44
  br label %.split_022

.split_014:                                       ; preds = %.split_0
  %53 = mul nsw i32 %24, 5
  br label %.split_065

.split_065:                                       ; preds = %.split_014
  %54 = xor i32 %53, %44
  br label %.split_022

.split_016:                                       ; preds = %.split_0
  %55 = add i32 %44, -97
  br label %.split_066

.split_066:                                       ; preds = %.split_016
  %56 = add i32 %55, %29
  br label %.split_022

.split_018:                                       ; preds = %.split_0
  %57 = xor i32 %35, 4660
  br label %.split_067

.split_067:                                       ; preds = %.split_018
  %58 = sub nsw i32 %44, %57
  br label %.split_022

default.unreachable60:                            ; preds = %.split_0
  unreachable

.split_020:                                       ; preds = %.split_0
  %59 = add i32 %44, 123
  br label %.split_068

.split_068:                                       ; preds = %.split_020
  %60 = add i32 %59, %41
  br label %.split_022

.split_022:                                       ; preds = %.split_068, %.split_067, %.split_066, %.split_065, %.split_064, %.split_063, %.split_062, %.split_061
  %.1 = phi i32 [ %60, %.split_068 ], [ %58, %.split_067 ], [ %56, %.split_066 ], [ %54, %.split_065 ], [ %52, %.split_064 ], [ %50, %.split_063 ], [ %49, %.split_062 ], [ %47, %.split_061 ]
  %61 = and i32 %.1, 1
  %.not = icmp eq i32 %61, 0
  br i1 %.not, label %.split_026, label %.split_024

.split_024:                                       ; preds = %.split_022
  %62 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %.split_028

.split_026:                                       ; preds = %.split_022
  %63 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %.split_028

.split_028:                                       ; preds = %.split_026, %.split_024
  %.2 = phi i32 [ %62, %.split_024 ], [ %63, %.split_026 ]
  %64 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %65 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %66 = add nsw i32 %65, %.2
  %67 = tail call i32 @vm_target(i32 noundef %0)
  %68 = add nsw i32 %66, %67
  ret i32 %68
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
.split_0:
  %1 = tail call i32 @branch_switch_array(i32 noundef %0)
  br label %.split_02

.split_02:                                        ; preds = %.split_0
  %2 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  br label %.split_1

.split_1:                                         ; preds = %.split_02
  %3 = add nsw i32 %2, %1
  ret i32 %3
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
