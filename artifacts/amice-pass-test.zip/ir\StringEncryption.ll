; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr global [38 x i8] c"\EB\E7\E3\E9\EF\F5\EB\E6\E6\F5\FA\EB\F9\F9\F5\F9\FE\F8\E3\E4\ED\F5\E7\EB\F8\E1\EF\F8\F5\98\9A\98\9C\9A\9D\9A\93\AA", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@dec_flag_.str = internal global i32 0

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
  %2 = load volatile i32, ptr @amice_sink, align 4
  %3 = add nsw i32 %0, %2
  %4 = xor i32 %3, %0
  %5 = add i32 %0, 3
  %6 = load volatile i32, ptr @amice_sink, align 4
  %7 = add nsw i32 %5, %6
  %8 = shl i32 %0, 1
  %9 = xor i32 %7, %8
  %10 = add nsw i32 %9, %4
  %11 = add i32 %0, 6
  %12 = load volatile i32, ptr @amice_sink, align 4
  %13 = add nsw i32 %11, %12
  %14 = shl i32 %0, 2
  %15 = xor i32 %13, %14
  %16 = add nsw i32 %15, %10
  %17 = add i32 %0, 9
  %18 = load volatile i32, ptr @amice_sink, align 4
  %19 = add nsw i32 %17, %18
  %20 = shl i32 %0, 3
  %21 = xor i32 %19, %20
  %22 = add nsw i32 %21, %16
  %23 = add i32 %0, 12
  %24 = load volatile i32, ptr @amice_sink, align 4
  %25 = add nsw i32 %23, %24
  %26 = xor i32 %25, %0
  %27 = add nsw i32 %26, %22
  %28 = add i32 %0, 15
  %29 = load volatile i32, ptr @amice_sink, align 4
  %30 = add nsw i32 %28, %29
  %31 = shl i32 %0, 1
  %32 = xor i32 %30, %31
  %33 = add nsw i32 %32, %27
  %34 = add i32 %0, 18
  %35 = load volatile i32, ptr @amice_sink, align 4
  %36 = add nsw i32 %34, %35
  %37 = shl i32 %0, 2
  %38 = xor i32 %36, %37
  %39 = add nsw i32 %38, %33
  %40 = add i32 %0, 21
  %41 = load volatile i32, ptr @amice_sink, align 4
  %42 = add nsw i32 %40, %41
  %43 = shl i32 %0, 3
  %44 = xor i32 %42, %43
  %45 = add nsw i32 %44, %39
  %46 = and i32 %0, 7
  switch i32 %46, label %default.unreachable31 [
    i32 0, label %47
    i32 1, label %50
    i32 2, label %53
    i32 3, label %55
    i32 4, label %58
    i32 5, label %61
    i32 6, label %64
    i32 7, label %67
  ]

47:                                               ; preds = %1
  %48 = mul nsw i32 %3, 17
  %49 = add nsw i32 %48, %45
  br label %70

50:                                               ; preds = %1
  %51 = add nsw i32 %7, 29
  %52 = xor i32 %51, %45
  br label %70

53:                                               ; preds = %1
  %.neg = mul i32 %13, -31
  %54 = add i32 %.neg, %45
  br label %70

55:                                               ; preds = %1
  %56 = xor i32 %19, 68
  %57 = add nsw i32 %56, %45
  br label %70

58:                                               ; preds = %1
  %59 = mul nsw i32 %25, 5
  %60 = xor i32 %59, %45
  br label %70

61:                                               ; preds = %1
  %62 = add i32 %45, -97
  %63 = add i32 %62, %30
  br label %70

64:                                               ; preds = %1
  %65 = xor i32 %36, 4660
  %66 = sub nsw i32 %45, %65
  br label %70

default.unreachable31:                            ; preds = %1
  unreachable

67:                                               ; preds = %1
  %68 = add i32 %45, 123
  %69 = add i32 %68, %42
  br label %70

70:                                               ; preds = %67, %64, %61, %58, %55, %53, %50, %47
  %.1 = phi i32 [ %69, %67 ], [ %66, %64 ], [ %63, %61 ], [ %60, %58 ], [ %57, %55 ], [ %54, %53 ], [ %52, %50 ], [ %49, %47 ]
  %71 = and i32 %.1, 1
  %.not = icmp eq i32 %71, 0
  br i1 %.not, label %74, label %72

72:                                               ; preds = %70
  %73 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %76

74:                                               ; preds = %70
  %75 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %76

76:                                               ; preds = %74, %72
  %.2 = phi i32 [ %73, %72 ], [ %75, %74 ]
  %77 = cmpxchg ptr @dec_flag_.str, i32 0, i32 1 acq_rel acquire, align 4
  %cmpxchg_success.i = extractvalue { i32, i1 } %77, 1
  br i1 %cmpxchg_success.i, label %next.i, label %spin_wait.i

spin_wait.i:                                      ; preds = %76, %spin_wait.i
  %flag_val.i = load atomic i32, ptr @dec_flag_.str acquire, align 4
  %is_complete.i = icmp eq i32 %flag_val.i, 2
  br i1 %is_complete.i, label %__amice__decrypt_strings_1545525505__.exit, label %spin_wait.i

next.i:                                           ; preds = %76, %next.i
  %indvars.iv.i = phi i64 [ %indvars.iv.next.i, %next.i ], [ 0, %76 ]
  %src_gep.i = getelementptr i8, ptr @.str, i64 %indvars.iv.i
  %cur.i = load i8, ptr %src_gep.i, align 1
  %new.i = xor i8 %cur.i, -86
  store i8 %new.i, ptr %src_gep.i, align 1
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1
  %exitcond.not.i = icmp eq i64 %indvars.iv.next.i, 38
  br i1 %exitcond.not.i, label %check_mark_done.i, label %next.i

check_mark_done.i:                                ; preds = %next.i
  store atomic i32 2, ptr @dec_flag_.str release, align 4
  br label %__amice__decrypt_strings_1545525505__.exit

__amice__decrypt_strings_1545525505__.exit:       ; preds = %spin_wait.i, %check_mark_done.i
  %78 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %79 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %80 = add nsw i32 %79, %.2
  %81 = tail call i32 @vm_target(i32 noundef %0)
  %82 = add nsw i32 %80, %81
  ret i32 %82
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
