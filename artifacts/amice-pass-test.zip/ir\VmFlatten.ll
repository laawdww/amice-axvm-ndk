; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@.amice.vm_flatten_opcodes = private global [91 x i32] [i32 1919, i32 -676399213, i32 0, i32 514, i32 6, i32 15, i32 1919, i32 547616849, i32 425697682, i32 1919, i32 -694196193, i32 0, i32 114, i32 0, i32 0, i32 1919, i32 425697682, i32 547616849, i32 810, i32 8, i32 28, i32 49, i32 55, i32 61, i32 67, i32 73, i32 79, i32 85, i32 1919, i32 1294777914, i32 1294777914, i32 1919, i32 -1208062612, i32 0, i32 514, i32 37, i32 43, i32 1919, i32 -488432669, i32 -181837745, i32 1919, i32 1321104728, i32 0, i32 1919, i32 -181837745, i32 -488432669, i32 114, i32 40, i32 0, i32 1919, i32 415464949, i32 415464949, i32 114, i32 31, i32 0, i32 1919, i32 902478929, i32 902478929, i32 114, i32 31, i32 0, i32 1919, i32 1036786743, i32 1036786743, i32 114, i32 31, i32 0, i32 1919, i32 166055859, i32 166055859, i32 114, i32 31, i32 0, i32 1919, i32 1827449080, i32 1827449080, i32 114, i32 31, i32 0, i32 1919, i32 -55502290, i32 -55502290, i32 114, i32 31, i32 0, i32 1919, i32 -1642436477, i32 -1642436477, i32 114, i32 31, i32 0]
@llvm.compiler.used = appending global [1 x ptr] [ptr @.amice.vm_flatten_opcodes], section "llvm.metadata"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add nsw i32 %1, %0
  %4 = xor i32 %3, 324508639
  ret i32 %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = mul nsw i32 %0, 3
  %.neg = mul i32 %1, -5
  %4 = add i32 %3, 11
  %5 = add i32 %4, %.neg
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) local_unnamed_addr #0 {
  %2 = mul nsw i32 %0, 7
  %3 = xor i32 %2, 85
  %4 = and i32 %0, 3
  %reass.sub = sub i32 %3, %4
  %5 = add i32 %reass.sub, 13
  ret i32 %5
}

; Function Attrs: nofree noinline nounwind memory(readwrite) uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #1 {
  %2 = alloca [8 x i32], align 4
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 28
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %5 = getelementptr inbounds nuw i8, ptr %2, i64 20
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %9 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %10 = and i32 %0, 7
  br label %.amice.vm_flatten_entry

.amice.vm_flatten_entry:                          ; preds = %.amice.vm_flatten_entry.backedge, %1
  %.049 = phi i32 [ 0, %1 ], [ %.049.be, %.amice.vm_flatten_entry.backedge ]
  %.0 = phi i32 [ 0, %1 ], [ %.0.be, %.amice.vm_flatten_entry.backedge ]
  %.amice.vm_flatten_br_flag.0 = phi i32 [ 0, %1 ], [ %.amice.vm_flatten_br_flag.0.be, %.amice.vm_flatten_entry.backedge ]
  %.amice.vm_flatten_pc.0 = phi i32 [ 0, %1 ], [ %.amice.vm_flatten_pc.0.be, %.amice.vm_flatten_entry.backedge ]
  %pc_plus_1 = add i32 %.amice.vm_flatten_pc.0, 1
  %11 = sext i32 %.amice.vm_flatten_pc.0 to i64
  %12 = getelementptr inbounds [91 x i32], ptr @.amice.vm_flatten_opcodes, i64 0, i64 %11
  %__op__ = load i32, ptr %12, align 4
  %13 = sext i32 %pc_plus_1 to i64
  %14 = getelementptr inbounds [91 x i32], ptr @.amice.vm_flatten_opcodes, i64 0, i64 %13
  %__left__ = load i32, ptr %14, align 4
  %cond_is_switch = icmp eq i32 %__op__, 810
  %15 = add i32 %__left__, 2
  %plus_value.v = select i1 %cond_is_switch, i32 %15, i32 3
  %plus_value = add i32 %plus_value.v, %.amice.vm_flatten_pc.0
  switch i32 %__op__, label %.amice.vm_flatten_default [
    i32 114, label %.amice.vm_flatten_entry.backedge
    i32 514, label %.amice.vm_flatten_jmp_if
    i32 1919, label %.amice.vm_flatten_run
    i32 810, label %.amice.vm_flatten_switch
  ]

.amice.vm_flatten_run:                            ; preds = %.amice.vm_flatten_entry
  switch i32 %__left__, label %.amice.vm_flatten_default [
    i32 -676399213, label %20
    i32 547616849, label %22
    i32 -694196193, label %33
    i32 425697682, label %35
    i32 415464949, label %36
    i32 902478929, label %40
    i32 1036786743, label %44
    i32 166055859, label %47
    i32 1827449080, label %51
    i32 -55502290, label %55
    i32 -1642436477, label %59
    i32 1294777914, label %63
    i32 -1208062612, label %67
    i32 -488432669, label %69
    i32 -181837745, label %71
    i32 1321104728, label %73
  ]

.amice.vm_flatten_jmp_if:                         ; preds = %.amice.vm_flatten_entry
  %pc_plus_2 = add i32 %.amice.vm_flatten_pc.0, 2
  %16 = sext i32 %pc_plus_2 to i64
  %17 = getelementptr inbounds [91 x i32], ptr @.amice.vm_flatten_opcodes, i64 0, i64 %16
  %__right__ = load i32, ptr %17, align 4
  %jmp_cmp = icmp eq i32 %.amice.vm_flatten_br_flag.0, 1
  %__left__.__right__ = select i1 %jmp_cmp, i32 %__left__, i32 %__right__
  br label %.amice.vm_flatten_entry.backedge

.amice.vm_flatten_switch:                         ; preds = %.amice.vm_flatten_entry
  %offset.neg = sub i32 %.amice.vm_flatten_br_flag.0, %__left__
  %pc_with_offset = add i32 %offset.neg, %plus_value
  %18 = sext i32 %pc_with_offset to i64
  %19 = getelementptr inbounds [91 x i32], ptr @.amice.vm_flatten_opcodes, i64 0, i64 %18
  %__value__ = load i32, ptr %19, align 4
  br label %.amice.vm_flatten_entry.backedge

20:                                               ; preds = %.amice.vm_flatten_run
  %21 = icmp slt i32 %.0, 8
  %_t_or_f_2 = zext i1 %21 to i32
  br label %.amice.vm_flatten_entry.backedge

22:                                               ; preds = %.amice.vm_flatten_run
  %23 = mul nsw i32 %.0, 3
  %24 = add nsw i32 %23, %0
  %25 = load volatile i32, ptr @amice_sink, align 4
  %26 = add nsw i32 %24, %25
  %27 = sext i32 %.0 to i64
  %28 = getelementptr inbounds [8 x i32], ptr %2, i64 0, i64 %27
  store i32 %26, ptr %28, align 4
  %29 = and i32 %.0, 3
  %30 = shl i32 %0, %29
  %31 = xor i32 %26, %30
  %32 = add nsw i32 %31, %.049
  br label %.amice.vm_flatten_entry.backedge

33:                                               ; preds = %.amice.vm_flatten_run
  %34 = add nsw i32 %.0, 1
  br label %.amice.vm_flatten_entry.backedge

35:                                               ; preds = %.amice.vm_flatten_run
  switch i32 %10, label %default.unreachable52 [
    i32 0, label %.vm_switch_case_1
    i32 1, label %.vm_switch_case_2
    i32 2, label %.vm_switch_case_3
    i32 3, label %.vm_switch_case_4
    i32 4, label %.vm_switch_case_5
    i32 5, label %.vm_switch_case_6
    i32 6, label %.vm_switch_case_7
    i32 7, label %.amice.vm_flatten_entry.backedge
  ]

36:                                               ; preds = %.amice.vm_flatten_run
  %37 = load i32, ptr %2, align 4
  %38 = mul nsw i32 %37, 17
  %39 = add nsw i32 %38, %.049
  br label %.amice.vm_flatten_entry.backedge

40:                                               ; preds = %.amice.vm_flatten_run
  %41 = load i32, ptr %9, align 4
  %42 = add nsw i32 %41, 29
  %43 = xor i32 %42, %.049
  br label %.amice.vm_flatten_entry.backedge

44:                                               ; preds = %.amice.vm_flatten_run
  %45 = load i32, ptr %8, align 4
  %.neg = mul i32 %45, -31
  %46 = add i32 %.neg, %.049
  br label %.amice.vm_flatten_entry.backedge

47:                                               ; preds = %.amice.vm_flatten_run
  %48 = load i32, ptr %7, align 4
  %49 = xor i32 %48, 68
  %50 = add nsw i32 %49, %.049
  br label %.amice.vm_flatten_entry.backedge

51:                                               ; preds = %.amice.vm_flatten_run
  %52 = load i32, ptr %6, align 4
  %53 = mul nsw i32 %52, 5
  %54 = xor i32 %53, %.049
  br label %.amice.vm_flatten_entry.backedge

55:                                               ; preds = %.amice.vm_flatten_run
  %56 = load i32, ptr %5, align 4
  %57 = add i32 %.049, -97
  %58 = add i32 %57, %56
  br label %.amice.vm_flatten_entry.backedge

59:                                               ; preds = %.amice.vm_flatten_run
  %60 = load i32, ptr %4, align 4
  %61 = xor i32 %60, 4660
  %62 = sub nsw i32 %.049, %61
  br label %.amice.vm_flatten_entry.backedge

63:                                               ; preds = %.amice.vm_flatten_run
  %64 = load i32, ptr %3, align 4
  %65 = add i32 %.049, 123
  %66 = add i32 %65, %64
  br label %.amice.vm_flatten_entry.backedge

67:                                               ; preds = %.amice.vm_flatten_run
  %68 = and i32 %.049, 1
  br label %.amice.vm_flatten_entry.backedge

69:                                               ; preds = %.amice.vm_flatten_run
  %70 = tail call i32 @helper_add(i32 noundef %.049, i32 noundef %0)
  br label %.amice.vm_flatten_entry.backedge

71:                                               ; preds = %.amice.vm_flatten_run
  %72 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.049)
  br label %.amice.vm_flatten_entry.backedge

73:                                               ; preds = %.amice.vm_flatten_run
  %74 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %75 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.049)
  %76 = add nsw i32 %75, %.049
  %77 = tail call i32 @vm_target(i32 noundef %0)
  %78 = add nsw i32 %76, %77
  ret i32 %78

.amice.vm_flatten_default:                        ; preds = %.amice.vm_flatten_run, %.amice.vm_flatten_entry
  br label %.amice.vm_flatten_entry.backedge

.amice.vm_flatten_entry.backedge:                 ; preds = %.amice.vm_flatten_default, %20, %22, %33, %.vm_switch_case_1, %.vm_switch_case_2, %.vm_switch_case_3, %.vm_switch_case_4, %.vm_switch_case_5, %.vm_switch_case_6, %.vm_switch_case_7, %36, %40, %44, %47, %51, %55, %59, %63, %67, %69, %71, %.amice.vm_flatten_switch, %.amice.vm_flatten_jmp_if, %.amice.vm_flatten_entry, %35
  %.049.be = phi i32 [ %.049, %.amice.vm_flatten_default ], [ %.049, %.amice.vm_flatten_switch ], [ %72, %71 ], [ %70, %69 ], [ %.049, %67 ], [ %66, %63 ], [ %62, %59 ], [ %58, %55 ], [ %54, %51 ], [ %50, %47 ], [ %46, %44 ], [ %43, %40 ], [ %39, %36 ], [ %.049, %.vm_switch_case_7 ], [ %.049, %.vm_switch_case_6 ], [ %.049, %.vm_switch_case_5 ], [ %.049, %.vm_switch_case_4 ], [ %.049, %.vm_switch_case_3 ], [ %.049, %.vm_switch_case_2 ], [ %.049, %.vm_switch_case_1 ], [ %.049, %33 ], [ %32, %22 ], [ %.049, %20 ], [ %.049, %.amice.vm_flatten_jmp_if ], [ %.049, %.amice.vm_flatten_entry ], [ %.049, %35 ]
  %.0.be = phi i32 [ %.0, %.amice.vm_flatten_default ], [ %.0, %.amice.vm_flatten_switch ], [ %.0, %71 ], [ %.0, %69 ], [ %.0, %67 ], [ %.0, %63 ], [ %.0, %59 ], [ %.0, %55 ], [ %.0, %51 ], [ %.0, %47 ], [ %.0, %44 ], [ %.0, %40 ], [ %.0, %36 ], [ %.0, %.vm_switch_case_7 ], [ %.0, %.vm_switch_case_6 ], [ %.0, %.vm_switch_case_5 ], [ %.0, %.vm_switch_case_4 ], [ %.0, %.vm_switch_case_3 ], [ %.0, %.vm_switch_case_2 ], [ %.0, %.vm_switch_case_1 ], [ %34, %33 ], [ %.0, %22 ], [ %.0, %20 ], [ %.0, %.amice.vm_flatten_jmp_if ], [ %.0, %.amice.vm_flatten_entry ], [ %.0, %35 ]
  %.amice.vm_flatten_br_flag.0.be = phi i32 [ %.amice.vm_flatten_br_flag.0, %.amice.vm_flatten_default ], [ %.amice.vm_flatten_br_flag.0, %.amice.vm_flatten_switch ], [ %.amice.vm_flatten_br_flag.0, %71 ], [ %.amice.vm_flatten_br_flag.0, %69 ], [ %68, %67 ], [ %.amice.vm_flatten_br_flag.0, %63 ], [ %.amice.vm_flatten_br_flag.0, %59 ], [ %.amice.vm_flatten_br_flag.0, %55 ], [ %.amice.vm_flatten_br_flag.0, %51 ], [ %.amice.vm_flatten_br_flag.0, %47 ], [ %.amice.vm_flatten_br_flag.0, %44 ], [ %.amice.vm_flatten_br_flag.0, %40 ], [ %.amice.vm_flatten_br_flag.0, %36 ], [ 7, %.vm_switch_case_7 ], [ 6, %.vm_switch_case_6 ], [ 5, %.vm_switch_case_5 ], [ 4, %.vm_switch_case_4 ], [ 3, %.vm_switch_case_3 ], [ 2, %.vm_switch_case_2 ], [ 1, %.vm_switch_case_1 ], [ %.amice.vm_flatten_br_flag.0, %33 ], [ %.amice.vm_flatten_br_flag.0, %22 ], [ %_t_or_f_2, %20 ], [ %.amice.vm_flatten_br_flag.0, %.amice.vm_flatten_jmp_if ], [ %.amice.vm_flatten_br_flag.0, %.amice.vm_flatten_entry ], [ 0, %35 ]
  %.amice.vm_flatten_pc.0.be = phi i32 [ %plus_value, %.amice.vm_flatten_default ], [ %__value__, %.amice.vm_flatten_switch ], [ %plus_value, %71 ], [ %plus_value, %69 ], [ %plus_value, %67 ], [ %plus_value, %63 ], [ %plus_value, %59 ], [ %plus_value, %55 ], [ %plus_value, %51 ], [ %plus_value, %47 ], [ %plus_value, %44 ], [ %plus_value, %40 ], [ %plus_value, %36 ], [ %plus_value, %.vm_switch_case_7 ], [ %plus_value, %.vm_switch_case_6 ], [ %plus_value, %.vm_switch_case_5 ], [ %plus_value, %.vm_switch_case_4 ], [ %plus_value, %.vm_switch_case_3 ], [ %plus_value, %.vm_switch_case_2 ], [ %plus_value, %.vm_switch_case_1 ], [ %plus_value, %33 ], [ %plus_value, %22 ], [ %plus_value, %20 ], [ %__left__.__right__, %.amice.vm_flatten_jmp_if ], [ %__left__, %.amice.vm_flatten_entry ], [ %plus_value, %35 ]
  br label %.amice.vm_flatten_entry

default.unreachable52:                            ; preds = %35
  unreachable

.vm_switch_case_1:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge

.vm_switch_case_2:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge

.vm_switch_case_3:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge

.vm_switch_case_4:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge

.vm_switch_case_5:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge

.vm_switch_case_6:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge

.vm_switch_case_7:                                ; preds = %35
  br label %.amice.vm_flatten_entry.backedge
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) local_unnamed_addr #3 {
  %2 = tail call i32 @branch_switch_array(i32 noundef %0)
  %3 = tail call i32 @helper_add(i32 noundef %0, i32 noundef 42)
  %4 = add nsw i32 %3, %2
  ret i32 %4
}

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree noinline nounwind memory(readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #3 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
