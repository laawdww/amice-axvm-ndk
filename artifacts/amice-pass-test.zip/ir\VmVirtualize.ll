; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test\ir\baseline.raw.ll'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"
@.amice.vm.bytecode.module.helper_add.n4.h711399579d9648e0 = private constant [974 x i8] c"LGQp \7Fv@\10`\04\FC\00(\80\00\00\00\00\00\00\00\91\00\00\00\12@p\E4\00(\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EE\B4\00\00\E8\10X\F0 \10$\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\B1\00\00\000\108\00\91\00\00\00\B1\00\00\00,\00\00\00O\17\C2\98\8Dv\1A\C0p\E0\08\FC8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00b\BC\00\00\E5p\\\000 (\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00,\00\00\00\FD\F0\E0\00(\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\E2\CC\00\00\EF0X\04\04\10 8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00bt\00\00\1E\C0\10`\10,8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\22\FC\00\00\D5\10l\10\\0 x\80\00\00\00\00\00\00\00\93\00\00\00u\F0<\10\DC0(\18\80\00\00\00\00\00\00\00$\00\00\00+T\F0$\B3\00\00\00\F1\00\00\00\E6\D4\00\00*M\10`\0C\1Cx\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EC\00\00\00H\10\DC\00p h\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00#\00\00\00:@\10 d[\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00&\CC\00\00L\10X\10d\10`8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\F1\00\00\00\81p$\08\1C\F8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\E4\00\00\00\AB@\10 \000\E4\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EE\B4\00\00\FB@\10d\10(\F0 8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\E6\\\00\00\830`\10L\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EET\00\00@\F0h\10\E4\10 \E8\80\00\00\00\00\00\00\00&\\\00\00\0D\10X\00\E2T\00\00$\00\00\00,\00\00\00a\18\1C@\00,\01\00\00\B7\00\00\00#\00\04\04\00\00\00\00\00\00\00\00\0C\04\10 h\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\22L\00\00x\00\EC@$\01\00\00\1C\00\00\00\83\14@8X\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\91\00\00\00\E8l\F8\00$\07\00\00'\00\00\00\18\1C\CC\10\E0$\01\00\E2\CC\00\00W\1C\0C|@\18\80\00a\00\00\00\F5\04\1C\18x\00\04\04\00\00\00\00\00\00\04\04\1C\C4h\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\22\D4\00\00\DB\00\EC\C8l\01\00\00\EC\00\00\00+0`\1C\CC\EC\01\00\EC\00\00\00\C0\1C\F4\EC\C4\10 (\80\00\00\00\00\00\00\00\1C\00\00\00\ED|\14\\\B1\00\00\00\91\00\00\00\EF\00\00\00"
@.amice.vm.native_table.module.helper_add.n4.h711399579d9648e0 = private constant [2 x ptr] [ptr @.amice.vm.native_thunk.amice_all_passes_entry.0, ptr @.amice.vm.native_thunk.amice_all_passes_entry.1]
@.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0 = private constant [32 x i64] [i64 -7926022821245606050, i64 -2290133567043882204, i64 2968141487704502704, i64 -2558426464548688305, i64 -3908177740531525670, i64 -1150369581183701390, i64 -1486790550778171451, i64 -4499684001852036840, i64 -3530149467810129656, i64 -2205013129980933431, i64 3513484494774642307, i64 6009886842512292970, i64 -2599397098504960228, i64 8081795999754509957, i64 -8103329276279221193, i64 -4864919943553382912, i64 -7920110502013932110, i64 2405712365791603134, i64 6824501206060083715, i64 -9000265335011947486, i64 8773379928329407214, i64 1397330587551669907, i64 -3887878109946148603, i64 -3654713035693661241, i64 -7608211557944890587, i64 -1492459942229722117, i64 -475842280560455528, i64 4379640786061814655, i64 4060742087959218750, i64 -2085348395619649268, i64 2301728200958570462, i64 6255752609927527004]
@.amice.vm.bytecode.helper_add = private constant [181 x i8] c"AMICEVMP\01\00\00\00\00\00\00\00\0A\00\00\00\00\00\00\00\F6\89\E1f\D3\AC)9@\00\00\00\06\00\00\00F\00\00\00l\00\00\00\B2\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00LGQp \7Fv@\10`\04\FC\00(\80\00\00\00\00\00\00\00\91\00\00\00\12@p\E4\00(\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EE\B4\00\00\E8\10X\F0 \10$\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\B1\00\00\000\108\00\91\00\00\00\B1\00\00\00,\00\00\00\01\00\00"
@.amice.vm.meta.helper_add = private constant [27 x i8] c"AMICE_VMP_RUNTIME_BYTECODE\00"
@.amice.vm.bytecode.custom_cc_target = private constant [309 x i8] c"AMICEVMP\01\00\00\00\00\00\00\00\12\00\00\00\00\00\00\00\B6\D8\E8\B1\C8\A7\90l@\00\00\00\06\00\00\00F\00\00\00\EC\00\00\002\01\00\00\03\00\00\00\00\00\00\00\00\00\00\00O\17\C2\98\8Dv\1A\C0p\E0\08\FC8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00b\BC\00\00\E5p\\\000 (\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00,\00\00\00\FD\F0\E0\00(\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\E2\CC\00\00\EF0X\04\04\10 8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00bt\00\00\1E\C0\10`\10,8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\22\FC\00\00\D5\10l\10\\0 x\80\00\00\00\00\00\00\00\93\00\00\00u\F0<\10\DC0(\18\80\00\00\00\00\00\00\00$\00\00\00+T\F0$\B3\00\00\00\F1\00\00\00\E6\D4\00\00\01\00\00"
@.amice.vm.meta.custom_cc_target = private constant [27 x i8] c"AMICE_VMP_RUNTIME_BYTECODE\00"
@.amice.vm.bytecode.vm_target = private constant [392 x i8] c"AMICEVMP\01\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\9E\0C\D9}a\B5\CFr@\00\00\00\01\00\00\00A\00\00\00D\01\00\00\85\01\00\00\03\00\00\00\00\00\00\00\00\00\00\00*M\10`\0C\1Cx\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EC\00\00\00H\10\DC\00p h\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00#\00\00\00:@\10 d[\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00&\CC\00\00L\10X\10d\10`8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\F1\00\00\00\81p$\08\1C\F8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\E4\00\00\00\AB@\10 \000\E4\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EE\B4\00\00\FB@\10d\10(\F0 8\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\E6\\\00\00\830`\10L\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\EET\00\00@\F0h\10\E4\10 \E8\80\00\00\00\00\00\00\00&\\\00\00\0D\10X\00\E2T\00\00$\00\00\00,\00\00\00\01\00\00"
@.amice.vm.meta.vm_target = private constant [27 x i8] c"AMICE_VMP_RUNTIME_BYTECODE\00"
@.amice.vm.bytecode.amice_all_passes_entry = private constant [360 x i8] c"AMICEVMP\01\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00.\10\98\8E\C7\B0\E7\A2@\00\00\00\01\00\00\00A\00\00\00$\01\00\00e\01\00\00\03\00\00\00\00\00\00\00\00\00\00\00a\18\1C@\00,\01\00\00\B7\00\00\00#\00\04\04\00\00\00\00\00\00\00\00\0C\04\10 h\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\22L\00\00x\00\EC@$\01\00\00\1C\00\00\00\83\14@8X\18\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\91\00\00\00\E8l\F8\00$\07\00\00'\00\00\00\18\1C\CC\10\E0$\01\00\E2\CC\00\00W\1C\0C|@\18\80\00a\00\00\00\F5\04\1C\18x\00\04\04\00\00\00\00\00\00\04\04\1C\C4h\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\22\D4\00\00\DB\00\EC\C8l\01\00\00\EC\00\00\00+0`\1C\CC\EC\01\00\EC\00\00\00\C0\1C\F4\EC\C4\10 (\80\00\00\00\00\00\00\00\1C\00\00\00\ED|\14\\\B1\00\00\00\91\00\00\00\EF\00\00\00\01\00\00"
@.amice.vm.meta.amice_all_passes_entry = private constant [27 x i8] c"AMICE_VMP_RUNTIME_BYTECODE\00"
@llvm.compiler.used = appending global [13 x ptr] [ptr @.amice.vm.bytecode.module.helper_add.n4.h711399579d9648e0, ptr @.amice.vm.native_thunk.amice_all_passes_entry.0, ptr @.amice.vm.native_thunk.amice_all_passes_entry.1, ptr @.amice.vm.native_table.module.helper_add.n4.h711399579d9648e0, ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, ptr @.amice.vm.bytecode.helper_add, ptr @.amice.vm.meta.helper_add, ptr @.amice.vm.bytecode.custom_cc_target, ptr @.amice.vm.meta.custom_cc_target, ptr @.amice.vm.bytecode.vm_target, ptr @.amice.vm.meta.vm_target, ptr @.amice.vm.bytecode.amice_all_passes_entry, ptr @.amice.vm.meta.amice_all_passes_entry], section "llvm.metadata"

; Function Attrs: nofree noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) local_unnamed_addr #0 {
  %2 = load volatile i32, ptr @amice_sink, align 4
  %3 = add nsw i32 %0, %2
  %4 = xor i32 %3, %0
  %5 = add i32 %0, 3
  %6 = load volatile i32, ptr @amice_sink, align 4
  %7 = add nsw i32 %5, %6
  %8 = shl i32 %0, 1
  %9 = xor i32 %7, %8
  %10 = add nsw i32 %9, %4
  %11 = add i32 %0, 6
  %12 = load volatile i32, ptr @amice_sink, align 4
  %13 = add nsw i32 %11, %12
  %14 = shl i32 %0, 2
  %15 = xor i32 %13, %14
  %16 = add nsw i32 %15, %10
  %17 = add i32 %0, 9
  %18 = load volatile i32, ptr @amice_sink, align 4
  %19 = add nsw i32 %17, %18
  %20 = shl i32 %0, 3
  %21 = xor i32 %19, %20
  %22 = add nsw i32 %21, %16
  %23 = add i32 %0, 12
  %24 = load volatile i32, ptr @amice_sink, align 4
  %25 = add nsw i32 %23, %24
  %26 = xor i32 %25, %0
  %27 = add nsw i32 %26, %22
  %28 = add i32 %0, 15
  %29 = load volatile i32, ptr @amice_sink, align 4
  %30 = add nsw i32 %28, %29
  %31 = shl i32 %0, 1
  %32 = xor i32 %30, %31
  %33 = add nsw i32 %32, %27
  %34 = add i32 %0, 18
  %35 = load volatile i32, ptr @amice_sink, align 4
  %36 = add nsw i32 %34, %35
  %37 = shl i32 %0, 2
  %38 = xor i32 %36, %37
  %39 = add nsw i32 %38, %33
  %40 = add i32 %0, 21
  %41 = load volatile i32, ptr @amice_sink, align 4
  %42 = add nsw i32 %40, %41
  %43 = shl i32 %0, 3
  %44 = xor i32 %42, %43
  %45 = add nsw i32 %44, %39
  %46 = and i32 %0, 7
  switch i32 %46, label %default.unreachable31 [
    i32 0, label %47
    i32 1, label %50
    i32 2, label %53
    i32 3, label %55
    i32 4, label %58
    i32 5, label %61
    i32 6, label %64
    i32 7, label %67
  ]

47:                                               ; preds = %1
  %48 = mul nsw i32 %3, 17
  %49 = add nsw i32 %48, %45
  br label %70

50:                                               ; preds = %1
  %51 = add nsw i32 %7, 29
  %52 = xor i32 %51, %45
  br label %70

53:                                               ; preds = %1
  %.neg = mul i32 %13, -31
  %54 = add i32 %.neg, %45
  br label %70

55:                                               ; preds = %1
  %56 = xor i32 %19, 68
  %57 = add nsw i32 %56, %45
  br label %70

58:                                               ; preds = %1
  %59 = mul nsw i32 %25, 5
  %60 = xor i32 %59, %45
  br label %70

61:                                               ; preds = %1
  %62 = add i32 %45, -97
  %63 = add i32 %62, %30
  br label %70

64:                                               ; preds = %1
  %65 = xor i32 %36, 4660
  %66 = sub nsw i32 %45, %65
  br label %70

default.unreachable31:                            ; preds = %1
  unreachable

67:                                               ; preds = %1
  %68 = add i32 %45, 123
  %69 = add i32 %68, %42
  br label %70

70:                                               ; preds = %67, %64, %61, %58, %55, %53, %50, %47
  %.1 = phi i32 [ %69, %67 ], [ %66, %64 ], [ %63, %61 ], [ %60, %58 ], [ %57, %55 ], [ %54, %53 ], [ %52, %50 ], [ %49, %47 ]
  %71 = and i32 %.1, 1
  %.not = icmp eq i32 %71, 0
  br i1 %.not, label %74, label %72

72:                                               ; preds = %70
  %73 = tail call i32 @helper_add(i32 noundef %.1, i32 noundef %0)
  br label %76

74:                                               ; preds = %70
  %75 = tail call i32 @helper_add(i32 noundef %0, i32 noundef %.1)
  br label %76

76:                                               ; preds = %74, %72
  %.2 = phi i32 [ %73, %72 ], [ %75, %74 ]
  %77 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str)
  %78 = tail call i32 @custom_cc_target(i32 noundef %0, i32 noundef %.2)
  %79 = add nsw i32 %78, %.2
  %80 = tail call i32 @vm_target(i32 noundef %0)
  %81 = add nsw i32 %79, %80
  ret i32 %81
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #1

define private { i64, i64, i64, i64, i64, i64, i64, i64 } @.amice.vm.native_thunk.amice_all_passes_entry.0(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7) unnamed_addr {
entry:
  %amice.vm.native.arg.trunc = trunc i64 %0 to i32
  %amice.vm.native.target = call i32 @branch_switch_array(i32 noundef %amice.vm.native.arg.trunc)
  %amice.vm.arg.zext = zext i32 %amice.vm.native.target to i64
  %amice.vm.native.ret.slot = insertvalue { i64, i64, i64, i64, i64, i64, i64, i64 } undef, i64 %amice.vm.arg.zext, 0
  ret { i64, i64, i64, i64, i64, i64, i64, i64 } %amice.vm.native.ret.slot
}

define private { i64, i64, i64, i64, i64, i64, i64, i64 } @.amice.vm.native_thunk.amice_all_passes_entry.1(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7) unnamed_addr {
entry:
  %amice.vm.native.arg.trunc = trunc i64 %0 to i32
  %amice.vm.native.arg.trunc1 = trunc i64 %1 to i32
  %amice.vm.native.target = call i32 @helper_add(i32 noundef %amice.vm.native.arg.trunc, i32 noundef %amice.vm.native.arg.trunc1)
  %amice.vm.arg.zext = zext i32 %amice.vm.native.target to i64
  %amice.vm.native.ret.slot = insertvalue { i64, i64, i64, i64, i64, i64, i64, i64 } undef, i64 %amice.vm.arg.zext, 0
  ret { i64, i64, i64, i64, i64, i64, i64, i64 } %amice.vm.native.ret.slot
}

; Function Attrs: alwaysinline
define private i64 @.amice.vm.h.eb7d375a76d54199(ptr %0, i64 %1, i64 %2, ptr %3) unnamed_addr #2 {
entry:
  %result = alloca i64, align 8
  %shift = alloca i64, align 8
  store i64 0, ptr %result, align 8
  store i64 0, ptr %shift, align 8
  br label %loop

loop:                                             ; preds = %read, %entry
  %offset = load i64, ptr %3, align 8
  %in_bounds = icmp ult i64 %offset, %1
  br i1 %in_bounds, label %read, label %done

read:                                             ; preds = %loop
  %byte.ptr = getelementptr i8, ptr %0, i64 %offset
  %raw.byte = load i8, ptr %byte.ptr, align 1
  %next.offset = add i64 %offset, 1
  store i64 %next.offset, ptr %3, align 8
  %key.rot.seed = mul i64 %offset, 13
  %key.rot = and i64 %key.rot.seed, 63
  %key.rot.left = shl i64 %2, %key.rot
  %key.rot.neg = sub i64 0, %key.rot
  %key.rot.right.amount = and i64 %key.rot.neg, 63
  %key.rot.right = lshr i64 %2, %key.rot.right.amount
  %key.rotated = or i64 %key.rot.left, %key.rot.right
  %key.index.mul = mul i64 %offset, -7046029254386353131
  %key.index.left = shl i64 %offset, 17
  %key.index.right = lshr i64 %offset, 47
  %key.index.rot = or i64 %key.index.left, %key.index.right
  %key.index.high = lshr i64 %offset, 7
  %key.mix.0 = xor i64 %key.rotated, %key.index.mul
  %key.mix.1 = xor i64 %key.mix.0, %key.index.rot
  %key.mix.2 = xor i64 %key.mix.1, %key.index.high
  %key.fold.32 = lshr i64 %key.mix.2, 32
  %key.fold.0 = xor i64 %key.mix.2, %key.fold.32
  %key.fold.16 = lshr i64 %key.mix.2, 16
  %key.fold.1 = xor i64 %key.fold.0, %key.fold.16
  %key.fold.8 = lshr i64 %key.mix.2, 8
  %key.fold.2 = xor i64 %key.fold.1, %key.fold.8
  %key.byte = trunc i64 %key.fold.2 to i8
  %decoded.xor = xor i8 %raw.byte, %key.byte
  %key.rot.seed1 = mul i64 %offset, 13
  %key.rot2 = and i64 %key.rot.seed1, 63
  %key.rot.left3 = shl i64 %2, %key.rot2
  %key.rot.neg4 = sub i64 0, %key.rot2
  %key.rot.right.amount5 = and i64 %key.rot.neg4, 63
  %key.rot.right6 = lshr i64 %2, %key.rot.right.amount5
  %key.rotated7 = or i64 %key.rot.left3, %key.rot.right6
  %key.index.mul8 = mul i64 %offset, -7046029254386353131
  %key.index.left9 = shl i64 %offset, 17
  %key.index.right10 = lshr i64 %offset, 47
  %key.index.rot11 = or i64 %key.index.left9, %key.index.right10
  %key.index.high12 = lshr i64 %offset, 7
  %key.mix.013 = xor i64 %key.rotated7, %key.index.mul8
  %key.mix.114 = xor i64 %key.mix.013, %key.index.rot11
  %key.mix.215 = xor i64 %key.mix.114, %key.index.high12
  %key.fold.3216 = lshr i64 %key.mix.215, 32
  %key.fold.017 = xor i64 %key.mix.215, %key.fold.3216
  %key.fold.1618 = lshr i64 %key.mix.215, 16
  %key.fold.119 = xor i64 %key.fold.017, %key.fold.1618
  %key.fold.820 = lshr i64 %key.mix.215, 8
  %key.fold.221 = xor i64 %key.fold.119, %key.fold.820
  %key.byte22 = trunc i64 %key.fold.221 to i8
  %decoded.add_stream = sub i8 %decoded.xor, %key.byte22
  %ror.right = lshr i8 %decoded.add_stream, 3
  %ror.left = shl i8 %decoded.add_stream, 5
  %ror = or i8 %ror.left, %ror.right
  %rol.left = shl i8 %ror, 1
  %rol.right = lshr i8 %ror, 7
  %rol = or i8 %rol.left, %rol.right
  %decoded64 = zext i8 %rol to i64
  %payload = and i64 %decoded64, 127
  %shift23 = load i64, ptr %shift, align 8
  %payload.shifted = shl i64 %payload, %shift23
  %result.old = load i64, ptr %result, align 8
  %result.new = or i64 %result.old, %payload.shifted
  store i64 %result.new, ptr %result, align 8
  %shift.next = add i64 %shift23, 7
  store i64 %shift.next, ptr %shift, align 8
  %cont.bit = and i64 %decoded64, 128
  %has.more = icmp ne i64 %cont.bit, 0
  br i1 %has.more, label %loop, label %done

done:                                             ; preds = %read, %loop
  %result24 = load i64, ptr %result, align 8
  ret i64 %result24
}

; Function Attrs: alwaysinline
define private i64 @.amice.vm.h.0066021953c051bc(ptr %0, i64 %1, i64 %2, ptr %3) unnamed_addr #2 {
entry:
  %operand.result = alloca i64, align 8
  %operand.shift = alloca i64, align 8
  store i64 0, ptr %operand.result, align 8
  store i64 0, ptr %operand.shift, align 8
  %operand.bit_width = call i64 @.amice.vm.h.eb7d375a76d54199(ptr %0, i64 %1, i64 %2, ptr %3)
  %operand.has_bits = icmp ne i64 %operand.bit_width, 0
  br i1 %operand.has_bits, label %loop, label %done

loop:                                             ; preds = %read, %entry
  %operand.shift.cur = load i64, ptr %operand.shift, align 8
  %operand.within_width = icmp ult i64 %operand.shift.cur, %operand.bit_width
  %operand.within_u64 = icmp ult i64 %operand.shift.cur, 64
  %operand.keep_reading = and i1 %operand.within_width, %operand.within_u64
  br i1 %operand.keep_reading, label %read, label %done

read:                                             ; preds = %loop
  %operand.chunk = call i64 @.amice.vm.h.eb7d375a76d54199(ptr %0, i64 %1, i64 %2, ptr %3)
  %operand.chunk.masked = and i64 %operand.chunk, 127
  %operand.chunk.shifted = shl i64 %operand.chunk.masked, %operand.shift.cur
  %operand.result.old = load i64, ptr %operand.result, align 8
  %operand.result.new = or i64 %operand.result.old, %operand.chunk.shifted
  store i64 %operand.result.new, ptr %operand.result, align 8
  %operand.shift.next = add i64 %operand.shift.cur, 7
  store i64 %operand.shift.next, ptr %operand.shift, align 8
  br label %loop

done:                                             ; preds = %loop, %entry
  %operand.result.final = load i64, ptr %operand.result, align 8
  ret i64 %operand.result.final
}

; Function Attrs: alwaysinline
define private i64 @.amice.vm.h.042ef71712c2e1a6(ptr %0, i64 %1, i64 %2, ptr %3) unnamed_addr #2 {
entry:
  %const.result = alloca i64, align 8
  %const.shift = alloca i64, align 8
  store i64 0, ptr %const.result, align 8
  store i64 0, ptr %const.shift, align 8
  br label %loop

loop:                                             ; preds = %read, %entry
  %const.offset = load i64, ptr %3, align 8
  %const.in_bounds = icmp ult i64 %const.offset, %1
  br i1 %const.in_bounds, label %read, label %done

read:                                             ; preds = %loop
  %const.byte.ptr = getelementptr i8, ptr %0, i64 %const.offset
  %const.raw.byte = load i8, ptr %const.byte.ptr, align 1
  %const.next.offset = add i64 %const.offset, 1
  store i64 %const.next.offset, ptr %3, align 8
  %key.rot.seed = mul i64 %const.offset, 13
  %key.rot = and i64 %key.rot.seed, 63
  %key.rot.left = shl i64 %2, %key.rot
  %key.rot.neg = sub i64 0, %key.rot
  %key.rot.right.amount = and i64 %key.rot.neg, 63
  %key.rot.right = lshr i64 %2, %key.rot.right.amount
  %key.rotated = or i64 %key.rot.left, %key.rot.right
  %key.index.mul = mul i64 %const.offset, -7046029254386353131
  %key.index.left = shl i64 %const.offset, 17
  %key.index.right = lshr i64 %const.offset, 47
  %key.index.rot = or i64 %key.index.left, %key.index.right
  %key.index.high = lshr i64 %const.offset, 7
  %key.mix.0 = xor i64 %key.rotated, %key.index.mul
  %key.mix.1 = xor i64 %key.mix.0, %key.index.rot
  %key.mix.2 = xor i64 %key.mix.1, %key.index.high
  %key.fold.32 = lshr i64 %key.mix.2, 32
  %key.fold.0 = xor i64 %key.mix.2, %key.fold.32
  %key.fold.16 = lshr i64 %key.mix.2, 16
  %key.fold.1 = xor i64 %key.fold.0, %key.fold.16
  %key.fold.8 = lshr i64 %key.mix.2, 8
  %key.fold.2 = xor i64 %key.fold.1, %key.fold.8
  %key.byte = trunc i64 %key.fold.2 to i8
  %const.decoded.xor = xor i8 %const.raw.byte, %key.byte
  %const.decoded64 = zext i8 %const.decoded.xor to i64
  %const.payload = and i64 %const.decoded64, 127
  %const.shift1 = load i64, ptr %const.shift, align 8
  %const.payload.shifted = shl i64 %const.payload, %const.shift1
  %const.result.old = load i64, ptr %const.result, align 8
  %const.result.new = or i64 %const.result.old, %const.payload.shifted
  store i64 %const.result.new, ptr %const.result, align 8
  %const.shift.next = add i64 %const.shift1, 7
  store i64 %const.shift.next, ptr %const.shift, align 8
  %const.cont.bit = and i64 %const.decoded64, 128
  %const.has.more = icmp ne i64 %const.cont.bit, 0
  br i1 %const.has.more, label %loop, label %done

done:                                             ; preds = %read, %loop
  %const.result2 = load i64, ptr %const.result, align 8
  ret i64 %const.result2
}

; Function Attrs: alwaysinline
define private i64 @.amice.vm.h.a19eb3e0dbe6d829(ptr %0, i64 %1, i64 %2, i64 %3) unnamed_addr #2 {
entry:
  %const.pool.offset = alloca i64, align 8
  %const.pool.current = alloca i64, align 8
  %const.pool.result = alloca i64, align 8
  store i64 0, ptr %const.pool.offset, align 8
  store i64 0, ptr %const.pool.current, align 8
  store i64 0, ptr %const.pool.result, align 8
  %const.pool.count = call i64 @.amice.vm.h.042ef71712c2e1a6(ptr %0, i64 %1, i64 %2, ptr %const.pool.offset)
  %const.pool.index.ok = icmp ult i64 %3, %const.pool.count
  br i1 %const.pool.index.ok, label %loop, label %done

loop:                                             ; preds = %advance, %entry
  %const.pool.value = call i64 @.amice.vm.h.042ef71712c2e1a6(ptr %0, i64 %1, i64 %2, ptr %const.pool.offset)
  %const.pool.current.value = load i64, ptr %const.pool.current, align 8
  %const.pool.is.target = icmp eq i64 %const.pool.current.value, %3
  br i1 %const.pool.is.target, label %found, label %advance

found:                                            ; preds = %loop
  store i64 %const.pool.value, ptr %const.pool.result, align 8
  br label %done

advance:                                          ; preds = %loop
  %const.pool.current.next = add i64 %const.pool.current.value, 1
  store i64 %const.pool.current.next, ptr %const.pool.current, align 8
  br label %loop

done:                                             ; preds = %found, %entry
  %const.pool.result1 = load i64, ptr %const.pool.result, align 8
  ret i64 %const.pool.result1
}

define private i64 @.amice.vm.h.c1df321a8d29a33b(i64 %0, ptr %1, ptr %2) unnamed_addr {
entry:
  %x = alloca [32 x i64], align 8
  %q = alloca [65 x <16 x i8>], align 16
  %pc = alloca i64, align 8
  %offset = alloca i64, align 8
  store i64 0, ptr %pc, align 8
  %reg.store.ptr = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  store i64 0, ptr %reg.store.ptr, align 8
  %reg.store.ptr1 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 1
  store i64 0, ptr %reg.store.ptr1, align 8
  %reg.store.ptr2 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 2
  store i64 0, ptr %reg.store.ptr2, align 8
  %reg.store.ptr3 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 3
  store i64 0, ptr %reg.store.ptr3, align 8
  %reg.store.ptr4 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 4
  store i64 0, ptr %reg.store.ptr4, align 8
  %reg.store.ptr5 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 5
  store i64 0, ptr %reg.store.ptr5, align 8
  %reg.store.ptr6 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 6
  store i64 0, ptr %reg.store.ptr6, align 8
  %reg.store.ptr7 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 7
  store i64 0, ptr %reg.store.ptr7, align 8
  %reg.store.ptr8 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 8
  store i64 0, ptr %reg.store.ptr8, align 8
  %reg.store.ptr9 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 9
  store i64 0, ptr %reg.store.ptr9, align 8
  %reg.store.ptr10 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 10
  store i64 0, ptr %reg.store.ptr10, align 8
  %reg.store.ptr11 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 11
  store i64 0, ptr %reg.store.ptr11, align 8
  %reg.store.ptr12 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 12
  store i64 0, ptr %reg.store.ptr12, align 8
  %reg.store.ptr13 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 13
  store i64 0, ptr %reg.store.ptr13, align 8
  %reg.store.ptr14 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 14
  store i64 0, ptr %reg.store.ptr14, align 8
  %reg.store.ptr15 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 15
  store i64 0, ptr %reg.store.ptr15, align 8
  %reg.store.ptr16 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 16
  store i64 0, ptr %reg.store.ptr16, align 8
  %reg.store.ptr17 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 17
  store i64 0, ptr %reg.store.ptr17, align 8
  %reg.store.ptr18 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 18
  store i64 0, ptr %reg.store.ptr18, align 8
  %reg.store.ptr19 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 19
  store i64 0, ptr %reg.store.ptr19, align 8
  %reg.store.ptr20 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 20
  store i64 0, ptr %reg.store.ptr20, align 8
  %reg.store.ptr21 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 21
  store i64 0, ptr %reg.store.ptr21, align 8
  %reg.store.ptr22 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 22
  store i64 0, ptr %reg.store.ptr22, align 8
  %reg.store.ptr23 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 23
  store i64 0, ptr %reg.store.ptr23, align 8
  %reg.store.ptr24 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 24
  store i64 0, ptr %reg.store.ptr24, align 8
  %reg.store.ptr25 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 25
  store i64 0, ptr %reg.store.ptr25, align 8
  %reg.store.ptr26 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 26
  store i64 0, ptr %reg.store.ptr26, align 8
  %reg.store.ptr27 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 27
  store i64 0, ptr %reg.store.ptr27, align 8
  %reg.store.ptr28 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 28
  store i64 0, ptr %reg.store.ptr28, align 8
  %reg.store.ptr29 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 29
  store i64 0, ptr %reg.store.ptr29, align 8
  %reg.store.ptr30 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 30
  store i64 0, ptr %reg.store.ptr30, align 8
  %reg.store.ptr31 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 31
  store i64 0, ptr %reg.store.ptr31, align 8
  %token.ror.right = lshr i64 %0, 46
  %token.ror.left = shl i64 %0, 18
  %token.ror = or i64 %token.ror.left, %token.ror.right
  %token.unxor = xor i64 %token.ror, -3568918127210691769
  %token.unadd = sub i64 %token.unxor, 6977447169822692566
  %token.index = mul i64 %token.unadd, -1018231460777725123
  %descriptor.index.ok = icmp ult i64 %token.index, 4
  br i1 %descriptor.index.ok, label %descriptor.decode, label %default.return

descriptor.decode:                                ; preds = %entry
  %descriptor.guard.row = mul i64 %token.index, 8
  %descriptor.guard.index = add i64 %descriptor.guard.row, 7
  %descriptor.guard.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.guard.index
  %descriptor.guard.encrypted = load i64, ptr %descriptor.guard.ptr, align 8
  %descriptor.key.index = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed = xor i64 %descriptor.key.index, 8148024752428435680
  %descriptor.key.base = xor i64 %descriptor.key.seed, -8685367510301726191
  %descriptor.key.mask.seed = xor i64 %descriptor.key.base, 8100178437174699977
  %descriptor.key.mask.add = add i64 %descriptor.key.mask.seed, -7046029254386353131
  %descriptor.key.mask.shr30 = lshr i64 %descriptor.key.mask.add, 30
  %descriptor.key.mask.xor30 = xor i64 %descriptor.key.mask.add, %descriptor.key.mask.shr30
  %descriptor.key.mask.mul0 = mul i64 %descriptor.key.mask.xor30, -4658895280553007687
  %descriptor.key.mask.shr27 = lshr i64 %descriptor.key.mask.mul0, 27
  %descriptor.key.mask.xor27 = xor i64 %descriptor.key.mask.mul0, %descriptor.key.mask.shr27
  %descriptor.key.mask.mul1 = mul i64 %descriptor.key.mask.xor27, -7723592293110705685
  %descriptor.key.mask.shr31 = lshr i64 %descriptor.key.mask.mul1, 31
  %descriptor.key.mask = xor i64 %descriptor.key.mask.mul1, %descriptor.key.mask.shr31
  %descriptor.key.add.seed = xor i64 %descriptor.key.base, -7209929243056714667
  %descriptor.key.add.add = add i64 %descriptor.key.add.seed, -7046029254386353131
  %descriptor.key.add.shr30 = lshr i64 %descriptor.key.add.add, 30
  %descriptor.key.add.xor30 = xor i64 %descriptor.key.add.add, %descriptor.key.add.shr30
  %descriptor.key.add.mul0 = mul i64 %descriptor.key.add.xor30, -4658895280553007687
  %descriptor.key.add.shr27 = lshr i64 %descriptor.key.add.mul0, 27
  %descriptor.key.add.xor27 = xor i64 %descriptor.key.add.mul0, %descriptor.key.add.shr27
  %descriptor.key.add.mul1 = mul i64 %descriptor.key.add.xor27, -7723592293110705685
  %descriptor.key.add.shr31 = lshr i64 %descriptor.key.add.mul1, 31
  %descriptor.key.add = xor i64 %descriptor.key.add.mul1, %descriptor.key.add.shr31
  %descriptor.key.rot.seed = xor i64 %descriptor.key.base, -4417276739564004087
  %descriptor.key.rot.raw.add = add i64 %descriptor.key.rot.seed, -7046029254386353131
  %descriptor.key.rot.raw.shr30 = lshr i64 %descriptor.key.rot.raw.add, 30
  %descriptor.key.rot.raw.xor30 = xor i64 %descriptor.key.rot.raw.add, %descriptor.key.rot.raw.shr30
  %descriptor.key.rot.raw.mul0 = mul i64 %descriptor.key.rot.raw.xor30, -4658895280553007687
  %descriptor.key.rot.raw.shr27 = lshr i64 %descriptor.key.rot.raw.mul0, 27
  %descriptor.key.rot.raw.xor27 = xor i64 %descriptor.key.rot.raw.mul0, %descriptor.key.rot.raw.shr27
  %descriptor.key.rot.raw.mul1 = mul i64 %descriptor.key.rot.raw.xor27, -7723592293110705685
  %descriptor.key.rot.raw.shr31 = lshr i64 %descriptor.key.rot.raw.mul1, 31
  %descriptor.key.rot.raw = xor i64 %descriptor.key.rot.raw.mul1, %descriptor.key.rot.raw.shr31
  %descriptor.key.rot.masked = and i64 %descriptor.key.rot.raw, 63
  %descriptor.key.rot.zero = icmp eq i64 %descriptor.key.rot.masked, 0
  %descriptor.key.rot = select i1 %descriptor.key.rot.zero, i64 1, i64 %descriptor.key.rot.masked
  %descriptor.guard.unadd = sub i64 %descriptor.guard.encrypted, %descriptor.key.add
  %descriptor.guard.unxor = xor i64 %descriptor.guard.unadd, %descriptor.key.mask
  %descriptor.guard.plain.amount = and i64 %descriptor.key.rot, 63
  %descriptor.guard.plain.right = lshr i64 %descriptor.guard.unxor, %descriptor.guard.plain.amount
  %descriptor.guard.plain.neg = sub i64 0, %descriptor.guard.plain.amount
  %descriptor.guard.plain.left.amount = and i64 %descriptor.guard.plain.neg, 63
  %descriptor.guard.plain.left = shl i64 %descriptor.guard.unxor, %descriptor.guard.plain.left.amount
  %descriptor.guard.plain = or i64 %descriptor.guard.plain.left, %descriptor.guard.plain.right
  %descriptor.guard.index32 = mul i64 %token.index, -3335678366873096957
  %descriptor.guard.seed = xor i64 %descriptor.guard.index32, 8148024752428435680
  %descriptor.guard.mix = xor i64 %descriptor.guard.seed, -6330199073103995059
  %descriptor.guard.expected.add = add i64 %descriptor.guard.mix, -7046029254386353131
  %descriptor.guard.expected.shr30 = lshr i64 %descriptor.guard.expected.add, 30
  %descriptor.guard.expected.xor30 = xor i64 %descriptor.guard.expected.add, %descriptor.guard.expected.shr30
  %descriptor.guard.expected.mul0 = mul i64 %descriptor.guard.expected.xor30, -4658895280553007687
  %descriptor.guard.expected.shr27 = lshr i64 %descriptor.guard.expected.mul0, 27
  %descriptor.guard.expected.xor27 = xor i64 %descriptor.guard.expected.mul0, %descriptor.guard.expected.shr27
  %descriptor.guard.expected.mul1 = mul i64 %descriptor.guard.expected.xor27, -7723592293110705685
  %descriptor.guard.expected.shr31 = lshr i64 %descriptor.guard.expected.mul1, 31
  %descriptor.guard.expected = xor i64 %descriptor.guard.expected.mul1, %descriptor.guard.expected.shr31
  %descriptor.guard.ok = icmp eq i64 %descriptor.guard.plain, %descriptor.guard.expected
  br i1 %descriptor.guard.ok, label %descriptor.ready, label %default.return

descriptor.ready:                                 ; preds = %descriptor.decode
  %descriptor.code.offset.row = mul i64 %token.index, 8
  %descriptor.code.offset.index = add i64 %descriptor.code.offset.row, 0
  %descriptor.code.offset.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.code.offset.index
  %descriptor.code.offset.encrypted = load i64, ptr %descriptor.code.offset.ptr, align 8
  %descriptor.key.index33 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed34 = xor i64 %descriptor.key.index33, 8148024752428435680
  %descriptor.key.base35 = xor i64 %descriptor.key.seed34, 0
  %descriptor.key.mask.seed36 = xor i64 %descriptor.key.base35, 8100178437174699977
  %descriptor.key.mask.add37 = add i64 %descriptor.key.mask.seed36, -7046029254386353131
  %descriptor.key.mask.shr3038 = lshr i64 %descriptor.key.mask.add37, 30
  %descriptor.key.mask.xor3039 = xor i64 %descriptor.key.mask.add37, %descriptor.key.mask.shr3038
  %descriptor.key.mask.mul040 = mul i64 %descriptor.key.mask.xor3039, -4658895280553007687
  %descriptor.key.mask.shr2741 = lshr i64 %descriptor.key.mask.mul040, 27
  %descriptor.key.mask.xor2742 = xor i64 %descriptor.key.mask.mul040, %descriptor.key.mask.shr2741
  %descriptor.key.mask.mul143 = mul i64 %descriptor.key.mask.xor2742, -7723592293110705685
  %descriptor.key.mask.shr3144 = lshr i64 %descriptor.key.mask.mul143, 31
  %descriptor.key.mask45 = xor i64 %descriptor.key.mask.mul143, %descriptor.key.mask.shr3144
  %descriptor.key.add.seed46 = xor i64 %descriptor.key.base35, -7209929243056714667
  %descriptor.key.add.add47 = add i64 %descriptor.key.add.seed46, -7046029254386353131
  %descriptor.key.add.shr3048 = lshr i64 %descriptor.key.add.add47, 30
  %descriptor.key.add.xor3049 = xor i64 %descriptor.key.add.add47, %descriptor.key.add.shr3048
  %descriptor.key.add.mul050 = mul i64 %descriptor.key.add.xor3049, -4658895280553007687
  %descriptor.key.add.shr2751 = lshr i64 %descriptor.key.add.mul050, 27
  %descriptor.key.add.xor2752 = xor i64 %descriptor.key.add.mul050, %descriptor.key.add.shr2751
  %descriptor.key.add.mul153 = mul i64 %descriptor.key.add.xor2752, -7723592293110705685
  %descriptor.key.add.shr3154 = lshr i64 %descriptor.key.add.mul153, 31
  %descriptor.key.add55 = xor i64 %descriptor.key.add.mul153, %descriptor.key.add.shr3154
  %descriptor.key.rot.seed56 = xor i64 %descriptor.key.base35, -4417276739564004087
  %descriptor.key.rot.raw.add57 = add i64 %descriptor.key.rot.seed56, -7046029254386353131
  %descriptor.key.rot.raw.shr3058 = lshr i64 %descriptor.key.rot.raw.add57, 30
  %descriptor.key.rot.raw.xor3059 = xor i64 %descriptor.key.rot.raw.add57, %descriptor.key.rot.raw.shr3058
  %descriptor.key.rot.raw.mul060 = mul i64 %descriptor.key.rot.raw.xor3059, -4658895280553007687
  %descriptor.key.rot.raw.shr2761 = lshr i64 %descriptor.key.rot.raw.mul060, 27
  %descriptor.key.rot.raw.xor2762 = xor i64 %descriptor.key.rot.raw.mul060, %descriptor.key.rot.raw.shr2761
  %descriptor.key.rot.raw.mul163 = mul i64 %descriptor.key.rot.raw.xor2762, -7723592293110705685
  %descriptor.key.rot.raw.shr3164 = lshr i64 %descriptor.key.rot.raw.mul163, 31
  %descriptor.key.rot.raw65 = xor i64 %descriptor.key.rot.raw.mul163, %descriptor.key.rot.raw.shr3164
  %descriptor.key.rot.masked66 = and i64 %descriptor.key.rot.raw65, 63
  %descriptor.key.rot.zero67 = icmp eq i64 %descriptor.key.rot.masked66, 0
  %descriptor.key.rot68 = select i1 %descriptor.key.rot.zero67, i64 1, i64 %descriptor.key.rot.masked66
  %descriptor.code.offset.unadd = sub i64 %descriptor.code.offset.encrypted, %descriptor.key.add55
  %descriptor.code.offset.unxor = xor i64 %descriptor.code.offset.unadd, %descriptor.key.mask45
  %descriptor.code.offset.plain.amount = and i64 %descriptor.key.rot68, 63
  %descriptor.code.offset.plain.right = lshr i64 %descriptor.code.offset.unxor, %descriptor.code.offset.plain.amount
  %descriptor.code.offset.plain.neg = sub i64 0, %descriptor.code.offset.plain.amount
  %descriptor.code.offset.plain.left.amount = and i64 %descriptor.code.offset.plain.neg, 63
  %descriptor.code.offset.plain.left = shl i64 %descriptor.code.offset.unxor, %descriptor.code.offset.plain.left.amount
  %descriptor.code.offset.plain = or i64 %descriptor.code.offset.plain.left, %descriptor.code.offset.plain.right
  %descriptor.code.len.row = mul i64 %token.index, 8
  %descriptor.code.len.index = add i64 %descriptor.code.len.row, 1
  %descriptor.code.len.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.code.len.index
  %descriptor.code.len.encrypted = load i64, ptr %descriptor.code.len.ptr, align 8
  %descriptor.key.index69 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed70 = xor i64 %descriptor.key.index69, 8148024752428435680
  %descriptor.key.base71 = xor i64 %descriptor.key.seed70, -6511265093960118489
  %descriptor.key.mask.seed72 = xor i64 %descriptor.key.base71, 8100178437174699977
  %descriptor.key.mask.add73 = add i64 %descriptor.key.mask.seed72, -7046029254386353131
  %descriptor.key.mask.shr3074 = lshr i64 %descriptor.key.mask.add73, 30
  %descriptor.key.mask.xor3075 = xor i64 %descriptor.key.mask.add73, %descriptor.key.mask.shr3074
  %descriptor.key.mask.mul076 = mul i64 %descriptor.key.mask.xor3075, -4658895280553007687
  %descriptor.key.mask.shr2777 = lshr i64 %descriptor.key.mask.mul076, 27
  %descriptor.key.mask.xor2778 = xor i64 %descriptor.key.mask.mul076, %descriptor.key.mask.shr2777
  %descriptor.key.mask.mul179 = mul i64 %descriptor.key.mask.xor2778, -7723592293110705685
  %descriptor.key.mask.shr3180 = lshr i64 %descriptor.key.mask.mul179, 31
  %descriptor.key.mask81 = xor i64 %descriptor.key.mask.mul179, %descriptor.key.mask.shr3180
  %descriptor.key.add.seed82 = xor i64 %descriptor.key.base71, -7209929243056714667
  %descriptor.key.add.add83 = add i64 %descriptor.key.add.seed82, -7046029254386353131
  %descriptor.key.add.shr3084 = lshr i64 %descriptor.key.add.add83, 30
  %descriptor.key.add.xor3085 = xor i64 %descriptor.key.add.add83, %descriptor.key.add.shr3084
  %descriptor.key.add.mul086 = mul i64 %descriptor.key.add.xor3085, -4658895280553007687
  %descriptor.key.add.shr2787 = lshr i64 %descriptor.key.add.mul086, 27
  %descriptor.key.add.xor2788 = xor i64 %descriptor.key.add.mul086, %descriptor.key.add.shr2787
  %descriptor.key.add.mul189 = mul i64 %descriptor.key.add.xor2788, -7723592293110705685
  %descriptor.key.add.shr3190 = lshr i64 %descriptor.key.add.mul189, 31
  %descriptor.key.add91 = xor i64 %descriptor.key.add.mul189, %descriptor.key.add.shr3190
  %descriptor.key.rot.seed92 = xor i64 %descriptor.key.base71, -4417276739564004087
  %descriptor.key.rot.raw.add93 = add i64 %descriptor.key.rot.seed92, -7046029254386353131
  %descriptor.key.rot.raw.shr3094 = lshr i64 %descriptor.key.rot.raw.add93, 30
  %descriptor.key.rot.raw.xor3095 = xor i64 %descriptor.key.rot.raw.add93, %descriptor.key.rot.raw.shr3094
  %descriptor.key.rot.raw.mul096 = mul i64 %descriptor.key.rot.raw.xor3095, -4658895280553007687
  %descriptor.key.rot.raw.shr2797 = lshr i64 %descriptor.key.rot.raw.mul096, 27
  %descriptor.key.rot.raw.xor2798 = xor i64 %descriptor.key.rot.raw.mul096, %descriptor.key.rot.raw.shr2797
  %descriptor.key.rot.raw.mul199 = mul i64 %descriptor.key.rot.raw.xor2798, -7723592293110705685
  %descriptor.key.rot.raw.shr31100 = lshr i64 %descriptor.key.rot.raw.mul199, 31
  %descriptor.key.rot.raw101 = xor i64 %descriptor.key.rot.raw.mul199, %descriptor.key.rot.raw.shr31100
  %descriptor.key.rot.masked102 = and i64 %descriptor.key.rot.raw101, 63
  %descriptor.key.rot.zero103 = icmp eq i64 %descriptor.key.rot.masked102, 0
  %descriptor.key.rot104 = select i1 %descriptor.key.rot.zero103, i64 1, i64 %descriptor.key.rot.masked102
  %descriptor.code.len.unadd = sub i64 %descriptor.code.len.encrypted, %descriptor.key.add91
  %descriptor.code.len.unxor = xor i64 %descriptor.code.len.unadd, %descriptor.key.mask81
  %descriptor.code.len.plain.amount = and i64 %descriptor.key.rot104, 63
  %descriptor.code.len.plain.right = lshr i64 %descriptor.code.len.unxor, %descriptor.code.len.plain.amount
  %descriptor.code.len.plain.neg = sub i64 0, %descriptor.code.len.plain.amount
  %descriptor.code.len.plain.left.amount = and i64 %descriptor.code.len.plain.neg, 63
  %descriptor.code.len.plain.left = shl i64 %descriptor.code.len.unxor, %descriptor.code.len.plain.left.amount
  %descriptor.code.len.plain = or i64 %descriptor.code.len.plain.left, %descriptor.code.len.plain.right
  %descriptor.const.pool.offset.row = mul i64 %token.index, 8
  %descriptor.const.pool.offset.index = add i64 %descriptor.const.pool.offset.row, 2
  %descriptor.const.pool.offset.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.const.pool.offset.index
  %descriptor.const.pool.offset.encrypted = load i64, ptr %descriptor.const.pool.offset.ptr, align 8
  %descriptor.key.index105 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed106 = xor i64 %descriptor.key.index105, 8148024752428435680
  %descriptor.key.base107 = xor i64 %descriptor.key.seed106, 5424213885789314638
  %descriptor.key.mask.seed108 = xor i64 %descriptor.key.base107, 8100178437174699977
  %descriptor.key.mask.add109 = add i64 %descriptor.key.mask.seed108, -7046029254386353131
  %descriptor.key.mask.shr30110 = lshr i64 %descriptor.key.mask.add109, 30
  %descriptor.key.mask.xor30111 = xor i64 %descriptor.key.mask.add109, %descriptor.key.mask.shr30110
  %descriptor.key.mask.mul0112 = mul i64 %descriptor.key.mask.xor30111, -4658895280553007687
  %descriptor.key.mask.shr27113 = lshr i64 %descriptor.key.mask.mul0112, 27
  %descriptor.key.mask.xor27114 = xor i64 %descriptor.key.mask.mul0112, %descriptor.key.mask.shr27113
  %descriptor.key.mask.mul1115 = mul i64 %descriptor.key.mask.xor27114, -7723592293110705685
  %descriptor.key.mask.shr31116 = lshr i64 %descriptor.key.mask.mul1115, 31
  %descriptor.key.mask117 = xor i64 %descriptor.key.mask.mul1115, %descriptor.key.mask.shr31116
  %descriptor.key.add.seed118 = xor i64 %descriptor.key.base107, -7209929243056714667
  %descriptor.key.add.add119 = add i64 %descriptor.key.add.seed118, -7046029254386353131
  %descriptor.key.add.shr30120 = lshr i64 %descriptor.key.add.add119, 30
  %descriptor.key.add.xor30121 = xor i64 %descriptor.key.add.add119, %descriptor.key.add.shr30120
  %descriptor.key.add.mul0122 = mul i64 %descriptor.key.add.xor30121, -4658895280553007687
  %descriptor.key.add.shr27123 = lshr i64 %descriptor.key.add.mul0122, 27
  %descriptor.key.add.xor27124 = xor i64 %descriptor.key.add.mul0122, %descriptor.key.add.shr27123
  %descriptor.key.add.mul1125 = mul i64 %descriptor.key.add.xor27124, -7723592293110705685
  %descriptor.key.add.shr31126 = lshr i64 %descriptor.key.add.mul1125, 31
  %descriptor.key.add127 = xor i64 %descriptor.key.add.mul1125, %descriptor.key.add.shr31126
  %descriptor.key.rot.seed128 = xor i64 %descriptor.key.base107, -4417276739564004087
  %descriptor.key.rot.raw.add129 = add i64 %descriptor.key.rot.seed128, -7046029254386353131
  %descriptor.key.rot.raw.shr30130 = lshr i64 %descriptor.key.rot.raw.add129, 30
  %descriptor.key.rot.raw.xor30131 = xor i64 %descriptor.key.rot.raw.add129, %descriptor.key.rot.raw.shr30130
  %descriptor.key.rot.raw.mul0132 = mul i64 %descriptor.key.rot.raw.xor30131, -4658895280553007687
  %descriptor.key.rot.raw.shr27133 = lshr i64 %descriptor.key.rot.raw.mul0132, 27
  %descriptor.key.rot.raw.xor27134 = xor i64 %descriptor.key.rot.raw.mul0132, %descriptor.key.rot.raw.shr27133
  %descriptor.key.rot.raw.mul1135 = mul i64 %descriptor.key.rot.raw.xor27134, -7723592293110705685
  %descriptor.key.rot.raw.shr31136 = lshr i64 %descriptor.key.rot.raw.mul1135, 31
  %descriptor.key.rot.raw137 = xor i64 %descriptor.key.rot.raw.mul1135, %descriptor.key.rot.raw.shr31136
  %descriptor.key.rot.masked138 = and i64 %descriptor.key.rot.raw137, 63
  %descriptor.key.rot.zero139 = icmp eq i64 %descriptor.key.rot.masked138, 0
  %descriptor.key.rot140 = select i1 %descriptor.key.rot.zero139, i64 1, i64 %descriptor.key.rot.masked138
  %descriptor.const.pool.offset.unadd = sub i64 %descriptor.const.pool.offset.encrypted, %descriptor.key.add127
  %descriptor.const.pool.offset.unxor = xor i64 %descriptor.const.pool.offset.unadd, %descriptor.key.mask117
  %descriptor.const.pool.offset.plain.amount = and i64 %descriptor.key.rot140, 63
  %descriptor.const.pool.offset.plain.right = lshr i64 %descriptor.const.pool.offset.unxor, %descriptor.const.pool.offset.plain.amount
  %descriptor.const.pool.offset.plain.neg = sub i64 0, %descriptor.const.pool.offset.plain.amount
  %descriptor.const.pool.offset.plain.left.amount = and i64 %descriptor.const.pool.offset.plain.neg, 63
  %descriptor.const.pool.offset.plain.left = shl i64 %descriptor.const.pool.offset.unxor, %descriptor.const.pool.offset.plain.left.amount
  %descriptor.const.pool.offset.plain = or i64 %descriptor.const.pool.offset.plain.left, %descriptor.const.pool.offset.plain.right
  %descriptor.const.pool.len.row = mul i64 %token.index, 8
  %descriptor.const.pool.len.index = add i64 %descriptor.const.pool.len.row, 3
  %descriptor.const.pool.len.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.const.pool.len.index
  %descriptor.const.pool.len.encrypted = load i64, ptr %descriptor.const.pool.len.ptr, align 8
  %descriptor.key.index141 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed142 = xor i64 %descriptor.key.index141, 8148024752428435680
  %descriptor.key.base143 = xor i64 %descriptor.key.seed142, -1087051208170803851
  %descriptor.key.mask.seed144 = xor i64 %descriptor.key.base143, 8100178437174699977
  %descriptor.key.mask.add145 = add i64 %descriptor.key.mask.seed144, -7046029254386353131
  %descriptor.key.mask.shr30146 = lshr i64 %descriptor.key.mask.add145, 30
  %descriptor.key.mask.xor30147 = xor i64 %descriptor.key.mask.add145, %descriptor.key.mask.shr30146
  %descriptor.key.mask.mul0148 = mul i64 %descriptor.key.mask.xor30147, -4658895280553007687
  %descriptor.key.mask.shr27149 = lshr i64 %descriptor.key.mask.mul0148, 27
  %descriptor.key.mask.xor27150 = xor i64 %descriptor.key.mask.mul0148, %descriptor.key.mask.shr27149
  %descriptor.key.mask.mul1151 = mul i64 %descriptor.key.mask.xor27150, -7723592293110705685
  %descriptor.key.mask.shr31152 = lshr i64 %descriptor.key.mask.mul1151, 31
  %descriptor.key.mask153 = xor i64 %descriptor.key.mask.mul1151, %descriptor.key.mask.shr31152
  %descriptor.key.add.seed154 = xor i64 %descriptor.key.base143, -7209929243056714667
  %descriptor.key.add.add155 = add i64 %descriptor.key.add.seed154, -7046029254386353131
  %descriptor.key.add.shr30156 = lshr i64 %descriptor.key.add.add155, 30
  %descriptor.key.add.xor30157 = xor i64 %descriptor.key.add.add155, %descriptor.key.add.shr30156
  %descriptor.key.add.mul0158 = mul i64 %descriptor.key.add.xor30157, -4658895280553007687
  %descriptor.key.add.shr27159 = lshr i64 %descriptor.key.add.mul0158, 27
  %descriptor.key.add.xor27160 = xor i64 %descriptor.key.add.mul0158, %descriptor.key.add.shr27159
  %descriptor.key.add.mul1161 = mul i64 %descriptor.key.add.xor27160, -7723592293110705685
  %descriptor.key.add.shr31162 = lshr i64 %descriptor.key.add.mul1161, 31
  %descriptor.key.add163 = xor i64 %descriptor.key.add.mul1161, %descriptor.key.add.shr31162
  %descriptor.key.rot.seed164 = xor i64 %descriptor.key.base143, -4417276739564004087
  %descriptor.key.rot.raw.add165 = add i64 %descriptor.key.rot.seed164, -7046029254386353131
  %descriptor.key.rot.raw.shr30166 = lshr i64 %descriptor.key.rot.raw.add165, 30
  %descriptor.key.rot.raw.xor30167 = xor i64 %descriptor.key.rot.raw.add165, %descriptor.key.rot.raw.shr30166
  %descriptor.key.rot.raw.mul0168 = mul i64 %descriptor.key.rot.raw.xor30167, -4658895280553007687
  %descriptor.key.rot.raw.shr27169 = lshr i64 %descriptor.key.rot.raw.mul0168, 27
  %descriptor.key.rot.raw.xor27170 = xor i64 %descriptor.key.rot.raw.mul0168, %descriptor.key.rot.raw.shr27169
  %descriptor.key.rot.raw.mul1171 = mul i64 %descriptor.key.rot.raw.xor27170, -7723592293110705685
  %descriptor.key.rot.raw.shr31172 = lshr i64 %descriptor.key.rot.raw.mul1171, 31
  %descriptor.key.rot.raw173 = xor i64 %descriptor.key.rot.raw.mul1171, %descriptor.key.rot.raw.shr31172
  %descriptor.key.rot.masked174 = and i64 %descriptor.key.rot.raw173, 63
  %descriptor.key.rot.zero175 = icmp eq i64 %descriptor.key.rot.masked174, 0
  %descriptor.key.rot176 = select i1 %descriptor.key.rot.zero175, i64 1, i64 %descriptor.key.rot.masked174
  %descriptor.const.pool.len.unadd = sub i64 %descriptor.const.pool.len.encrypted, %descriptor.key.add163
  %descriptor.const.pool.len.unxor = xor i64 %descriptor.const.pool.len.unadd, %descriptor.key.mask153
  %descriptor.const.pool.len.plain.amount = and i64 %descriptor.key.rot176, 63
  %descriptor.const.pool.len.plain.right = lshr i64 %descriptor.const.pool.len.unxor, %descriptor.const.pool.len.plain.amount
  %descriptor.const.pool.len.plain.neg = sub i64 0, %descriptor.const.pool.len.plain.amount
  %descriptor.const.pool.len.plain.left.amount = and i64 %descriptor.const.pool.len.plain.neg, 63
  %descriptor.const.pool.len.plain.left = shl i64 %descriptor.const.pool.len.unxor, %descriptor.const.pool.len.plain.left.amount
  %descriptor.const.pool.len.plain = or i64 %descriptor.const.pool.len.plain.left, %descriptor.const.pool.len.plain.right
  %descriptor.bytecode.key.row = mul i64 %token.index, 8
  %descriptor.bytecode.key.index = add i64 %descriptor.bytecode.key.row, 4
  %descriptor.bytecode.key.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.bytecode.key.index
  %descriptor.bytecode.key.encrypted = load i64, ptr %descriptor.bytecode.key.ptr, align 8
  %descriptor.key.index177 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed178 = xor i64 %descriptor.key.index177, 8148024752428435680
  %descriptor.key.base179 = xor i64 %descriptor.key.seed178, -7598316302130922340
  %descriptor.key.mask.seed180 = xor i64 %descriptor.key.base179, 8100178437174699977
  %descriptor.key.mask.add181 = add i64 %descriptor.key.mask.seed180, -7046029254386353131
  %descriptor.key.mask.shr30182 = lshr i64 %descriptor.key.mask.add181, 30
  %descriptor.key.mask.xor30183 = xor i64 %descriptor.key.mask.add181, %descriptor.key.mask.shr30182
  %descriptor.key.mask.mul0184 = mul i64 %descriptor.key.mask.xor30183, -4658895280553007687
  %descriptor.key.mask.shr27185 = lshr i64 %descriptor.key.mask.mul0184, 27
  %descriptor.key.mask.xor27186 = xor i64 %descriptor.key.mask.mul0184, %descriptor.key.mask.shr27185
  %descriptor.key.mask.mul1187 = mul i64 %descriptor.key.mask.xor27186, -7723592293110705685
  %descriptor.key.mask.shr31188 = lshr i64 %descriptor.key.mask.mul1187, 31
  %descriptor.key.mask189 = xor i64 %descriptor.key.mask.mul1187, %descriptor.key.mask.shr31188
  %descriptor.key.add.seed190 = xor i64 %descriptor.key.base179, -7209929243056714667
  %descriptor.key.add.add191 = add i64 %descriptor.key.add.seed190, -7046029254386353131
  %descriptor.key.add.shr30192 = lshr i64 %descriptor.key.add.add191, 30
  %descriptor.key.add.xor30193 = xor i64 %descriptor.key.add.add191, %descriptor.key.add.shr30192
  %descriptor.key.add.mul0194 = mul i64 %descriptor.key.add.xor30193, -4658895280553007687
  %descriptor.key.add.shr27195 = lshr i64 %descriptor.key.add.mul0194, 27
  %descriptor.key.add.xor27196 = xor i64 %descriptor.key.add.mul0194, %descriptor.key.add.shr27195
  %descriptor.key.add.mul1197 = mul i64 %descriptor.key.add.xor27196, -7723592293110705685
  %descriptor.key.add.shr31198 = lshr i64 %descriptor.key.add.mul1197, 31
  %descriptor.key.add199 = xor i64 %descriptor.key.add.mul1197, %descriptor.key.add.shr31198
  %descriptor.key.rot.seed200 = xor i64 %descriptor.key.base179, -4417276739564004087
  %descriptor.key.rot.raw.add201 = add i64 %descriptor.key.rot.seed200, -7046029254386353131
  %descriptor.key.rot.raw.shr30202 = lshr i64 %descriptor.key.rot.raw.add201, 30
  %descriptor.key.rot.raw.xor30203 = xor i64 %descriptor.key.rot.raw.add201, %descriptor.key.rot.raw.shr30202
  %descriptor.key.rot.raw.mul0204 = mul i64 %descriptor.key.rot.raw.xor30203, -4658895280553007687
  %descriptor.key.rot.raw.shr27205 = lshr i64 %descriptor.key.rot.raw.mul0204, 27
  %descriptor.key.rot.raw.xor27206 = xor i64 %descriptor.key.rot.raw.mul0204, %descriptor.key.rot.raw.shr27205
  %descriptor.key.rot.raw.mul1207 = mul i64 %descriptor.key.rot.raw.xor27206, -7723592293110705685
  %descriptor.key.rot.raw.shr31208 = lshr i64 %descriptor.key.rot.raw.mul1207, 31
  %descriptor.key.rot.raw209 = xor i64 %descriptor.key.rot.raw.mul1207, %descriptor.key.rot.raw.shr31208
  %descriptor.key.rot.masked210 = and i64 %descriptor.key.rot.raw209, 63
  %descriptor.key.rot.zero211 = icmp eq i64 %descriptor.key.rot.masked210, 0
  %descriptor.key.rot212 = select i1 %descriptor.key.rot.zero211, i64 1, i64 %descriptor.key.rot.masked210
  %descriptor.bytecode.key.unadd = sub i64 %descriptor.bytecode.key.encrypted, %descriptor.key.add199
  %descriptor.bytecode.key.unxor = xor i64 %descriptor.bytecode.key.unadd, %descriptor.key.mask189
  %descriptor.bytecode.key.plain.amount = and i64 %descriptor.key.rot212, 63
  %descriptor.bytecode.key.plain.right = lshr i64 %descriptor.bytecode.key.unxor, %descriptor.bytecode.key.plain.amount
  %descriptor.bytecode.key.plain.neg = sub i64 0, %descriptor.bytecode.key.plain.amount
  %descriptor.bytecode.key.plain.left.amount = and i64 %descriptor.bytecode.key.plain.neg, 63
  %descriptor.bytecode.key.plain.left = shl i64 %descriptor.bytecode.key.unxor, %descriptor.bytecode.key.plain.left.amount
  %descriptor.bytecode.key.plain = or i64 %descriptor.bytecode.key.plain.left, %descriptor.bytecode.key.plain.right
  %descriptor.native.base.row = mul i64 %token.index, 8
  %descriptor.native.base.index = add i64 %descriptor.native.base.row, 5
  %descriptor.native.base.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.native.base.index
  %descriptor.native.base.encrypted = load i64, ptr %descriptor.native.base.ptr, align 8
  %descriptor.key.index213 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed214 = xor i64 %descriptor.key.index213, 8148024752428435680
  %descriptor.key.base215 = xor i64 %descriptor.key.seed214, 4337162677618510787
  %descriptor.key.mask.seed216 = xor i64 %descriptor.key.base215, 8100178437174699977
  %descriptor.key.mask.add217 = add i64 %descriptor.key.mask.seed216, -7046029254386353131
  %descriptor.key.mask.shr30218 = lshr i64 %descriptor.key.mask.add217, 30
  %descriptor.key.mask.xor30219 = xor i64 %descriptor.key.mask.add217, %descriptor.key.mask.shr30218
  %descriptor.key.mask.mul0220 = mul i64 %descriptor.key.mask.xor30219, -4658895280553007687
  %descriptor.key.mask.shr27221 = lshr i64 %descriptor.key.mask.mul0220, 27
  %descriptor.key.mask.xor27222 = xor i64 %descriptor.key.mask.mul0220, %descriptor.key.mask.shr27221
  %descriptor.key.mask.mul1223 = mul i64 %descriptor.key.mask.xor27222, -7723592293110705685
  %descriptor.key.mask.shr31224 = lshr i64 %descriptor.key.mask.mul1223, 31
  %descriptor.key.mask225 = xor i64 %descriptor.key.mask.mul1223, %descriptor.key.mask.shr31224
  %descriptor.key.add.seed226 = xor i64 %descriptor.key.base215, -7209929243056714667
  %descriptor.key.add.add227 = add i64 %descriptor.key.add.seed226, -7046029254386353131
  %descriptor.key.add.shr30228 = lshr i64 %descriptor.key.add.add227, 30
  %descriptor.key.add.xor30229 = xor i64 %descriptor.key.add.add227, %descriptor.key.add.shr30228
  %descriptor.key.add.mul0230 = mul i64 %descriptor.key.add.xor30229, -4658895280553007687
  %descriptor.key.add.shr27231 = lshr i64 %descriptor.key.add.mul0230, 27
  %descriptor.key.add.xor27232 = xor i64 %descriptor.key.add.mul0230, %descriptor.key.add.shr27231
  %descriptor.key.add.mul1233 = mul i64 %descriptor.key.add.xor27232, -7723592293110705685
  %descriptor.key.add.shr31234 = lshr i64 %descriptor.key.add.mul1233, 31
  %descriptor.key.add235 = xor i64 %descriptor.key.add.mul1233, %descriptor.key.add.shr31234
  %descriptor.key.rot.seed236 = xor i64 %descriptor.key.base215, -4417276739564004087
  %descriptor.key.rot.raw.add237 = add i64 %descriptor.key.rot.seed236, -7046029254386353131
  %descriptor.key.rot.raw.shr30238 = lshr i64 %descriptor.key.rot.raw.add237, 30
  %descriptor.key.rot.raw.xor30239 = xor i64 %descriptor.key.rot.raw.add237, %descriptor.key.rot.raw.shr30238
  %descriptor.key.rot.raw.mul0240 = mul i64 %descriptor.key.rot.raw.xor30239, -4658895280553007687
  %descriptor.key.rot.raw.shr27241 = lshr i64 %descriptor.key.rot.raw.mul0240, 27
  %descriptor.key.rot.raw.xor27242 = xor i64 %descriptor.key.rot.raw.mul0240, %descriptor.key.rot.raw.shr27241
  %descriptor.key.rot.raw.mul1243 = mul i64 %descriptor.key.rot.raw.xor27242, -7723592293110705685
  %descriptor.key.rot.raw.shr31244 = lshr i64 %descriptor.key.rot.raw.mul1243, 31
  %descriptor.key.rot.raw245 = xor i64 %descriptor.key.rot.raw.mul1243, %descriptor.key.rot.raw.shr31244
  %descriptor.key.rot.masked246 = and i64 %descriptor.key.rot.raw245, 63
  %descriptor.key.rot.zero247 = icmp eq i64 %descriptor.key.rot.masked246, 0
  %descriptor.key.rot248 = select i1 %descriptor.key.rot.zero247, i64 1, i64 %descriptor.key.rot.masked246
  %descriptor.native.base.unadd = sub i64 %descriptor.native.base.encrypted, %descriptor.key.add235
  %descriptor.native.base.unxor = xor i64 %descriptor.native.base.unadd, %descriptor.key.mask225
  %descriptor.native.base.plain.amount = and i64 %descriptor.key.rot248, 63
  %descriptor.native.base.plain.right = lshr i64 %descriptor.native.base.unxor, %descriptor.native.base.plain.amount
  %descriptor.native.base.plain.neg = sub i64 0, %descriptor.native.base.plain.amount
  %descriptor.native.base.plain.left.amount = and i64 %descriptor.native.base.plain.neg, 63
  %descriptor.native.base.plain.left = shl i64 %descriptor.native.base.unxor, %descriptor.native.base.plain.left.amount
  %descriptor.native.base.plain = or i64 %descriptor.native.base.plain.left, %descriptor.native.base.plain.right
  %descriptor.native.count.row = mul i64 %token.index, 8
  %descriptor.native.count.index = add i64 %descriptor.native.count.row, 6
  %descriptor.native.count.ptr = getelementptr inbounds [32 x i64], ptr @.amice.vm.descriptor_table.helper_add.n4.h711399579d9648e0, i64 0, i64 %descriptor.native.count.index
  %descriptor.native.count.encrypted = load i64, ptr %descriptor.native.count.ptr, align 8
  %descriptor.key.index249 = mul i64 %token.index, -2960836687051489901
  %descriptor.key.seed250 = xor i64 %descriptor.key.index249, 8148024752428435680
  %descriptor.key.base251 = xor i64 %descriptor.key.seed250, -2174102416341607702
  %descriptor.key.mask.seed252 = xor i64 %descriptor.key.base251, 8100178437174699977
  %descriptor.key.mask.add253 = add i64 %descriptor.key.mask.seed252, -7046029254386353131
  %descriptor.key.mask.shr30254 = lshr i64 %descriptor.key.mask.add253, 30
  %descriptor.key.mask.xor30255 = xor i64 %descriptor.key.mask.add253, %descriptor.key.mask.shr30254
  %descriptor.key.mask.mul0256 = mul i64 %descriptor.key.mask.xor30255, -4658895280553007687
  %descriptor.key.mask.shr27257 = lshr i64 %descriptor.key.mask.mul0256, 27
  %descriptor.key.mask.xor27258 = xor i64 %descriptor.key.mask.mul0256, %descriptor.key.mask.shr27257
  %descriptor.key.mask.mul1259 = mul i64 %descriptor.key.mask.xor27258, -7723592293110705685
  %descriptor.key.mask.shr31260 = lshr i64 %descriptor.key.mask.mul1259, 31
  %descriptor.key.mask261 = xor i64 %descriptor.key.mask.mul1259, %descriptor.key.mask.shr31260
  %descriptor.key.add.seed262 = xor i64 %descriptor.key.base251, -7209929243056714667
  %descriptor.key.add.add263 = add i64 %descriptor.key.add.seed262, -7046029254386353131
  %descriptor.key.add.shr30264 = lshr i64 %descriptor.key.add.add263, 30
  %descriptor.key.add.xor30265 = xor i64 %descriptor.key.add.add263, %descriptor.key.add.shr30264
  %descriptor.key.add.mul0266 = mul i64 %descriptor.key.add.xor30265, -4658895280553007687
  %descriptor.key.add.shr27267 = lshr i64 %descriptor.key.add.mul0266, 27
  %descriptor.key.add.xor27268 = xor i64 %descriptor.key.add.mul0266, %descriptor.key.add.shr27267
  %descriptor.key.add.mul1269 = mul i64 %descriptor.key.add.xor27268, -7723592293110705685
  %descriptor.key.add.shr31270 = lshr i64 %descriptor.key.add.mul1269, 31
  %descriptor.key.add271 = xor i64 %descriptor.key.add.mul1269, %descriptor.key.add.shr31270
  %descriptor.key.rot.seed272 = xor i64 %descriptor.key.base251, -4417276739564004087
  %descriptor.key.rot.raw.add273 = add i64 %descriptor.key.rot.seed272, -7046029254386353131
  %descriptor.key.rot.raw.shr30274 = lshr i64 %descriptor.key.rot.raw.add273, 30
  %descriptor.key.rot.raw.xor30275 = xor i64 %descriptor.key.rot.raw.add273, %descriptor.key.rot.raw.shr30274
  %descriptor.key.rot.raw.mul0276 = mul i64 %descriptor.key.rot.raw.xor30275, -4658895280553007687
  %descriptor.key.rot.raw.shr27277 = lshr i64 %descriptor.key.rot.raw.mul0276, 27
  %descriptor.key.rot.raw.xor27278 = xor i64 %descriptor.key.rot.raw.mul0276, %descriptor.key.rot.raw.shr27277
  %descriptor.key.rot.raw.mul1279 = mul i64 %descriptor.key.rot.raw.xor27278, -7723592293110705685
  %descriptor.key.rot.raw.shr31280 = lshr i64 %descriptor.key.rot.raw.mul1279, 31
  %descriptor.key.rot.raw281 = xor i64 %descriptor.key.rot.raw.mul1279, %descriptor.key.rot.raw.shr31280
  %descriptor.key.rot.masked282 = and i64 %descriptor.key.rot.raw281, 63
  %descriptor.key.rot.zero283 = icmp eq i64 %descriptor.key.rot.masked282, 0
  %descriptor.key.rot284 = select i1 %descriptor.key.rot.zero283, i64 1, i64 %descriptor.key.rot.masked282
  %descriptor.native.count.unadd = sub i64 %descriptor.native.count.encrypted, %descriptor.key.add271
  %descriptor.native.count.unxor = xor i64 %descriptor.native.count.unadd, %descriptor.key.mask261
  %descriptor.native.count.plain.amount = and i64 %descriptor.key.rot284, 63
  %descriptor.native.count.plain.right = lshr i64 %descriptor.native.count.unxor, %descriptor.native.count.plain.amount
  %descriptor.native.count.plain.neg = sub i64 0, %descriptor.native.count.plain.amount
  %descriptor.native.count.plain.left.amount = and i64 %descriptor.native.count.plain.neg, 63
  %descriptor.native.count.plain.left = shl i64 %descriptor.native.count.unxor, %descriptor.native.count.plain.left.amount
  %descriptor.native.count.plain = or i64 %descriptor.native.count.plain.left, %descriptor.native.count.plain.right
  %descriptor.code.ptr = getelementptr i8, ptr @.amice.vm.bytecode.module.helper_add.n4.h711399579d9648e0, i64 %descriptor.code.offset.plain
  %descriptor.const.pool.ptr = getelementptr i8, ptr @.amice.vm.bytecode.module.helper_add.n4.h711399579d9648e0, i64 %descriptor.const.pool.offset.plain
  %arg.slot = getelementptr [16 x i64], ptr %2, i64 0, i64 0
  %arg.value = load i64, ptr %arg.slot, align 8
  %reg.store.ptr285 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  store i64 %arg.value, ptr %reg.store.ptr285, align 8
  %arg.slot286 = getelementptr [16 x i64], ptr %2, i64 0, i64 1
  %arg.value287 = load i64, ptr %arg.slot286, align 8
  %reg.store.ptr288 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 1
  store i64 %arg.value287, ptr %reg.store.ptr288, align 8
  %arg.slot289 = getelementptr [16 x i64], ptr %2, i64 0, i64 2
  %arg.value290 = load i64, ptr %arg.slot289, align 8
  %reg.store.ptr291 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 2
  store i64 %arg.value290, ptr %reg.store.ptr291, align 8
  %arg.slot292 = getelementptr [16 x i64], ptr %2, i64 0, i64 3
  %arg.value293 = load i64, ptr %arg.slot292, align 8
  %reg.store.ptr294 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 3
  store i64 %arg.value293, ptr %reg.store.ptr294, align 8
  %arg.slot295 = getelementptr [16 x i64], ptr %2, i64 0, i64 4
  %arg.value296 = load i64, ptr %arg.slot295, align 8
  %reg.store.ptr297 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 4
  store i64 %arg.value296, ptr %reg.store.ptr297, align 8
  %arg.slot298 = getelementptr [16 x i64], ptr %2, i64 0, i64 5
  %arg.value299 = load i64, ptr %arg.slot298, align 8
  %reg.store.ptr300 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 5
  store i64 %arg.value299, ptr %reg.store.ptr300, align 8
  %arg.slot301 = getelementptr [16 x i64], ptr %2, i64 0, i64 6
  %arg.value302 = load i64, ptr %arg.slot301, align 8
  %reg.store.ptr303 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 6
  store i64 %arg.value302, ptr %reg.store.ptr303, align 8
  %arg.slot304 = getelementptr [16 x i64], ptr %2, i64 0, i64 7
  %arg.value305 = load i64, ptr %arg.slot304, align 8
  %reg.store.ptr306 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 7
  store i64 %arg.value305, ptr %reg.store.ptr306, align 8
  %arg.slot307 = getelementptr [16 x i64], ptr %2, i64 0, i64 8
  %arg.value308 = load i64, ptr %arg.slot307, align 8
  %reg.store.ptr309 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 8
  store i64 %arg.value308, ptr %reg.store.ptr309, align 8
  %arg.slot310 = getelementptr [16 x i64], ptr %2, i64 0, i64 9
  %arg.value311 = load i64, ptr %arg.slot310, align 8
  %reg.store.ptr312 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 9
  store i64 %arg.value311, ptr %reg.store.ptr312, align 8
  %arg.slot313 = getelementptr [16 x i64], ptr %2, i64 0, i64 10
  %arg.value314 = load i64, ptr %arg.slot313, align 8
  %reg.store.ptr315 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 10
  store i64 %arg.value314, ptr %reg.store.ptr315, align 8
  %arg.slot316 = getelementptr [16 x i64], ptr %2, i64 0, i64 11
  %arg.value317 = load i64, ptr %arg.slot316, align 8
  %reg.store.ptr318 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 11
  store i64 %arg.value317, ptr %reg.store.ptr318, align 8
  %arg.slot319 = getelementptr [16 x i64], ptr %2, i64 0, i64 12
  %arg.value320 = load i64, ptr %arg.slot319, align 8
  %reg.store.ptr321 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 12
  store i64 %arg.value320, ptr %reg.store.ptr321, align 8
  %arg.slot322 = getelementptr [16 x i64], ptr %2, i64 0, i64 13
  %arg.value323 = load i64, ptr %arg.slot322, align 8
  %reg.store.ptr324 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 13
  store i64 %arg.value323, ptr %reg.store.ptr324, align 8
  %arg.slot325 = getelementptr [16 x i64], ptr %2, i64 0, i64 14
  %arg.value326 = load i64, ptr %arg.slot325, align 8
  %reg.store.ptr327 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 14
  store i64 %arg.value326, ptr %reg.store.ptr327, align 8
  %arg.slot328 = getelementptr [16 x i64], ptr %2, i64 0, i64 15
  %arg.value329 = load i64, ptr %arg.slot328, align 8
  %reg.store.ptr330 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 15
  store i64 %arg.value329, ptr %reg.store.ptr330, align 8
  br label %loop.check

loop.check:                                       ; preds = %handler.load_isdiv.op98d.split.body, %handler.memset_dyn.op141.split.body, %handler.trap.op9c4.split.body, %handler.iadd.op7a.split.body, %handler.volatile_atomic_rmw_umin.op968.split.body, %handler.fake_nop.op9b7.split.body, %handler.fcos.op8c7.split.body, %handler.const_load.op804.split.body, %handler.sitofp.opbb.split.body, %handler.fminimum.op8ac.split.body, %handler.ixor.op853.split.body, %handler.iadd_xor.op83d.split.body, %handler.volatile_memcpy_dyn.op91c.split.body, %handler.volatile_cmpxchg.op97f.split.body, %handler.memmove_dyn.op145.split.body, %handler.ret.op59.split.body, %handler.trunc.op32.split.body, %handler.ior.op15.split.body, %handler.volatile_atomic_store.op177.split.body, %handler.isdiv.op89.split.body, %handler.volatile_atomic_rmw_uinc_wrap.op196.split.body, %handler.fshl.op894.split.body, %handler.iabs.op118.split.body, %handler.load_ismax.op99a.split.body, %handler.bitreverse.op105.split.body, %handler.flround.op73b.split.body, %handler.load_isub.op9b2.split.body, %handler.ishl.op2b.split.body, %handler.stackrestore.op906.split.body, %handler.fadd.op897.split.body, %handler.clear_cache.op908.split.body, %handler.ctpop.op888.split.body, %handler.reset_fpmode.op830.split.body, %handler.fminnum.op70a.split.body, %handler.issub_overflow.op134.split.body, %handler.write_fpmode.op82e.split.body, %handler.load.op35.split.body, %handler.atomic_rmw_fadd.op947.split.body, %handler.br.op40.split.body, %handler.fllround.op73c.split.body, %handler.frint.op71c.split.body, %handler.fcopysign.op8a2.split.body, %handler.fsqrt.op8b4.split.body, %handler.sitofp.op8d7.split.body, %handler.icmp.op52.split.body, %handler.fcmp.opaf.split.body, %handler.reset_fpmode.op1cf.split.body, %handler.icmp.op5e.split.body, %handler.volatile_memset_dyn.op920.split.body, %handler.fdiv.opa6.split.body, %handler.volatile_atomic_rmw_umax.op965.split.body, %handler.read_steady.op812.split.body, %handler.atomic_rmw_usub_cond.op170.split.body, %handler.atomic_load.op922.split.body, %handler.fneg.opb5.split.body, %handler.memcpy_dyn.op144.split.body, %handler.vm_ret.op29.split.body, %handler.global_addr.op13d.split.body, %handler.fptosi.op8dc.split.body, %handler.ismin.op11c.split.body, %handler.froundeven.op8c4.split.body, %handler.store.op911.split.body, %handler.atomic_rmw_add.ope2.split.body, %handler.fake_nop.op39.split.body, %handler.volatile_atomic_rmw_umax.op192.split.body, %handler.fsub.op899.split.body, %handler.volatile_atomic_rmw_fminimum.op1a9.split.body, %handler.volatile_atomic_rmw_min.op190.split.body, %handler.load_ilshr.op1e4.split.body, %handler.volatile_atomic_rmw_min.op191.split.body, %handler.volatile_atomic_rmw_fsub.op974.split.body, %handler.ctlz.op114.split.body, %handler.fadd.op96.split.body, %handler.flog.op72d.split.body, %handler.atomic_rmw_max.opf2.split.body, %handler.isub.op66.split.body, %handler.atomic_rmw_xor.opeb.split.body, %handler.uitofp.opbc.split.body, %handler.ismin.op11b.split.body, %handler.iurem.op84c.split.body, %handler.unreachable.opde.split.body, %handler.volatile_load.op148.split.body, %handler.trunc.op8fc.split.body, %handler.pseudoprobe.op1b7.split.body, %handler.iadd_xor.op10c.split.body, %handler.reset_fpenv.op827.split.body, %handler.fptoui.opc6.split.body, %handler.load_ilshr.op1e5.split.body, %handler.load_isdiv.op1dc.split.body, %handler.iadd.op5a.split.body, %handler.atomic_rmw_xor.opea.split.body, %handler.write_fpenv.op1c7.split.body, %handler.volatile_atomic_rmw_nand.op18c.split.body, %handler.issub_sat.op875.split.body, %handler.read_vscale.op815.split.body, %handler.fllrint.op739.split.body, %handler.atomic_rmw_uinc_wrap.op93f.split.body, %handler.fptoui_sat.op1bb.split.body, %handler.memcpy_dyn.op916.split.body, %handler.fneg.op8af.split.body, %handler.atomic_rmw_and.op930.split.body, %handler.gep.op983.split.body, %handler.fabs.op702.split.body, %handler.volatile_atomic_rmw_umax.op966.split.body, %handler.volatile_load.op147.split.body, %handler.const_load.op0a.split.body, %handler.iumul_overflow.op136.split.body, %handler.alloca.op55.split.body, %handler.volatile_atomic_rmw_add.op955.split.body, %handler.clear_cache.op1b5.split.body, %handler.read_thread_pointer.op1c0.split.body, %handler.fcmp.op8f3.split.body, %handler.iushl_sat.op129.split.body, %handler.atomic_rmw_usub_sat.op946.split.body, %handler.ffloor.op8b7.split.body, %handler.alloca_dyn.op902.split.body, %handler.load_isadd_sat.op9a6.split.body, %handler.read_fpenv.op821.split.body, %handler.pseudoprobe.op1b6.split.body, %handler.atomic_rmw_fmin.op94e.split.body, %handler.isdiv.op88.split.body, %handler.mov_imm.op4f.split.body, %handler.read_fpmode.op82b.split.body, %handler.reset_fpenv.op829.split.body, %handler.load_issub_sat.op1f6.split.body, %handler.fmul.op9f.split.body, %handler.load_ixor.op9b4.split.body, %handler.fneg.opb6.split.body, %handler.uitofp.opbe.split.body, %handler.volatile_atomic_rmw_min.op964.split.body, %handler.atomic_rmw_fadd.op161.split.body, %handler.atomic_load.opd5.split.body, %handler.fptrunc.opcf.split.body, %handler.mov.op56.split.body, %handler.fadd.op95.split.body, %handler.const_load.op805.split.body, %handler.ffmuladd.op8d5.split.body, %handler.fpext.opd0.split.body, %handler.write_fpmode.op82f.split.body, %handler.fllrint.op738.split.body, %handler.read_rounding.op1bf.split.body, %handler.load_isshl_sat.op1fa.split.body, %handler.load_isadd_sat.op1f4.split.body, %handler.atomic_rmw_fsub.op94a.split.body, %handler.load_iushl_sat.op1f8.split.body, %handler.fmaximum.op8ad.split.body, %handler.load_ismin.op1ea.split.body, %handler.stackrestore.op905.split.body, %handler.fadd.op94.split.body, %handler.trunc.op2f.split.body, %handler.icmp.op20.split.body, %handler.ishl.op85f.split.body, %handler.store.op24.split.body, %handler.fptrunc.op8e3.split.body, %handler.mov_imm.op65.split.body, %handler.read_vscale.op1bd.split.body, %handler.bitcast.op33.split.body, %handler.read_cycle.op1aa.split.body, %handler.volatile_memmove_dyn.op17b.split.body, %handler.vm_ret.op9c0.split.body, %handler.fneg.op8b0.split.body, %handler.fcmp.op8f4.split.body, %handler.ffmuladd.op712.split.body, %handler.iumin.op11f.split.body, %handler.icmp_br_if.op8f2.split.body, %handler.read_rounding.op81a.split.body, %handler.volatile_atomic_rmw_usub_cond.op19b.split.body, %handler.isshl_sat.op12b.split.body, %handler.br_if.op9bb.split.body, %handler.ctpop.op101.split.body, %handler.fpext.opd1.split.body, %handler.fpow.op733.split.body, %handler.fsub.op9d.split.body, %handler.ior.op85a.split.body, %handler.fpclass.op8f6.split.body, %handler.atomic_rmw_umin.opf9.split.body, %handler.load_iashr.op1e7.split.body, %handler.iumax.op86b.split.body, %handler.ctpop.op887.split.body, %handler.reset_fpenv.op1c8.split.body, %handler.volatile_atomic_rmw_udec_wrap.op96b.split.body, %handler.volatile_memcpy_dyn.op178.split.body, %handler.load_imul.op98a.split.body, %handler.volatile_atomic_rmw_usub_cond.op19a.split.body, %handler.load_ismin.op1eb.split.body, %handler.icmp_br_if.op8f1.split.body, %handler.atomic_rmw_fmaximum.op169.split.body, %handler.global_addr.op13e.split.body, %handler.write_fpenv.op1c6.split.body, %handler.fneg.opb3.split.body, %handler.iumax.op86c.split.body, %handler.fptrunc.opcb.split.body, %handler.fptoui.op8de.split.body, %handler.fptosi_sat.op8df.split.body, %handler.fptosi.opc5.split.body, %handler.load_ishl.op1e2.split.body, %handler.gep.op22.split.body, %handler.isdiv.op86.split.body, %handler.pseudoprobe.op90a.split.body, %handler.load_iadd.op112.split.body, %handler.iumin.op86d.split.body, %handler.sext.op8fa.split.body, %handler.fpowi.op8a5.split.body, %handler.ismax.op119.split.body, %handler.volatile_atomic_rmw_max.op962.split.body, %handler.sideeffect.op837.split.body, %handler.fptoui_sat.op1ba.split.body, %handler.const_load.op5f.split.body, %handler.atomic_rmw_fminimum.op16b.split.body, %handler.volatile_atomic_rmw_or.op95b.split.body, %handler.isshl_sat.op87a.split.body, %handler.flround.op8ec.split.body, %handler.const_load.op03.split.body, %handler.read_thread_pointer.op834.split.body, %handler.fcos.op726.split.body, %handler.iumul_overflow.op884.split.body, %handler.volatile_atomic_rmw_usub_sat.op19d.split.body, %handler.tls_addr.op809.split.body, %handler.load_ixor.opfc.split.body, %handler.atomic_rmw_uinc_wrap.op16c.split.body, %handler.iurem.op8e.split.body, %handler.ctlz.op113.split.body, %handler.trunc.op1b.split.body, %handler.volatile_atomic_rmw_usub_cond.op96d.split.body, %handler.load_ior.op9b0.split.body, %handler.iudiv.op845.split.body, %handler.read_fpenv.op1c4.split.body, %handler.fmaximum.op711.split.body, %handler.volatile_atomic_rmw_or.op95c.split.body, %handler.isdiv.op84a.split.body, %handler.bswap.op103.split.body, %handler.call_native.op5b.split.body, %handler.ffloor.op716.split.body, %handler.volatile_atomic_rmw_fadd.op971.split.body, %handler.fsub.op89a.split.body, %handler.uitofp.opbf.split.body, %handler.volatile_memset_dyn.op91f.split.body, %handler.load_iurem.op1df.split.body, %handler.fpowi.op734.split.body, %handler.iashr.op863.split.body, %handler.volatile_memcpy_dyn.op179.split.body, %handler.cttz.op88b.split.body, %handler.load_iushl_sat.op9aa.split.body, %handler.load_iuadd_sat.op1f0.split.body, %handler.ishl.op85e.split.body, %handler.ishl.op16.split.body, %handler.iudiv.op80.split.body, %handler.icmp.op76.split.body, %handler.iusub_overflow.op132.split.body, %handler.load.op90d.split.body, %handler.write_rounding.op1c3.split.body, %handler.fsub.op9b.split.body, %handler.isrem.op93.split.body, %handler.atomic_rmw_fmax.op94b.split.body, %handler.read_cycle.op810.split.body, %handler.gep_load.op986.split.body, %handler.fence.op982.split.body, %handler.bitcast.op8fd.split.body, %handler.ishl.op78.split.body, %handler.volatile_atomic_rmw_fmaximum.op97a.split.body, %handler.fpext.op8e6.split.body, %handler.volatile_atomic_rmw_fmaximum.op1a6.split.body, %handler.fmaximum.op710.split.body, %handler.fcmp.opb0.split.body, %handler.sitofp.opb9.split.body, %handler.volatile_atomic_rmw_max.op961.split.body, %handler.bswap.op88f.split.body, %handler.volatile_atomic_rmw_fmin.op977.split.body, %handler.read_cycle.op811.split.body, %handler.iadd.op2c.split.body, %handler.fptoui.op8dd.split.body, %handler.fminimum.op70f.split.body, %handler.volatile_atomic_rmw_uinc_wrap.op96a.split.body, %handler.load_issub_sat.op9a8.split.body, %handler.mov.op807.split.body, %handler.fshr.op10a.split.body, %handler.fadd.op98.split.body, %handler.zext.op23.split.body, %handler.atomic_rmw_uinc_wrap.op940.split.body, %handler.ismax.op868.split.body, %handler.atomic_rmw_fmaximum.op94f.split.body, %handler.fceil.op8b9.split.body, %handler.iuadd_sat.op86f.split.body, %handler.iand.op856.split.body, %handler.load_iumin.op1ef.split.body, %handler.volatile_memset_dyn.op17d.split.body, %handler.ftrunc.op71b.split.body, %handler.iusub_sat.op123.split.body, %handler.fshl.op107.split.body, %handler.fptoui.opca.split.body, %handler.iadd_xor.op10b.split.body, %handler.atomic_rmw_xchg.ope0.split.body, %handler.zext.op63.split.body, %handler.fptrunc.opce.split.body, %handler.iurem.op84d.split.body, %handler.flog10.op72f.split.body, %handler.read_fpmode.op82a.split.body, %handler.load_iurem.op98f.split.body, %handler.atomic_rmw_xor.op933.split.body, %handler.atomic_rmw_max.op938.split.body, %handler.atomic_store.op924.split.body, %handler.bitreverse.op106.split.body, %handler.fcanonicalize.op715.split.body, %handler.ilshr.op862.split.body, %handler.iand.op14.split.body, %handler.load.op51.split.body, %handler.fadd.op97.split.body, %handler.prefetch.op90c.split.body, %handler.iumin.op86e.split.body, %handler.fmaxnum.op70c.split.body, %handler.read_vscale.op816.split.body, %handler.alloca.op0b.split.body, %handler.write_fpenv.op826.split.body, %handler.vm_ret.op9bf.split.body, %handler.sideeffect.op1ae.split.body, %handler.frem.opab.split.body, %handler.icmp.op8ef.split.body, %handler.ishl.op3c.split.body, %handler.atomic_rmw_sub.op92d.split.body, %handler.volatile_atomic_rmw_sub.op184.split.body, %handler.ixor.op2a.split.body, %handler.iuadd_sat.op121.split.body, %handler.flog2.op8d2.split.body, %handler.ilshr.op5c.split.body, %handler.fshl.op893.split.body, %handler.volatile_atomic_rmw_fminimum.op97b.split.body, %handler.issub_sat.op128.split.body, %handler.zext.op8f7.split.body, %handler.atomic_rmw_fadd.op948.split.body, %handler.isdiv.op85.split.body, %handler.fptosi.op8db.split.body, %handler.iusub_sat.op124.split.body, %handler.ixor.op6b.split.body, %handler.alloca.op05.split.body, %handler.isadd_overflow.op130.split.body, %handler.iadd.op83a.split.body, %handler.ior.op2e.split.body, %handler.flog10.op8cf.split.body, %handler.icmp.op1f.split.body, %handler.load_iusub_sat.op1f2.split.body, %handler.load_iuadd_sat.op9a1.split.body, %handler.frem.opa8.split.body, %handler.atomic_store.opda.split.body, %handler.load_ishl.op994.split.body, %handler.ffmuladd.op713.split.body, %handler.flrint.op8e8.split.body, %handler.fsub.op9a.split.body, %handler.ilshr.op861.split.body, %handler.load_isadd_sat.op9a5.split.body, %handler.isshl_sat.op12c.split.body, %handler.iusub_sat.op872.split.body, %handler.fpext.opd4.split.body, %handler.volatile_store.op149.split.body, %handler.fsub.op99.split.body, %handler.ffloor.op717.split.body, %handler.zext.op46.split.body, %handler.fllrint.op8ea.split.body, %handler.volatile_atomic_rmw_fminimum.op97c.split.body, %handler.fexp.op729.split.body, %handler.atomic_rmw_nand.opf0.split.body, %handler.fdiv.opa4.split.body, %handler.load_ismax.op1e9.split.body, %handler.load_iumax.op1ec.split.body, %handler.read_flt_rounds.op1d0.split.body, %handler.sext.op7d.split.body, %handler.load_iumin.op1ee.split.body, %handler.clear_cache.op907.split.body, %handler.volatile_atomic_rmw_and.op959.split.body, %handler.trap.op9c3.split.body, %handler.fround.op721.split.body, %handler.load_isrem.op1e0.split.body, %handler.fptosi_sat.op8e0.split.body, %handler.fsin.op724.split.body, %handler.cmpxchg.opec.split.body, %handler.write_rounding.op81e.split.body, %handler.load_ilshr.op995.split.body, %handler.load_ilshr.op996.split.body, %handler.isshl_sat.op879.split.body, %handler.br_if.op9bc.split.body, %handler.load_imul.op1d9.split.body, %handler.fmul.op89c.split.body, %handler.stacksave.op903.split.body, %handler.atomic_rmw_sub.ope4.split.body, %handler.br_if.op3f.split.body, %handler.iadd.op83b.split.body, %handler.load_iudiv.op1db.split.body, %handler.trunc.op8fb.split.body, %handler.iashr.op4b.split.body, %handler.load_iand.op9ad.split.body, %handler.sext.op58.split.body, %handler.fminimum.op8ab.split.body, %handler.load_isshl_sat.op9ac.split.body, %handler.ptrmask.op857.split.body, %handler.atomic_rmw_umin.opf8.split.body, %handler.frem.opa9.split.body, %handler.fexp2.op72a.split.body, %handler.vm_ret.op43.split.body, %handler.fptoui.opc9.split.body, %handler.froundeven.op722.split.body, %handler.uitofp.opc0.split.body, %handler.sideeffect.op836.split.body, %handler.load_iuadd_sat.op1f1.split.body, %handler.atomic_rmw_sub.ope5.split.body, %handler.atomic_store.opd9.split.body, %handler.atomic_rmw_fadd.op160.split.body, %handler.volatile_atomic_rmw_add.op183.split.body, %handler.ret.op9c5.split.body, %handler.load_iumax.op1ed.split.body, %handler.ilshr.op17.split.body, %handler.fsub.op9c.split.body, %handler.atomic_rmw_fmaximum.op168.split.body, %handler.load_issub_sat.op1f7.split.body, %handler.fneg.opb2.split.body, %handler.ixor.op04.split.body, %handler.load_isdiv.op1dd.split.body, %handler.flog2.op8d1.split.body, %handler.iurem.op8b.split.body, %handler.fptosi_sat.op1b9.split.body, %handler.unreachable.op9c2.split.body, %handler.icmp_br_if.op10d.split.body, %handler.iudiv.op846.split.body, %handler.atomic_rmw_xchg.ope1.split.body, %handler.load_iushl_sat.op9a9.split.body, %handler.write_rounding.op81f.split.body, %handler.load_imul.op1d8.split.body, %handler.fshl.op108.split.body, %handler.memset_dyn.op91a.split.body, %handler.frint.op71d.split.body, %handler.vm_ret.op44.split.body, %handler.ilshr.op4e.split.body, %handler.fpowi.op8a6.split.body, %handler.issub_sat.op127.split.body, %handler.imul.op12.split.body, %handler.ftrunc.op71a.split.body, %handler.iuadd_sat.op122.split.body, %handler.atomic_rmw_fmin.op167.split.body, %handler.prefetch.op90b.split.body, %handler.store.op912.split.body, %handler.issub_sat.op876.split.body, %handler.global_addr.op80d.split.body, %handler.fake_nop.op9b8.split.body, %handler.mov_imm.op0e.split.body, %handler.atomic_rmw_sub.op92e.split.body, %handler.ismax.op866.split.body, %handler.frint.op8bd.split.body, %handler.stackrestore.op1b2.split.body, %handler.iusub_overflow.op880.split.body, %handler.volatile_atomic_rmw_fadd.op972.split.body, %handler.volatile_atomic_rmw_fminimum.op1a8.split.body, %handler.isadd_overflow.op12f.split.body, %handler.iumax.op11d.split.body, %handler.uitofp.op8d9.split.body, %handler.fcanonicalize.op8b5.split.body, %handler.br.op4c.split.body, %handler.br.op67.split.body, %handler.read_fpenv.op823.split.body, %handler.fake_nop.op07.split.body, %handler.frem.opaa.split.body, %handler.fence.opee.split.body, %handler.volatile_atomic_load.op925.split.body, %handler.flrint.op737.split.body, %handler.load_iudiv.op98b.split.body, %handler.iadd_xor.op83c.split.body, %handler.atomic_rmw_fmaximum.op950.split.body, %handler.volatile_atomic_rmw_xchg.op181.split.body, %handler.fcos.op727.split.body, %handler.ismax.op11a.split.body, %handler.atomic_rmw_max.op937.split.body, %handler.issub_overflow.op133.split.body, %handler.fabs.op8b1.split.body, %handler.fsqrt.op707.split.body, %handler.load_iumin.op99f.split.body, %handler.fmul.op89b.split.body, %handler.volatile_atomic_rmw_xor.op95e.split.body, %handler.memmove_dyn.op917.split.body, %handler.fmul.opa0.split.body, %handler.atomic_rmw_and.ope7.split.body, %handler.ixor.op21.split.body, %handler.gep.op37.split.body, %handler.fllround.op73d.split.body, %handler.atomic_rmw_or.ope9.split.body, %handler.volatile_atomic_rmw_nand.op95f.split.body, %handler.frem.opac.split.body, %handler.atomic_rmw_udec_wrap.op942.split.body, %handler.iuadd_sat.op870.split.body, %native.done1604, %handler.fpowi.op735.split.body, %handler.iabs.op117.split.body, %handler.volatile_atomic_rmw_min.op963.split.body, %handler.bswap.op104.split.body, %handler.load_iuadd_sat.op9a2.split.body, %handler.mov.op06.split.body, %handler.call_native.op38.split.body, %handler.write_fpmode.op1cc.split.body, %handler.fllround.op8ed.split.body, %handler.ismul_overflow.op138.split.body, %handler.iusub_overflow.op131.split.body, %handler.global_addr.op80e.split.body, %handler.bitcast.op8fe.split.body, %handler.isrem.op84e.split.body, %handler.atomic_rmw_and.ope6.split.body, %handler.iudiv.op83.split.body, %handler.alloca.op8ff.split.body, %handler.atomic_rmw_xchg.op92a.split.body, %handler.load_ior.op9af.split.body, %handler.fcopysign.op8a1.split.body, %handler.volatile_atomic_load.op926.split.body, %handler.atomic_rmw_nand.op935.split.body, %handler.cmpxchg.op97e.split.body, %handler.issub_overflow.op882.split.body, %handler.load_iusub_sat.op9a3.split.body, %handler.iadd.op6d.split.body, %handler.const_load.op803.split.body, %handler.volatile_atomic_rmw_and.op95a.split.body, %handler.vm_call.op42.split.body, %handler.memmove_dyn.op918.split.body, %handler.sideeffect.op838.split.body, %handler.load.op0f.split.body, %handler.clear_cache.op1b4.split.body, %handler.stackrestore.op1b3.split.body, %handler.fdiv.op89d.split.body, %handler.fptosi.opc1.split.body, %handler.froundeven.op8c3.split.body, %handler.fmul.opa2.split.body, %handler.imul.op843.split.body, %handler.volatile_store.op914.split.body, %handler.mov_imm.op01.split.body, %handler.fnearbyint.op71f.split.body, %handler.load_iurem.op1de.split.body, %handler.atomic_rmw_min.opf5.split.body, %handler.mov.op02.split.body, %handler.iuadd_overflow.op87c.split.body, %handler.volatile_atomic_rmw_fmaximum.op1a7.split.body, %handler.load_iadd.op111.split.body, %handler.atomic_rmw_add.op92c.split.body, %handler.fexp.op728.split.body, %handler.atomic_rmw_min.op93a.split.body, %handler.isadd_overflow.op87e.split.body, %handler.atomic_rmw_usub_cond.op943.split.body, %handler.atomic_rmw_or.op932.split.body, %handler.fround.op8c1.split.body, %handler.volatile_atomic_rmw_umin.op195.split.body, %handler.volatile_atomic_rmw_and.op187.split.body, %handler.load_iushl_sat.op1f9.split.body, %handler.atomic_rmw_usub_sat.op172.split.body, %handler.fcmp.opb1.split.body, %handler.ctlz.op88a.split.body, %handler.fmaximum.op8ae.split.body, %handler.read_vscale.op1bc.split.body, %handler.fround.op720.split.body, %handler.ismin.op869.split.body, %handler.iand.op74.split.body, %handler.memset_dyn.op142.split.body, %handler.isub.op841.split.body, %handler.iand.op47.split.body, %handler.fceil.op719.split.body, %handler.cttz.op116.split.body, %handler.isub.op11.split.body, %handler.volatile_atomic_rmw_fsub.op1a1.split.body, %handler.store.op36.split.body, %handler.fround.op8c2.split.body, %handler.ismin.op86a.split.body, %handler.fexp.op8c9.split.body, %handler.read_flt_rounds.op1d1.split.body, %handler.atomic_rmw_fsub.op949.split.body, %handler.atomic_rmw_fminimum.op951.split.body, %handler.ctpop.op102.split.body, %handler.volatile_atomic_rmw_xchg.op954.split.body, %handler.atomic_load.opd7.split.body, %handler.iurem.op8c.split.body, %handler.volatile_atomic_rmw_fmax.op976.split.body, %handler.atomic_rmw_fmax.op164.split.body, %handler.load.op7c.split.body, %handler.ffma.op708.split.body, %handler.frem.op89f.split.body, %handler.volatile_atomic_rmw_xor.op95d.split.body, %handler.volatile_atomic_rmw_fadd.op19f.split.body, %handler.load_iand.op1d4.split.body, %handler.sitofp.op8d8.split.body, %handler.ret.op1a.split.body, %handler.atomic_rmw_usub_cond.op171.split.body, %handler.bitreverse.op891.split.body, %handler.fdiv.op89e.split.body, %handler.iashr.op25.split.body, %handler.fpclass.op8f5.split.body, %handler.volatile_atomic_rmw_uinc_wrap.op969.split.body, %handler.volatile_atomic_load.op175.split.body, %handler.load_iumax.op99d.split.body, %handler.iumax.op11e.split.body, %handler.load.op90e.split.body, %handler.atomic_rmw_umin.op93e.split.body, %handler.sext.op31.split.body, %handler.iashr.op50.split.body, %handler.fnearbyint.op8c0.split.body, %handler.flrint.op736.split.body, %handler.trap.opdf.split.body, %handler.vm_call.op6e.split.body, %handler.volatile_store.op14a.split.body, %handler.read_thread_pointer.op1c1.split.body, %handler.volatile_atomic_rmw_usub_sat.op19c.split.body, %handler.iashr.op864.split.body, %handler.load_iurem.op990.split.body, %handler.ismul_overflow.op885.split.body, %handler.fcmp.opae.split.body, %handler.volatile_atomic_rmw_fsub.op1a0.split.body, %handler.fcos.op8c8.split.body, %handler.atomic_rmw_udec_wrap.op941.split.body, %handler.fpow.op732.split.body, %handler.imul.op4a.split.body, %handler.fminimum.op70e.split.body, %handler.ilshr.op860.split.body, %handler.iumin.op120.split.body, %handler.volatile_atomic_rmw_fmaximum.op979.split.body, %handler.read_fpenv.op1c5.split.body, %handler.bitreverse.op892.split.body, %handler.atomic_rmw_umax.opf6.split.body, %handler.iumul_overflow.op135.split.body, %handler.fake_nop.op48.split.body, %handler.fsin.op8c6.split.body, %handler.volatile_memmove_dyn.op91d.split.body, %handler.unreachable.op9c1.split.body, %handler.iand.op855.split.body, %handler.imul.op28.split.body, %handler.read_fpmode.op1ca.split.body, %handler.fcopysign.op705.split.body, %handler.atomic_rmw_min.opf4.split.body, %handler.stacksave.op1b0.split.body, %handler.atomic_rmw_usub_sat.op173.split.body, %handler.fmaxnum.op8aa.split.body, %handler.tls_addr.op80b.split.body, %handler.atomic_rmw_umax.op93c.split.body, %handler.fshr.op895.split.body, %handler.iand.op854.split.body, %handler.atomic_rmw_fmin.op166.split.body, %handler.iashr.op865.split.body, %handler.atomic_rmw_nand.opf1.split.body, %handler.fpext.op8e5.split.body, %handler.load_isshl_sat.op1fb.split.body, %handler.read_steady.op814.split.body, %handler.tls_addr.op13b.split.body, %handler.volatile_atomic_rmw_umin.op967.split.body, %handler.fminnum.op8a8.split.body, %handler.volatile_atomic_rmw_umax.op193.split.body, %handler.volatile_memcpy_dyn.op91b.split.body, %handler.uitofp.opbd.split.body, %handler.fptoui_sat.op8e1.split.body, %handler.iushl_sat.op878.split.body, %handler.isadd_sat.op873.split.body, %handler.volatile_atomic_rmw_fmax.op1a3.split.body, %handler.load_ismax.op1e8.split.body, %handler.stacksave.op1b1.split.body, %handler.load_isrem.op1e1.split.body, %handler.vm_call.op70.split.body, %handler.iudiv.op847.split.body, %handler.isub.op83f.split.body, %handler.write_rounding.op820.split.body, %handler.flround.op73a.split.body, %handler.ftrunc.op8bb.split.body, %handler.fdiv.opa7.split.body, %handler.read_fpmode.op1cb.split.body, %handler.prefetch.op200.split.body, %handler.atomic_rmw_min.op939.split.body, %handler.call_native.op9b5.split.body, %handler.load_ishl.op1e3.split.body, %handler.ior.op69.split.body, %handler.ior.op85b.split.body, %handler.iadd.op10.split.body, %handler.iadd_xor.op83e.split.body, %handler.volatile_atomic_rmw_fmin.op978.split.body, %handler.ftrunc.op8bc.split.body, %handler.volatile_atomic_rmw_fmax.op975.split.body, %handler.iuadd_overflow.op12d.split.body, %handler.isub.op7e.split.body, %handler.fmul.opa1.split.body, %handler.flog10.op8d0.split.body, %handler.fptosi.opc3.split.body, %handler.isrem.op84f.split.body, %handler.fadd.op898.split.body, %handler.vm_ret.op19.split.body, %handler.volatile_load.op910.split.body, %handler.fabs.op8b2.split.body, %handler.atomic_rmw_usub_sat.op945.split.body, %handler.reset_fpmode.op831.split.body, %handler.isrem.op90.split.body, %handler.atomic_rmw_udec_wrap.op16e.split.body, %handler.mov.op808.split.body, %handler.load_iumin.op9a0.split.body, %handler.mov_imm.op801.split.body, %handler.fpclass.op700.split.body, %handler.load_iashr.op998.split.body, %handler.sitofp.opba.split.body, %handler.fexp2.op72b.split.body, %handler.volatile_cmpxchg.op980.split.body, %handler.frint.op8be.split.body, %handler.atomic_rmw_umax.opf7.split.body, %handler.iabs.op88d.split.body, %handler.volatile_atomic_rmw_fmin.op1a5.split.body, %handler.fpclass.op701.split.body, %handler.read_thread_pointer.op833.split.body, %handler.ilshr.op6c.split.body, %handler.imul.op842.split.body, %handler.ixor.op852.split.body, %handler.tls_addr.op80a.split.body, %handler.fexp2.op8cb.split.body, %handler.icmp_br_if.op10e.split.body, %handler.sitofp.opb8.split.body, %handler.volatile_atomic_rmw_sub.op958.split.body, %handler.vm_call.op9bd.split.body, %handler.cttz.op88c.split.body, %handler.fnearbyint.op71e.split.body, %handler.sext.op4d.split.body, %handler.load_imul.op989.split.body, %handler.load_ismax.op999.split.body, %handler.ior.op68.split.body, %handler.br_if.op3b.split.body, %handler.tls_addr.op13c.split.body, %handler.sitofp.opb7.split.body, %handler.cmpxchg.oped.split.body, %handler.volatile_atomic_rmw_udec_wrap.op96c.split.body, %handler.ilshr.op6a.split.body, %handler.volatile_atomic_rmw_fsub.op973.split.body, %handler.iuadd_overflow.op87b.split.body, %handler.read_cycle.op1ab.split.body, %handler.flog.op72c.split.body, %handler.atomic_store.op923.split.body, %handler.sideeffect.op1af.split.body, %handler.volatile_atomic_rmw_sub.op185.split.body, %handler.volatile_atomic_rmw_max.op18e.split.body, %handler.isadd_sat.op125.split.body, %handler.load_isrem.op992.split.body, %handler.atomic_rmw_fsub.op162.split.body, %handler.fshr.op109.split.body, %handler.fmaxnum.op8a9.split.body, %handler.global_addr.op80c.split.body, %handler.ffma.op8d3.split.body, %handler.imul.op79.split.body, %handler.fpext.opd3.split.body, %handler.imul.op844.split.body, %handler.reset_fpmode.op1ce.split.body, %handler.volatile_atomic_rmw_usub_sat.op96f.split.body, %handler.fptrunc.opcd.split.body, %handler.load_iashr.op997.split.body, %handler.bitcast.op0d.split.body, %handler.load_ixor.op9b3.split.body, %handler.load_iand.op9ae.split.body, %handler.ptrmask.op859.split.body, %handler.fminnum.op8a7.split.body, %handler.icmp.op8f0.split.body, %handler.iashr.op18.split.body, %handler.fexp.op8ca.split.body, %handler.iuadd_overflow.op12e.split.body, %handler.memcpy_dyn.op143.split.body, %handler.memcpy_dyn.op915.split.body, %handler.br.op9ba.split.body, %handler.load_ior.op1d6.split.body, %handler.alloca.op900.split.body, %handler.write_fpmode.op1cd.split.body, %handler.ismul_overflow.op137.split.body, %handler.memset_dyn.op919.split.body, %handler.atomic_rmw_fmax.op165.split.body, %handler.volatile_atomic_rmw_udec_wrap.op198.split.body, %handler.store.op49.split.body, %handler.volatile_atomic_rmw_sub.op957.split.body, %handler.atomic_store.opdb.split.body, %handler.bswap.op890.split.body, %handler.iadd.op839.split.body, %handler.fptosi.opc4.split.body, %handler.mov_imm.op802.split.body, %handler.fptrunc.opcc.split.body, %handler.isadd_sat.op874.split.body, %handler.fake_nop.op64.split.body, %handler.bitcast.op27.split.body, %handler.fsqrt.op706.split.body, %handler.atomic_rmw_fsub.op163.split.body, %handler.isdiv.op849.split.body, %handler.volatile_atomic_rmw_max.op18f.split.body, %handler.read_fpmode.op82c.split.body, %handler.atomic_rmw_umin.op93d.split.body, %handler.atomic_rmw_add.ope3.split.body, %handler.isadd_sat.op126.split.body, %handler.load_iadd.op987.split.body, %handler.fptoui.opc7.split.body, %handler.mov.op75.split.body, %handler.volatile_atomic_rmw_usub_sat.op970.split.body, %handler.reset_fpenv.op1c9.split.body, %handler.volatile_atomic_rmw_xor.op18b.split.body, %handler.ixor.op13.split.body, %handler.read_fpenv.op822.split.body, %handler.iushl_sat.op877.split.body, %handler.atomic_rmw_fminimum.op16a.split.body, %handler.ctlz.op889.split.body, %handler.atomic_load.op921.split.body, %handler.volatile_atomic_load.op174.split.body, %handler.flog2.op730.split.body, %handler.ismul_overflow.op886.split.body, %handler.alloca_dyn.op13f.split.body, %handler.atomic_rmw_uinc_wrap.op16d.split.body, %handler.isub.op3d.split.body, %handler.const_load.op5d.split.body, %handler.volatile_atomic_rmw_fmin.op1a4.split.body, %handler.volatile_cmpxchg.op17f.split.body, %handler.isdiv.op87.split.body, %handler.isdiv.op848.split.body, %handler.alloca.op34.split.body, %handler.atomic_rmw_and.op92f.split.body, %handler.atomic_rmw_fmin.op94d.split.body, %handler.froundeven.op723.split.body, %handler.vm_call.op9be.split.body, %handler.volatile_atomic_rmw_umin.op194.split.body, %handler.volatile_atomic_rmw_fadd.op19e.split.body, %handler.iusub_sat.op871.split.body, %handler.volatile_atomic_rmw_uinc_wrap.op197.split.body, %handler.iusub_overflow.op87f.split.body, %handler.flog.op8cd.split.body, %handler.fceil.op8ba.split.body, %handler.volatile_atomic_rmw_or.op189.split.body, %handler.flog2.op731.split.body, %handler.fptoui.opc8.split.body, %handler.fpow.op8a4.split.body, %handler.fptrunc.op8e4.split.body, %handler.volatile_atomic_store.op176.split.body, %handler.fnearbyint.op8bf.split.body, %handler.load_isrem.op991.split.body, %handler.isub.op57.split.body, %handler.cmpxchg.op97d.split.body, %handler.load_iashr.op1e6.split.body, %handler.fllround.op8ee.split.body, %handler.volatile_atomic_rmw_nand.op18d.split.body, %handler.trunc.op26.split.body, %handler.fdiv.opa3.split.body, %handler.volatile_memset_dyn.op17c.split.body, %handler.prefetch.op201.split.body, %handler.write_fpenv.op825.split.body, %handler.fsin.op725.split.body, %handler.fminnum.op70b.split.body, %handler.ishl.op53.split.body, %handler.volatile_atomic_rmw_or.op188.split.body, %handler.load_isub.op1d3.split.body, %handler.isrem.op92.split.body, %handler.volatile_atomic_store.op928.split.body, %handler.atomic_rmw_max.opf3.split.body, %handler.atomic_load.opd8.split.body, %handler.br.op9b9.split.body, %handler.reset_fpmode.op832.split.body, %handler.br.op1c.split.body, %handler.flog10.op72e.split.body, %handler.load_isub.op1d2.split.body, %handler.mov_imm.op60.split.body, %handler.iurem.op8d.split.body, %handler.vm_call.op71.split.body, %handler.read_steady.op1ad.split.body, %handler.gep_load.op985.split.body, %handler.ior.op6f.split.body, %handler.atomic_rmw_fminimum.op952.split.body, %handler.iurem.op8a.split.body, %handler.volatile_load.op90f.split.body, %handler.isrem.op91.split.body, %handler.load_isub.op9b1.split.body, %handler.volatile_atomic_rmw_add.op182.split.body, %handler.read_rounding.op819.split.body, %handler.flog.op8ce.split.body, %handler.store.op7b.split.body, %handler.load_iand.op1d5.split.body, %handler.call_native.op9b6.split.body, %handler.fabs.op703.split.body, %handler.fllrint.op8e9.split.body, %handler.fexp2.op8cc.split.body, %handler.sext.op8f9.split.body, %handler.load_ismin.op99b.split.body, %handler.fmaxnum.op70d.split.body, %handler.fsqrt.op8b3.split.body, %handler.br_if.op41.split.body, %handler.zext.op30.split.body, %native.done, %handler.frem.op8a0.split.body, %handler.atomic_rmw_or.ope8.split.body, %handler.mov.op806.split.body, %handler.pseudoprobe.op909.split.body, %handler.imul.op1d.split.body, %handler.fshr.op896.split.body, %handler.load_iusub_sat.op9a4.split.body, %handler.fcanonicalize.op8b6.split.body, %handler.load_issub_sat.op9a7.split.body, %handler.atomic_rmw_umax.op93b.split.body, %handler.load_iusub_sat.op1f3.split.body, %handler.volatile_cmpxchg.op17e.split.body, %handler.mov.op3a.split.body, %handler.memmove_dyn.op146.split.body, %handler.isub.op840.split.body, %handler.read_flt_rounds.op81d.split.body, %handler.ffma.op709.split.body, %handler.volatile_atomic_rmw_add.op956.split.body, %handler.volatile_atomic_rmw_xchg.op180.split.body, %handler.volatile_atomic_store.op927.split.body, %handler.write_rounding.op1c2.split.body, %handler.iumul_overflow.op883.split.body, %handler.sext.op61.split.body, %handler.fceil.op718.split.body, %handler.fptosi_sat.op1b8.split.body, %handler.load_ishl.op993.split.body, %handler.iudiv.op82.split.body, %handler.iudiv.op81.split.body, %handler.gep_load.op110.split.body, %handler.ptrmask.op139.split.body, %handler.ffmuladd.op8d6.split.body, %handler.alloca_dyn.op901.split.body, %handler.reset_fpenv.op828.split.body, %handler.load_isshl_sat.op9ab.split.body, %handler.volatile_memmove_dyn.op17a.split.body, %handler.issub_overflow.op881.split.body, %handler.read_thread_pointer.op835.split.body, %handler.isadd_overflow.op87d.split.body, %handler.ffma.op8d4.split.body, %handler.iand.op72.split.body, %handler.read_rounding.op1be.split.body, %handler.gep.op09.split.body, %handler.read_flt_rounds.op81b.split.body, %handler.volatile_atomic_rmw_xor.op18a.split.body, %handler.write_fpenv.op824.split.body, %handler.stacksave.op904.split.body, %handler.iashr.op08.split.body, %handler.volatile_atomic_rmw_fmax.op1a2.split.body, %handler.iabs.op88e.split.body, %handler.uitofp.op8da.split.body, %handler.zext.op8f8.split.body, %handler.fpext.opd2.split.body, %handler.iurem.op84b.split.body, %handler.iand.op2d.split.body, %handler.gep.op1e.split.body, %handler.load_iudiv.op1da.split.body, %handler.fdiv.opa5.split.body, %handler.volatile_store.op913.split.body, %handler.br_if.op62.split.body, %handler.read_steady.op813.split.body, %handler.fence.opef.split.body, %handler.iudiv.op84.split.body, %handler.bitcast.op3e.split.body, %handler.ior.op85c.split.body, %handler.mov_imm.op800.split.body, %handler.ffloor.op8b8.split.body, %handler.atomic_rmw_fmax.op94c.split.body, %handler.fcanonicalize.op714.split.body, %handler.load_ixor.opfd.split.body, %handler.gep_load.op10f.split.body, %handler.load_iumax.op99e.split.body, %handler.volatile_atomic_rmw_xchg.op953.split.body, %handler.atomic_store.opdc.split.body, %handler.ptrmask.op13a.split.body, %handler.volatile_atomic_rmw_udec_wrap.op199.split.body, %handler.fcopysign.op704.split.body, %handler.flrint.op8e7.split.body, %handler.read_cycle.op80f.split.body, %handler.read_flt_rounds.op81c.split.body, %handler.volatile_atomic_rmw_usub_cond.op96e.split.body, %handler.fptoui_sat.op8e2.split.body, %handler.ishl.op85d.split.body, %handler.cttz.op115.split.body, %handler.atomic_rmw_add.op92b.split.body, %handler.fsin.op8c5.split.body, %handler.alloca_dyn.op140.split.body, %handler.fcmp.opad.split.body, %handler.zext.op54.split.body, %handler.load_iudiv.op98c.split.body, %handler.atomic_rmw_xor.op934.split.body, %handler.load_ior.op1d7.split.body, %handler.isrem.op8f.split.body, %handler.read_vscale.op817.split.body, %handler.fptosi.opc2.split.body, %handler.atomic_rmw_udec_wrap.op16f.split.body, %handler.atomic_load.opd6.split.body, %handler.read_rounding.op818.split.body, %handler.atomic_rmw_xchg.op929.split.body, %handler.fence.op981.split.body, %handler.ixor.op851.split.body, %handler.volatile_memmove_dyn.op91e.split.body, %handler.read_steady.op1ac.split.body, %handler.const_load.op45.split.body, %handler.volatile_atomic_rmw_and.op186.split.body, %handler.isrem.op850.split.body, %handler.atomic_rmw_nand.op936.split.body, %handler.load_ismin.op99c.split.body, %handler.fmul.op9e.split.body, %handler.load_iadd.op988.split.body, %handler.load_isadd_sat.op1f5.split.body, %handler.gep.op984.split.body, %handler.ptrmask.op858.split.body, %handler.fneg.opb4.split.body, %handler.fpow.op8a3.split.body, %handler.unreachable.opdd.split.body, %handler.flround.op8eb.split.body, %handler.load_isdiv.op98e.split.body, %handler.iushl_sat.op12a.split.body, %handler.atomic_rmw_or.op931.split.body, %handler.write_fpmode.op82d.split.body, %handler.atomic_rmw_usub_cond.op944.split.body, %handler.volatile_atomic_rmw_nand.op960.split.body, %handler.ismax.op867.split.body, %descriptor.ready
  %pc331 = load i64, ptr %pc, align 8
  %pc.in.range = icmp ult i64 %pc331, %descriptor.code.len.plain
  store i64 %pc331, ptr %offset, align 8
  br i1 %pc.in.range, label %execute.decode, label %default.return

execute.decode:                                   ; preds = %loop.check
  %opcode = call i64 @.amice.vm.h.eb7d375a76d54199(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  switch i64 %opcode, label %default.return [
    i64 2151, label %handler.ismax.op867.split.entry
    i64 2400, label %handler.volatile_atomic_rmw_nand.op960.split.entry
    i64 2372, label %handler.atomic_rmw_usub_cond.op944.split.entry
    i64 2093, label %handler.write_fpmode.op82d.split.entry
    i64 2353, label %handler.atomic_rmw_or.op931.split.entry
    i64 298, label %handler.iushl_sat.op12a.split.entry
    i64 2446, label %handler.load_isdiv.op98e.split.entry
    i64 2283, label %handler.flround.op8eb.split.entry
    i64 221, label %handler.unreachable.opdd.split.entry
    i64 2211, label %handler.fpow.op8a3.split.entry
    i64 180, label %handler.fneg.opb4.split.entry
    i64 2136, label %handler.ptrmask.op858.split.entry
    i64 2436, label %handler.gep.op984.split.entry
    i64 501, label %handler.load_isadd_sat.op1f5.split.entry
    i64 2440, label %handler.load_iadd.op988.split.entry
    i64 158, label %handler.fmul.op9e.split.entry
    i64 2460, label %handler.load_ismin.op99c.split.entry
    i64 2358, label %handler.atomic_rmw_nand.op936.split.entry
    i64 2128, label %handler.isrem.op850.split.entry
    i64 390, label %handler.volatile_atomic_rmw_and.op186.split.entry
    i64 69, label %handler.const_load.op45.split.entry
    i64 428, label %handler.read_steady.op1ac.split.entry
    i64 2334, label %handler.volatile_memmove_dyn.op91e.split.entry
    i64 2129, label %handler.ixor.op851.split.entry
    i64 2433, label %handler.fence.op981.split.entry
    i64 2345, label %handler.atomic_rmw_xchg.op929.split.entry
    i64 2072, label %handler.read_rounding.op818.split.entry
    i64 214, label %handler.atomic_load.opd6.split.entry
    i64 367, label %handler.atomic_rmw_udec_wrap.op16f.split.entry
    i64 194, label %handler.fptosi.opc2.split.entry
    i64 2071, label %handler.read_vscale.op817.split.entry
    i64 143, label %handler.isrem.op8f.split.entry
    i64 471, label %handler.load_ior.op1d7.split.entry
    i64 2356, label %handler.atomic_rmw_xor.op934.split.entry
    i64 2444, label %handler.load_iudiv.op98c.split.entry
    i64 84, label %handler.zext.op54.split.entry
    i64 173, label %handler.fcmp.opad.split.entry
    i64 320, label %handler.alloca_dyn.op140.split.entry
    i64 2245, label %handler.fsin.op8c5.split.entry
    i64 2347, label %handler.atomic_rmw_add.op92b.split.entry
    i64 277, label %handler.cttz.op115.split.entry
    i64 2141, label %handler.ishl.op85d.split.entry
    i64 2274, label %handler.fptoui_sat.op8e2.split.entry
    i64 2414, label %handler.volatile_atomic_rmw_usub_cond.op96e.split.entry
    i64 2076, label %handler.read_flt_rounds.op81c.split.entry
    i64 2063, label %handler.read_cycle.op80f.split.entry
    i64 2279, label %handler.flrint.op8e7.split.entry
    i64 1796, label %handler.fcopysign.op704.split.entry
    i64 409, label %handler.volatile_atomic_rmw_udec_wrap.op199.split.entry
    i64 314, label %handler.ptrmask.op13a.split.entry
    i64 220, label %handler.atomic_store.opdc.split.entry
    i64 127, label %handler.ret.op7f.split.entry
    i64 2387, label %handler.volatile_atomic_rmw_xchg.op953.split.entry
    i64 2462, label %handler.load_iumax.op99e.split.entry
    i64 271, label %handler.gep_load.op10f.split.entry
    i64 253, label %handler.load_ixor.opfd.split.entry
    i64 1812, label %handler.fcanonicalize.op714.split.entry
    i64 2380, label %handler.atomic_rmw_fmax.op94c.split.entry
    i64 2232, label %handler.ffloor.op8b8.split.entry
    i64 2048, label %handler.mov_imm.op800.split.entry
    i64 2140, label %handler.ior.op85c.split.entry
    i64 62, label %handler.bitcast.op3e.split.entry
    i64 132, label %handler.iudiv.op84.split.entry
    i64 239, label %handler.fence.opef.split.entry
    i64 2067, label %handler.read_steady.op813.split.entry
    i64 98, label %handler.br_if.op62.split.entry
    i64 2323, label %handler.volatile_store.op913.split.entry
    i64 165, label %handler.fdiv.opa5.split.entry
    i64 474, label %handler.load_iudiv.op1da.split.entry
    i64 30, label %handler.gep.op1e.split.entry
    i64 45, label %handler.iand.op2d.split.entry
    i64 2123, label %handler.iurem.op84b.split.entry
    i64 210, label %handler.fpext.opd2.split.entry
    i64 2296, label %handler.zext.op8f8.split.entry
    i64 2266, label %handler.uitofp.op8da.split.entry
    i64 2190, label %handler.iabs.op88e.split.entry
    i64 418, label %handler.volatile_atomic_rmw_fmax.op1a2.split.entry
    i64 8, label %handler.iashr.op08.split.entry
    i64 2308, label %handler.stacksave.op904.split.entry
    i64 2084, label %handler.write_fpenv.op824.split.entry
    i64 394, label %handler.volatile_atomic_rmw_xor.op18a.split.entry
    i64 2075, label %handler.read_flt_rounds.op81b.split.entry
    i64 9, label %handler.gep.op09.split.entry
    i64 446, label %handler.read_rounding.op1be.split.entry
    i64 114, label %handler.iand.op72.split.entry
    i64 2260, label %handler.ffma.op8d4.split.entry
    i64 2173, label %handler.isadd_overflow.op87d.split.entry
    i64 2101, label %handler.read_thread_pointer.op835.split.entry
    i64 2177, label %handler.issub_overflow.op881.split.entry
    i64 378, label %handler.volatile_memmove_dyn.op17a.split.entry
    i64 2475, label %handler.load_isshl_sat.op9ab.split.entry
    i64 2088, label %handler.reset_fpenv.op828.split.entry
    i64 2305, label %handler.alloca_dyn.op901.split.entry
    i64 2262, label %handler.ffmuladd.op8d6.split.entry
    i64 313, label %handler.ptrmask.op139.split.entry
    i64 272, label %handler.gep_load.op110.split.entry
    i64 129, label %handler.iudiv.op81.split.entry
    i64 130, label %handler.iudiv.op82.split.entry
    i64 2451, label %handler.load_ishl.op993.split.entry
    i64 440, label %handler.fptosi_sat.op1b8.split.entry
    i64 1816, label %handler.fceil.op718.split.entry
    i64 97, label %handler.sext.op61.split.entry
    i64 2179, label %handler.iumul_overflow.op883.split.entry
    i64 450, label %handler.write_rounding.op1c2.split.entry
    i64 2343, label %handler.volatile_atomic_store.op927.split.entry
    i64 384, label %handler.volatile_atomic_rmw_xchg.op180.split.entry
    i64 2390, label %handler.volatile_atomic_rmw_add.op956.split.entry
    i64 1801, label %handler.ffma.op709.split.entry
    i64 2077, label %handler.read_flt_rounds.op81d.split.entry
    i64 2112, label %handler.isub.op840.split.entry
    i64 326, label %handler.memmove_dyn.op146.split.entry
    i64 58, label %handler.mov.op3a.split.entry
    i64 382, label %handler.volatile_cmpxchg.op17e.split.entry
    i64 499, label %handler.load_iusub_sat.op1f3.split.entry
    i64 2363, label %handler.atomic_rmw_umax.op93b.split.entry
    i64 2471, label %handler.load_issub_sat.op9a7.split.entry
    i64 2230, label %handler.fcanonicalize.op8b6.split.entry
    i64 2468, label %handler.load_iusub_sat.op9a4.split.entry
    i64 2198, label %handler.fshr.op896.split.entry
    i64 29, label %handler.imul.op1d.split.entry
    i64 2313, label %handler.pseudoprobe.op909.split.entry
    i64 2054, label %handler.mov.op806.split.entry
    i64 232, label %handler.atomic_rmw_or.ope8.split.entry
    i64 2208, label %handler.frem.op8a0.split.entry
    i64 119, label %handler.call_native.op77.split.entry
    i64 48, label %handler.zext.op30.split.entry
    i64 65, label %handler.br_if.op41.split.entry
    i64 2227, label %handler.fsqrt.op8b3.split.entry
    i64 1805, label %handler.fmaxnum.op70d.split.entry
    i64 2459, label %handler.load_ismin.op99b.split.entry
    i64 2297, label %handler.sext.op8f9.split.entry
    i64 2252, label %handler.fexp2.op8cc.split.entry
    i64 2281, label %handler.fllrint.op8e9.split.entry
    i64 1795, label %handler.fabs.op703.split.entry
    i64 2486, label %handler.call_native.op9b6.split.entry
    i64 469, label %handler.load_iand.op1d5.split.entry
    i64 123, label %handler.store.op7b.split.entry
    i64 2254, label %handler.flog.op8ce.split.entry
    i64 2073, label %handler.read_rounding.op819.split.entry
    i64 386, label %handler.volatile_atomic_rmw_add.op182.split.entry
    i64 2481, label %handler.load_isub.op9b1.split.entry
    i64 145, label %handler.isrem.op91.split.entry
    i64 2319, label %handler.volatile_load.op90f.split.entry
    i64 138, label %handler.iurem.op8a.split.entry
    i64 2386, label %handler.atomic_rmw_fminimum.op952.split.entry
    i64 111, label %handler.ior.op6f.split.entry
    i64 2437, label %handler.gep_load.op985.split.entry
    i64 429, label %handler.read_steady.op1ad.split.entry
    i64 113, label %handler.vm_call.op71.split.entry
    i64 141, label %handler.iurem.op8d.split.entry
    i64 96, label %handler.mov_imm.op60.split.entry
    i64 466, label %handler.load_isub.op1d2.split.entry
    i64 1838, label %handler.flog10.op72e.split.entry
    i64 28, label %handler.br.op1c.split.entry
    i64 2098, label %handler.reset_fpmode.op832.split.entry
    i64 2489, label %handler.br.op9b9.split.entry
    i64 216, label %handler.atomic_load.opd8.split.entry
    i64 243, label %handler.atomic_rmw_max.opf3.split.entry
    i64 2344, label %handler.volatile_atomic_store.op928.split.entry
    i64 146, label %handler.isrem.op92.split.entry
    i64 467, label %handler.load_isub.op1d3.split.entry
    i64 392, label %handler.volatile_atomic_rmw_or.op188.split.entry
    i64 83, label %handler.ishl.op53.split.entry
    i64 1803, label %handler.fminnum.op70b.split.entry
    i64 1829, label %handler.fsin.op725.split.entry
    i64 2085, label %handler.write_fpenv.op825.split.entry
    i64 513, label %handler.prefetch.op201.split.entry
    i64 380, label %handler.volatile_memset_dyn.op17c.split.entry
    i64 163, label %handler.fdiv.opa3.split.entry
    i64 38, label %handler.trunc.op26.split.entry
    i64 397, label %handler.volatile_atomic_rmw_nand.op18d.split.entry
    i64 2286, label %handler.fllround.op8ee.split.entry
    i64 486, label %handler.load_iashr.op1e6.split.entry
    i64 2429, label %handler.cmpxchg.op97d.split.entry
    i64 87, label %handler.isub.op57.split.entry
    i64 2449, label %handler.load_isrem.op991.split.entry
    i64 2239, label %handler.fnearbyint.op8bf.split.entry
    i64 374, label %handler.volatile_atomic_store.op176.split.entry
    i64 2276, label %handler.fptrunc.op8e4.split.entry
    i64 2212, label %handler.fpow.op8a4.split.entry
    i64 200, label %handler.fptoui.opc8.split.entry
    i64 1841, label %handler.flog2.op731.split.entry
    i64 393, label %handler.volatile_atomic_rmw_or.op189.split.entry
    i64 2234, label %handler.fceil.op8ba.split.entry
    i64 2253, label %handler.flog.op8cd.split.entry
    i64 2175, label %handler.iusub_overflow.op87f.split.entry
    i64 407, label %handler.volatile_atomic_rmw_uinc_wrap.op197.split.entry
    i64 2161, label %handler.iusub_sat.op871.split.entry
    i64 414, label %handler.volatile_atomic_rmw_fadd.op19e.split.entry
    i64 404, label %handler.volatile_atomic_rmw_umin.op194.split.entry
    i64 2494, label %handler.vm_call.op9be.split.entry
    i64 1827, label %handler.froundeven.op723.split.entry
    i64 2381, label %handler.atomic_rmw_fmin.op94d.split.entry
    i64 2351, label %handler.atomic_rmw_and.op92f.split.entry
    i64 52, label %handler.alloca.op34.split.entry
    i64 2120, label %handler.isdiv.op848.split.entry
    i64 135, label %handler.isdiv.op87.split.entry
    i64 383, label %handler.volatile_cmpxchg.op17f.split.entry
    i64 420, label %handler.volatile_atomic_rmw_fmin.op1a4.split.entry
    i64 93, label %handler.const_load.op5d.split.entry
    i64 61, label %handler.isub.op3d.split.entry
    i64 365, label %handler.atomic_rmw_uinc_wrap.op16d.split.entry
    i64 319, label %handler.alloca_dyn.op13f.split.entry
    i64 2182, label %handler.ismul_overflow.op886.split.entry
    i64 1840, label %handler.flog2.op730.split.entry
    i64 372, label %handler.volatile_atomic_load.op174.split.entry
    i64 2337, label %handler.atomic_load.op921.split.entry
    i64 2185, label %handler.ctlz.op889.split.entry
    i64 362, label %handler.atomic_rmw_fminimum.op16a.split.entry
    i64 2167, label %handler.iushl_sat.op877.split.entry
    i64 2082, label %handler.read_fpenv.op822.split.entry
    i64 19, label %handler.ixor.op13.split.entry
    i64 395, label %handler.volatile_atomic_rmw_xor.op18b.split.entry
    i64 457, label %handler.reset_fpenv.op1c9.split.entry
    i64 2416, label %handler.volatile_atomic_rmw_usub_sat.op970.split.entry
    i64 117, label %handler.mov.op75.split.entry
    i64 199, label %handler.fptoui.opc7.split.entry
    i64 2439, label %handler.load_iadd.op987.split.entry
    i64 294, label %handler.isadd_sat.op126.split.entry
    i64 227, label %handler.atomic_rmw_add.ope3.split.entry
    i64 2365, label %handler.atomic_rmw_umin.op93d.split.entry
    i64 2092, label %handler.read_fpmode.op82c.split.entry
    i64 399, label %handler.volatile_atomic_rmw_max.op18f.split.entry
    i64 2121, label %handler.isdiv.op849.split.entry
    i64 355, label %handler.atomic_rmw_fsub.op163.split.entry
    i64 1798, label %handler.fsqrt.op706.split.entry
    i64 39, label %handler.bitcast.op27.split.entry
    i64 100, label %handler.fake_nop.op64.split.entry
    i64 2164, label %handler.isadd_sat.op874.split.entry
    i64 204, label %handler.fptrunc.opcc.split.entry
    i64 2050, label %handler.mov_imm.op802.split.entry
    i64 196, label %handler.fptosi.opc4.split.entry
    i64 2105, label %handler.iadd.op839.split.entry
    i64 2192, label %handler.bswap.op890.split.entry
    i64 219, label %handler.atomic_store.opdb.split.entry
    i64 2391, label %handler.volatile_atomic_rmw_sub.op957.split.entry
    i64 73, label %handler.store.op49.split.entry
    i64 408, label %handler.volatile_atomic_rmw_udec_wrap.op198.split.entry
    i64 357, label %handler.atomic_rmw_fmax.op165.split.entry
    i64 2329, label %handler.memset_dyn.op919.split.entry
    i64 311, label %handler.ismul_overflow.op137.split.entry
    i64 461, label %handler.write_fpmode.op1cd.split.entry
    i64 2304, label %handler.alloca.op900.split.entry
    i64 470, label %handler.load_ior.op1d6.split.entry
    i64 2490, label %handler.br.op9ba.split.entry
    i64 2325, label %handler.memcpy_dyn.op915.split.entry
    i64 323, label %handler.memcpy_dyn.op143.split.entry
    i64 302, label %handler.iuadd_overflow.op12e.split.entry
    i64 2250, label %handler.fexp.op8ca.split.entry
    i64 24, label %handler.iashr.op18.split.entry
    i64 2288, label %handler.icmp.op8f0.split.entry
    i64 2215, label %handler.fminnum.op8a7.split.entry
    i64 2137, label %handler.ptrmask.op859.split.entry
    i64 2478, label %handler.load_iand.op9ae.split.entry
    i64 2483, label %handler.load_ixor.op9b3.split.entry
    i64 13, label %handler.bitcast.op0d.split.entry
    i64 2455, label %handler.load_iashr.op997.split.entry
    i64 205, label %handler.fptrunc.opcd.split.entry
    i64 2415, label %handler.volatile_atomic_rmw_usub_sat.op96f.split.entry
    i64 462, label %handler.reset_fpmode.op1ce.split.entry
    i64 2116, label %handler.imul.op844.split.entry
    i64 211, label %handler.fpext.opd3.split.entry
    i64 121, label %handler.imul.op79.split.entry
    i64 2259, label %handler.ffma.op8d3.split.entry
    i64 2060, label %handler.global_addr.op80c.split.entry
    i64 2217, label %handler.fmaxnum.op8a9.split.entry
    i64 265, label %handler.fshr.op109.split.entry
    i64 354, label %handler.atomic_rmw_fsub.op162.split.entry
    i64 2450, label %handler.load_isrem.op992.split.entry
    i64 293, label %handler.isadd_sat.op125.split.entry
    i64 398, label %handler.volatile_atomic_rmw_max.op18e.split.entry
    i64 389, label %handler.volatile_atomic_rmw_sub.op185.split.entry
    i64 431, label %handler.sideeffect.op1af.split.entry
    i64 2339, label %handler.atomic_store.op923.split.entry
    i64 1836, label %handler.flog.op72c.split.entry
    i64 427, label %handler.read_cycle.op1ab.split.entry
    i64 2171, label %handler.iuadd_overflow.op87b.split.entry
    i64 2419, label %handler.volatile_atomic_rmw_fsub.op973.split.entry
    i64 106, label %handler.ilshr.op6a.split.entry
    i64 2412, label %handler.volatile_atomic_rmw_udec_wrap.op96c.split.entry
    i64 237, label %handler.cmpxchg.oped.split.entry
    i64 183, label %handler.sitofp.opb7.split.entry
    i64 316, label %handler.tls_addr.op13c.split.entry
    i64 59, label %handler.br_if.op3b.split.entry
    i64 104, label %handler.ior.op68.split.entry
    i64 2457, label %handler.load_ismax.op999.split.entry
    i64 2441, label %handler.load_imul.op989.split.entry
    i64 77, label %handler.sext.op4d.split.entry
    i64 1822, label %handler.fnearbyint.op71e.split.entry
    i64 2188, label %handler.cttz.op88c.split.entry
    i64 2493, label %handler.vm_call.op9bd.split.entry
    i64 2392, label %handler.volatile_atomic_rmw_sub.op958.split.entry
    i64 184, label %handler.sitofp.opb8.split.entry
    i64 270, label %handler.icmp_br_if.op10e.split.entry
    i64 2251, label %handler.fexp2.op8cb.split.entry
    i64 2058, label %handler.tls_addr.op80a.split.entry
    i64 2130, label %handler.ixor.op852.split.entry
    i64 2114, label %handler.imul.op842.split.entry
    i64 108, label %handler.ilshr.op6c.split.entry
    i64 2099, label %handler.read_thread_pointer.op833.split.entry
    i64 1793, label %handler.fpclass.op701.split.entry
    i64 421, label %handler.volatile_atomic_rmw_fmin.op1a5.split.entry
    i64 2189, label %handler.iabs.op88d.split.entry
    i64 247, label %handler.atomic_rmw_umax.opf7.split.entry
    i64 2238, label %handler.frint.op8be.split.entry
    i64 2432, label %handler.volatile_cmpxchg.op980.split.entry
    i64 1835, label %handler.fexp2.op72b.split.entry
    i64 186, label %handler.sitofp.opba.split.entry
    i64 2456, label %handler.load_iashr.op998.split.entry
    i64 1792, label %handler.fpclass.op700.split.entry
    i64 2049, label %handler.mov_imm.op801.split.entry
    i64 2464, label %handler.load_iumin.op9a0.split.entry
    i64 2056, label %handler.mov.op808.split.entry
    i64 366, label %handler.atomic_rmw_udec_wrap.op16e.split.entry
    i64 144, label %handler.isrem.op90.split.entry
    i64 2097, label %handler.reset_fpmode.op831.split.entry
    i64 2373, label %handler.atomic_rmw_usub_sat.op945.split.entry
    i64 2226, label %handler.fabs.op8b2.split.entry
    i64 2320, label %handler.volatile_load.op910.split.entry
    i64 25, label %handler.vm_ret.op19.split.entry
    i64 2200, label %handler.fadd.op898.split.entry
    i64 2127, label %handler.isrem.op84f.split.entry
    i64 195, label %handler.fptosi.opc3.split.entry
    i64 2256, label %handler.flog10.op8d0.split.entry
    i64 161, label %handler.fmul.opa1.split.entry
    i64 126, label %handler.isub.op7e.split.entry
    i64 301, label %handler.iuadd_overflow.op12d.split.entry
    i64 2421, label %handler.volatile_atomic_rmw_fmax.op975.split.entry
    i64 2236, label %handler.ftrunc.op8bc.split.entry
    i64 2424, label %handler.volatile_atomic_rmw_fmin.op978.split.entry
    i64 2110, label %handler.iadd_xor.op83e.split.entry
    i64 16, label %handler.iadd.op10.split.entry
    i64 2139, label %handler.ior.op85b.split.entry
    i64 105, label %handler.ior.op69.split.entry
    i64 483, label %handler.load_ishl.op1e3.split.entry
    i64 2485, label %handler.call_native.op9b5.split.entry
    i64 2361, label %handler.atomic_rmw_min.op939.split.entry
    i64 512, label %handler.prefetch.op200.split.entry
    i64 459, label %handler.read_fpmode.op1cb.split.entry
    i64 167, label %handler.fdiv.opa7.split.entry
    i64 2235, label %handler.ftrunc.op8bb.split.entry
    i64 1850, label %handler.flround.op73a.split.entry
    i64 2080, label %handler.write_rounding.op820.split.entry
    i64 2111, label %handler.isub.op83f.split.entry
    i64 2119, label %handler.iudiv.op847.split.entry
    i64 112, label %handler.vm_call.op70.split.entry
    i64 481, label %handler.load_isrem.op1e1.split.entry
    i64 433, label %handler.stacksave.op1b1.split.entry
    i64 488, label %handler.load_ismax.op1e8.split.entry
    i64 419, label %handler.volatile_atomic_rmw_fmax.op1a3.split.entry
    i64 2163, label %handler.isadd_sat.op873.split.entry
    i64 2168, label %handler.iushl_sat.op878.split.entry
    i64 2273, label %handler.fptoui_sat.op8e1.split.entry
    i64 189, label %handler.uitofp.opbd.split.entry
    i64 2331, label %handler.volatile_memcpy_dyn.op91b.split.entry
    i64 403, label %handler.volatile_atomic_rmw_umax.op193.split.entry
    i64 2216, label %handler.fminnum.op8a8.split.entry
    i64 2407, label %handler.volatile_atomic_rmw_umin.op967.split.entry
    i64 315, label %handler.tls_addr.op13b.split.entry
    i64 2068, label %handler.read_steady.op814.split.entry
    i64 507, label %handler.load_isshl_sat.op1fb.split.entry
    i64 2277, label %handler.fpext.op8e5.split.entry
    i64 241, label %handler.atomic_rmw_nand.opf1.split.entry
    i64 2149, label %handler.iashr.op865.split.entry
    i64 358, label %handler.atomic_rmw_fmin.op166.split.entry
    i64 2132, label %handler.iand.op854.split.entry
    i64 2197, label %handler.fshr.op895.split.entry
    i64 2364, label %handler.atomic_rmw_umax.op93c.split.entry
    i64 2059, label %handler.tls_addr.op80b.split.entry
    i64 2218, label %handler.fmaxnum.op8aa.split.entry
    i64 371, label %handler.atomic_rmw_usub_sat.op173.split.entry
    i64 432, label %handler.stacksave.op1b0.split.entry
    i64 244, label %handler.atomic_rmw_min.opf4.split.entry
    i64 1797, label %handler.fcopysign.op705.split.entry
    i64 458, label %handler.read_fpmode.op1ca.split.entry
    i64 40, label %handler.imul.op28.split.entry
    i64 2133, label %handler.iand.op855.split.entry
    i64 2497, label %handler.unreachable.op9c1.split.entry
    i64 2333, label %handler.volatile_memmove_dyn.op91d.split.entry
    i64 2246, label %handler.fsin.op8c6.split.entry
    i64 72, label %handler.fake_nop.op48.split.entry
    i64 309, label %handler.iumul_overflow.op135.split.entry
    i64 246, label %handler.atomic_rmw_umax.opf6.split.entry
    i64 2194, label %handler.bitreverse.op892.split.entry
    i64 453, label %handler.read_fpenv.op1c5.split.entry
    i64 2425, label %handler.volatile_atomic_rmw_fmaximum.op979.split.entry
    i64 288, label %handler.iumin.op120.split.entry
    i64 2144, label %handler.ilshr.op860.split.entry
    i64 1806, label %handler.fminimum.op70e.split.entry
    i64 74, label %handler.imul.op4a.split.entry
    i64 2502, label %handler.ret.op9c6.split.entry
    i64 1842, label %handler.fpow.op732.split.entry
    i64 2369, label %handler.atomic_rmw_udec_wrap.op941.split.entry
    i64 2248, label %handler.fcos.op8c8.split.entry
    i64 416, label %handler.volatile_atomic_rmw_fsub.op1a0.split.entry
    i64 174, label %handler.fcmp.opae.split.entry
    i64 2181, label %handler.ismul_overflow.op885.split.entry
    i64 2448, label %handler.load_iurem.op990.split.entry
    i64 2148, label %handler.iashr.op864.split.entry
    i64 412, label %handler.volatile_atomic_rmw_usub_sat.op19c.split.entry
    i64 449, label %handler.read_thread_pointer.op1c1.split.entry
    i64 330, label %handler.volatile_store.op14a.split.entry
    i64 110, label %handler.vm_call.op6e.split.entry
    i64 223, label %handler.trap.opdf.split.entry
    i64 1846, label %handler.flrint.op736.split.entry
    i64 2240, label %handler.fnearbyint.op8c0.split.entry
    i64 80, label %handler.iashr.op50.split.entry
    i64 49, label %handler.sext.op31.split.entry
    i64 2366, label %handler.atomic_rmw_umin.op93e.split.entry
    i64 2318, label %handler.load.op90e.split.entry
    i64 286, label %handler.iumax.op11e.split.entry
    i64 2461, label %handler.load_iumax.op99d.split.entry
    i64 373, label %handler.volatile_atomic_load.op175.split.entry
    i64 2409, label %handler.volatile_atomic_rmw_uinc_wrap.op969.split.entry
    i64 2293, label %handler.fpclass.op8f5.split.entry
    i64 37, label %handler.iashr.op25.split.entry
    i64 2206, label %handler.fdiv.op89e.split.entry
    i64 2193, label %handler.bitreverse.op891.split.entry
    i64 369, label %handler.atomic_rmw_usub_cond.op171.split.entry
    i64 26, label %handler.ret.op1a.split.entry
    i64 2264, label %handler.sitofp.op8d8.split.entry
    i64 468, label %handler.load_iand.op1d4.split.entry
    i64 415, label %handler.volatile_atomic_rmw_fadd.op19f.split.entry
    i64 2397, label %handler.volatile_atomic_rmw_xor.op95d.split.entry
    i64 2207, label %handler.frem.op89f.split.entry
    i64 1800, label %handler.ffma.op708.split.entry
    i64 124, label %handler.load.op7c.split.entry
    i64 356, label %handler.atomic_rmw_fmax.op164.split.entry
    i64 2422, label %handler.volatile_atomic_rmw_fmax.op976.split.entry
    i64 140, label %handler.iurem.op8c.split.entry
    i64 215, label %handler.atomic_load.opd7.split.entry
    i64 2388, label %handler.volatile_atomic_rmw_xchg.op954.split.entry
    i64 258, label %handler.ctpop.op102.split.entry
    i64 2385, label %handler.atomic_rmw_fminimum.op951.split.entry
    i64 2377, label %handler.atomic_rmw_fsub.op949.split.entry
    i64 465, label %handler.read_flt_rounds.op1d1.split.entry
    i64 2249, label %handler.fexp.op8c9.split.entry
    i64 2154, label %handler.ismin.op86a.split.entry
    i64 2242, label %handler.fround.op8c2.split.entry
    i64 54, label %handler.store.op36.split.entry
    i64 417, label %handler.volatile_atomic_rmw_fsub.op1a1.split.entry
    i64 17, label %handler.isub.op11.split.entry
    i64 278, label %handler.cttz.op116.split.entry
    i64 1817, label %handler.fceil.op719.split.entry
    i64 71, label %handler.iand.op47.split.entry
    i64 2113, label %handler.isub.op841.split.entry
    i64 322, label %handler.memset_dyn.op142.split.entry
    i64 116, label %handler.iand.op74.split.entry
    i64 2153, label %handler.ismin.op869.split.entry
    i64 1824, label %handler.fround.op720.split.entry
    i64 444, label %handler.read_vscale.op1bc.split.entry
    i64 2222, label %handler.fmaximum.op8ae.split.entry
    i64 2186, label %handler.ctlz.op88a.split.entry
    i64 177, label %handler.fcmp.opb1.split.entry
    i64 370, label %handler.atomic_rmw_usub_sat.op172.split.entry
    i64 505, label %handler.load_iushl_sat.op1f9.split.entry
    i64 391, label %handler.volatile_atomic_rmw_and.op187.split.entry
    i64 405, label %handler.volatile_atomic_rmw_umin.op195.split.entry
    i64 2241, label %handler.fround.op8c1.split.entry
    i64 2354, label %handler.atomic_rmw_or.op932.split.entry
    i64 2371, label %handler.atomic_rmw_usub_cond.op943.split.entry
    i64 2174, label %handler.isadd_overflow.op87e.split.entry
    i64 2362, label %handler.atomic_rmw_min.op93a.split.entry
    i64 1832, label %handler.fexp.op728.split.entry
    i64 2348, label %handler.atomic_rmw_add.op92c.split.entry
    i64 273, label %handler.load_iadd.op111.split.entry
    i64 423, label %handler.volatile_atomic_rmw_fmaximum.op1a7.split.entry
    i64 2172, label %handler.iuadd_overflow.op87c.split.entry
    i64 2, label %handler.mov.op02.split.entry
    i64 245, label %handler.atomic_rmw_min.opf5.split.entry
    i64 478, label %handler.load_iurem.op1de.split.entry
    i64 1823, label %handler.fnearbyint.op71f.split.entry
    i64 1, label %handler.mov_imm.op01.split.entry
    i64 2324, label %handler.volatile_store.op914.split.entry
    i64 2115, label %handler.imul.op843.split.entry
    i64 162, label %handler.fmul.opa2.split.entry
    i64 2243, label %handler.froundeven.op8c3.split.entry
    i64 193, label %handler.fptosi.opc1.split.entry
    i64 2205, label %handler.fdiv.op89d.split.entry
    i64 435, label %handler.stackrestore.op1b3.split.entry
    i64 436, label %handler.clear_cache.op1b4.split.entry
    i64 15, label %handler.load.op0f.split.entry
    i64 2104, label %handler.sideeffect.op838.split.entry
    i64 2328, label %handler.memmove_dyn.op918.split.entry
    i64 66, label %handler.vm_call.op42.split.entry
    i64 2394, label %handler.volatile_atomic_rmw_and.op95a.split.entry
    i64 2051, label %handler.const_load.op803.split.entry
    i64 109, label %handler.iadd.op6d.split.entry
    i64 2467, label %handler.load_iusub_sat.op9a3.split.entry
    i64 2178, label %handler.issub_overflow.op882.split.entry
    i64 2430, label %handler.cmpxchg.op97e.split.entry
    i64 2357, label %handler.atomic_rmw_nand.op935.split.entry
    i64 2342, label %handler.volatile_atomic_load.op926.split.entry
    i64 2209, label %handler.fcopysign.op8a1.split.entry
    i64 2479, label %handler.load_ior.op9af.split.entry
    i64 2346, label %handler.atomic_rmw_xchg.op92a.split.entry
    i64 2303, label %handler.alloca.op8ff.split.entry
    i64 131, label %handler.iudiv.op83.split.entry
    i64 230, label %handler.atomic_rmw_and.ope6.split.entry
    i64 2126, label %handler.isrem.op84e.split.entry
    i64 2302, label %handler.bitcast.op8fe.split.entry
    i64 2062, label %handler.global_addr.op80e.split.entry
    i64 305, label %handler.iusub_overflow.op131.split.entry
    i64 312, label %handler.ismul_overflow.op138.split.entry
    i64 2285, label %handler.fllround.op8ed.split.entry
    i64 460, label %handler.write_fpmode.op1cc.split.entry
    i64 56, label %handler.call_native.op38.split.entry
    i64 6, label %handler.mov.op06.split.entry
    i64 2466, label %handler.load_iuadd_sat.op9a2.split.entry
    i64 260, label %handler.bswap.op104.split.entry
    i64 2403, label %handler.volatile_atomic_rmw_min.op963.split.entry
    i64 279, label %handler.iabs.op117.split.entry
    i64 1845, label %handler.fpowi.op735.split.entry
    i64 115, label %handler.call_native.op73.split.entry
    i64 2160, label %handler.iuadd_sat.op870.split.entry
    i64 2370, label %handler.atomic_rmw_udec_wrap.op942.split.entry
    i64 172, label %handler.frem.opac.split.entry
    i64 2399, label %handler.volatile_atomic_rmw_nand.op95f.split.entry
    i64 233, label %handler.atomic_rmw_or.ope9.split.entry
    i64 1853, label %handler.fllround.op73d.split.entry
    i64 55, label %handler.gep.op37.split.entry
    i64 33, label %handler.ixor.op21.split.entry
    i64 231, label %handler.atomic_rmw_and.ope7.split.entry
    i64 160, label %handler.fmul.opa0.split.entry
    i64 2327, label %handler.memmove_dyn.op917.split.entry
    i64 2398, label %handler.volatile_atomic_rmw_xor.op95e.split.entry
    i64 2203, label %handler.fmul.op89b.split.entry
    i64 2463, label %handler.load_iumin.op99f.split.entry
    i64 1799, label %handler.fsqrt.op707.split.entry
    i64 2225, label %handler.fabs.op8b1.split.entry
    i64 307, label %handler.issub_overflow.op133.split.entry
    i64 2359, label %handler.atomic_rmw_max.op937.split.entry
    i64 282, label %handler.ismax.op11a.split.entry
    i64 1831, label %handler.fcos.op727.split.entry
    i64 385, label %handler.volatile_atomic_rmw_xchg.op181.split.entry
    i64 2384, label %handler.atomic_rmw_fmaximum.op950.split.entry
    i64 2108, label %handler.iadd_xor.op83c.split.entry
    i64 2443, label %handler.load_iudiv.op98b.split.entry
    i64 1847, label %handler.flrint.op737.split.entry
    i64 2341, label %handler.volatile_atomic_load.op925.split.entry
    i64 238, label %handler.fence.opee.split.entry
    i64 170, label %handler.frem.opaa.split.entry
    i64 7, label %handler.fake_nop.op07.split.entry
    i64 2083, label %handler.read_fpenv.op823.split.entry
    i64 103, label %handler.br.op67.split.entry
    i64 76, label %handler.br.op4c.split.entry
    i64 2229, label %handler.fcanonicalize.op8b5.split.entry
    i64 2265, label %handler.uitofp.op8d9.split.entry
    i64 285, label %handler.iumax.op11d.split.entry
    i64 303, label %handler.isadd_overflow.op12f.split.entry
    i64 424, label %handler.volatile_atomic_rmw_fminimum.op1a8.split.entry
    i64 2418, label %handler.volatile_atomic_rmw_fadd.op972.split.entry
    i64 2176, label %handler.iusub_overflow.op880.split.entry
    i64 434, label %handler.stackrestore.op1b2.split.entry
    i64 2237, label %handler.frint.op8bd.split.entry
    i64 2150, label %handler.ismax.op866.split.entry
    i64 2350, label %handler.atomic_rmw_sub.op92e.split.entry
    i64 14, label %handler.mov_imm.op0e.split.entry
    i64 2488, label %handler.fake_nop.op9b8.split.entry
    i64 2061, label %handler.global_addr.op80d.split.entry
    i64 2166, label %handler.issub_sat.op876.split.entry
    i64 2322, label %handler.store.op912.split.entry
    i64 2315, label %handler.prefetch.op90b.split.entry
    i64 359, label %handler.atomic_rmw_fmin.op167.split.entry
    i64 290, label %handler.iuadd_sat.op122.split.entry
    i64 1818, label %handler.ftrunc.op71a.split.entry
    i64 18, label %handler.imul.op12.split.entry
    i64 295, label %handler.issub_sat.op127.split.entry
    i64 2214, label %handler.fpowi.op8a6.split.entry
    i64 78, label %handler.ilshr.op4e.split.entry
    i64 68, label %handler.vm_ret.op44.split.entry
    i64 1821, label %handler.frint.op71d.split.entry
    i64 2330, label %handler.memset_dyn.op91a.split.entry
    i64 264, label %handler.fshl.op108.split.entry
    i64 472, label %handler.load_imul.op1d8.split.entry
    i64 2079, label %handler.write_rounding.op81f.split.entry
    i64 2473, label %handler.load_iushl_sat.op9a9.split.entry
    i64 225, label %handler.atomic_rmw_xchg.ope1.split.entry
    i64 2118, label %handler.iudiv.op846.split.entry
    i64 269, label %handler.icmp_br_if.op10d.split.entry
    i64 2498, label %handler.unreachable.op9c2.split.entry
    i64 441, label %handler.fptosi_sat.op1b9.split.entry
    i64 139, label %handler.iurem.op8b.split.entry
    i64 2257, label %handler.flog2.op8d1.split.entry
    i64 477, label %handler.load_isdiv.op1dd.split.entry
    i64 4, label %handler.ixor.op04.split.entry
    i64 178, label %handler.fneg.opb2.split.entry
    i64 503, label %handler.load_issub_sat.op1f7.split.entry
    i64 360, label %handler.atomic_rmw_fmaximum.op168.split.entry
    i64 156, label %handler.fsub.op9c.split.entry
    i64 23, label %handler.ilshr.op17.split.entry
    i64 493, label %handler.load_iumax.op1ed.split.entry
    i64 2501, label %handler.ret.op9c5.split.entry
    i64 12, label %handler.ret.op0c.split.entry
    i64 387, label %handler.volatile_atomic_rmw_add.op183.split.entry
    i64 352, label %handler.atomic_rmw_fadd.op160.split.entry
    i64 217, label %handler.atomic_store.opd9.split.entry
    i64 229, label %handler.atomic_rmw_sub.ope5.split.entry
    i64 497, label %handler.load_iuadd_sat.op1f1.split.entry
    i64 2102, label %handler.sideeffect.op836.split.entry
    i64 192, label %handler.uitofp.opc0.split.entry
    i64 1826, label %handler.froundeven.op722.split.entry
    i64 201, label %handler.fptoui.opc9.split.entry
    i64 67, label %handler.vm_ret.op43.split.entry
    i64 1834, label %handler.fexp2.op72a.split.entry
    i64 169, label %handler.frem.opa9.split.entry
    i64 248, label %handler.atomic_rmw_umin.opf8.split.entry
    i64 2135, label %handler.ptrmask.op857.split.entry
    i64 2476, label %handler.load_isshl_sat.op9ac.split.entry
    i64 2219, label %handler.fminimum.op8ab.split.entry
    i64 88, label %handler.sext.op58.split.entry
    i64 2477, label %handler.load_iand.op9ad.split.entry
    i64 75, label %handler.iashr.op4b.split.entry
    i64 2299, label %handler.trunc.op8fb.split.entry
    i64 475, label %handler.load_iudiv.op1db.split.entry
    i64 2107, label %handler.iadd.op83b.split.entry
    i64 63, label %handler.br_if.op3f.split.entry
    i64 228, label %handler.atomic_rmw_sub.ope4.split.entry
    i64 2307, label %handler.stacksave.op903.split.entry
    i64 2204, label %handler.fmul.op89c.split.entry
    i64 473, label %handler.load_imul.op1d9.split.entry
    i64 2492, label %handler.br_if.op9bc.split.entry
    i64 2169, label %handler.isshl_sat.op879.split.entry
    i64 2454, label %handler.load_ilshr.op996.split.entry
    i64 2453, label %handler.load_ilshr.op995.split.entry
    i64 2078, label %handler.write_rounding.op81e.split.entry
    i64 236, label %handler.cmpxchg.opec.split.entry
    i64 1828, label %handler.fsin.op724.split.entry
    i64 2272, label %handler.fptosi_sat.op8e0.split.entry
    i64 480, label %handler.load_isrem.op1e0.split.entry
    i64 1825, label %handler.fround.op721.split.entry
    i64 2499, label %handler.trap.op9c3.split.entry
    i64 2393, label %handler.volatile_atomic_rmw_and.op959.split.entry
    i64 2311, label %handler.clear_cache.op907.split.entry
    i64 494, label %handler.load_iumin.op1ee.split.entry
    i64 125, label %handler.sext.op7d.split.entry
    i64 464, label %handler.read_flt_rounds.op1d0.split.entry
    i64 492, label %handler.load_iumax.op1ec.split.entry
    i64 489, label %handler.load_ismax.op1e9.split.entry
    i64 164, label %handler.fdiv.opa4.split.entry
    i64 240, label %handler.atomic_rmw_nand.opf0.split.entry
    i64 1833, label %handler.fexp.op729.split.entry
    i64 2428, label %handler.volatile_atomic_rmw_fminimum.op97c.split.entry
    i64 2282, label %handler.fllrint.op8ea.split.entry
    i64 70, label %handler.zext.op46.split.entry
    i64 1815, label %handler.ffloor.op717.split.entry
    i64 153, label %handler.fsub.op99.split.entry
    i64 329, label %handler.volatile_store.op149.split.entry
    i64 212, label %handler.fpext.opd4.split.entry
    i64 2162, label %handler.iusub_sat.op872.split.entry
    i64 300, label %handler.isshl_sat.op12c.split.entry
    i64 2469, label %handler.load_isadd_sat.op9a5.split.entry
    i64 2145, label %handler.ilshr.op861.split.entry
    i64 154, label %handler.fsub.op9a.split.entry
    i64 2280, label %handler.flrint.op8e8.split.entry
    i64 1811, label %handler.ffmuladd.op713.split.entry
    i64 2452, label %handler.load_ishl.op994.split.entry
    i64 218, label %handler.atomic_store.opda.split.entry
    i64 168, label %handler.frem.opa8.split.entry
    i64 2465, label %handler.load_iuadd_sat.op9a1.split.entry
    i64 498, label %handler.load_iusub_sat.op1f2.split.entry
    i64 31, label %handler.icmp.op1f.split.entry
    i64 2255, label %handler.flog10.op8cf.split.entry
    i64 46, label %handler.ior.op2e.split.entry
    i64 2106, label %handler.iadd.op83a.split.entry
    i64 304, label %handler.isadd_overflow.op130.split.entry
    i64 5, label %handler.alloca.op05.split.entry
    i64 107, label %handler.ixor.op6b.split.entry
    i64 292, label %handler.iusub_sat.op124.split.entry
    i64 2267, label %handler.fptosi.op8db.split.entry
    i64 133, label %handler.isdiv.op85.split.entry
    i64 2376, label %handler.atomic_rmw_fadd.op948.split.entry
    i64 2295, label %handler.zext.op8f7.split.entry
    i64 296, label %handler.issub_sat.op128.split.entry
    i64 2427, label %handler.volatile_atomic_rmw_fminimum.op97b.split.entry
    i64 2195, label %handler.fshl.op893.split.entry
    i64 92, label %handler.ilshr.op5c.split.entry
    i64 2258, label %handler.flog2.op8d2.split.entry
    i64 289, label %handler.iuadd_sat.op121.split.entry
    i64 42, label %handler.ixor.op2a.split.entry
    i64 388, label %handler.volatile_atomic_rmw_sub.op184.split.entry
    i64 2349, label %handler.atomic_rmw_sub.op92d.split.entry
    i64 60, label %handler.ishl.op3c.split.entry
    i64 2287, label %handler.icmp.op8ef.split.entry
    i64 171, label %handler.frem.opab.split.entry
    i64 430, label %handler.sideeffect.op1ae.split.entry
    i64 2495, label %handler.vm_ret.op9bf.split.entry
    i64 2086, label %handler.write_fpenv.op826.split.entry
    i64 11, label %handler.alloca.op0b.split.entry
    i64 2070, label %handler.read_vscale.op816.split.entry
    i64 1804, label %handler.fmaxnum.op70c.split.entry
    i64 2158, label %handler.iumin.op86e.split.entry
    i64 2316, label %handler.prefetch.op90c.split.entry
    i64 151, label %handler.fadd.op97.split.entry
    i64 81, label %handler.load.op51.split.entry
    i64 20, label %handler.iand.op14.split.entry
    i64 2146, label %handler.ilshr.op862.split.entry
    i64 1813, label %handler.fcanonicalize.op715.split.entry
    i64 262, label %handler.bitreverse.op106.split.entry
    i64 2340, label %handler.atomic_store.op924.split.entry
    i64 2360, label %handler.atomic_rmw_max.op938.split.entry
    i64 2355, label %handler.atomic_rmw_xor.op933.split.entry
    i64 2447, label %handler.load_iurem.op98f.split.entry
    i64 2090, label %handler.read_fpmode.op82a.split.entry
    i64 1839, label %handler.flog10.op72f.split.entry
    i64 2125, label %handler.iurem.op84d.split.entry
    i64 206, label %handler.fptrunc.opce.split.entry
    i64 99, label %handler.zext.op63.split.entry
    i64 224, label %handler.atomic_rmw_xchg.ope0.split.entry
    i64 267, label %handler.iadd_xor.op10b.split.entry
    i64 202, label %handler.fptoui.opca.split.entry
    i64 263, label %handler.fshl.op107.split.entry
    i64 291, label %handler.iusub_sat.op123.split.entry
    i64 1819, label %handler.ftrunc.op71b.split.entry
    i64 381, label %handler.volatile_memset_dyn.op17d.split.entry
    i64 495, label %handler.load_iumin.op1ef.split.entry
    i64 2134, label %handler.iand.op856.split.entry
    i64 2159, label %handler.iuadd_sat.op86f.split.entry
    i64 2233, label %handler.fceil.op8b9.split.entry
    i64 2383, label %handler.atomic_rmw_fmaximum.op94f.split.entry
    i64 2152, label %handler.ismax.op868.split.entry
    i64 2368, label %handler.atomic_rmw_uinc_wrap.op940.split.entry
    i64 35, label %handler.zext.op23.split.entry
    i64 152, label %handler.fadd.op98.split.entry
    i64 266, label %handler.fshr.op10a.split.entry
    i64 2055, label %handler.mov.op807.split.entry
    i64 2472, label %handler.load_issub_sat.op9a8.split.entry
    i64 2410, label %handler.volatile_atomic_rmw_uinc_wrap.op96a.split.entry
    i64 1807, label %handler.fminimum.op70f.split.entry
    i64 2269, label %handler.fptoui.op8dd.split.entry
    i64 44, label %handler.iadd.op2c.split.entry
    i64 2065, label %handler.read_cycle.op811.split.entry
    i64 2423, label %handler.volatile_atomic_rmw_fmin.op977.split.entry
    i64 2191, label %handler.bswap.op88f.split.entry
    i64 2401, label %handler.volatile_atomic_rmw_max.op961.split.entry
    i64 185, label %handler.sitofp.opb9.split.entry
    i64 176, label %handler.fcmp.opb0.split.entry
    i64 1808, label %handler.fmaximum.op710.split.entry
    i64 422, label %handler.volatile_atomic_rmw_fmaximum.op1a6.split.entry
    i64 2278, label %handler.fpext.op8e6.split.entry
    i64 2426, label %handler.volatile_atomic_rmw_fmaximum.op97a.split.entry
    i64 120, label %handler.ishl.op78.split.entry
    i64 2301, label %handler.bitcast.op8fd.split.entry
    i64 2434, label %handler.fence.op982.split.entry
    i64 2438, label %handler.gep_load.op986.split.entry
    i64 2064, label %handler.read_cycle.op810.split.entry
    i64 2379, label %handler.atomic_rmw_fmax.op94b.split.entry
    i64 147, label %handler.isrem.op93.split.entry
    i64 155, label %handler.fsub.op9b.split.entry
    i64 451, label %handler.write_rounding.op1c3.split.entry
    i64 2317, label %handler.load.op90d.split.entry
    i64 306, label %handler.iusub_overflow.op132.split.entry
    i64 118, label %handler.icmp.op76.split.entry
    i64 128, label %handler.iudiv.op80.split.entry
    i64 22, label %handler.ishl.op16.split.entry
    i64 2142, label %handler.ishl.op85e.split.entry
    i64 496, label %handler.load_iuadd_sat.op1f0.split.entry
    i64 2474, label %handler.load_iushl_sat.op9aa.split.entry
    i64 2187, label %handler.cttz.op88b.split.entry
    i64 377, label %handler.volatile_memcpy_dyn.op179.split.entry
    i64 2147, label %handler.iashr.op863.split.entry
    i64 1844, label %handler.fpowi.op734.split.entry
    i64 479, label %handler.load_iurem.op1df.split.entry
    i64 2335, label %handler.volatile_memset_dyn.op91f.split.entry
    i64 191, label %handler.uitofp.opbf.split.entry
    i64 2202, label %handler.fsub.op89a.split.entry
    i64 2417, label %handler.volatile_atomic_rmw_fadd.op971.split.entry
    i64 1814, label %handler.ffloor.op716.split.entry
    i64 91, label %handler.call_native.op5b.split.entry
    i64 259, label %handler.bswap.op103.split.entry
    i64 2122, label %handler.isdiv.op84a.split.entry
    i64 2396, label %handler.volatile_atomic_rmw_or.op95c.split.entry
    i64 1809, label %handler.fmaximum.op711.split.entry
    i64 452, label %handler.read_fpenv.op1c4.split.entry
    i64 2117, label %handler.iudiv.op845.split.entry
    i64 2480, label %handler.load_ior.op9b0.split.entry
    i64 2413, label %handler.volatile_atomic_rmw_usub_cond.op96d.split.entry
    i64 27, label %handler.trunc.op1b.split.entry
    i64 275, label %handler.ctlz.op113.split.entry
    i64 142, label %handler.iurem.op8e.split.entry
    i64 364, label %handler.atomic_rmw_uinc_wrap.op16c.split.entry
    i64 252, label %handler.load_ixor.opfc.split.entry
    i64 2057, label %handler.tls_addr.op809.split.entry
    i64 413, label %handler.volatile_atomic_rmw_usub_sat.op19d.split.entry
    i64 2180, label %handler.iumul_overflow.op884.split.entry
    i64 1830, label %handler.fcos.op726.split.entry
    i64 2100, label %handler.read_thread_pointer.op834.split.entry
    i64 3, label %handler.const_load.op03.split.entry
    i64 2284, label %handler.flround.op8ec.split.entry
    i64 2170, label %handler.isshl_sat.op87a.split.entry
    i64 2395, label %handler.volatile_atomic_rmw_or.op95b.split.entry
    i64 363, label %handler.atomic_rmw_fminimum.op16b.split.entry
    i64 95, label %handler.const_load.op5f.split.entry
    i64 442, label %handler.fptoui_sat.op1ba.split.entry
    i64 2103, label %handler.sideeffect.op837.split.entry
    i64 2402, label %handler.volatile_atomic_rmw_max.op962.split.entry
    i64 281, label %handler.ismax.op119.split.entry
    i64 2213, label %handler.fpowi.op8a5.split.entry
    i64 2298, label %handler.sext.op8fa.split.entry
    i64 2157, label %handler.iumin.op86d.split.entry
    i64 274, label %handler.load_iadd.op112.split.entry
    i64 2314, label %handler.pseudoprobe.op90a.split.entry
    i64 134, label %handler.isdiv.op86.split.entry
    i64 34, label %handler.gep.op22.split.entry
    i64 482, label %handler.load_ishl.op1e2.split.entry
    i64 197, label %handler.fptosi.opc5.split.entry
    i64 2271, label %handler.fptosi_sat.op8df.split.entry
    i64 2270, label %handler.fptoui.op8de.split.entry
    i64 203, label %handler.fptrunc.opcb.split.entry
    i64 2156, label %handler.iumax.op86c.split.entry
    i64 179, label %handler.fneg.opb3.split.entry
    i64 454, label %handler.write_fpenv.op1c6.split.entry
    i64 318, label %handler.global_addr.op13e.split.entry
    i64 361, label %handler.atomic_rmw_fmaximum.op169.split.entry
    i64 2289, label %handler.icmp_br_if.op8f1.split.entry
    i64 491, label %handler.load_ismin.op1eb.split.entry
    i64 410, label %handler.volatile_atomic_rmw_usub_cond.op19a.split.entry
    i64 2442, label %handler.load_imul.op98a.split.entry
    i64 376, label %handler.volatile_memcpy_dyn.op178.split.entry
    i64 2411, label %handler.volatile_atomic_rmw_udec_wrap.op96b.split.entry
    i64 456, label %handler.reset_fpenv.op1c8.split.entry
    i64 2183, label %handler.ctpop.op887.split.entry
    i64 2155, label %handler.iumax.op86b.split.entry
    i64 487, label %handler.load_iashr.op1e7.split.entry
    i64 249, label %handler.atomic_rmw_umin.opf9.split.entry
    i64 2294, label %handler.fpclass.op8f6.split.entry
    i64 2138, label %handler.ior.op85a.split.entry
    i64 157, label %handler.fsub.op9d.split.entry
    i64 1843, label %handler.fpow.op733.split.entry
    i64 209, label %handler.fpext.opd1.split.entry
    i64 257, label %handler.ctpop.op101.split.entry
    i64 2491, label %handler.br_if.op9bb.split.entry
    i64 299, label %handler.isshl_sat.op12b.split.entry
    i64 411, label %handler.volatile_atomic_rmw_usub_cond.op19b.split.entry
    i64 2074, label %handler.read_rounding.op81a.split.entry
    i64 2290, label %handler.icmp_br_if.op8f2.split.entry
    i64 287, label %handler.iumin.op11f.split.entry
    i64 1810, label %handler.ffmuladd.op712.split.entry
    i64 2292, label %handler.fcmp.op8f4.split.entry
    i64 2224, label %handler.fneg.op8b0.split.entry
    i64 2496, label %handler.vm_ret.op9c0.split.entry
    i64 379, label %handler.volatile_memmove_dyn.op17b.split.entry
    i64 426, label %handler.read_cycle.op1aa.split.entry
    i64 51, label %handler.bitcast.op33.split.entry
    i64 445, label %handler.read_vscale.op1bd.split.entry
    i64 101, label %handler.mov_imm.op65.split.entry
    i64 2275, label %handler.fptrunc.op8e3.split.entry
    i64 36, label %handler.store.op24.split.entry
    i64 2143, label %handler.ishl.op85f.split.entry
    i64 32, label %handler.icmp.op20.split.entry
    i64 47, label %handler.trunc.op2f.split.entry
    i64 148, label %handler.fadd.op94.split.entry
    i64 2309, label %handler.stackrestore.op905.split.entry
    i64 490, label %handler.load_ismin.op1ea.split.entry
    i64 2221, label %handler.fmaximum.op8ad.split.entry
    i64 504, label %handler.load_iushl_sat.op1f8.split.entry
    i64 2378, label %handler.atomic_rmw_fsub.op94a.split.entry
    i64 500, label %handler.load_isadd_sat.op1f4.split.entry
    i64 506, label %handler.load_isshl_sat.op1fa.split.entry
    i64 447, label %handler.read_rounding.op1bf.split.entry
    i64 1848, label %handler.fllrint.op738.split.entry
    i64 2095, label %handler.write_fpmode.op82f.split.entry
    i64 208, label %handler.fpext.opd0.split.entry
    i64 2261, label %handler.ffmuladd.op8d5.split.entry
    i64 2053, label %handler.const_load.op805.split.entry
    i64 149, label %handler.fadd.op95.split.entry
    i64 86, label %handler.mov.op56.split.entry
    i64 207, label %handler.fptrunc.opcf.split.entry
    i64 213, label %handler.atomic_load.opd5.split.entry
    i64 353, label %handler.atomic_rmw_fadd.op161.split.entry
    i64 2404, label %handler.volatile_atomic_rmw_min.op964.split.entry
    i64 190, label %handler.uitofp.opbe.split.entry
    i64 182, label %handler.fneg.opb6.split.entry
    i64 2484, label %handler.load_ixor.op9b4.split.entry
    i64 159, label %handler.fmul.op9f.split.entry
    i64 502, label %handler.load_issub_sat.op1f6.split.entry
    i64 2089, label %handler.reset_fpenv.op829.split.entry
    i64 2091, label %handler.read_fpmode.op82b.split.entry
    i64 79, label %handler.mov_imm.op4f.split.entry
    i64 136, label %handler.isdiv.op88.split.entry
    i64 2382, label %handler.atomic_rmw_fmin.op94e.split.entry
    i64 438, label %handler.pseudoprobe.op1b6.split.entry
    i64 2081, label %handler.read_fpenv.op821.split.entry
    i64 2470, label %handler.load_isadd_sat.op9a6.split.entry
    i64 2306, label %handler.alloca_dyn.op902.split.entry
    i64 2231, label %handler.ffloor.op8b7.split.entry
    i64 2374, label %handler.atomic_rmw_usub_sat.op946.split.entry
    i64 297, label %handler.iushl_sat.op129.split.entry
    i64 2291, label %handler.fcmp.op8f3.split.entry
    i64 448, label %handler.read_thread_pointer.op1c0.split.entry
    i64 437, label %handler.clear_cache.op1b5.split.entry
    i64 2389, label %handler.volatile_atomic_rmw_add.op955.split.entry
    i64 85, label %handler.alloca.op55.split.entry
    i64 310, label %handler.iumul_overflow.op136.split.entry
    i64 10, label %handler.const_load.op0a.split.entry
    i64 327, label %handler.volatile_load.op147.split.entry
    i64 2406, label %handler.volatile_atomic_rmw_umax.op966.split.entry
    i64 1794, label %handler.fabs.op702.split.entry
    i64 2435, label %handler.gep.op983.split.entry
    i64 2352, label %handler.atomic_rmw_and.op930.split.entry
    i64 2223, label %handler.fneg.op8af.split.entry
    i64 2326, label %handler.memcpy_dyn.op916.split.entry
    i64 443, label %handler.fptoui_sat.op1bb.split.entry
    i64 2367, label %handler.atomic_rmw_uinc_wrap.op93f.split.entry
    i64 1849, label %handler.fllrint.op739.split.entry
    i64 2069, label %handler.read_vscale.op815.split.entry
    i64 2165, label %handler.issub_sat.op875.split.entry
    i64 396, label %handler.volatile_atomic_rmw_nand.op18c.split.entry
    i64 455, label %handler.write_fpenv.op1c7.split.entry
    i64 234, label %handler.atomic_rmw_xor.opea.split.entry
    i64 90, label %handler.iadd.op5a.split.entry
    i64 476, label %handler.load_isdiv.op1dc.split.entry
    i64 485, label %handler.load_ilshr.op1e5.split.entry
    i64 198, label %handler.fptoui.opc6.split.entry
    i64 2087, label %handler.reset_fpenv.op827.split.entry
    i64 268, label %handler.iadd_xor.op10c.split.entry
    i64 439, label %handler.pseudoprobe.op1b7.split.entry
    i64 2300, label %handler.trunc.op8fc.split.entry
    i64 328, label %handler.volatile_load.op148.split.entry
    i64 222, label %handler.unreachable.opde.split.entry
    i64 2124, label %handler.iurem.op84c.split.entry
    i64 283, label %handler.ismin.op11b.split.entry
    i64 188, label %handler.uitofp.opbc.split.entry
    i64 235, label %handler.atomic_rmw_xor.opeb.split.entry
    i64 102, label %handler.isub.op66.split.entry
    i64 242, label %handler.atomic_rmw_max.opf2.split.entry
    i64 1837, label %handler.flog.op72d.split.entry
    i64 150, label %handler.fadd.op96.split.entry
    i64 276, label %handler.ctlz.op114.split.entry
    i64 2420, label %handler.volatile_atomic_rmw_fsub.op974.split.entry
    i64 401, label %handler.volatile_atomic_rmw_min.op191.split.entry
    i64 484, label %handler.load_ilshr.op1e4.split.entry
    i64 400, label %handler.volatile_atomic_rmw_min.op190.split.entry
    i64 425, label %handler.volatile_atomic_rmw_fminimum.op1a9.split.entry
    i64 2201, label %handler.fsub.op899.split.entry
    i64 402, label %handler.volatile_atomic_rmw_umax.op192.split.entry
    i64 57, label %handler.fake_nop.op39.split.entry
    i64 226, label %handler.atomic_rmw_add.ope2.split.entry
    i64 2321, label %handler.store.op911.split.entry
    i64 2244, label %handler.froundeven.op8c4.split.entry
    i64 284, label %handler.ismin.op11c.split.entry
    i64 2268, label %handler.fptosi.op8dc.split.entry
    i64 317, label %handler.global_addr.op13d.split.entry
    i64 41, label %handler.vm_ret.op29.split.entry
    i64 324, label %handler.memcpy_dyn.op144.split.entry
    i64 181, label %handler.fneg.opb5.split.entry
    i64 2338, label %handler.atomic_load.op922.split.entry
    i64 368, label %handler.atomic_rmw_usub_cond.op170.split.entry
    i64 2066, label %handler.read_steady.op812.split.entry
    i64 2405, label %handler.volatile_atomic_rmw_umax.op965.split.entry
    i64 166, label %handler.fdiv.opa6.split.entry
    i64 2336, label %handler.volatile_memset_dyn.op920.split.entry
    i64 94, label %handler.icmp.op5e.split.entry
    i64 463, label %handler.reset_fpmode.op1cf.split.entry
    i64 175, label %handler.fcmp.opaf.split.entry
    i64 82, label %handler.icmp.op52.split.entry
    i64 2263, label %handler.sitofp.op8d7.split.entry
    i64 2228, label %handler.fsqrt.op8b4.split.entry
    i64 2210, label %handler.fcopysign.op8a2.split.entry
    i64 1820, label %handler.frint.op71c.split.entry
    i64 1852, label %handler.fllround.op73c.split.entry
    i64 64, label %handler.br.op40.split.entry
    i64 2375, label %handler.atomic_rmw_fadd.op947.split.entry
    i64 53, label %handler.load.op35.split.entry
    i64 2094, label %handler.write_fpmode.op82e.split.entry
    i64 308, label %handler.issub_overflow.op134.split.entry
    i64 1802, label %handler.fminnum.op70a.split.entry
    i64 2096, label %handler.reset_fpmode.op830.split.entry
    i64 2184, label %handler.ctpop.op888.split.entry
    i64 2312, label %handler.clear_cache.op908.split.entry
    i64 2199, label %handler.fadd.op897.split.entry
    i64 2310, label %handler.stackrestore.op906.split.entry
    i64 43, label %handler.ishl.op2b.split.entry
    i64 2482, label %handler.load_isub.op9b2.split.entry
    i64 1851, label %handler.flround.op73b.split.entry
    i64 261, label %handler.bitreverse.op105.split.entry
    i64 2458, label %handler.load_ismax.op99a.split.entry
    i64 280, label %handler.iabs.op118.split.entry
    i64 2196, label %handler.fshl.op894.split.entry
    i64 406, label %handler.volatile_atomic_rmw_uinc_wrap.op196.split.entry
    i64 137, label %handler.isdiv.op89.split.entry
    i64 375, label %handler.volatile_atomic_store.op177.split.entry
    i64 21, label %handler.ior.op15.split.entry
    i64 50, label %handler.trunc.op32.split.entry
    i64 89, label %handler.ret.op59.split.entry
    i64 325, label %handler.memmove_dyn.op145.split.entry
    i64 2431, label %handler.volatile_cmpxchg.op97f.split.entry
    i64 2332, label %handler.volatile_memcpy_dyn.op91c.split.entry
    i64 2109, label %handler.iadd_xor.op83d.split.entry
    i64 2131, label %handler.ixor.op853.split.entry
    i64 2220, label %handler.fminimum.op8ac.split.entry
    i64 187, label %handler.sitofp.opbb.split.entry
    i64 2052, label %handler.const_load.op804.split.entry
    i64 2247, label %handler.fcos.op8c7.split.entry
    i64 2487, label %handler.fake_nop.op9b7.split.entry
    i64 2408, label %handler.volatile_atomic_rmw_umin.op968.split.entry
    i64 122, label %handler.iadd.op7a.split.entry
    i64 2500, label %handler.trap.op9c4.split.entry
    i64 321, label %handler.memset_dyn.op141.split.entry
    i64 2445, label %handler.load_isdiv.op98d.split.entry
  ]

default.return:                                   ; preds = %execute.decode, %handler.ret.op0c.split.body, %handler.ret.op9c6.split.body, %handler.ret.op7f.split.body, %loop.check, %descriptor.decode, %entry
  %reg.load.ptr2751 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  %ret = load i64, ptr %reg.load.ptr2751, align 8
  %reg.load.ptr2752 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  %ret.slot.value = load i64, ptr %reg.load.ptr2752, align 8
  %ret.slot.ptr = getelementptr i64, ptr %1, i64 0
  store i64 %ret.slot.value, ptr %ret.slot.ptr, align 8
  %reg.load.ptr2753 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 1
  %ret.slot.value2754 = load i64, ptr %reg.load.ptr2753, align 8
  %ret.slot.ptr2755 = getelementptr i64, ptr %1, i64 1
  store i64 %ret.slot.value2754, ptr %ret.slot.ptr2755, align 8
  %reg.load.ptr2756 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 2
  %ret.slot.value2757 = load i64, ptr %reg.load.ptr2756, align 8
  %ret.slot.ptr2758 = getelementptr i64, ptr %1, i64 2
  store i64 %ret.slot.value2757, ptr %ret.slot.ptr2758, align 8
  ret i64 %ret

handler.ismax.op867.split.entry:                  ; preds = %execute.decode
  br label %handler.ismax.op867.split.body

handler.ismax.op867.split.body:                   ; preds = %handler.ismax.op867.split.entry
  %dead.alias.pc = load i64, ptr %pc, align 8
  %dead.alias.next = add i64 %dead.alias.pc, 32
  store i64 %dead.alias.next, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_nand.op960.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_nand.op960.split.body

handler.volatile_atomic_rmw_nand.op960.split.body: ; preds = %handler.volatile_atomic_rmw_nand.op960.split.entry
  %dead.alias.pc332 = load i64, ptr %pc, align 8
  %dead.alias.next333 = add i64 %dead.alias.pc332, 32
  store i64 %dead.alias.next333, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_cond.op944.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_cond.op944.split.body

handler.atomic_rmw_usub_cond.op944.split.body:    ; preds = %handler.atomic_rmw_usub_cond.op944.split.entry
  %dead.alias.pc334 = load i64, ptr %pc, align 8
  %dead.alias.next335 = add i64 %dead.alias.pc334, 32
  store i64 %dead.alias.next335, ptr %pc, align 8
  br label %loop.check

handler.write_fpmode.op82d.split.entry:           ; preds = %execute.decode
  br label %handler.write_fpmode.op82d.split.body

handler.write_fpmode.op82d.split.body:            ; preds = %handler.write_fpmode.op82d.split.entry
  %dead.alias.pc336 = load i64, ptr %pc, align 8
  %dead.alias.next337 = add i64 %dead.alias.pc336, 8
  store i64 %dead.alias.next337, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_or.op931.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_or.op931.split.body

handler.atomic_rmw_or.op931.split.body:           ; preds = %handler.atomic_rmw_or.op931.split.entry
  %dead.alias.pc338 = load i64, ptr %pc, align 8
  %dead.alias.next339 = add i64 %dead.alias.pc338, 32
  store i64 %dead.alias.next339, ptr %pc, align 8
  br label %loop.check

handler.iushl_sat.op12a.split.entry:              ; preds = %execute.decode
  br label %handler.iushl_sat.op12a.split.body

handler.iushl_sat.op12a.split.body:               ; preds = %handler.iushl_sat.op12a.split.entry
  %dead.alias.pc340 = load i64, ptr %pc, align 8
  %dead.alias.next341 = add i64 %dead.alias.pc340, 32
  store i64 %dead.alias.next341, ptr %pc, align 8
  br label %loop.check

handler.load_isdiv.op98e.split.entry:             ; preds = %execute.decode
  br label %handler.load_isdiv.op98e.split.body

handler.load_isdiv.op98e.split.body:              ; preds = %handler.load_isdiv.op98e.split.entry
  %dead.alias.pc342 = load i64, ptr %pc, align 8
  %dead.alias.next343 = add i64 %dead.alias.pc342, 32
  store i64 %dead.alias.next343, ptr %pc, align 8
  br label %loop.check

handler.flround.op8eb.split.entry:                ; preds = %execute.decode
  br label %handler.flround.op8eb.split.body

handler.flround.op8eb.split.body:                 ; preds = %handler.flround.op8eb.split.entry
  %dead.alias.pc344 = load i64, ptr %pc, align 8
  %dead.alias.next345 = add i64 %dead.alias.pc344, 16
  store i64 %dead.alias.next345, ptr %pc, align 8
  br label %loop.check

handler.unreachable.opdd.split.entry:             ; preds = %execute.decode
  br label %handler.unreachable.opdd.split.body

handler.unreachable.opdd.split.body:              ; preds = %handler.unreachable.opdd.split.entry
  %dead.alias.pc346 = load i64, ptr %pc, align 8
  %dead.alias.next347 = add i64 %dead.alias.pc346, 4
  store i64 %dead.alias.next347, ptr %pc, align 8
  br label %loop.check

handler.fpow.op8a3.split.entry:                   ; preds = %execute.decode
  br label %handler.fpow.op8a3.split.body

handler.fpow.op8a3.split.body:                    ; preds = %handler.fpow.op8a3.split.entry
  %dead.alias.pc348 = load i64, ptr %pc, align 8
  %dead.alias.next349 = add i64 %dead.alias.pc348, 16
  store i64 %dead.alias.next349, ptr %pc, align 8
  br label %loop.check

handler.fneg.opb4.split.entry:                    ; preds = %execute.decode
  br label %handler.fneg.opb4.split.body

handler.fneg.opb4.split.body:                     ; preds = %handler.fneg.opb4.split.entry
  %dead.alias.pc350 = load i64, ptr %pc, align 8
  %dead.alias.next351 = add i64 %dead.alias.pc350, 32
  store i64 %dead.alias.next351, ptr %pc, align 8
  br label %loop.check

handler.ptrmask.op858.split.entry:                ; preds = %execute.decode
  br label %handler.ptrmask.op858.split.body

handler.ptrmask.op858.split.body:                 ; preds = %handler.ptrmask.op858.split.entry
  %dead.alias.pc352 = load i64, ptr %pc, align 8
  %dead.alias.next353 = add i64 %dead.alias.pc352, 16
  store i64 %dead.alias.next353, ptr %pc, align 8
  br label %loop.check

handler.gep.op984.split.entry:                    ; preds = %execute.decode
  br label %handler.gep.op984.split.body

handler.gep.op984.split.body:                     ; preds = %handler.gep.op984.split.entry
  %dead.alias.pc354 = load i64, ptr %pc, align 8
  %dead.alias.next355 = add i64 %dead.alias.pc354, 32
  store i64 %dead.alias.next355, ptr %pc, align 8
  br label %loop.check

handler.load_isadd_sat.op1f5.split.entry:         ; preds = %execute.decode
  br label %handler.load_isadd_sat.op1f5.split.body

handler.load_isadd_sat.op1f5.split.body:          ; preds = %handler.load_isadd_sat.op1f5.split.entry
  %dead.alias.pc356 = load i64, ptr %pc, align 8
  %dead.alias.next357 = add i64 %dead.alias.pc356, 32
  store i64 %dead.alias.next357, ptr %pc, align 8
  br label %loop.check

handler.load_iadd.op988.split.entry:              ; preds = %execute.decode
  br label %handler.load_iadd.op988.split.body

handler.load_iadd.op988.split.body:               ; preds = %handler.load_iadd.op988.split.entry
  %dead.alias.pc358 = load i64, ptr %pc, align 8
  %dead.alias.next359 = add i64 %dead.alias.pc358, 32
  store i64 %dead.alias.next359, ptr %pc, align 8
  br label %loop.check

handler.fmul.op9e.split.entry:                    ; preds = %execute.decode
  br label %handler.fmul.op9e.split.body

handler.fmul.op9e.split.body:                     ; preds = %handler.fmul.op9e.split.entry
  %dead.alias.pc360 = load i64, ptr %pc, align 8
  %dead.alias.next361 = add i64 %dead.alias.pc360, 32
  store i64 %dead.alias.next361, ptr %pc, align 8
  br label %loop.check

handler.load_ismin.op99c.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismin.op99c.split.body

handler.load_ismin.op99c.split.body:              ; preds = %handler.load_ismin.op99c.split.entry
  %dead.alias.pc362 = load i64, ptr %pc, align 8
  %dead.alias.next363 = add i64 %dead.alias.pc362, 32
  store i64 %dead.alias.next363, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_nand.op936.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_nand.op936.split.body

handler.atomic_rmw_nand.op936.split.body:         ; preds = %handler.atomic_rmw_nand.op936.split.entry
  %dead.alias.pc364 = load i64, ptr %pc, align 8
  %dead.alias.next365 = add i64 %dead.alias.pc364, 32
  store i64 %dead.alias.next365, ptr %pc, align 8
  br label %loop.check

handler.isrem.op850.split.entry:                  ; preds = %execute.decode
  br label %handler.isrem.op850.split.body

handler.isrem.op850.split.body:                   ; preds = %handler.isrem.op850.split.entry
  %dead.alias.pc366 = load i64, ptr %pc, align 8
  %dead.alias.next367 = add i64 %dead.alias.pc366, 32
  store i64 %dead.alias.next367, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_and.op186.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_and.op186.split.body

handler.volatile_atomic_rmw_and.op186.split.body: ; preds = %handler.volatile_atomic_rmw_and.op186.split.entry
  %dead.alias.pc368 = load i64, ptr %pc, align 8
  %dead.alias.next369 = add i64 %dead.alias.pc368, 32
  store i64 %dead.alias.next369, ptr %pc, align 8
  br label %loop.check

handler.const_load.op45.split.entry:              ; preds = %execute.decode
  br label %handler.const_load.op45.split.body

handler.const_load.op45.split.body:               ; preds = %handler.const_load.op45.split.entry
  %const_load.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %const_load.index = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %const_load.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %const.pool.read = call i64 @.amice.vm.h.a19eb3e0dbe6d829(ptr %descriptor.const.pool.ptr, i64 %descriptor.const.pool.len.plain, i64 %descriptor.bytecode.key.plain, i64 %const_load.index)
  %width.is64 = icmp eq i64 %const_load.width, 64
  %width.shift = and i64 %const_load.width, 63
  %mask.shifted = shl i64 1, %width.shift
  %mask.candidate = sub i64 %mask.shifted, 1
  %width.mask = select i1 %width.is64, i64 -1, i64 %mask.candidate
  %width.masked = and i64 %const.pool.read, %width.mask
  %reg.store.ptr370 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %const_load.dst
  store i64 %width.masked, ptr %reg.store.ptr370, align 8
  %pc.old = load i64, ptr %pc, align 8
  %pc.next = add i64 %pc.old, 32
  store i64 %pc.next, ptr %pc, align 8
  br label %loop.check

handler.read_steady.op1ac.split.entry:            ; preds = %execute.decode
  br label %handler.read_steady.op1ac.split.body

handler.read_steady.op1ac.split.body:             ; preds = %handler.read_steady.op1ac.split.entry
  %dead.alias.pc371 = load i64, ptr %pc, align 8
  %dead.alias.next372 = add i64 %dead.alias.pc371, 8
  store i64 %dead.alias.next372, ptr %pc, align 8
  br label %loop.check

handler.volatile_memmove_dyn.op91e.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_memmove_dyn.op91e.split.body

handler.volatile_memmove_dyn.op91e.split.body:    ; preds = %handler.volatile_memmove_dyn.op91e.split.entry
  %dead.alias.pc373 = load i64, ptr %pc, align 8
  %dead.alias.next374 = add i64 %dead.alias.pc373, 8
  store i64 %dead.alias.next374, ptr %pc, align 8
  br label %loop.check

handler.ixor.op851.split.entry:                   ; preds = %execute.decode
  br label %handler.ixor.op851.split.body

handler.ixor.op851.split.body:                    ; preds = %handler.ixor.op851.split.entry
  %dead.alias.pc375 = load i64, ptr %pc, align 8
  %dead.alias.next376 = add i64 %dead.alias.pc375, 32
  store i64 %dead.alias.next376, ptr %pc, align 8
  br label %loop.check

handler.fence.op981.split.entry:                  ; preds = %execute.decode
  br label %handler.fence.op981.split.body

handler.fence.op981.split.body:                   ; preds = %handler.fence.op981.split.entry
  %dead.alias.pc377 = load i64, ptr %pc, align 8
  %dead.alias.next378 = add i64 %dead.alias.pc377, 32
  store i64 %dead.alias.next378, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xchg.op929.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_xchg.op929.split.body

handler.atomic_rmw_xchg.op929.split.body:         ; preds = %handler.atomic_rmw_xchg.op929.split.entry
  %dead.alias.pc379 = load i64, ptr %pc, align 8
  %dead.alias.next380 = add i64 %dead.alias.pc379, 32
  store i64 %dead.alias.next380, ptr %pc, align 8
  br label %loop.check

handler.read_rounding.op818.split.entry:          ; preds = %execute.decode
  br label %handler.read_rounding.op818.split.body

handler.read_rounding.op818.split.body:           ; preds = %handler.read_rounding.op818.split.entry
  %dead.alias.pc381 = load i64, ptr %pc, align 8
  %dead.alias.next382 = add i64 %dead.alias.pc381, 8
  store i64 %dead.alias.next382, ptr %pc, align 8
  br label %loop.check

handler.atomic_load.opd6.split.entry:             ; preds = %execute.decode
  br label %handler.atomic_load.opd6.split.body

handler.atomic_load.opd6.split.body:              ; preds = %handler.atomic_load.opd6.split.entry
  %dead.alias.pc383 = load i64, ptr %pc, align 8
  %dead.alias.next384 = add i64 %dead.alias.pc383, 32
  store i64 %dead.alias.next384, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_udec_wrap.op16f.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_udec_wrap.op16f.split.body

handler.atomic_rmw_udec_wrap.op16f.split.body:    ; preds = %handler.atomic_rmw_udec_wrap.op16f.split.entry
  %dead.alias.pc385 = load i64, ptr %pc, align 8
  %dead.alias.next386 = add i64 %dead.alias.pc385, 32
  store i64 %dead.alias.next386, ptr %pc, align 8
  br label %loop.check

handler.fptosi.opc2.split.entry:                  ; preds = %execute.decode
  br label %handler.fptosi.opc2.split.body

handler.fptosi.opc2.split.body:                   ; preds = %handler.fptosi.opc2.split.entry
  %dead.alias.pc387 = load i64, ptr %pc, align 8
  %dead.alias.next388 = add i64 %dead.alias.pc387, 32
  store i64 %dead.alias.next388, ptr %pc, align 8
  br label %loop.check

handler.read_vscale.op817.split.entry:            ; preds = %execute.decode
  br label %handler.read_vscale.op817.split.body

handler.read_vscale.op817.split.body:             ; preds = %handler.read_vscale.op817.split.entry
  %dead.alias.pc389 = load i64, ptr %pc, align 8
  %dead.alias.next390 = add i64 %dead.alias.pc389, 8
  store i64 %dead.alias.next390, ptr %pc, align 8
  br label %loop.check

handler.isrem.op8f.split.entry:                   ; preds = %execute.decode
  br label %handler.isrem.op8f.split.body

handler.isrem.op8f.split.body:                    ; preds = %handler.isrem.op8f.split.entry
  %dead.alias.pc391 = load i64, ptr %pc, align 8
  %dead.alias.next392 = add i64 %dead.alias.pc391, 32
  store i64 %dead.alias.next392, ptr %pc, align 8
  br label %loop.check

handler.load_ior.op1d7.split.entry:               ; preds = %execute.decode
  br label %handler.load_ior.op1d7.split.body

handler.load_ior.op1d7.split.body:                ; preds = %handler.load_ior.op1d7.split.entry
  %dead.alias.pc393 = load i64, ptr %pc, align 8
  %dead.alias.next394 = add i64 %dead.alias.pc393, 32
  store i64 %dead.alias.next394, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xor.op934.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_xor.op934.split.body

handler.atomic_rmw_xor.op934.split.body:          ; preds = %handler.atomic_rmw_xor.op934.split.entry
  %dead.alias.pc395 = load i64, ptr %pc, align 8
  %dead.alias.next396 = add i64 %dead.alias.pc395, 32
  store i64 %dead.alias.next396, ptr %pc, align 8
  br label %loop.check

handler.load_iudiv.op98c.split.entry:             ; preds = %execute.decode
  br label %handler.load_iudiv.op98c.split.body

handler.load_iudiv.op98c.split.body:              ; preds = %handler.load_iudiv.op98c.split.entry
  %dead.alias.pc397 = load i64, ptr %pc, align 8
  %dead.alias.next398 = add i64 %dead.alias.pc397, 32
  store i64 %dead.alias.next398, ptr %pc, align 8
  br label %loop.check

handler.zext.op54.split.entry:                    ; preds = %execute.decode
  br label %handler.zext.op54.split.body

handler.zext.op54.split.body:                     ; preds = %handler.zext.op54.split.entry
  %dead.alias.pc399 = load i64, ptr %pc, align 8
  %dead.alias.next400 = add i64 %dead.alias.pc399, 32
  store i64 %dead.alias.next400, ptr %pc, align 8
  br label %loop.check

handler.fcmp.opad.split.entry:                    ; preds = %execute.decode
  br label %handler.fcmp.opad.split.body

handler.fcmp.opad.split.body:                     ; preds = %handler.fcmp.opad.split.entry
  %dead.alias.pc401 = load i64, ptr %pc, align 8
  %dead.alias.next402 = add i64 %dead.alias.pc401, 32
  store i64 %dead.alias.next402, ptr %pc, align 8
  br label %loop.check

handler.alloca_dyn.op140.split.entry:             ; preds = %execute.decode
  br label %handler.alloca_dyn.op140.split.body

handler.alloca_dyn.op140.split.body:              ; preds = %handler.alloca_dyn.op140.split.entry
  %dead.alias.pc403 = load i64, ptr %pc, align 8
  %dead.alias.next404 = add i64 %dead.alias.pc403, 32
  store i64 %dead.alias.next404, ptr %pc, align 8
  br label %loop.check

handler.fsin.op8c5.split.entry:                   ; preds = %execute.decode
  br label %handler.fsin.op8c5.split.body

handler.fsin.op8c5.split.body:                    ; preds = %handler.fsin.op8c5.split.entry
  %dead.alias.pc405 = load i64, ptr %pc, align 8
  %dead.alias.next406 = add i64 %dead.alias.pc405, 32
  store i64 %dead.alias.next406, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_add.op92b.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_add.op92b.split.body

handler.atomic_rmw_add.op92b.split.body:          ; preds = %handler.atomic_rmw_add.op92b.split.entry
  %dead.alias.pc407 = load i64, ptr %pc, align 8
  %dead.alias.next408 = add i64 %dead.alias.pc407, 32
  store i64 %dead.alias.next408, ptr %pc, align 8
  br label %loop.check

handler.cttz.op115.split.entry:                   ; preds = %execute.decode
  br label %handler.cttz.op115.split.body

handler.cttz.op115.split.body:                    ; preds = %handler.cttz.op115.split.entry
  %dead.alias.pc409 = load i64, ptr %pc, align 8
  %dead.alias.next410 = add i64 %dead.alias.pc409, 32
  store i64 %dead.alias.next410, ptr %pc, align 8
  br label %loop.check

handler.ishl.op85d.split.entry:                   ; preds = %execute.decode
  br label %handler.ishl.op85d.split.body

handler.ishl.op85d.split.body:                    ; preds = %handler.ishl.op85d.split.entry
  %dead.alias.pc411 = load i64, ptr %pc, align 8
  %dead.alias.next412 = add i64 %dead.alias.pc411, 32
  store i64 %dead.alias.next412, ptr %pc, align 8
  br label %loop.check

handler.fptoui_sat.op8e2.split.entry:             ; preds = %execute.decode
  br label %handler.fptoui_sat.op8e2.split.body

handler.fptoui_sat.op8e2.split.body:              ; preds = %handler.fptoui_sat.op8e2.split.entry
  %dead.alias.pc413 = load i64, ptr %pc, align 8
  %dead.alias.next414 = add i64 %dead.alias.pc413, 16
  store i64 %dead.alias.next414, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_cond.op96e.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_cond.op96e.split.body

handler.volatile_atomic_rmw_usub_cond.op96e.split.body: ; preds = %handler.volatile_atomic_rmw_usub_cond.op96e.split.entry
  %dead.alias.pc415 = load i64, ptr %pc, align 8
  %dead.alias.next416 = add i64 %dead.alias.pc415, 32
  store i64 %dead.alias.next416, ptr %pc, align 8
  br label %loop.check

handler.read_flt_rounds.op81c.split.entry:        ; preds = %execute.decode
  br label %handler.read_flt_rounds.op81c.split.body

handler.read_flt_rounds.op81c.split.body:         ; preds = %handler.read_flt_rounds.op81c.split.entry
  %dead.alias.pc417 = load i64, ptr %pc, align 8
  %dead.alias.next418 = add i64 %dead.alias.pc417, 8
  store i64 %dead.alias.next418, ptr %pc, align 8
  br label %loop.check

handler.read_cycle.op80f.split.entry:             ; preds = %execute.decode
  br label %handler.read_cycle.op80f.split.body

handler.read_cycle.op80f.split.body:              ; preds = %handler.read_cycle.op80f.split.entry
  %dead.alias.pc419 = load i64, ptr %pc, align 8
  %dead.alias.next420 = add i64 %dead.alias.pc419, 8
  store i64 %dead.alias.next420, ptr %pc, align 8
  br label %loop.check

handler.flrint.op8e7.split.entry:                 ; preds = %execute.decode
  br label %handler.flrint.op8e7.split.body

handler.flrint.op8e7.split.body:                  ; preds = %handler.flrint.op8e7.split.entry
  %dead.alias.pc421 = load i64, ptr %pc, align 8
  %dead.alias.next422 = add i64 %dead.alias.pc421, 16
  store i64 %dead.alias.next422, ptr %pc, align 8
  br label %loop.check

handler.fcopysign.op704.split.entry:              ; preds = %execute.decode
  br label %handler.fcopysign.op704.split.body

handler.fcopysign.op704.split.body:               ; preds = %handler.fcopysign.op704.split.entry
  %dead.alias.pc423 = load i64, ptr %pc, align 8
  %dead.alias.next424 = add i64 %dead.alias.pc423, 32
  store i64 %dead.alias.next424, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_udec_wrap.op199.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_udec_wrap.op199.split.body

handler.volatile_atomic_rmw_udec_wrap.op199.split.body: ; preds = %handler.volatile_atomic_rmw_udec_wrap.op199.split.entry
  %dead.alias.pc425 = load i64, ptr %pc, align 8
  %dead.alias.next426 = add i64 %dead.alias.pc425, 32
  store i64 %dead.alias.next426, ptr %pc, align 8
  br label %loop.check

handler.ptrmask.op13a.split.entry:                ; preds = %execute.decode
  br label %handler.ptrmask.op13a.split.body

handler.ptrmask.op13a.split.body:                 ; preds = %handler.ptrmask.op13a.split.entry
  %dead.alias.pc427 = load i64, ptr %pc, align 8
  %dead.alias.next428 = add i64 %dead.alias.pc427, 16
  store i64 %dead.alias.next428, ptr %pc, align 8
  br label %loop.check

handler.atomic_store.opdc.split.entry:            ; preds = %execute.decode
  br label %handler.atomic_store.opdc.split.body

handler.atomic_store.opdc.split.body:             ; preds = %handler.atomic_store.opdc.split.entry
  %dead.alias.pc429 = load i64, ptr %pc, align 8
  %dead.alias.next430 = add i64 %dead.alias.pc429, 32
  store i64 %dead.alias.next430, ptr %pc, align 8
  br label %loop.check

handler.ret.op7f.split.entry:                     ; preds = %execute.decode
  br label %handler.ret.op7f.split.body

handler.ret.op7f.split.body:                      ; preds = %handler.ret.op7f.split.entry
  %ret.src = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ret.src
  %ret.value = load i64, ptr %reg.load.ptr, align 8
  %reg.store.ptr431 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  store i64 %ret.value, ptr %reg.store.ptr431, align 8
  br label %default.return

handler.volatile_atomic_rmw_xchg.op953.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xchg.op953.split.body

handler.volatile_atomic_rmw_xchg.op953.split.body: ; preds = %handler.volatile_atomic_rmw_xchg.op953.split.entry
  %dead.alias.pc432 = load i64, ptr %pc, align 8
  %dead.alias.next433 = add i64 %dead.alias.pc432, 32
  store i64 %dead.alias.next433, ptr %pc, align 8
  br label %loop.check

handler.load_iumax.op99e.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumax.op99e.split.body

handler.load_iumax.op99e.split.body:              ; preds = %handler.load_iumax.op99e.split.entry
  %dead.alias.pc434 = load i64, ptr %pc, align 8
  %dead.alias.next435 = add i64 %dead.alias.pc434, 32
  store i64 %dead.alias.next435, ptr %pc, align 8
  br label %loop.check

handler.gep_load.op10f.split.entry:               ; preds = %execute.decode
  br label %handler.gep_load.op10f.split.body

handler.gep_load.op10f.split.body:                ; preds = %handler.gep_load.op10f.split.entry
  %dead.alias.pc436 = load i64, ptr %pc, align 8
  %dead.alias.next437 = add i64 %dead.alias.pc436, 32
  store i64 %dead.alias.next437, ptr %pc, align 8
  br label %loop.check

handler.load_ixor.opfd.split.entry:               ; preds = %execute.decode
  br label %handler.load_ixor.opfd.split.body

handler.load_ixor.opfd.split.body:                ; preds = %handler.load_ixor.opfd.split.entry
  %dead.alias.pc438 = load i64, ptr %pc, align 8
  %dead.alias.next439 = add i64 %dead.alias.pc438, 32
  store i64 %dead.alias.next439, ptr %pc, align 8
  br label %loop.check

handler.fcanonicalize.op714.split.entry:          ; preds = %execute.decode
  br label %handler.fcanonicalize.op714.split.body

handler.fcanonicalize.op714.split.body:           ; preds = %handler.fcanonicalize.op714.split.entry
  %dead.alias.pc440 = load i64, ptr %pc, align 8
  %dead.alias.next441 = add i64 %dead.alias.pc440, 32
  store i64 %dead.alias.next441, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmax.op94c.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmax.op94c.split.body

handler.atomic_rmw_fmax.op94c.split.body:         ; preds = %handler.atomic_rmw_fmax.op94c.split.entry
  %dead.alias.pc442 = load i64, ptr %pc, align 8
  %dead.alias.next443 = add i64 %dead.alias.pc442, 32
  store i64 %dead.alias.next443, ptr %pc, align 8
  br label %loop.check

handler.ffloor.op8b8.split.entry:                 ; preds = %execute.decode
  br label %handler.ffloor.op8b8.split.body

handler.ffloor.op8b8.split.body:                  ; preds = %handler.ffloor.op8b8.split.entry
  %dead.alias.pc444 = load i64, ptr %pc, align 8
  %dead.alias.next445 = add i64 %dead.alias.pc444, 32
  store i64 %dead.alias.next445, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op800.split.entry:                ; preds = %execute.decode
  br label %handler.mov_imm.op800.split.body

handler.mov_imm.op800.split.body:                 ; preds = %handler.mov_imm.op800.split.entry
  %dead.alias.pc446 = load i64, ptr %pc, align 8
  %dead.alias.next447 = add i64 %dead.alias.pc446, 32
  store i64 %dead.alias.next447, ptr %pc, align 8
  br label %loop.check

handler.ior.op85c.split.entry:                    ; preds = %execute.decode
  br label %handler.ior.op85c.split.body

handler.ior.op85c.split.body:                     ; preds = %handler.ior.op85c.split.entry
  %dead.alias.pc448 = load i64, ptr %pc, align 8
  %dead.alias.next449 = add i64 %dead.alias.pc448, 32
  store i64 %dead.alias.next449, ptr %pc, align 8
  br label %loop.check

handler.bitcast.op3e.split.entry:                 ; preds = %execute.decode
  br label %handler.bitcast.op3e.split.body

handler.bitcast.op3e.split.body:                  ; preds = %handler.bitcast.op3e.split.entry
  %dead.alias.pc450 = load i64, ptr %pc, align 8
  %dead.alias.next451 = add i64 %dead.alias.pc450, 32
  store i64 %dead.alias.next451, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op84.split.entry:                   ; preds = %execute.decode
  br label %handler.iudiv.op84.split.body

handler.iudiv.op84.split.body:                    ; preds = %handler.iudiv.op84.split.entry
  %dead.alias.pc452 = load i64, ptr %pc, align 8
  %dead.alias.next453 = add i64 %dead.alias.pc452, 32
  store i64 %dead.alias.next453, ptr %pc, align 8
  br label %loop.check

handler.fence.opef.split.entry:                   ; preds = %execute.decode
  br label %handler.fence.opef.split.body

handler.fence.opef.split.body:                    ; preds = %handler.fence.opef.split.entry
  %dead.alias.pc454 = load i64, ptr %pc, align 8
  %dead.alias.next455 = add i64 %dead.alias.pc454, 32
  store i64 %dead.alias.next455, ptr %pc, align 8
  br label %loop.check

handler.read_steady.op813.split.entry:            ; preds = %execute.decode
  br label %handler.read_steady.op813.split.body

handler.read_steady.op813.split.body:             ; preds = %handler.read_steady.op813.split.entry
  %dead.alias.pc456 = load i64, ptr %pc, align 8
  %dead.alias.next457 = add i64 %dead.alias.pc456, 8
  store i64 %dead.alias.next457, ptr %pc, align 8
  br label %loop.check

handler.br_if.op62.split.entry:                   ; preds = %execute.decode
  br label %handler.br_if.op62.split.body

handler.br_if.op62.split.body:                    ; preds = %handler.br_if.op62.split.entry
  %dead.alias.pc458 = load i64, ptr %pc, align 8
  %dead.alias.next459 = add i64 %dead.alias.pc458, 32
  store i64 %dead.alias.next459, ptr %pc, align 8
  br label %loop.check

handler.volatile_store.op913.split.entry:         ; preds = %execute.decode
  br label %handler.volatile_store.op913.split.body

handler.volatile_store.op913.split.body:          ; preds = %handler.volatile_store.op913.split.entry
  %dead.alias.pc460 = load i64, ptr %pc, align 8
  %dead.alias.next461 = add i64 %dead.alias.pc460, 16
  store i64 %dead.alias.next461, ptr %pc, align 8
  br label %loop.check

handler.fdiv.opa5.split.entry:                    ; preds = %execute.decode
  br label %handler.fdiv.opa5.split.body

handler.fdiv.opa5.split.body:                     ; preds = %handler.fdiv.opa5.split.entry
  %dead.alias.pc462 = load i64, ptr %pc, align 8
  %dead.alias.next463 = add i64 %dead.alias.pc462, 32
  store i64 %dead.alias.next463, ptr %pc, align 8
  br label %loop.check

handler.load_iudiv.op1da.split.entry:             ; preds = %execute.decode
  br label %handler.load_iudiv.op1da.split.body

handler.load_iudiv.op1da.split.body:              ; preds = %handler.load_iudiv.op1da.split.entry
  %dead.alias.pc464 = load i64, ptr %pc, align 8
  %dead.alias.next465 = add i64 %dead.alias.pc464, 32
  store i64 %dead.alias.next465, ptr %pc, align 8
  br label %loop.check

handler.gep.op1e.split.entry:                     ; preds = %execute.decode
  br label %handler.gep.op1e.split.body

handler.gep.op1e.split.body:                      ; preds = %handler.gep.op1e.split.entry
  %dead.alias.pc466 = load i64, ptr %pc, align 8
  %dead.alias.next467 = add i64 %dead.alias.pc466, 32
  store i64 %dead.alias.next467, ptr %pc, align 8
  br label %loop.check

handler.iand.op2d.split.entry:                    ; preds = %execute.decode
  br label %handler.iand.op2d.split.body

handler.iand.op2d.split.body:                     ; preds = %handler.iand.op2d.split.entry
  %dead.alias.pc468 = load i64, ptr %pc, align 8
  %dead.alias.next469 = add i64 %dead.alias.pc468, 32
  store i64 %dead.alias.next469, ptr %pc, align 8
  br label %loop.check

handler.iurem.op84b.split.entry:                  ; preds = %execute.decode
  br label %handler.iurem.op84b.split.body

handler.iurem.op84b.split.body:                   ; preds = %handler.iurem.op84b.split.entry
  %dead.alias.pc470 = load i64, ptr %pc, align 8
  %dead.alias.next471 = add i64 %dead.alias.pc470, 32
  store i64 %dead.alias.next471, ptr %pc, align 8
  br label %loop.check

handler.fpext.opd2.split.entry:                   ; preds = %execute.decode
  br label %handler.fpext.opd2.split.body

handler.fpext.opd2.split.body:                    ; preds = %handler.fpext.opd2.split.entry
  %dead.alias.pc472 = load i64, ptr %pc, align 8
  %dead.alias.next473 = add i64 %dead.alias.pc472, 32
  store i64 %dead.alias.next473, ptr %pc, align 8
  br label %loop.check

handler.zext.op8f8.split.entry:                   ; preds = %execute.decode
  br label %handler.zext.op8f8.split.body

handler.zext.op8f8.split.body:                    ; preds = %handler.zext.op8f8.split.entry
  %dead.alias.pc474 = load i64, ptr %pc, align 8
  %dead.alias.next475 = add i64 %dead.alias.pc474, 32
  store i64 %dead.alias.next475, ptr %pc, align 8
  br label %loop.check

handler.uitofp.op8da.split.entry:                 ; preds = %execute.decode
  br label %handler.uitofp.op8da.split.body

handler.uitofp.op8da.split.body:                  ; preds = %handler.uitofp.op8da.split.entry
  %dead.alias.pc476 = load i64, ptr %pc, align 8
  %dead.alias.next477 = add i64 %dead.alias.pc476, 32
  store i64 %dead.alias.next477, ptr %pc, align 8
  br label %loop.check

handler.iabs.op88e.split.entry:                   ; preds = %execute.decode
  br label %handler.iabs.op88e.split.body

handler.iabs.op88e.split.body:                    ; preds = %handler.iabs.op88e.split.entry
  %dead.alias.pc478 = load i64, ptr %pc, align 8
  %dead.alias.next479 = add i64 %dead.alias.pc478, 32
  store i64 %dead.alias.next479, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmax.op1a2.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmax.op1a2.split.body

handler.volatile_atomic_rmw_fmax.op1a2.split.body: ; preds = %handler.volatile_atomic_rmw_fmax.op1a2.split.entry
  %dead.alias.pc480 = load i64, ptr %pc, align 8
  %dead.alias.next481 = add i64 %dead.alias.pc480, 32
  store i64 %dead.alias.next481, ptr %pc, align 8
  br label %loop.check

handler.iashr.op08.split.entry:                   ; preds = %execute.decode
  br label %handler.iashr.op08.split.body

handler.iashr.op08.split.body:                    ; preds = %handler.iashr.op08.split.entry
  %dead.alias.pc482 = load i64, ptr %pc, align 8
  %dead.alias.next483 = add i64 %dead.alias.pc482, 32
  store i64 %dead.alias.next483, ptr %pc, align 8
  br label %loop.check

handler.stacksave.op904.split.entry:              ; preds = %execute.decode
  br label %handler.stacksave.op904.split.body

handler.stacksave.op904.split.body:               ; preds = %handler.stacksave.op904.split.entry
  %dead.alias.pc484 = load i64, ptr %pc, align 8
  %dead.alias.next485 = add i64 %dead.alias.pc484, 8
  store i64 %dead.alias.next485, ptr %pc, align 8
  br label %loop.check

handler.write_fpenv.op824.split.entry:            ; preds = %execute.decode
  br label %handler.write_fpenv.op824.split.body

handler.write_fpenv.op824.split.body:             ; preds = %handler.write_fpenv.op824.split.entry
  %dead.alias.pc486 = load i64, ptr %pc, align 8
  %dead.alias.next487 = add i64 %dead.alias.pc486, 8
  store i64 %dead.alias.next487, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xor.op18a.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xor.op18a.split.body

handler.volatile_atomic_rmw_xor.op18a.split.body: ; preds = %handler.volatile_atomic_rmw_xor.op18a.split.entry
  %dead.alias.pc488 = load i64, ptr %pc, align 8
  %dead.alias.next489 = add i64 %dead.alias.pc488, 32
  store i64 %dead.alias.next489, ptr %pc, align 8
  br label %loop.check

handler.read_flt_rounds.op81b.split.entry:        ; preds = %execute.decode
  br label %handler.read_flt_rounds.op81b.split.body

handler.read_flt_rounds.op81b.split.body:         ; preds = %handler.read_flt_rounds.op81b.split.entry
  %dead.alias.pc490 = load i64, ptr %pc, align 8
  %dead.alias.next491 = add i64 %dead.alias.pc490, 8
  store i64 %dead.alias.next491, ptr %pc, align 8
  br label %loop.check

handler.gep.op09.split.entry:                     ; preds = %execute.decode
  br label %handler.gep.op09.split.body

handler.gep.op09.split.body:                      ; preds = %handler.gep.op09.split.entry
  %dead.alias.pc492 = load i64, ptr %pc, align 8
  %dead.alias.next493 = add i64 %dead.alias.pc492, 32
  store i64 %dead.alias.next493, ptr %pc, align 8
  br label %loop.check

handler.read_rounding.op1be.split.entry:          ; preds = %execute.decode
  br label %handler.read_rounding.op1be.split.body

handler.read_rounding.op1be.split.body:           ; preds = %handler.read_rounding.op1be.split.entry
  %dead.alias.pc494 = load i64, ptr %pc, align 8
  %dead.alias.next495 = add i64 %dead.alias.pc494, 8
  store i64 %dead.alias.next495, ptr %pc, align 8
  br label %loop.check

handler.iand.op72.split.entry:                    ; preds = %execute.decode
  br label %handler.iand.op72.split.body

handler.iand.op72.split.body:                     ; preds = %handler.iand.op72.split.entry
  %dead.alias.pc496 = load i64, ptr %pc, align 8
  %dead.alias.next497 = add i64 %dead.alias.pc496, 32
  store i64 %dead.alias.next497, ptr %pc, align 8
  br label %loop.check

handler.ffma.op8d4.split.entry:                   ; preds = %execute.decode
  br label %handler.ffma.op8d4.split.body

handler.ffma.op8d4.split.body:                    ; preds = %handler.ffma.op8d4.split.entry
  %dead.alias.pc498 = load i64, ptr %pc, align 8
  %dead.alias.next499 = add i64 %dead.alias.pc498, 48
  store i64 %dead.alias.next499, ptr %pc, align 8
  br label %loop.check

handler.isadd_overflow.op87d.split.entry:         ; preds = %execute.decode
  br label %handler.isadd_overflow.op87d.split.body

handler.isadd_overflow.op87d.split.body:          ; preds = %handler.isadd_overflow.op87d.split.entry
  %dead.alias.pc500 = load i64, ptr %pc, align 8
  %dead.alias.next501 = add i64 %dead.alias.pc500, 32
  store i64 %dead.alias.next501, ptr %pc, align 8
  br label %loop.check

handler.read_thread_pointer.op835.split.entry:    ; preds = %execute.decode
  br label %handler.read_thread_pointer.op835.split.body

handler.read_thread_pointer.op835.split.body:     ; preds = %handler.read_thread_pointer.op835.split.entry
  %dead.alias.pc502 = load i64, ptr %pc, align 8
  %dead.alias.next503 = add i64 %dead.alias.pc502, 8
  store i64 %dead.alias.next503, ptr %pc, align 8
  br label %loop.check

handler.issub_overflow.op881.split.entry:         ; preds = %execute.decode
  br label %handler.issub_overflow.op881.split.body

handler.issub_overflow.op881.split.body:          ; preds = %handler.issub_overflow.op881.split.entry
  %dead.alias.pc504 = load i64, ptr %pc, align 8
  %dead.alias.next505 = add i64 %dead.alias.pc504, 32
  store i64 %dead.alias.next505, ptr %pc, align 8
  br label %loop.check

handler.volatile_memmove_dyn.op17a.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_memmove_dyn.op17a.split.body

handler.volatile_memmove_dyn.op17a.split.body:    ; preds = %handler.volatile_memmove_dyn.op17a.split.entry
  %dead.alias.pc506 = load i64, ptr %pc, align 8
  %dead.alias.next507 = add i64 %dead.alias.pc506, 8
  store i64 %dead.alias.next507, ptr %pc, align 8
  br label %loop.check

handler.load_isshl_sat.op9ab.split.entry:         ; preds = %execute.decode
  br label %handler.load_isshl_sat.op9ab.split.body

handler.load_isshl_sat.op9ab.split.body:          ; preds = %handler.load_isshl_sat.op9ab.split.entry
  %dead.alias.pc508 = load i64, ptr %pc, align 8
  %dead.alias.next509 = add i64 %dead.alias.pc508, 32
  store i64 %dead.alias.next509, ptr %pc, align 8
  br label %loop.check

handler.reset_fpenv.op828.split.entry:            ; preds = %execute.decode
  br label %handler.reset_fpenv.op828.split.body

handler.reset_fpenv.op828.split.body:             ; preds = %handler.reset_fpenv.op828.split.entry
  %dead.alias.pc510 = load i64, ptr %pc, align 8
  %dead.alias.next511 = add i64 %dead.alias.pc510, 4
  store i64 %dead.alias.next511, ptr %pc, align 8
  br label %loop.check

handler.alloca_dyn.op901.split.entry:             ; preds = %execute.decode
  br label %handler.alloca_dyn.op901.split.body

handler.alloca_dyn.op901.split.body:              ; preds = %handler.alloca_dyn.op901.split.entry
  %dead.alias.pc512 = load i64, ptr %pc, align 8
  %dead.alias.next513 = add i64 %dead.alias.pc512, 32
  store i64 %dead.alias.next513, ptr %pc, align 8
  br label %loop.check

handler.ffmuladd.op8d6.split.entry:               ; preds = %execute.decode
  br label %handler.ffmuladd.op8d6.split.body

handler.ffmuladd.op8d6.split.body:                ; preds = %handler.ffmuladd.op8d6.split.entry
  %dead.alias.pc514 = load i64, ptr %pc, align 8
  %dead.alias.next515 = add i64 %dead.alias.pc514, 48
  store i64 %dead.alias.next515, ptr %pc, align 8
  br label %loop.check

handler.ptrmask.op139.split.entry:                ; preds = %execute.decode
  br label %handler.ptrmask.op139.split.body

handler.ptrmask.op139.split.body:                 ; preds = %handler.ptrmask.op139.split.entry
  %dead.alias.pc516 = load i64, ptr %pc, align 8
  %dead.alias.next517 = add i64 %dead.alias.pc516, 16
  store i64 %dead.alias.next517, ptr %pc, align 8
  br label %loop.check

handler.gep_load.op110.split.entry:               ; preds = %execute.decode
  br label %handler.gep_load.op110.split.body

handler.gep_load.op110.split.body:                ; preds = %handler.gep_load.op110.split.entry
  %dead.alias.pc518 = load i64, ptr %pc, align 8
  %dead.alias.next519 = add i64 %dead.alias.pc518, 32
  store i64 %dead.alias.next519, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op81.split.entry:                   ; preds = %execute.decode
  br label %handler.iudiv.op81.split.body

handler.iudiv.op81.split.body:                    ; preds = %handler.iudiv.op81.split.entry
  %dead.alias.pc520 = load i64, ptr %pc, align 8
  %dead.alias.next521 = add i64 %dead.alias.pc520, 32
  store i64 %dead.alias.next521, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op82.split.entry:                   ; preds = %execute.decode
  br label %handler.iudiv.op82.split.body

handler.iudiv.op82.split.body:                    ; preds = %handler.iudiv.op82.split.entry
  %dead.alias.pc522 = load i64, ptr %pc, align 8
  %dead.alias.next523 = add i64 %dead.alias.pc522, 32
  store i64 %dead.alias.next523, ptr %pc, align 8
  br label %loop.check

handler.load_ishl.op993.split.entry:              ; preds = %execute.decode
  br label %handler.load_ishl.op993.split.body

handler.load_ishl.op993.split.body:               ; preds = %handler.load_ishl.op993.split.entry
  %dead.alias.pc524 = load i64, ptr %pc, align 8
  %dead.alias.next525 = add i64 %dead.alias.pc524, 32
  store i64 %dead.alias.next525, ptr %pc, align 8
  br label %loop.check

handler.fptosi_sat.op1b8.split.entry:             ; preds = %execute.decode
  br label %handler.fptosi_sat.op1b8.split.body

handler.fptosi_sat.op1b8.split.body:              ; preds = %handler.fptosi_sat.op1b8.split.entry
  %dead.alias.pc526 = load i64, ptr %pc, align 8
  %dead.alias.next527 = add i64 %dead.alias.pc526, 16
  store i64 %dead.alias.next527, ptr %pc, align 8
  br label %loop.check

handler.fceil.op718.split.entry:                  ; preds = %execute.decode
  br label %handler.fceil.op718.split.body

handler.fceil.op718.split.body:                   ; preds = %handler.fceil.op718.split.entry
  %dead.alias.pc528 = load i64, ptr %pc, align 8
  %dead.alias.next529 = add i64 %dead.alias.pc528, 32
  store i64 %dead.alias.next529, ptr %pc, align 8
  br label %loop.check

handler.sext.op61.split.entry:                    ; preds = %execute.decode
  br label %handler.sext.op61.split.body

handler.sext.op61.split.body:                     ; preds = %handler.sext.op61.split.entry
  %dead.alias.pc530 = load i64, ptr %pc, align 8
  %dead.alias.next531 = add i64 %dead.alias.pc530, 32
  store i64 %dead.alias.next531, ptr %pc, align 8
  br label %loop.check

handler.iumul_overflow.op883.split.entry:         ; preds = %execute.decode
  br label %handler.iumul_overflow.op883.split.body

handler.iumul_overflow.op883.split.body:          ; preds = %handler.iumul_overflow.op883.split.entry
  %dead.alias.pc532 = load i64, ptr %pc, align 8
  %dead.alias.next533 = add i64 %dead.alias.pc532, 32
  store i64 %dead.alias.next533, ptr %pc, align 8
  br label %loop.check

handler.write_rounding.op1c2.split.entry:         ; preds = %execute.decode
  br label %handler.write_rounding.op1c2.split.body

handler.write_rounding.op1c2.split.body:          ; preds = %handler.write_rounding.op1c2.split.entry
  %dead.alias.pc534 = load i64, ptr %pc, align 8
  %dead.alias.next535 = add i64 %dead.alias.pc534, 8
  store i64 %dead.alias.next535, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_store.op927.split.entry:  ; preds = %execute.decode
  br label %handler.volatile_atomic_store.op927.split.body

handler.volatile_atomic_store.op927.split.body:   ; preds = %handler.volatile_atomic_store.op927.split.entry
  %dead.alias.pc536 = load i64, ptr %pc, align 8
  %dead.alias.next537 = add i64 %dead.alias.pc536, 32
  store i64 %dead.alias.next537, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xchg.op180.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xchg.op180.split.body

handler.volatile_atomic_rmw_xchg.op180.split.body: ; preds = %handler.volatile_atomic_rmw_xchg.op180.split.entry
  %dead.alias.pc538 = load i64, ptr %pc, align 8
  %dead.alias.next539 = add i64 %dead.alias.pc538, 32
  store i64 %dead.alias.next539, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_add.op956.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_add.op956.split.body

handler.volatile_atomic_rmw_add.op956.split.body: ; preds = %handler.volatile_atomic_rmw_add.op956.split.entry
  %dead.alias.pc540 = load i64, ptr %pc, align 8
  %dead.alias.next541 = add i64 %dead.alias.pc540, 32
  store i64 %dead.alias.next541, ptr %pc, align 8
  br label %loop.check

handler.ffma.op709.split.entry:                   ; preds = %execute.decode
  br label %handler.ffma.op709.split.body

handler.ffma.op709.split.body:                    ; preds = %handler.ffma.op709.split.entry
  %dead.alias.pc542 = load i64, ptr %pc, align 8
  %dead.alias.next543 = add i64 %dead.alias.pc542, 48
  store i64 %dead.alias.next543, ptr %pc, align 8
  br label %loop.check

handler.read_flt_rounds.op81d.split.entry:        ; preds = %execute.decode
  br label %handler.read_flt_rounds.op81d.split.body

handler.read_flt_rounds.op81d.split.body:         ; preds = %handler.read_flt_rounds.op81d.split.entry
  %dead.alias.pc544 = load i64, ptr %pc, align 8
  %dead.alias.next545 = add i64 %dead.alias.pc544, 8
  store i64 %dead.alias.next545, ptr %pc, align 8
  br label %loop.check

handler.isub.op840.split.entry:                   ; preds = %execute.decode
  br label %handler.isub.op840.split.body

handler.isub.op840.split.body:                    ; preds = %handler.isub.op840.split.entry
  %dead.alias.pc546 = load i64, ptr %pc, align 8
  %dead.alias.next547 = add i64 %dead.alias.pc546, 32
  store i64 %dead.alias.next547, ptr %pc, align 8
  br label %loop.check

handler.memmove_dyn.op146.split.entry:            ; preds = %execute.decode
  br label %handler.memmove_dyn.op146.split.body

handler.memmove_dyn.op146.split.body:             ; preds = %handler.memmove_dyn.op146.split.entry
  %dead.alias.pc548 = load i64, ptr %pc, align 8
  %dead.alias.next549 = add i64 %dead.alias.pc548, 8
  store i64 %dead.alias.next549, ptr %pc, align 8
  br label %loop.check

handler.mov.op3a.split.entry:                     ; preds = %execute.decode
  br label %handler.mov.op3a.split.body

handler.mov.op3a.split.body:                      ; preds = %handler.mov.op3a.split.entry
  %dead.alias.pc550 = load i64, ptr %pc, align 8
  %dead.alias.next551 = add i64 %dead.alias.pc550, 8
  store i64 %dead.alias.next551, ptr %pc, align 8
  br label %loop.check

handler.volatile_cmpxchg.op17e.split.entry:       ; preds = %execute.decode
  br label %handler.volatile_cmpxchg.op17e.split.body

handler.volatile_cmpxchg.op17e.split.body:        ; preds = %handler.volatile_cmpxchg.op17e.split.entry
  %dead.alias.pc552 = load i64, ptr %pc, align 8
  %dead.alias.next553 = add i64 %dead.alias.pc552, 32
  store i64 %dead.alias.next553, ptr %pc, align 8
  br label %loop.check

handler.load_iusub_sat.op1f3.split.entry:         ; preds = %execute.decode
  br label %handler.load_iusub_sat.op1f3.split.body

handler.load_iusub_sat.op1f3.split.body:          ; preds = %handler.load_iusub_sat.op1f3.split.entry
  %dead.alias.pc554 = load i64, ptr %pc, align 8
  %dead.alias.next555 = add i64 %dead.alias.pc554, 32
  store i64 %dead.alias.next555, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umax.op93b.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_umax.op93b.split.body

handler.atomic_rmw_umax.op93b.split.body:         ; preds = %handler.atomic_rmw_umax.op93b.split.entry
  %dead.alias.pc556 = load i64, ptr %pc, align 8
  %dead.alias.next557 = add i64 %dead.alias.pc556, 32
  store i64 %dead.alias.next557, ptr %pc, align 8
  br label %loop.check

handler.load_issub_sat.op9a7.split.entry:         ; preds = %execute.decode
  br label %handler.load_issub_sat.op9a7.split.body

handler.load_issub_sat.op9a7.split.body:          ; preds = %handler.load_issub_sat.op9a7.split.entry
  %dead.alias.pc558 = load i64, ptr %pc, align 8
  %dead.alias.next559 = add i64 %dead.alias.pc558, 32
  store i64 %dead.alias.next559, ptr %pc, align 8
  br label %loop.check

handler.fcanonicalize.op8b6.split.entry:          ; preds = %execute.decode
  br label %handler.fcanonicalize.op8b6.split.body

handler.fcanonicalize.op8b6.split.body:           ; preds = %handler.fcanonicalize.op8b6.split.entry
  %dead.alias.pc560 = load i64, ptr %pc, align 8
  %dead.alias.next561 = add i64 %dead.alias.pc560, 32
  store i64 %dead.alias.next561, ptr %pc, align 8
  br label %loop.check

handler.load_iusub_sat.op9a4.split.entry:         ; preds = %execute.decode
  br label %handler.load_iusub_sat.op9a4.split.body

handler.load_iusub_sat.op9a4.split.body:          ; preds = %handler.load_iusub_sat.op9a4.split.entry
  %dead.alias.pc562 = load i64, ptr %pc, align 8
  %dead.alias.next563 = add i64 %dead.alias.pc562, 32
  store i64 %dead.alias.next563, ptr %pc, align 8
  br label %loop.check

handler.fshr.op896.split.entry:                   ; preds = %execute.decode
  br label %handler.fshr.op896.split.body

handler.fshr.op896.split.body:                    ; preds = %handler.fshr.op896.split.entry
  %dead.alias.pc564 = load i64, ptr %pc, align 8
  %dead.alias.next565 = add i64 %dead.alias.pc564, 48
  store i64 %dead.alias.next565, ptr %pc, align 8
  br label %loop.check

handler.imul.op1d.split.entry:                    ; preds = %execute.decode
  br label %handler.imul.op1d.split.body

handler.imul.op1d.split.body:                     ; preds = %handler.imul.op1d.split.entry
  %dead.alias.pc566 = load i64, ptr %pc, align 8
  %dead.alias.next567 = add i64 %dead.alias.pc566, 32
  store i64 %dead.alias.next567, ptr %pc, align 8
  br label %loop.check

handler.pseudoprobe.op909.split.entry:            ; preds = %execute.decode
  br label %handler.pseudoprobe.op909.split.body

handler.pseudoprobe.op909.split.body:             ; preds = %handler.pseudoprobe.op909.split.entry
  %dead.alias.pc568 = load i64, ptr %pc, align 8
  %dead.alias.next569 = add i64 %dead.alias.pc568, 48
  store i64 %dead.alias.next569, ptr %pc, align 8
  br label %loop.check

handler.mov.op806.split.entry:                    ; preds = %execute.decode
  br label %handler.mov.op806.split.body

handler.mov.op806.split.body:                     ; preds = %handler.mov.op806.split.entry
  %dead.alias.pc570 = load i64, ptr %pc, align 8
  %dead.alias.next571 = add i64 %dead.alias.pc570, 8
  store i64 %dead.alias.next571, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_or.ope8.split.entry:           ; preds = %execute.decode
  br label %handler.atomic_rmw_or.ope8.split.body

handler.atomic_rmw_or.ope8.split.body:            ; preds = %handler.atomic_rmw_or.ope8.split.entry
  %dead.alias.pc572 = load i64, ptr %pc, align 8
  %dead.alias.next573 = add i64 %dead.alias.pc572, 32
  store i64 %dead.alias.next573, ptr %pc, align 8
  br label %loop.check

handler.frem.op8a0.split.entry:                   ; preds = %execute.decode
  br label %handler.frem.op8a0.split.body

handler.frem.op8a0.split.body:                    ; preds = %handler.frem.op8a0.split.entry
  %dead.alias.pc574 = load i64, ptr %pc, align 8
  %dead.alias.next575 = add i64 %dead.alias.pc574, 32
  store i64 %dead.alias.next575, ptr %pc, align 8
  br label %loop.check

handler.call_native.op77.split.entry:             ; preds = %execute.decode
  br label %handler.call_native.op77.split.body

handler.call_native.op77.split.body:              ; preds = %handler.call_native.op77.split.entry
  %call_native.callee = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.argc = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg0 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg1 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg2 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg3 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg4 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg5 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg6 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg7 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret_count = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret0 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret0_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret1 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret1_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret2 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret2_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret3 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret3_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret4 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret4_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret5 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret5_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret6 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret6_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret7 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret7_width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr576 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg0
  %native.arg = load i64, ptr %reg.load.ptr576, align 8
  %reg.load.ptr577 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg1
  %native.arg578 = load i64, ptr %reg.load.ptr577, align 8
  %reg.load.ptr579 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg2
  %native.arg580 = load i64, ptr %reg.load.ptr579, align 8
  %reg.load.ptr581 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg3
  %native.arg582 = load i64, ptr %reg.load.ptr581, align 8
  %reg.load.ptr583 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg4
  %native.arg584 = load i64, ptr %reg.load.ptr583, align 8
  %reg.load.ptr585 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg5
  %native.arg586 = load i64, ptr %reg.load.ptr585, align 8
  %reg.load.ptr587 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg6
  %native.arg588 = load i64, ptr %reg.load.ptr587, align 8
  %reg.load.ptr589 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg7
  %native.arg590 = load i64, ptr %reg.load.ptr589, align 8
  %native.argc.ok = icmp ule i64 %call_native.argc, 8
  %native.id.ok = icmp ult i64 %call_native.callee, %descriptor.native.count.plain
  %native.ret.count.ok = icmp ule i64 %call_native.ret_count, 8
  %native.call.bounds.ok = and i1 %native.argc.ok, %native.id.ok
  %native.can.call = and i1 %native.call.bounds.ok, %native.ret.count.ok
  br i1 %native.can.call, label %native.call, label %native.done

native.call:                                      ; preds = %handler.call_native.op77.split.body
  %native.table.index = add i64 %descriptor.native.base.plain, %call_native.callee
  %native.slot = getelementptr ptr, ptr @.amice.vm.native_table.module.helper_add.n4.h711399579d9648e0, i64 %native.table.index
  %native.thunk = load ptr, ptr %native.slot, align 8
  %native.ret = call { i64, i64, i64, i64, i64, i64, i64, i64 } %native.thunk(i64 %native.arg, i64 %native.arg578, i64 %native.arg580, i64 %native.arg582, i64 %native.arg584, i64 %native.arg586, i64 %native.arg588, i64 %native.arg590)
  %native.ret0.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 0
  %width.is64591 = icmp eq i64 %call_native.ret0_width, 64
  %width.shift592 = and i64 %call_native.ret0_width, 63
  %mask.shifted593 = shl i64 1, %width.shift592
  %mask.candidate594 = sub i64 %mask.shifted593, 1
  %width.mask595 = select i1 %width.is64591, i64 -1, i64 %mask.candidate594
  %width.masked596 = and i64 %native.ret0.value, %width.mask595
  %native.ret1.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 1
  %width.is64597 = icmp eq i64 %call_native.ret1_width, 64
  %width.shift598 = and i64 %call_native.ret1_width, 63
  %mask.shifted599 = shl i64 1, %width.shift598
  %mask.candidate600 = sub i64 %mask.shifted599, 1
  %width.mask601 = select i1 %width.is64597, i64 -1, i64 %mask.candidate600
  %width.masked602 = and i64 %native.ret1.value, %width.mask601
  %native.ret2.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 2
  %width.is64603 = icmp eq i64 %call_native.ret2_width, 64
  %width.shift604 = and i64 %call_native.ret2_width, 63
  %mask.shifted605 = shl i64 1, %width.shift604
  %mask.candidate606 = sub i64 %mask.shifted605, 1
  %width.mask607 = select i1 %width.is64603, i64 -1, i64 %mask.candidate606
  %width.masked608 = and i64 %native.ret2.value, %width.mask607
  %native.ret3.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 3
  %width.is64609 = icmp eq i64 %call_native.ret3_width, 64
  %width.shift610 = and i64 %call_native.ret3_width, 63
  %mask.shifted611 = shl i64 1, %width.shift610
  %mask.candidate612 = sub i64 %mask.shifted611, 1
  %width.mask613 = select i1 %width.is64609, i64 -1, i64 %mask.candidate612
  %width.masked614 = and i64 %native.ret3.value, %width.mask613
  %native.ret4.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 4
  %width.is64615 = icmp eq i64 %call_native.ret4_width, 64
  %width.shift616 = and i64 %call_native.ret4_width, 63
  %mask.shifted617 = shl i64 1, %width.shift616
  %mask.candidate618 = sub i64 %mask.shifted617, 1
  %width.mask619 = select i1 %width.is64615, i64 -1, i64 %mask.candidate618
  %width.masked620 = and i64 %native.ret4.value, %width.mask619
  %native.ret5.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 5
  %width.is64621 = icmp eq i64 %call_native.ret5_width, 64
  %width.shift622 = and i64 %call_native.ret5_width, 63
  %mask.shifted623 = shl i64 1, %width.shift622
  %mask.candidate624 = sub i64 %mask.shifted623, 1
  %width.mask625 = select i1 %width.is64621, i64 -1, i64 %mask.candidate624
  %width.masked626 = and i64 %native.ret5.value, %width.mask625
  %native.ret6.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 6
  %width.is64627 = icmp eq i64 %call_native.ret6_width, 64
  %width.shift628 = and i64 %call_native.ret6_width, 63
  %mask.shifted629 = shl i64 1, %width.shift628
  %mask.candidate630 = sub i64 %mask.shifted629, 1
  %width.mask631 = select i1 %width.is64627, i64 -1, i64 %mask.candidate630
  %width.masked632 = and i64 %native.ret6.value, %width.mask631
  %native.ret7.value = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret, 7
  %width.is64633 = icmp eq i64 %call_native.ret7_width, 64
  %width.shift634 = and i64 %call_native.ret7_width, 63
  %mask.shifted635 = shl i64 1, %width.shift634
  %mask.candidate636 = sub i64 %mask.shifted635, 1
  %width.mask637 = select i1 %width.is64633, i64 -1, i64 %mask.candidate636
  %width.masked638 = and i64 %native.ret7.value, %width.mask637
  %native.has.ret0 = icmp uge i64 %call_native.ret_count, 1
  br i1 %native.has.ret0, label %native.ret0.store, label %native.store.done

native.done:                                      ; preds = %native.store.done, %handler.call_native.op77.split.body
  %pc.old647 = load i64, ptr %pc, align 8
  %pc.next648 = add i64 %pc.old647, 64
  store i64 %pc.next648, ptr %pc, align 8
  br label %loop.check

native.store.done:                                ; preds = %native.ret7.store, %native.ret7.check, %native.ret6.check, %native.ret5.check, %native.ret4.check, %native.ret3.check, %native.ret2.check, %native.ret1.check, %native.call
  br label %native.done

native.ret0.store:                                ; preds = %native.call
  %reg.store.ptr639 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret0
  store i64 %width.masked596, ptr %reg.store.ptr639, align 8
  br label %native.ret1.check

native.ret1.check:                                ; preds = %native.ret0.store
  %native.has.ret1 = icmp uge i64 %call_native.ret_count, 2
  br i1 %native.has.ret1, label %native.ret1.store, label %native.store.done

native.ret1.store:                                ; preds = %native.ret1.check
  %reg.store.ptr640 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret1
  store i64 %width.masked602, ptr %reg.store.ptr640, align 8
  br label %native.ret2.check

native.ret2.check:                                ; preds = %native.ret1.store
  %native.has.ret2 = icmp uge i64 %call_native.ret_count, 3
  br i1 %native.has.ret2, label %native.ret2.store, label %native.store.done

native.ret2.store:                                ; preds = %native.ret2.check
  %reg.store.ptr641 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret2
  store i64 %width.masked608, ptr %reg.store.ptr641, align 8
  br label %native.ret3.check

native.ret3.check:                                ; preds = %native.ret2.store
  %native.has.ret3 = icmp uge i64 %call_native.ret_count, 4
  br i1 %native.has.ret3, label %native.ret3.store, label %native.store.done

native.ret3.store:                                ; preds = %native.ret3.check
  %reg.store.ptr642 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret3
  store i64 %width.masked614, ptr %reg.store.ptr642, align 8
  br label %native.ret4.check

native.ret4.check:                                ; preds = %native.ret3.store
  %native.has.ret4 = icmp uge i64 %call_native.ret_count, 5
  br i1 %native.has.ret4, label %native.ret4.store, label %native.store.done

native.ret4.store:                                ; preds = %native.ret4.check
  %reg.store.ptr643 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret4
  store i64 %width.masked620, ptr %reg.store.ptr643, align 8
  br label %native.ret5.check

native.ret5.check:                                ; preds = %native.ret4.store
  %native.has.ret5 = icmp uge i64 %call_native.ret_count, 6
  br i1 %native.has.ret5, label %native.ret5.store, label %native.store.done

native.ret5.store:                                ; preds = %native.ret5.check
  %reg.store.ptr644 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret5
  store i64 %width.masked626, ptr %reg.store.ptr644, align 8
  br label %native.ret6.check

native.ret6.check:                                ; preds = %native.ret5.store
  %native.has.ret6 = icmp uge i64 %call_native.ret_count, 7
  br i1 %native.has.ret6, label %native.ret6.store, label %native.store.done

native.ret6.store:                                ; preds = %native.ret6.check
  %reg.store.ptr645 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret6
  store i64 %width.masked632, ptr %reg.store.ptr645, align 8
  br label %native.ret7.check

native.ret7.check:                                ; preds = %native.ret6.store
  %native.has.ret7 = icmp uge i64 %call_native.ret_count, 8
  br i1 %native.has.ret7, label %native.ret7.store, label %native.store.done

native.ret7.store:                                ; preds = %native.ret7.check
  %reg.store.ptr646 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret7
  store i64 %width.masked638, ptr %reg.store.ptr646, align 8
  br label %native.store.done

handler.zext.op30.split.entry:                    ; preds = %execute.decode
  br label %handler.zext.op30.split.body

handler.zext.op30.split.body:                     ; preds = %handler.zext.op30.split.entry
  %dead.alias.pc649 = load i64, ptr %pc, align 8
  %dead.alias.next650 = add i64 %dead.alias.pc649, 32
  store i64 %dead.alias.next650, ptr %pc, align 8
  br label %loop.check

handler.br_if.op41.split.entry:                   ; preds = %execute.decode
  br label %handler.br_if.op41.split.body

handler.br_if.op41.split.body:                    ; preds = %handler.br_if.op41.split.entry
  %dead.alias.pc651 = load i64, ptr %pc, align 8
  %dead.alias.next652 = add i64 %dead.alias.pc651, 32
  store i64 %dead.alias.next652, ptr %pc, align 8
  br label %loop.check

handler.fsqrt.op8b3.split.entry:                  ; preds = %execute.decode
  br label %handler.fsqrt.op8b3.split.body

handler.fsqrt.op8b3.split.body:                   ; preds = %handler.fsqrt.op8b3.split.entry
  %dead.alias.pc653 = load i64, ptr %pc, align 8
  %dead.alias.next654 = add i64 %dead.alias.pc653, 32
  store i64 %dead.alias.next654, ptr %pc, align 8
  br label %loop.check

handler.fmaxnum.op70d.split.entry:                ; preds = %execute.decode
  br label %handler.fmaxnum.op70d.split.body

handler.fmaxnum.op70d.split.body:                 ; preds = %handler.fmaxnum.op70d.split.entry
  %dead.alias.pc655 = load i64, ptr %pc, align 8
  %dead.alias.next656 = add i64 %dead.alias.pc655, 16
  store i64 %dead.alias.next656, ptr %pc, align 8
  br label %loop.check

handler.load_ismin.op99b.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismin.op99b.split.body

handler.load_ismin.op99b.split.body:              ; preds = %handler.load_ismin.op99b.split.entry
  %dead.alias.pc657 = load i64, ptr %pc, align 8
  %dead.alias.next658 = add i64 %dead.alias.pc657, 32
  store i64 %dead.alias.next658, ptr %pc, align 8
  br label %loop.check

handler.sext.op8f9.split.entry:                   ; preds = %execute.decode
  br label %handler.sext.op8f9.split.body

handler.sext.op8f9.split.body:                    ; preds = %handler.sext.op8f9.split.entry
  %dead.alias.pc659 = load i64, ptr %pc, align 8
  %dead.alias.next660 = add i64 %dead.alias.pc659, 32
  store i64 %dead.alias.next660, ptr %pc, align 8
  br label %loop.check

handler.fexp2.op8cc.split.entry:                  ; preds = %execute.decode
  br label %handler.fexp2.op8cc.split.body

handler.fexp2.op8cc.split.body:                   ; preds = %handler.fexp2.op8cc.split.entry
  %dead.alias.pc661 = load i64, ptr %pc, align 8
  %dead.alias.next662 = add i64 %dead.alias.pc661, 32
  store i64 %dead.alias.next662, ptr %pc, align 8
  br label %loop.check

handler.fllrint.op8e9.split.entry:                ; preds = %execute.decode
  br label %handler.fllrint.op8e9.split.body

handler.fllrint.op8e9.split.body:                 ; preds = %handler.fllrint.op8e9.split.entry
  %dead.alias.pc663 = load i64, ptr %pc, align 8
  %dead.alias.next664 = add i64 %dead.alias.pc663, 16
  store i64 %dead.alias.next664, ptr %pc, align 8
  br label %loop.check

handler.fabs.op703.split.entry:                   ; preds = %execute.decode
  br label %handler.fabs.op703.split.body

handler.fabs.op703.split.body:                    ; preds = %handler.fabs.op703.split.entry
  %dead.alias.pc665 = load i64, ptr %pc, align 8
  %dead.alias.next666 = add i64 %dead.alias.pc665, 32
  store i64 %dead.alias.next666, ptr %pc, align 8
  br label %loop.check

handler.call_native.op9b6.split.entry:            ; preds = %execute.decode
  br label %handler.call_native.op9b6.split.body

handler.call_native.op9b6.split.body:             ; preds = %handler.call_native.op9b6.split.entry
  %dead.alias.pc667 = load i64, ptr %pc, align 8
  %dead.alias.next668 = add i64 %dead.alias.pc667, 64
  store i64 %dead.alias.next668, ptr %pc, align 8
  br label %loop.check

handler.load_iand.op1d5.split.entry:              ; preds = %execute.decode
  br label %handler.load_iand.op1d5.split.body

handler.load_iand.op1d5.split.body:               ; preds = %handler.load_iand.op1d5.split.entry
  %dead.alias.pc669 = load i64, ptr %pc, align 8
  %dead.alias.next670 = add i64 %dead.alias.pc669, 32
  store i64 %dead.alias.next670, ptr %pc, align 8
  br label %loop.check

handler.store.op7b.split.entry:                   ; preds = %execute.decode
  br label %handler.store.op7b.split.body

handler.store.op7b.split.body:                    ; preds = %handler.store.op7b.split.entry
  %dead.alias.pc671 = load i64, ptr %pc, align 8
  %dead.alias.next672 = add i64 %dead.alias.pc671, 32
  store i64 %dead.alias.next672, ptr %pc, align 8
  br label %loop.check

handler.flog.op8ce.split.entry:                   ; preds = %execute.decode
  br label %handler.flog.op8ce.split.body

handler.flog.op8ce.split.body:                    ; preds = %handler.flog.op8ce.split.entry
  %dead.alias.pc673 = load i64, ptr %pc, align 8
  %dead.alias.next674 = add i64 %dead.alias.pc673, 32
  store i64 %dead.alias.next674, ptr %pc, align 8
  br label %loop.check

handler.read_rounding.op819.split.entry:          ; preds = %execute.decode
  br label %handler.read_rounding.op819.split.body

handler.read_rounding.op819.split.body:           ; preds = %handler.read_rounding.op819.split.entry
  %dead.alias.pc675 = load i64, ptr %pc, align 8
  %dead.alias.next676 = add i64 %dead.alias.pc675, 8
  store i64 %dead.alias.next676, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_add.op182.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_add.op182.split.body

handler.volatile_atomic_rmw_add.op182.split.body: ; preds = %handler.volatile_atomic_rmw_add.op182.split.entry
  %dead.alias.pc677 = load i64, ptr %pc, align 8
  %dead.alias.next678 = add i64 %dead.alias.pc677, 32
  store i64 %dead.alias.next678, ptr %pc, align 8
  br label %loop.check

handler.load_isub.op9b1.split.entry:              ; preds = %execute.decode
  br label %handler.load_isub.op9b1.split.body

handler.load_isub.op9b1.split.body:               ; preds = %handler.load_isub.op9b1.split.entry
  %dead.alias.pc679 = load i64, ptr %pc, align 8
  %dead.alias.next680 = add i64 %dead.alias.pc679, 32
  store i64 %dead.alias.next680, ptr %pc, align 8
  br label %loop.check

handler.isrem.op91.split.entry:                   ; preds = %execute.decode
  br label %handler.isrem.op91.split.body

handler.isrem.op91.split.body:                    ; preds = %handler.isrem.op91.split.entry
  %dead.alias.pc681 = load i64, ptr %pc, align 8
  %dead.alias.next682 = add i64 %dead.alias.pc681, 32
  store i64 %dead.alias.next682, ptr %pc, align 8
  br label %loop.check

handler.volatile_load.op90f.split.entry:          ; preds = %execute.decode
  br label %handler.volatile_load.op90f.split.body

handler.volatile_load.op90f.split.body:           ; preds = %handler.volatile_load.op90f.split.entry
  %dead.alias.pc683 = load i64, ptr %pc, align 8
  %dead.alias.next684 = add i64 %dead.alias.pc683, 16
  store i64 %dead.alias.next684, ptr %pc, align 8
  br label %loop.check

handler.iurem.op8a.split.entry:                   ; preds = %execute.decode
  br label %handler.iurem.op8a.split.body

handler.iurem.op8a.split.body:                    ; preds = %handler.iurem.op8a.split.entry
  %dead.alias.pc685 = load i64, ptr %pc, align 8
  %dead.alias.next686 = add i64 %dead.alias.pc685, 32
  store i64 %dead.alias.next686, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fminimum.op952.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fminimum.op952.split.body

handler.atomic_rmw_fminimum.op952.split.body:     ; preds = %handler.atomic_rmw_fminimum.op952.split.entry
  %dead.alias.pc687 = load i64, ptr %pc, align 8
  %dead.alias.next688 = add i64 %dead.alias.pc687, 32
  store i64 %dead.alias.next688, ptr %pc, align 8
  br label %loop.check

handler.ior.op6f.split.entry:                     ; preds = %execute.decode
  br label %handler.ior.op6f.split.body

handler.ior.op6f.split.body:                      ; preds = %handler.ior.op6f.split.entry
  %dead.alias.pc689 = load i64, ptr %pc, align 8
  %dead.alias.next690 = add i64 %dead.alias.pc689, 32
  store i64 %dead.alias.next690, ptr %pc, align 8
  br label %loop.check

handler.gep_load.op985.split.entry:               ; preds = %execute.decode
  br label %handler.gep_load.op985.split.body

handler.gep_load.op985.split.body:                ; preds = %handler.gep_load.op985.split.entry
  %dead.alias.pc691 = load i64, ptr %pc, align 8
  %dead.alias.next692 = add i64 %dead.alias.pc691, 32
  store i64 %dead.alias.next692, ptr %pc, align 8
  br label %loop.check

handler.read_steady.op1ad.split.entry:            ; preds = %execute.decode
  br label %handler.read_steady.op1ad.split.body

handler.read_steady.op1ad.split.body:             ; preds = %handler.read_steady.op1ad.split.entry
  %dead.alias.pc693 = load i64, ptr %pc, align 8
  %dead.alias.next694 = add i64 %dead.alias.pc693, 8
  store i64 %dead.alias.next694, ptr %pc, align 8
  br label %loop.check

handler.vm_call.op71.split.entry:                 ; preds = %execute.decode
  br label %handler.vm_call.op71.split.body

handler.vm_call.op71.split.body:                  ; preds = %handler.vm_call.op71.split.entry
  %dead.alias.pc695 = load i64, ptr %pc, align 8
  %dead.alias.next696 = add i64 %dead.alias.pc695, 32
  store i64 %dead.alias.next696, ptr %pc, align 8
  br label %loop.check

handler.iurem.op8d.split.entry:                   ; preds = %execute.decode
  br label %handler.iurem.op8d.split.body

handler.iurem.op8d.split.body:                    ; preds = %handler.iurem.op8d.split.entry
  %dead.alias.pc697 = load i64, ptr %pc, align 8
  %dead.alias.next698 = add i64 %dead.alias.pc697, 32
  store i64 %dead.alias.next698, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op60.split.entry:                 ; preds = %execute.decode
  br label %handler.mov_imm.op60.split.body

handler.mov_imm.op60.split.body:                  ; preds = %handler.mov_imm.op60.split.entry
  %mov_imm.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.imm = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %width.is64699 = icmp eq i64 %mov_imm.width, 64
  %width.shift700 = and i64 %mov_imm.width, 63
  %mask.shifted701 = shl i64 1, %width.shift700
  %mask.candidate702 = sub i64 %mask.shifted701, 1
  %width.mask703 = select i1 %width.is64699, i64 -1, i64 %mask.candidate702
  %width.masked704 = and i64 %mov_imm.imm, %width.mask703
  %reg.store.ptr705 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov_imm.dst
  store i64 %width.masked704, ptr %reg.store.ptr705, align 8
  %pc.old706 = load i64, ptr %pc, align 8
  %pc.next707 = add i64 %pc.old706, 32
  store i64 %pc.next707, ptr %pc, align 8
  br label %loop.check

handler.load_isub.op1d2.split.entry:              ; preds = %execute.decode
  br label %handler.load_isub.op1d2.split.body

handler.load_isub.op1d2.split.body:               ; preds = %handler.load_isub.op1d2.split.entry
  %dead.alias.pc708 = load i64, ptr %pc, align 8
  %dead.alias.next709 = add i64 %dead.alias.pc708, 32
  store i64 %dead.alias.next709, ptr %pc, align 8
  br label %loop.check

handler.flog10.op72e.split.entry:                 ; preds = %execute.decode
  br label %handler.flog10.op72e.split.body

handler.flog10.op72e.split.body:                  ; preds = %handler.flog10.op72e.split.entry
  %dead.alias.pc710 = load i64, ptr %pc, align 8
  %dead.alias.next711 = add i64 %dead.alias.pc710, 32
  store i64 %dead.alias.next711, ptr %pc, align 8
  br label %loop.check

handler.br.op1c.split.entry:                      ; preds = %execute.decode
  br label %handler.br.op1c.split.body

handler.br.op1c.split.body:                       ; preds = %handler.br.op1c.split.entry
  %dead.alias.pc712 = load i64, ptr %pc, align 8
  %dead.alias.next713 = add i64 %dead.alias.pc712, 32
  store i64 %dead.alias.next713, ptr %pc, align 8
  br label %loop.check

handler.reset_fpmode.op832.split.entry:           ; preds = %execute.decode
  br label %handler.reset_fpmode.op832.split.body

handler.reset_fpmode.op832.split.body:            ; preds = %handler.reset_fpmode.op832.split.entry
  %dead.alias.pc714 = load i64, ptr %pc, align 8
  %dead.alias.next715 = add i64 %dead.alias.pc714, 4
  store i64 %dead.alias.next715, ptr %pc, align 8
  br label %loop.check

handler.br.op9b9.split.entry:                     ; preds = %execute.decode
  br label %handler.br.op9b9.split.body

handler.br.op9b9.split.body:                      ; preds = %handler.br.op9b9.split.entry
  %dead.alias.pc716 = load i64, ptr %pc, align 8
  %dead.alias.next717 = add i64 %dead.alias.pc716, 32
  store i64 %dead.alias.next717, ptr %pc, align 8
  br label %loop.check

handler.atomic_load.opd8.split.entry:             ; preds = %execute.decode
  br label %handler.atomic_load.opd8.split.body

handler.atomic_load.opd8.split.body:              ; preds = %handler.atomic_load.opd8.split.entry
  %dead.alias.pc718 = load i64, ptr %pc, align 8
  %dead.alias.next719 = add i64 %dead.alias.pc718, 32
  store i64 %dead.alias.next719, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_max.opf3.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_max.opf3.split.body

handler.atomic_rmw_max.opf3.split.body:           ; preds = %handler.atomic_rmw_max.opf3.split.entry
  %dead.alias.pc720 = load i64, ptr %pc, align 8
  %dead.alias.next721 = add i64 %dead.alias.pc720, 32
  store i64 %dead.alias.next721, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_store.op928.split.entry:  ; preds = %execute.decode
  br label %handler.volatile_atomic_store.op928.split.body

handler.volatile_atomic_store.op928.split.body:   ; preds = %handler.volatile_atomic_store.op928.split.entry
  %dead.alias.pc722 = load i64, ptr %pc, align 8
  %dead.alias.next723 = add i64 %dead.alias.pc722, 32
  store i64 %dead.alias.next723, ptr %pc, align 8
  br label %loop.check

handler.isrem.op92.split.entry:                   ; preds = %execute.decode
  br label %handler.isrem.op92.split.body

handler.isrem.op92.split.body:                    ; preds = %handler.isrem.op92.split.entry
  %dead.alias.pc724 = load i64, ptr %pc, align 8
  %dead.alias.next725 = add i64 %dead.alias.pc724, 32
  store i64 %dead.alias.next725, ptr %pc, align 8
  br label %loop.check

handler.load_isub.op1d3.split.entry:              ; preds = %execute.decode
  br label %handler.load_isub.op1d3.split.body

handler.load_isub.op1d3.split.body:               ; preds = %handler.load_isub.op1d3.split.entry
  %dead.alias.pc726 = load i64, ptr %pc, align 8
  %dead.alias.next727 = add i64 %dead.alias.pc726, 32
  store i64 %dead.alias.next727, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_or.op188.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_or.op188.split.body

handler.volatile_atomic_rmw_or.op188.split.body:  ; preds = %handler.volatile_atomic_rmw_or.op188.split.entry
  %dead.alias.pc728 = load i64, ptr %pc, align 8
  %dead.alias.next729 = add i64 %dead.alias.pc728, 32
  store i64 %dead.alias.next729, ptr %pc, align 8
  br label %loop.check

handler.ishl.op53.split.entry:                    ; preds = %execute.decode
  br label %handler.ishl.op53.split.body

handler.ishl.op53.split.body:                     ; preds = %handler.ishl.op53.split.entry
  %dead.alias.pc730 = load i64, ptr %pc, align 8
  %dead.alias.next731 = add i64 %dead.alias.pc730, 32
  store i64 %dead.alias.next731, ptr %pc, align 8
  br label %loop.check

handler.fminnum.op70b.split.entry:                ; preds = %execute.decode
  br label %handler.fminnum.op70b.split.body

handler.fminnum.op70b.split.body:                 ; preds = %handler.fminnum.op70b.split.entry
  %dead.alias.pc732 = load i64, ptr %pc, align 8
  %dead.alias.next733 = add i64 %dead.alias.pc732, 16
  store i64 %dead.alias.next733, ptr %pc, align 8
  br label %loop.check

handler.fsin.op725.split.entry:                   ; preds = %execute.decode
  br label %handler.fsin.op725.split.body

handler.fsin.op725.split.body:                    ; preds = %handler.fsin.op725.split.entry
  %dead.alias.pc734 = load i64, ptr %pc, align 8
  %dead.alias.next735 = add i64 %dead.alias.pc734, 32
  store i64 %dead.alias.next735, ptr %pc, align 8
  br label %loop.check

handler.write_fpenv.op825.split.entry:            ; preds = %execute.decode
  br label %handler.write_fpenv.op825.split.body

handler.write_fpenv.op825.split.body:             ; preds = %handler.write_fpenv.op825.split.entry
  %dead.alias.pc736 = load i64, ptr %pc, align 8
  %dead.alias.next737 = add i64 %dead.alias.pc736, 8
  store i64 %dead.alias.next737, ptr %pc, align 8
  br label %loop.check

handler.prefetch.op201.split.entry:               ; preds = %execute.decode
  br label %handler.prefetch.op201.split.body

handler.prefetch.op201.split.body:                ; preds = %handler.prefetch.op201.split.entry
  %dead.alias.pc738 = load i64, ptr %pc, align 8
  %dead.alias.next739 = add i64 %dead.alias.pc738, 16
  store i64 %dead.alias.next739, ptr %pc, align 8
  br label %loop.check

handler.volatile_memset_dyn.op17c.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memset_dyn.op17c.split.body

handler.volatile_memset_dyn.op17c.split.body:     ; preds = %handler.volatile_memset_dyn.op17c.split.entry
  %dead.alias.pc740 = load i64, ptr %pc, align 8
  %dead.alias.next741 = add i64 %dead.alias.pc740, 8
  store i64 %dead.alias.next741, ptr %pc, align 8
  br label %loop.check

handler.fdiv.opa3.split.entry:                    ; preds = %execute.decode
  br label %handler.fdiv.opa3.split.body

handler.fdiv.opa3.split.body:                     ; preds = %handler.fdiv.opa3.split.entry
  %dead.alias.pc742 = load i64, ptr %pc, align 8
  %dead.alias.next743 = add i64 %dead.alias.pc742, 32
  store i64 %dead.alias.next743, ptr %pc, align 8
  br label %loop.check

handler.trunc.op26.split.entry:                   ; preds = %execute.decode
  br label %handler.trunc.op26.split.body

handler.trunc.op26.split.body:                    ; preds = %handler.trunc.op26.split.entry
  %dead.alias.pc744 = load i64, ptr %pc, align 8
  %dead.alias.next745 = add i64 %dead.alias.pc744, 32
  store i64 %dead.alias.next745, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_nand.op18d.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_nand.op18d.split.body

handler.volatile_atomic_rmw_nand.op18d.split.body: ; preds = %handler.volatile_atomic_rmw_nand.op18d.split.entry
  %dead.alias.pc746 = load i64, ptr %pc, align 8
  %dead.alias.next747 = add i64 %dead.alias.pc746, 32
  store i64 %dead.alias.next747, ptr %pc, align 8
  br label %loop.check

handler.fllround.op8ee.split.entry:               ; preds = %execute.decode
  br label %handler.fllround.op8ee.split.body

handler.fllround.op8ee.split.body:                ; preds = %handler.fllround.op8ee.split.entry
  %dead.alias.pc748 = load i64, ptr %pc, align 8
  %dead.alias.next749 = add i64 %dead.alias.pc748, 16
  store i64 %dead.alias.next749, ptr %pc, align 8
  br label %loop.check

handler.load_iashr.op1e6.split.entry:             ; preds = %execute.decode
  br label %handler.load_iashr.op1e6.split.body

handler.load_iashr.op1e6.split.body:              ; preds = %handler.load_iashr.op1e6.split.entry
  %dead.alias.pc750 = load i64, ptr %pc, align 8
  %dead.alias.next751 = add i64 %dead.alias.pc750, 32
  store i64 %dead.alias.next751, ptr %pc, align 8
  br label %loop.check

handler.cmpxchg.op97d.split.entry:                ; preds = %execute.decode
  br label %handler.cmpxchg.op97d.split.body

handler.cmpxchg.op97d.split.body:                 ; preds = %handler.cmpxchg.op97d.split.entry
  %dead.alias.pc752 = load i64, ptr %pc, align 8
  %dead.alias.next753 = add i64 %dead.alias.pc752, 32
  store i64 %dead.alias.next753, ptr %pc, align 8
  br label %loop.check

handler.isub.op57.split.entry:                    ; preds = %execute.decode
  br label %handler.isub.op57.split.body

handler.isub.op57.split.body:                     ; preds = %handler.isub.op57.split.entry
  %dead.alias.pc754 = load i64, ptr %pc, align 8
  %dead.alias.next755 = add i64 %dead.alias.pc754, 32
  store i64 %dead.alias.next755, ptr %pc, align 8
  br label %loop.check

handler.load_isrem.op991.split.entry:             ; preds = %execute.decode
  br label %handler.load_isrem.op991.split.body

handler.load_isrem.op991.split.body:              ; preds = %handler.load_isrem.op991.split.entry
  %dead.alias.pc756 = load i64, ptr %pc, align 8
  %dead.alias.next757 = add i64 %dead.alias.pc756, 32
  store i64 %dead.alias.next757, ptr %pc, align 8
  br label %loop.check

handler.fnearbyint.op8bf.split.entry:             ; preds = %execute.decode
  br label %handler.fnearbyint.op8bf.split.body

handler.fnearbyint.op8bf.split.body:              ; preds = %handler.fnearbyint.op8bf.split.entry
  %dead.alias.pc758 = load i64, ptr %pc, align 8
  %dead.alias.next759 = add i64 %dead.alias.pc758, 32
  store i64 %dead.alias.next759, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_store.op176.split.entry:  ; preds = %execute.decode
  br label %handler.volatile_atomic_store.op176.split.body

handler.volatile_atomic_store.op176.split.body:   ; preds = %handler.volatile_atomic_store.op176.split.entry
  %dead.alias.pc760 = load i64, ptr %pc, align 8
  %dead.alias.next761 = add i64 %dead.alias.pc760, 32
  store i64 %dead.alias.next761, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.op8e4.split.entry:                ; preds = %execute.decode
  br label %handler.fptrunc.op8e4.split.body

handler.fptrunc.op8e4.split.body:                 ; preds = %handler.fptrunc.op8e4.split.entry
  %dead.alias.pc762 = load i64, ptr %pc, align 8
  %dead.alias.next763 = add i64 %dead.alias.pc762, 32
  store i64 %dead.alias.next763, ptr %pc, align 8
  br label %loop.check

handler.fpow.op8a4.split.entry:                   ; preds = %execute.decode
  br label %handler.fpow.op8a4.split.body

handler.fpow.op8a4.split.body:                    ; preds = %handler.fpow.op8a4.split.entry
  %dead.alias.pc764 = load i64, ptr %pc, align 8
  %dead.alias.next765 = add i64 %dead.alias.pc764, 16
  store i64 %dead.alias.next765, ptr %pc, align 8
  br label %loop.check

handler.fptoui.opc8.split.entry:                  ; preds = %execute.decode
  br label %handler.fptoui.opc8.split.body

handler.fptoui.opc8.split.body:                   ; preds = %handler.fptoui.opc8.split.entry
  %dead.alias.pc766 = load i64, ptr %pc, align 8
  %dead.alias.next767 = add i64 %dead.alias.pc766, 32
  store i64 %dead.alias.next767, ptr %pc, align 8
  br label %loop.check

handler.flog2.op731.split.entry:                  ; preds = %execute.decode
  br label %handler.flog2.op731.split.body

handler.flog2.op731.split.body:                   ; preds = %handler.flog2.op731.split.entry
  %dead.alias.pc768 = load i64, ptr %pc, align 8
  %dead.alias.next769 = add i64 %dead.alias.pc768, 32
  store i64 %dead.alias.next769, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_or.op189.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_or.op189.split.body

handler.volatile_atomic_rmw_or.op189.split.body:  ; preds = %handler.volatile_atomic_rmw_or.op189.split.entry
  %dead.alias.pc770 = load i64, ptr %pc, align 8
  %dead.alias.next771 = add i64 %dead.alias.pc770, 32
  store i64 %dead.alias.next771, ptr %pc, align 8
  br label %loop.check

handler.fceil.op8ba.split.entry:                  ; preds = %execute.decode
  br label %handler.fceil.op8ba.split.body

handler.fceil.op8ba.split.body:                   ; preds = %handler.fceil.op8ba.split.entry
  %dead.alias.pc772 = load i64, ptr %pc, align 8
  %dead.alias.next773 = add i64 %dead.alias.pc772, 32
  store i64 %dead.alias.next773, ptr %pc, align 8
  br label %loop.check

handler.flog.op8cd.split.entry:                   ; preds = %execute.decode
  br label %handler.flog.op8cd.split.body

handler.flog.op8cd.split.body:                    ; preds = %handler.flog.op8cd.split.entry
  %dead.alias.pc774 = load i64, ptr %pc, align 8
  %dead.alias.next775 = add i64 %dead.alias.pc774, 32
  store i64 %dead.alias.next775, ptr %pc, align 8
  br label %loop.check

handler.iusub_overflow.op87f.split.entry:         ; preds = %execute.decode
  br label %handler.iusub_overflow.op87f.split.body

handler.iusub_overflow.op87f.split.body:          ; preds = %handler.iusub_overflow.op87f.split.entry
  %dead.alias.pc776 = load i64, ptr %pc, align 8
  %dead.alias.next777 = add i64 %dead.alias.pc776, 32
  store i64 %dead.alias.next777, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_uinc_wrap.op197.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_uinc_wrap.op197.split.body

handler.volatile_atomic_rmw_uinc_wrap.op197.split.body: ; preds = %handler.volatile_atomic_rmw_uinc_wrap.op197.split.entry
  %dead.alias.pc778 = load i64, ptr %pc, align 8
  %dead.alias.next779 = add i64 %dead.alias.pc778, 32
  store i64 %dead.alias.next779, ptr %pc, align 8
  br label %loop.check

handler.iusub_sat.op871.split.entry:              ; preds = %execute.decode
  br label %handler.iusub_sat.op871.split.body

handler.iusub_sat.op871.split.body:               ; preds = %handler.iusub_sat.op871.split.entry
  %dead.alias.pc780 = load i64, ptr %pc, align 8
  %dead.alias.next781 = add i64 %dead.alias.pc780, 32
  store i64 %dead.alias.next781, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fadd.op19e.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fadd.op19e.split.body

handler.volatile_atomic_rmw_fadd.op19e.split.body: ; preds = %handler.volatile_atomic_rmw_fadd.op19e.split.entry
  %dead.alias.pc782 = load i64, ptr %pc, align 8
  %dead.alias.next783 = add i64 %dead.alias.pc782, 32
  store i64 %dead.alias.next783, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umin.op194.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umin.op194.split.body

handler.volatile_atomic_rmw_umin.op194.split.body: ; preds = %handler.volatile_atomic_rmw_umin.op194.split.entry
  %dead.alias.pc784 = load i64, ptr %pc, align 8
  %dead.alias.next785 = add i64 %dead.alias.pc784, 32
  store i64 %dead.alias.next785, ptr %pc, align 8
  br label %loop.check

handler.vm_call.op9be.split.entry:                ; preds = %execute.decode
  br label %handler.vm_call.op9be.split.body

handler.vm_call.op9be.split.body:                 ; preds = %handler.vm_call.op9be.split.entry
  %dead.alias.pc786 = load i64, ptr %pc, align 8
  %dead.alias.next787 = add i64 %dead.alias.pc786, 32
  store i64 %dead.alias.next787, ptr %pc, align 8
  br label %loop.check

handler.froundeven.op723.split.entry:             ; preds = %execute.decode
  br label %handler.froundeven.op723.split.body

handler.froundeven.op723.split.body:              ; preds = %handler.froundeven.op723.split.entry
  %dead.alias.pc788 = load i64, ptr %pc, align 8
  %dead.alias.next789 = add i64 %dead.alias.pc788, 32
  store i64 %dead.alias.next789, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmin.op94d.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmin.op94d.split.body

handler.atomic_rmw_fmin.op94d.split.body:         ; preds = %handler.atomic_rmw_fmin.op94d.split.entry
  %dead.alias.pc790 = load i64, ptr %pc, align 8
  %dead.alias.next791 = add i64 %dead.alias.pc790, 32
  store i64 %dead.alias.next791, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_and.op92f.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_and.op92f.split.body

handler.atomic_rmw_and.op92f.split.body:          ; preds = %handler.atomic_rmw_and.op92f.split.entry
  %dead.alias.pc792 = load i64, ptr %pc, align 8
  %dead.alias.next793 = add i64 %dead.alias.pc792, 32
  store i64 %dead.alias.next793, ptr %pc, align 8
  br label %loop.check

handler.alloca.op34.split.entry:                  ; preds = %execute.decode
  br label %handler.alloca.op34.split.body

handler.alloca.op34.split.body:                   ; preds = %handler.alloca.op34.split.entry
  %dead.alias.pc794 = load i64, ptr %pc, align 8
  %dead.alias.next795 = add i64 %dead.alias.pc794, 32
  store i64 %dead.alias.next795, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op848.split.entry:                  ; preds = %execute.decode
  br label %handler.isdiv.op848.split.body

handler.isdiv.op848.split.body:                   ; preds = %handler.isdiv.op848.split.entry
  %dead.alias.pc796 = load i64, ptr %pc, align 8
  %dead.alias.next797 = add i64 %dead.alias.pc796, 32
  store i64 %dead.alias.next797, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op87.split.entry:                   ; preds = %execute.decode
  br label %handler.isdiv.op87.split.body

handler.isdiv.op87.split.body:                    ; preds = %handler.isdiv.op87.split.entry
  %dead.alias.pc798 = load i64, ptr %pc, align 8
  %dead.alias.next799 = add i64 %dead.alias.pc798, 32
  store i64 %dead.alias.next799, ptr %pc, align 8
  br label %loop.check

handler.volatile_cmpxchg.op17f.split.entry:       ; preds = %execute.decode
  br label %handler.volatile_cmpxchg.op17f.split.body

handler.volatile_cmpxchg.op17f.split.body:        ; preds = %handler.volatile_cmpxchg.op17f.split.entry
  %dead.alias.pc800 = load i64, ptr %pc, align 8
  %dead.alias.next801 = add i64 %dead.alias.pc800, 32
  store i64 %dead.alias.next801, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmin.op1a4.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmin.op1a4.split.body

handler.volatile_atomic_rmw_fmin.op1a4.split.body: ; preds = %handler.volatile_atomic_rmw_fmin.op1a4.split.entry
  %dead.alias.pc802 = load i64, ptr %pc, align 8
  %dead.alias.next803 = add i64 %dead.alias.pc802, 32
  store i64 %dead.alias.next803, ptr %pc, align 8
  br label %loop.check

handler.const_load.op5d.split.entry:              ; preds = %execute.decode
  br label %handler.const_load.op5d.split.body

handler.const_load.op5d.split.body:               ; preds = %handler.const_load.op5d.split.entry
  %dead.alias.pc804 = load i64, ptr %pc, align 8
  %dead.alias.next805 = add i64 %dead.alias.pc804, 32
  store i64 %dead.alias.next805, ptr %pc, align 8
  br label %loop.check

handler.isub.op3d.split.entry:                    ; preds = %execute.decode
  br label %handler.isub.op3d.split.body

handler.isub.op3d.split.body:                     ; preds = %handler.isub.op3d.split.entry
  %dead.alias.pc806 = load i64, ptr %pc, align 8
  %dead.alias.next807 = add i64 %dead.alias.pc806, 32
  store i64 %dead.alias.next807, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_uinc_wrap.op16d.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_uinc_wrap.op16d.split.body

handler.atomic_rmw_uinc_wrap.op16d.split.body:    ; preds = %handler.atomic_rmw_uinc_wrap.op16d.split.entry
  %dead.alias.pc808 = load i64, ptr %pc, align 8
  %dead.alias.next809 = add i64 %dead.alias.pc808, 32
  store i64 %dead.alias.next809, ptr %pc, align 8
  br label %loop.check

handler.alloca_dyn.op13f.split.entry:             ; preds = %execute.decode
  br label %handler.alloca_dyn.op13f.split.body

handler.alloca_dyn.op13f.split.body:              ; preds = %handler.alloca_dyn.op13f.split.entry
  %dead.alias.pc810 = load i64, ptr %pc, align 8
  %dead.alias.next811 = add i64 %dead.alias.pc810, 32
  store i64 %dead.alias.next811, ptr %pc, align 8
  br label %loop.check

handler.ismul_overflow.op886.split.entry:         ; preds = %execute.decode
  br label %handler.ismul_overflow.op886.split.body

handler.ismul_overflow.op886.split.body:          ; preds = %handler.ismul_overflow.op886.split.entry
  %dead.alias.pc812 = load i64, ptr %pc, align 8
  %dead.alias.next813 = add i64 %dead.alias.pc812, 32
  store i64 %dead.alias.next813, ptr %pc, align 8
  br label %loop.check

handler.flog2.op730.split.entry:                  ; preds = %execute.decode
  br label %handler.flog2.op730.split.body

handler.flog2.op730.split.body:                   ; preds = %handler.flog2.op730.split.entry
  %dead.alias.pc814 = load i64, ptr %pc, align 8
  %dead.alias.next815 = add i64 %dead.alias.pc814, 32
  store i64 %dead.alias.next815, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_load.op174.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_atomic_load.op174.split.body

handler.volatile_atomic_load.op174.split.body:    ; preds = %handler.volatile_atomic_load.op174.split.entry
  %dead.alias.pc816 = load i64, ptr %pc, align 8
  %dead.alias.next817 = add i64 %dead.alias.pc816, 32
  store i64 %dead.alias.next817, ptr %pc, align 8
  br label %loop.check

handler.atomic_load.op921.split.entry:            ; preds = %execute.decode
  br label %handler.atomic_load.op921.split.body

handler.atomic_load.op921.split.body:             ; preds = %handler.atomic_load.op921.split.entry
  %dead.alias.pc818 = load i64, ptr %pc, align 8
  %dead.alias.next819 = add i64 %dead.alias.pc818, 32
  store i64 %dead.alias.next819, ptr %pc, align 8
  br label %loop.check

handler.ctlz.op889.split.entry:                   ; preds = %execute.decode
  br label %handler.ctlz.op889.split.body

handler.ctlz.op889.split.body:                    ; preds = %handler.ctlz.op889.split.entry
  %dead.alias.pc820 = load i64, ptr %pc, align 8
  %dead.alias.next821 = add i64 %dead.alias.pc820, 32
  store i64 %dead.alias.next821, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fminimum.op16a.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fminimum.op16a.split.body

handler.atomic_rmw_fminimum.op16a.split.body:     ; preds = %handler.atomic_rmw_fminimum.op16a.split.entry
  %dead.alias.pc822 = load i64, ptr %pc, align 8
  %dead.alias.next823 = add i64 %dead.alias.pc822, 32
  store i64 %dead.alias.next823, ptr %pc, align 8
  br label %loop.check

handler.iushl_sat.op877.split.entry:              ; preds = %execute.decode
  br label %handler.iushl_sat.op877.split.body

handler.iushl_sat.op877.split.body:               ; preds = %handler.iushl_sat.op877.split.entry
  %dead.alias.pc824 = load i64, ptr %pc, align 8
  %dead.alias.next825 = add i64 %dead.alias.pc824, 32
  store i64 %dead.alias.next825, ptr %pc, align 8
  br label %loop.check

handler.read_fpenv.op822.split.entry:             ; preds = %execute.decode
  br label %handler.read_fpenv.op822.split.body

handler.read_fpenv.op822.split.body:              ; preds = %handler.read_fpenv.op822.split.entry
  %dead.alias.pc826 = load i64, ptr %pc, align 8
  %dead.alias.next827 = add i64 %dead.alias.pc826, 8
  store i64 %dead.alias.next827, ptr %pc, align 8
  br label %loop.check

handler.ixor.op13.split.entry:                    ; preds = %execute.decode
  br label %handler.ixor.op13.split.body

handler.ixor.op13.split.body:                     ; preds = %handler.ixor.op13.split.entry
  %ixor.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %ixor.lhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %ixor.rhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %ixor.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr828 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ixor.lhs
  %lhs = load i64, ptr %reg.load.ptr828, align 8
  %reg.load.ptr829 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ixor.rhs
  %rhs = load i64, ptr %reg.load.ptr829, align 8
  %shift.masked = and i64 %rhs, 63
  %bin.xor = xor i64 %lhs, %rhs
  %width.is64830 = icmp eq i64 %ixor.width, 64
  %width.shift831 = and i64 %ixor.width, 63
  %mask.shifted832 = shl i64 1, %width.shift831
  %mask.candidate833 = sub i64 %mask.shifted832, 1
  %width.mask834 = select i1 %width.is64830, i64 -1, i64 %mask.candidate833
  %width.masked835 = and i64 %bin.xor, %width.mask834
  %reg.store.ptr836 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ixor.dst
  store i64 %width.masked835, ptr %reg.store.ptr836, align 8
  %pc.old837 = load i64, ptr %pc, align 8
  %pc.next838 = add i64 %pc.old837, 32
  store i64 %pc.next838, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xor.op18b.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xor.op18b.split.body

handler.volatile_atomic_rmw_xor.op18b.split.body: ; preds = %handler.volatile_atomic_rmw_xor.op18b.split.entry
  %dead.alias.pc839 = load i64, ptr %pc, align 8
  %dead.alias.next840 = add i64 %dead.alias.pc839, 32
  store i64 %dead.alias.next840, ptr %pc, align 8
  br label %loop.check

handler.reset_fpenv.op1c9.split.entry:            ; preds = %execute.decode
  br label %handler.reset_fpenv.op1c9.split.body

handler.reset_fpenv.op1c9.split.body:             ; preds = %handler.reset_fpenv.op1c9.split.entry
  %dead.alias.pc841 = load i64, ptr %pc, align 8
  %dead.alias.next842 = add i64 %dead.alias.pc841, 4
  store i64 %dead.alias.next842, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_sat.op970.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_sat.op970.split.body

handler.volatile_atomic_rmw_usub_sat.op970.split.body: ; preds = %handler.volatile_atomic_rmw_usub_sat.op970.split.entry
  %dead.alias.pc843 = load i64, ptr %pc, align 8
  %dead.alias.next844 = add i64 %dead.alias.pc843, 32
  store i64 %dead.alias.next844, ptr %pc, align 8
  br label %loop.check

handler.mov.op75.split.entry:                     ; preds = %execute.decode
  br label %handler.mov.op75.split.body

handler.mov.op75.split.body:                      ; preds = %handler.mov.op75.split.entry
  %mov.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov.src = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr845 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov.src
  %mov.src846 = load i64, ptr %reg.load.ptr845, align 8
  %width.is64847 = icmp eq i64 %mov.width, 64
  %width.shift848 = and i64 %mov.width, 63
  %mask.shifted849 = shl i64 1, %width.shift848
  %mask.candidate850 = sub i64 %mask.shifted849, 1
  %width.mask851 = select i1 %width.is64847, i64 -1, i64 %mask.candidate850
  %width.masked852 = and i64 %mov.src846, %width.mask851
  %reg.store.ptr853 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov.dst
  store i64 %width.masked852, ptr %reg.store.ptr853, align 8
  %pc.old854 = load i64, ptr %pc, align 8
  %pc.next855 = add i64 %pc.old854, 8
  store i64 %pc.next855, ptr %pc, align 8
  br label %loop.check

handler.fptoui.opc7.split.entry:                  ; preds = %execute.decode
  br label %handler.fptoui.opc7.split.body

handler.fptoui.opc7.split.body:                   ; preds = %handler.fptoui.opc7.split.entry
  %dead.alias.pc856 = load i64, ptr %pc, align 8
  %dead.alias.next857 = add i64 %dead.alias.pc856, 32
  store i64 %dead.alias.next857, ptr %pc, align 8
  br label %loop.check

handler.load_iadd.op987.split.entry:              ; preds = %execute.decode
  br label %handler.load_iadd.op987.split.body

handler.load_iadd.op987.split.body:               ; preds = %handler.load_iadd.op987.split.entry
  %dead.alias.pc858 = load i64, ptr %pc, align 8
  %dead.alias.next859 = add i64 %dead.alias.pc858, 32
  store i64 %dead.alias.next859, ptr %pc, align 8
  br label %loop.check

handler.isadd_sat.op126.split.entry:              ; preds = %execute.decode
  br label %handler.isadd_sat.op126.split.body

handler.isadd_sat.op126.split.body:               ; preds = %handler.isadd_sat.op126.split.entry
  %dead.alias.pc860 = load i64, ptr %pc, align 8
  %dead.alias.next861 = add i64 %dead.alias.pc860, 32
  store i64 %dead.alias.next861, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_add.ope3.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_add.ope3.split.body

handler.atomic_rmw_add.ope3.split.body:           ; preds = %handler.atomic_rmw_add.ope3.split.entry
  %dead.alias.pc862 = load i64, ptr %pc, align 8
  %dead.alias.next863 = add i64 %dead.alias.pc862, 32
  store i64 %dead.alias.next863, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umin.op93d.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_umin.op93d.split.body

handler.atomic_rmw_umin.op93d.split.body:         ; preds = %handler.atomic_rmw_umin.op93d.split.entry
  %dead.alias.pc864 = load i64, ptr %pc, align 8
  %dead.alias.next865 = add i64 %dead.alias.pc864, 32
  store i64 %dead.alias.next865, ptr %pc, align 8
  br label %loop.check

handler.read_fpmode.op82c.split.entry:            ; preds = %execute.decode
  br label %handler.read_fpmode.op82c.split.body

handler.read_fpmode.op82c.split.body:             ; preds = %handler.read_fpmode.op82c.split.entry
  %dead.alias.pc866 = load i64, ptr %pc, align 8
  %dead.alias.next867 = add i64 %dead.alias.pc866, 8
  store i64 %dead.alias.next867, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_max.op18f.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_max.op18f.split.body

handler.volatile_atomic_rmw_max.op18f.split.body: ; preds = %handler.volatile_atomic_rmw_max.op18f.split.entry
  %dead.alias.pc868 = load i64, ptr %pc, align 8
  %dead.alias.next869 = add i64 %dead.alias.pc868, 32
  store i64 %dead.alias.next869, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op849.split.entry:                  ; preds = %execute.decode
  br label %handler.isdiv.op849.split.body

handler.isdiv.op849.split.body:                   ; preds = %handler.isdiv.op849.split.entry
  %dead.alias.pc870 = load i64, ptr %pc, align 8
  %dead.alias.next871 = add i64 %dead.alias.pc870, 32
  store i64 %dead.alias.next871, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fsub.op163.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fsub.op163.split.body

handler.atomic_rmw_fsub.op163.split.body:         ; preds = %handler.atomic_rmw_fsub.op163.split.entry
  %dead.alias.pc872 = load i64, ptr %pc, align 8
  %dead.alias.next873 = add i64 %dead.alias.pc872, 32
  store i64 %dead.alias.next873, ptr %pc, align 8
  br label %loop.check

handler.fsqrt.op706.split.entry:                  ; preds = %execute.decode
  br label %handler.fsqrt.op706.split.body

handler.fsqrt.op706.split.body:                   ; preds = %handler.fsqrt.op706.split.entry
  %dead.alias.pc874 = load i64, ptr %pc, align 8
  %dead.alias.next875 = add i64 %dead.alias.pc874, 32
  store i64 %dead.alias.next875, ptr %pc, align 8
  br label %loop.check

handler.bitcast.op27.split.entry:                 ; preds = %execute.decode
  br label %handler.bitcast.op27.split.body

handler.bitcast.op27.split.body:                  ; preds = %handler.bitcast.op27.split.entry
  %dead.alias.pc876 = load i64, ptr %pc, align 8
  %dead.alias.next877 = add i64 %dead.alias.pc876, 32
  store i64 %dead.alias.next877, ptr %pc, align 8
  br label %loop.check

handler.fake_nop.op64.split.entry:                ; preds = %execute.decode
  br label %handler.fake_nop.op64.split.body

handler.fake_nop.op64.split.body:                 ; preds = %handler.fake_nop.op64.split.entry
  %pc.old878 = load i64, ptr %pc, align 8
  %pc.next879 = add i64 %pc.old878, 4
  store i64 %pc.next879, ptr %pc, align 8
  br label %loop.check

handler.isadd_sat.op874.split.entry:              ; preds = %execute.decode
  br label %handler.isadd_sat.op874.split.body

handler.isadd_sat.op874.split.body:               ; preds = %handler.isadd_sat.op874.split.entry
  %dead.alias.pc880 = load i64, ptr %pc, align 8
  %dead.alias.next881 = add i64 %dead.alias.pc880, 32
  store i64 %dead.alias.next881, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.opcc.split.entry:                 ; preds = %execute.decode
  br label %handler.fptrunc.opcc.split.body

handler.fptrunc.opcc.split.body:                  ; preds = %handler.fptrunc.opcc.split.entry
  %dead.alias.pc882 = load i64, ptr %pc, align 8
  %dead.alias.next883 = add i64 %dead.alias.pc882, 32
  store i64 %dead.alias.next883, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op802.split.entry:                ; preds = %execute.decode
  br label %handler.mov_imm.op802.split.body

handler.mov_imm.op802.split.body:                 ; preds = %handler.mov_imm.op802.split.entry
  %mov_imm.dst884 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.imm885 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.width886 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %width.is64887 = icmp eq i64 %mov_imm.width886, 64
  %width.shift888 = and i64 %mov_imm.width886, 63
  %mask.shifted889 = shl i64 1, %width.shift888
  %mask.candidate890 = sub i64 %mask.shifted889, 1
  %width.mask891 = select i1 %width.is64887, i64 -1, i64 %mask.candidate890
  %width.masked892 = and i64 %mov_imm.imm885, %width.mask891
  %reg.store.ptr893 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov_imm.dst884
  store i64 %width.masked892, ptr %reg.store.ptr893, align 8
  %pc.old894 = load i64, ptr %pc, align 8
  %pc.next895 = add i64 %pc.old894, 32
  store i64 %pc.next895, ptr %pc, align 8
  br label %loop.check

handler.fptosi.opc4.split.entry:                  ; preds = %execute.decode
  br label %handler.fptosi.opc4.split.body

handler.fptosi.opc4.split.body:                   ; preds = %handler.fptosi.opc4.split.entry
  %dead.alias.pc896 = load i64, ptr %pc, align 8
  %dead.alias.next897 = add i64 %dead.alias.pc896, 32
  store i64 %dead.alias.next897, ptr %pc, align 8
  br label %loop.check

handler.iadd.op839.split.entry:                   ; preds = %execute.decode
  br label %handler.iadd.op839.split.body

handler.iadd.op839.split.body:                    ; preds = %handler.iadd.op839.split.entry
  %dead.alias.pc898 = load i64, ptr %pc, align 8
  %dead.alias.next899 = add i64 %dead.alias.pc898, 16
  store i64 %dead.alias.next899, ptr %pc, align 8
  br label %loop.check

handler.bswap.op890.split.entry:                  ; preds = %execute.decode
  br label %handler.bswap.op890.split.body

handler.bswap.op890.split.body:                   ; preds = %handler.bswap.op890.split.entry
  %dead.alias.pc900 = load i64, ptr %pc, align 8
  %dead.alias.next901 = add i64 %dead.alias.pc900, 32
  store i64 %dead.alias.next901, ptr %pc, align 8
  br label %loop.check

handler.atomic_store.opdb.split.entry:            ; preds = %execute.decode
  br label %handler.atomic_store.opdb.split.body

handler.atomic_store.opdb.split.body:             ; preds = %handler.atomic_store.opdb.split.entry
  %dead.alias.pc902 = load i64, ptr %pc, align 8
  %dead.alias.next903 = add i64 %dead.alias.pc902, 32
  store i64 %dead.alias.next903, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_sub.op957.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_sub.op957.split.body

handler.volatile_atomic_rmw_sub.op957.split.body: ; preds = %handler.volatile_atomic_rmw_sub.op957.split.entry
  %dead.alias.pc904 = load i64, ptr %pc, align 8
  %dead.alias.next905 = add i64 %dead.alias.pc904, 32
  store i64 %dead.alias.next905, ptr %pc, align 8
  br label %loop.check

handler.store.op49.split.entry:                   ; preds = %execute.decode
  br label %handler.store.op49.split.body

handler.store.op49.split.body:                    ; preds = %handler.store.op49.split.entry
  %dead.alias.pc906 = load i64, ptr %pc, align 8
  %dead.alias.next907 = add i64 %dead.alias.pc906, 32
  store i64 %dead.alias.next907, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_udec_wrap.op198.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_udec_wrap.op198.split.body

handler.volatile_atomic_rmw_udec_wrap.op198.split.body: ; preds = %handler.volatile_atomic_rmw_udec_wrap.op198.split.entry
  %dead.alias.pc908 = load i64, ptr %pc, align 8
  %dead.alias.next909 = add i64 %dead.alias.pc908, 32
  store i64 %dead.alias.next909, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmax.op165.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmax.op165.split.body

handler.atomic_rmw_fmax.op165.split.body:         ; preds = %handler.atomic_rmw_fmax.op165.split.entry
  %dead.alias.pc910 = load i64, ptr %pc, align 8
  %dead.alias.next911 = add i64 %dead.alias.pc910, 32
  store i64 %dead.alias.next911, ptr %pc, align 8
  br label %loop.check

handler.memset_dyn.op919.split.entry:             ; preds = %execute.decode
  br label %handler.memset_dyn.op919.split.body

handler.memset_dyn.op919.split.body:              ; preds = %handler.memset_dyn.op919.split.entry
  %dead.alias.pc912 = load i64, ptr %pc, align 8
  %dead.alias.next913 = add i64 %dead.alias.pc912, 8
  store i64 %dead.alias.next913, ptr %pc, align 8
  br label %loop.check

handler.ismul_overflow.op137.split.entry:         ; preds = %execute.decode
  br label %handler.ismul_overflow.op137.split.body

handler.ismul_overflow.op137.split.body:          ; preds = %handler.ismul_overflow.op137.split.entry
  %dead.alias.pc914 = load i64, ptr %pc, align 8
  %dead.alias.next915 = add i64 %dead.alias.pc914, 32
  store i64 %dead.alias.next915, ptr %pc, align 8
  br label %loop.check

handler.write_fpmode.op1cd.split.entry:           ; preds = %execute.decode
  br label %handler.write_fpmode.op1cd.split.body

handler.write_fpmode.op1cd.split.body:            ; preds = %handler.write_fpmode.op1cd.split.entry
  %dead.alias.pc916 = load i64, ptr %pc, align 8
  %dead.alias.next917 = add i64 %dead.alias.pc916, 8
  store i64 %dead.alias.next917, ptr %pc, align 8
  br label %loop.check

handler.alloca.op900.split.entry:                 ; preds = %execute.decode
  br label %handler.alloca.op900.split.body

handler.alloca.op900.split.body:                  ; preds = %handler.alloca.op900.split.entry
  %dead.alias.pc918 = load i64, ptr %pc, align 8
  %dead.alias.next919 = add i64 %dead.alias.pc918, 32
  store i64 %dead.alias.next919, ptr %pc, align 8
  br label %loop.check

handler.load_ior.op1d6.split.entry:               ; preds = %execute.decode
  br label %handler.load_ior.op1d6.split.body

handler.load_ior.op1d6.split.body:                ; preds = %handler.load_ior.op1d6.split.entry
  %dead.alias.pc920 = load i64, ptr %pc, align 8
  %dead.alias.next921 = add i64 %dead.alias.pc920, 32
  store i64 %dead.alias.next921, ptr %pc, align 8
  br label %loop.check

handler.br.op9ba.split.entry:                     ; preds = %execute.decode
  br label %handler.br.op9ba.split.body

handler.br.op9ba.split.body:                      ; preds = %handler.br.op9ba.split.entry
  %dead.alias.pc922 = load i64, ptr %pc, align 8
  %dead.alias.next923 = add i64 %dead.alias.pc922, 32
  store i64 %dead.alias.next923, ptr %pc, align 8
  br label %loop.check

handler.memcpy_dyn.op915.split.entry:             ; preds = %execute.decode
  br label %handler.memcpy_dyn.op915.split.body

handler.memcpy_dyn.op915.split.body:              ; preds = %handler.memcpy_dyn.op915.split.entry
  %dead.alias.pc924 = load i64, ptr %pc, align 8
  %dead.alias.next925 = add i64 %dead.alias.pc924, 8
  store i64 %dead.alias.next925, ptr %pc, align 8
  br label %loop.check

handler.memcpy_dyn.op143.split.entry:             ; preds = %execute.decode
  br label %handler.memcpy_dyn.op143.split.body

handler.memcpy_dyn.op143.split.body:              ; preds = %handler.memcpy_dyn.op143.split.entry
  %dead.alias.pc926 = load i64, ptr %pc, align 8
  %dead.alias.next927 = add i64 %dead.alias.pc926, 8
  store i64 %dead.alias.next927, ptr %pc, align 8
  br label %loop.check

handler.iuadd_overflow.op12e.split.entry:         ; preds = %execute.decode
  br label %handler.iuadd_overflow.op12e.split.body

handler.iuadd_overflow.op12e.split.body:          ; preds = %handler.iuadd_overflow.op12e.split.entry
  %dead.alias.pc928 = load i64, ptr %pc, align 8
  %dead.alias.next929 = add i64 %dead.alias.pc928, 32
  store i64 %dead.alias.next929, ptr %pc, align 8
  br label %loop.check

handler.fexp.op8ca.split.entry:                   ; preds = %execute.decode
  br label %handler.fexp.op8ca.split.body

handler.fexp.op8ca.split.body:                    ; preds = %handler.fexp.op8ca.split.entry
  %dead.alias.pc930 = load i64, ptr %pc, align 8
  %dead.alias.next931 = add i64 %dead.alias.pc930, 32
  store i64 %dead.alias.next931, ptr %pc, align 8
  br label %loop.check

handler.iashr.op18.split.entry:                   ; preds = %execute.decode
  br label %handler.iashr.op18.split.body

handler.iashr.op18.split.body:                    ; preds = %handler.iashr.op18.split.entry
  %dead.alias.pc932 = load i64, ptr %pc, align 8
  %dead.alias.next933 = add i64 %dead.alias.pc932, 32
  store i64 %dead.alias.next933, ptr %pc, align 8
  br label %loop.check

handler.icmp.op8f0.split.entry:                   ; preds = %execute.decode
  br label %handler.icmp.op8f0.split.body

handler.icmp.op8f0.split.body:                    ; preds = %handler.icmp.op8f0.split.entry
  %dead.alias.pc934 = load i64, ptr %pc, align 8
  %dead.alias.next935 = add i64 %dead.alias.pc934, 32
  store i64 %dead.alias.next935, ptr %pc, align 8
  br label %loop.check

handler.fminnum.op8a7.split.entry:                ; preds = %execute.decode
  br label %handler.fminnum.op8a7.split.body

handler.fminnum.op8a7.split.body:                 ; preds = %handler.fminnum.op8a7.split.entry
  %dead.alias.pc936 = load i64, ptr %pc, align 8
  %dead.alias.next937 = add i64 %dead.alias.pc936, 16
  store i64 %dead.alias.next937, ptr %pc, align 8
  br label %loop.check

handler.ptrmask.op859.split.entry:                ; preds = %execute.decode
  br label %handler.ptrmask.op859.split.body

handler.ptrmask.op859.split.body:                 ; preds = %handler.ptrmask.op859.split.entry
  %dead.alias.pc938 = load i64, ptr %pc, align 8
  %dead.alias.next939 = add i64 %dead.alias.pc938, 16
  store i64 %dead.alias.next939, ptr %pc, align 8
  br label %loop.check

handler.load_iand.op9ae.split.entry:              ; preds = %execute.decode
  br label %handler.load_iand.op9ae.split.body

handler.load_iand.op9ae.split.body:               ; preds = %handler.load_iand.op9ae.split.entry
  %dead.alias.pc940 = load i64, ptr %pc, align 8
  %dead.alias.next941 = add i64 %dead.alias.pc940, 32
  store i64 %dead.alias.next941, ptr %pc, align 8
  br label %loop.check

handler.load_ixor.op9b3.split.entry:              ; preds = %execute.decode
  br label %handler.load_ixor.op9b3.split.body

handler.load_ixor.op9b3.split.body:               ; preds = %handler.load_ixor.op9b3.split.entry
  %dead.alias.pc942 = load i64, ptr %pc, align 8
  %dead.alias.next943 = add i64 %dead.alias.pc942, 32
  store i64 %dead.alias.next943, ptr %pc, align 8
  br label %loop.check

handler.bitcast.op0d.split.entry:                 ; preds = %execute.decode
  br label %handler.bitcast.op0d.split.body

handler.bitcast.op0d.split.body:                  ; preds = %handler.bitcast.op0d.split.entry
  %dead.alias.pc944 = load i64, ptr %pc, align 8
  %dead.alias.next945 = add i64 %dead.alias.pc944, 32
  store i64 %dead.alias.next945, ptr %pc, align 8
  br label %loop.check

handler.load_iashr.op997.split.entry:             ; preds = %execute.decode
  br label %handler.load_iashr.op997.split.body

handler.load_iashr.op997.split.body:              ; preds = %handler.load_iashr.op997.split.entry
  %dead.alias.pc946 = load i64, ptr %pc, align 8
  %dead.alias.next947 = add i64 %dead.alias.pc946, 32
  store i64 %dead.alias.next947, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.opcd.split.entry:                 ; preds = %execute.decode
  br label %handler.fptrunc.opcd.split.body

handler.fptrunc.opcd.split.body:                  ; preds = %handler.fptrunc.opcd.split.entry
  %dead.alias.pc948 = load i64, ptr %pc, align 8
  %dead.alias.next949 = add i64 %dead.alias.pc948, 32
  store i64 %dead.alias.next949, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_sat.op96f.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_sat.op96f.split.body

handler.volatile_atomic_rmw_usub_sat.op96f.split.body: ; preds = %handler.volatile_atomic_rmw_usub_sat.op96f.split.entry
  %dead.alias.pc950 = load i64, ptr %pc, align 8
  %dead.alias.next951 = add i64 %dead.alias.pc950, 32
  store i64 %dead.alias.next951, ptr %pc, align 8
  br label %loop.check

handler.reset_fpmode.op1ce.split.entry:           ; preds = %execute.decode
  br label %handler.reset_fpmode.op1ce.split.body

handler.reset_fpmode.op1ce.split.body:            ; preds = %handler.reset_fpmode.op1ce.split.entry
  %dead.alias.pc952 = load i64, ptr %pc, align 8
  %dead.alias.next953 = add i64 %dead.alias.pc952, 4
  store i64 %dead.alias.next953, ptr %pc, align 8
  br label %loop.check

handler.imul.op844.split.entry:                   ; preds = %execute.decode
  br label %handler.imul.op844.split.body

handler.imul.op844.split.body:                    ; preds = %handler.imul.op844.split.entry
  %dead.alias.pc954 = load i64, ptr %pc, align 8
  %dead.alias.next955 = add i64 %dead.alias.pc954, 32
  store i64 %dead.alias.next955, ptr %pc, align 8
  br label %loop.check

handler.fpext.opd3.split.entry:                   ; preds = %execute.decode
  br label %handler.fpext.opd3.split.body

handler.fpext.opd3.split.body:                    ; preds = %handler.fpext.opd3.split.entry
  %dead.alias.pc956 = load i64, ptr %pc, align 8
  %dead.alias.next957 = add i64 %dead.alias.pc956, 32
  store i64 %dead.alias.next957, ptr %pc, align 8
  br label %loop.check

handler.imul.op79.split.entry:                    ; preds = %execute.decode
  br label %handler.imul.op79.split.body

handler.imul.op79.split.body:                     ; preds = %handler.imul.op79.split.entry
  %imul.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %imul.lhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %imul.rhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %imul.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr958 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %imul.lhs
  %lhs959 = load i64, ptr %reg.load.ptr958, align 8
  %reg.load.ptr960 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %imul.rhs
  %rhs961 = load i64, ptr %reg.load.ptr960, align 8
  %shift.masked962 = and i64 %rhs961, 63
  %bin.mul = mul i64 %lhs959, %rhs961
  %width.is64963 = icmp eq i64 %imul.width, 64
  %width.shift964 = and i64 %imul.width, 63
  %mask.shifted965 = shl i64 1, %width.shift964
  %mask.candidate966 = sub i64 %mask.shifted965, 1
  %width.mask967 = select i1 %width.is64963, i64 -1, i64 %mask.candidate966
  %width.masked968 = and i64 %bin.mul, %width.mask967
  %reg.store.ptr969 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %imul.dst
  store i64 %width.masked968, ptr %reg.store.ptr969, align 8
  %pc.old970 = load i64, ptr %pc, align 8
  %pc.next971 = add i64 %pc.old970, 32
  store i64 %pc.next971, ptr %pc, align 8
  br label %loop.check

handler.ffma.op8d3.split.entry:                   ; preds = %execute.decode
  br label %handler.ffma.op8d3.split.body

handler.ffma.op8d3.split.body:                    ; preds = %handler.ffma.op8d3.split.entry
  %dead.alias.pc972 = load i64, ptr %pc, align 8
  %dead.alias.next973 = add i64 %dead.alias.pc972, 48
  store i64 %dead.alias.next973, ptr %pc, align 8
  br label %loop.check

handler.global_addr.op80c.split.entry:            ; preds = %execute.decode
  br label %handler.global_addr.op80c.split.body

handler.global_addr.op80c.split.body:             ; preds = %handler.global_addr.op80c.split.entry
  %dead.alias.pc974 = load i64, ptr %pc, align 8
  %dead.alias.next975 = add i64 %dead.alias.pc974, 8
  store i64 %dead.alias.next975, ptr %pc, align 8
  br label %loop.check

handler.fmaxnum.op8a9.split.entry:                ; preds = %execute.decode
  br label %handler.fmaxnum.op8a9.split.body

handler.fmaxnum.op8a9.split.body:                 ; preds = %handler.fmaxnum.op8a9.split.entry
  %dead.alias.pc976 = load i64, ptr %pc, align 8
  %dead.alias.next977 = add i64 %dead.alias.pc976, 16
  store i64 %dead.alias.next977, ptr %pc, align 8
  br label %loop.check

handler.fshr.op109.split.entry:                   ; preds = %execute.decode
  br label %handler.fshr.op109.split.body

handler.fshr.op109.split.body:                    ; preds = %handler.fshr.op109.split.entry
  %dead.alias.pc978 = load i64, ptr %pc, align 8
  %dead.alias.next979 = add i64 %dead.alias.pc978, 48
  store i64 %dead.alias.next979, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fsub.op162.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fsub.op162.split.body

handler.atomic_rmw_fsub.op162.split.body:         ; preds = %handler.atomic_rmw_fsub.op162.split.entry
  %dead.alias.pc980 = load i64, ptr %pc, align 8
  %dead.alias.next981 = add i64 %dead.alias.pc980, 32
  store i64 %dead.alias.next981, ptr %pc, align 8
  br label %loop.check

handler.load_isrem.op992.split.entry:             ; preds = %execute.decode
  br label %handler.load_isrem.op992.split.body

handler.load_isrem.op992.split.body:              ; preds = %handler.load_isrem.op992.split.entry
  %dead.alias.pc982 = load i64, ptr %pc, align 8
  %dead.alias.next983 = add i64 %dead.alias.pc982, 32
  store i64 %dead.alias.next983, ptr %pc, align 8
  br label %loop.check

handler.isadd_sat.op125.split.entry:              ; preds = %execute.decode
  br label %handler.isadd_sat.op125.split.body

handler.isadd_sat.op125.split.body:               ; preds = %handler.isadd_sat.op125.split.entry
  %dead.alias.pc984 = load i64, ptr %pc, align 8
  %dead.alias.next985 = add i64 %dead.alias.pc984, 32
  store i64 %dead.alias.next985, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_max.op18e.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_max.op18e.split.body

handler.volatile_atomic_rmw_max.op18e.split.body: ; preds = %handler.volatile_atomic_rmw_max.op18e.split.entry
  %dead.alias.pc986 = load i64, ptr %pc, align 8
  %dead.alias.next987 = add i64 %dead.alias.pc986, 32
  store i64 %dead.alias.next987, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_sub.op185.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_sub.op185.split.body

handler.volatile_atomic_rmw_sub.op185.split.body: ; preds = %handler.volatile_atomic_rmw_sub.op185.split.entry
  %dead.alias.pc988 = load i64, ptr %pc, align 8
  %dead.alias.next989 = add i64 %dead.alias.pc988, 32
  store i64 %dead.alias.next989, ptr %pc, align 8
  br label %loop.check

handler.sideeffect.op1af.split.entry:             ; preds = %execute.decode
  br label %handler.sideeffect.op1af.split.body

handler.sideeffect.op1af.split.body:              ; preds = %handler.sideeffect.op1af.split.entry
  %dead.alias.pc990 = load i64, ptr %pc, align 8
  %dead.alias.next991 = add i64 %dead.alias.pc990, 4
  store i64 %dead.alias.next991, ptr %pc, align 8
  br label %loop.check

handler.atomic_store.op923.split.entry:           ; preds = %execute.decode
  br label %handler.atomic_store.op923.split.body

handler.atomic_store.op923.split.body:            ; preds = %handler.atomic_store.op923.split.entry
  %dead.alias.pc992 = load i64, ptr %pc, align 8
  %dead.alias.next993 = add i64 %dead.alias.pc992, 32
  store i64 %dead.alias.next993, ptr %pc, align 8
  br label %loop.check

handler.flog.op72c.split.entry:                   ; preds = %execute.decode
  br label %handler.flog.op72c.split.body

handler.flog.op72c.split.body:                    ; preds = %handler.flog.op72c.split.entry
  %dead.alias.pc994 = load i64, ptr %pc, align 8
  %dead.alias.next995 = add i64 %dead.alias.pc994, 32
  store i64 %dead.alias.next995, ptr %pc, align 8
  br label %loop.check

handler.read_cycle.op1ab.split.entry:             ; preds = %execute.decode
  br label %handler.read_cycle.op1ab.split.body

handler.read_cycle.op1ab.split.body:              ; preds = %handler.read_cycle.op1ab.split.entry
  %dead.alias.pc996 = load i64, ptr %pc, align 8
  %dead.alias.next997 = add i64 %dead.alias.pc996, 8
  store i64 %dead.alias.next997, ptr %pc, align 8
  br label %loop.check

handler.iuadd_overflow.op87b.split.entry:         ; preds = %execute.decode
  br label %handler.iuadd_overflow.op87b.split.body

handler.iuadd_overflow.op87b.split.body:          ; preds = %handler.iuadd_overflow.op87b.split.entry
  %dead.alias.pc998 = load i64, ptr %pc, align 8
  %dead.alias.next999 = add i64 %dead.alias.pc998, 32
  store i64 %dead.alias.next999, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fsub.op973.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fsub.op973.split.body

handler.volatile_atomic_rmw_fsub.op973.split.body: ; preds = %handler.volatile_atomic_rmw_fsub.op973.split.entry
  %dead.alias.pc1000 = load i64, ptr %pc, align 8
  %dead.alias.next1001 = add i64 %dead.alias.pc1000, 32
  store i64 %dead.alias.next1001, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op6a.split.entry:                   ; preds = %execute.decode
  br label %handler.ilshr.op6a.split.body

handler.ilshr.op6a.split.body:                    ; preds = %handler.ilshr.op6a.split.entry
  %dead.alias.pc1002 = load i64, ptr %pc, align 8
  %dead.alias.next1003 = add i64 %dead.alias.pc1002, 32
  store i64 %dead.alias.next1003, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_udec_wrap.op96c.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_udec_wrap.op96c.split.body

handler.volatile_atomic_rmw_udec_wrap.op96c.split.body: ; preds = %handler.volatile_atomic_rmw_udec_wrap.op96c.split.entry
  %dead.alias.pc1004 = load i64, ptr %pc, align 8
  %dead.alias.next1005 = add i64 %dead.alias.pc1004, 32
  store i64 %dead.alias.next1005, ptr %pc, align 8
  br label %loop.check

handler.cmpxchg.oped.split.entry:                 ; preds = %execute.decode
  br label %handler.cmpxchg.oped.split.body

handler.cmpxchg.oped.split.body:                  ; preds = %handler.cmpxchg.oped.split.entry
  %dead.alias.pc1006 = load i64, ptr %pc, align 8
  %dead.alias.next1007 = add i64 %dead.alias.pc1006, 32
  store i64 %dead.alias.next1007, ptr %pc, align 8
  br label %loop.check

handler.sitofp.opb7.split.entry:                  ; preds = %execute.decode
  br label %handler.sitofp.opb7.split.body

handler.sitofp.opb7.split.body:                   ; preds = %handler.sitofp.opb7.split.entry
  %dead.alias.pc1008 = load i64, ptr %pc, align 8
  %dead.alias.next1009 = add i64 %dead.alias.pc1008, 32
  store i64 %dead.alias.next1009, ptr %pc, align 8
  br label %loop.check

handler.tls_addr.op13c.split.entry:               ; preds = %execute.decode
  br label %handler.tls_addr.op13c.split.body

handler.tls_addr.op13c.split.body:                ; preds = %handler.tls_addr.op13c.split.entry
  %dead.alias.pc1010 = load i64, ptr %pc, align 8
  %dead.alias.next1011 = add i64 %dead.alias.pc1010, 8
  store i64 %dead.alias.next1011, ptr %pc, align 8
  br label %loop.check

handler.br_if.op3b.split.entry:                   ; preds = %execute.decode
  br label %handler.br_if.op3b.split.body

handler.br_if.op3b.split.body:                    ; preds = %handler.br_if.op3b.split.entry
  %dead.alias.pc1012 = load i64, ptr %pc, align 8
  %dead.alias.next1013 = add i64 %dead.alias.pc1012, 32
  store i64 %dead.alias.next1013, ptr %pc, align 8
  br label %loop.check

handler.ior.op68.split.entry:                     ; preds = %execute.decode
  br label %handler.ior.op68.split.body

handler.ior.op68.split.body:                      ; preds = %handler.ior.op68.split.entry
  %dead.alias.pc1014 = load i64, ptr %pc, align 8
  %dead.alias.next1015 = add i64 %dead.alias.pc1014, 32
  store i64 %dead.alias.next1015, ptr %pc, align 8
  br label %loop.check

handler.load_ismax.op999.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismax.op999.split.body

handler.load_ismax.op999.split.body:              ; preds = %handler.load_ismax.op999.split.entry
  %dead.alias.pc1016 = load i64, ptr %pc, align 8
  %dead.alias.next1017 = add i64 %dead.alias.pc1016, 32
  store i64 %dead.alias.next1017, ptr %pc, align 8
  br label %loop.check

handler.load_imul.op989.split.entry:              ; preds = %execute.decode
  br label %handler.load_imul.op989.split.body

handler.load_imul.op989.split.body:               ; preds = %handler.load_imul.op989.split.entry
  %dead.alias.pc1018 = load i64, ptr %pc, align 8
  %dead.alias.next1019 = add i64 %dead.alias.pc1018, 32
  store i64 %dead.alias.next1019, ptr %pc, align 8
  br label %loop.check

handler.sext.op4d.split.entry:                    ; preds = %execute.decode
  br label %handler.sext.op4d.split.body

handler.sext.op4d.split.body:                     ; preds = %handler.sext.op4d.split.entry
  %dead.alias.pc1020 = load i64, ptr %pc, align 8
  %dead.alias.next1021 = add i64 %dead.alias.pc1020, 32
  store i64 %dead.alias.next1021, ptr %pc, align 8
  br label %loop.check

handler.fnearbyint.op71e.split.entry:             ; preds = %execute.decode
  br label %handler.fnearbyint.op71e.split.body

handler.fnearbyint.op71e.split.body:              ; preds = %handler.fnearbyint.op71e.split.entry
  %dead.alias.pc1022 = load i64, ptr %pc, align 8
  %dead.alias.next1023 = add i64 %dead.alias.pc1022, 32
  store i64 %dead.alias.next1023, ptr %pc, align 8
  br label %loop.check

handler.cttz.op88c.split.entry:                   ; preds = %execute.decode
  br label %handler.cttz.op88c.split.body

handler.cttz.op88c.split.body:                    ; preds = %handler.cttz.op88c.split.entry
  %dead.alias.pc1024 = load i64, ptr %pc, align 8
  %dead.alias.next1025 = add i64 %dead.alias.pc1024, 32
  store i64 %dead.alias.next1025, ptr %pc, align 8
  br label %loop.check

handler.vm_call.op9bd.split.entry:                ; preds = %execute.decode
  br label %handler.vm_call.op9bd.split.body

handler.vm_call.op9bd.split.body:                 ; preds = %handler.vm_call.op9bd.split.entry
  %dead.alias.pc1026 = load i64, ptr %pc, align 8
  %dead.alias.next1027 = add i64 %dead.alias.pc1026, 32
  store i64 %dead.alias.next1027, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_sub.op958.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_sub.op958.split.body

handler.volatile_atomic_rmw_sub.op958.split.body: ; preds = %handler.volatile_atomic_rmw_sub.op958.split.entry
  %dead.alias.pc1028 = load i64, ptr %pc, align 8
  %dead.alias.next1029 = add i64 %dead.alias.pc1028, 32
  store i64 %dead.alias.next1029, ptr %pc, align 8
  br label %loop.check

handler.sitofp.opb8.split.entry:                  ; preds = %execute.decode
  br label %handler.sitofp.opb8.split.body

handler.sitofp.opb8.split.body:                   ; preds = %handler.sitofp.opb8.split.entry
  %dead.alias.pc1030 = load i64, ptr %pc, align 8
  %dead.alias.next1031 = add i64 %dead.alias.pc1030, 32
  store i64 %dead.alias.next1031, ptr %pc, align 8
  br label %loop.check

handler.icmp_br_if.op10e.split.entry:             ; preds = %execute.decode
  br label %handler.icmp_br_if.op10e.split.body

handler.icmp_br_if.op10e.split.body:              ; preds = %handler.icmp_br_if.op10e.split.entry
  %dead.alias.pc1032 = load i64, ptr %pc, align 8
  %dead.alias.next1033 = add i64 %dead.alias.pc1032, 32
  store i64 %dead.alias.next1033, ptr %pc, align 8
  br label %loop.check

handler.fexp2.op8cb.split.entry:                  ; preds = %execute.decode
  br label %handler.fexp2.op8cb.split.body

handler.fexp2.op8cb.split.body:                   ; preds = %handler.fexp2.op8cb.split.entry
  %dead.alias.pc1034 = load i64, ptr %pc, align 8
  %dead.alias.next1035 = add i64 %dead.alias.pc1034, 32
  store i64 %dead.alias.next1035, ptr %pc, align 8
  br label %loop.check

handler.tls_addr.op80a.split.entry:               ; preds = %execute.decode
  br label %handler.tls_addr.op80a.split.body

handler.tls_addr.op80a.split.body:                ; preds = %handler.tls_addr.op80a.split.entry
  %dead.alias.pc1036 = load i64, ptr %pc, align 8
  %dead.alias.next1037 = add i64 %dead.alias.pc1036, 8
  store i64 %dead.alias.next1037, ptr %pc, align 8
  br label %loop.check

handler.ixor.op852.split.entry:                   ; preds = %execute.decode
  br label %handler.ixor.op852.split.body

handler.ixor.op852.split.body:                    ; preds = %handler.ixor.op852.split.entry
  %dead.alias.pc1038 = load i64, ptr %pc, align 8
  %dead.alias.next1039 = add i64 %dead.alias.pc1038, 32
  store i64 %dead.alias.next1039, ptr %pc, align 8
  br label %loop.check

handler.imul.op842.split.entry:                   ; preds = %execute.decode
  br label %handler.imul.op842.split.body

handler.imul.op842.split.body:                    ; preds = %handler.imul.op842.split.entry
  %dead.alias.pc1040 = load i64, ptr %pc, align 8
  %dead.alias.next1041 = add i64 %dead.alias.pc1040, 32
  store i64 %dead.alias.next1041, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op6c.split.entry:                   ; preds = %execute.decode
  br label %handler.ilshr.op6c.split.body

handler.ilshr.op6c.split.body:                    ; preds = %handler.ilshr.op6c.split.entry
  %dead.alias.pc1042 = load i64, ptr %pc, align 8
  %dead.alias.next1043 = add i64 %dead.alias.pc1042, 32
  store i64 %dead.alias.next1043, ptr %pc, align 8
  br label %loop.check

handler.read_thread_pointer.op833.split.entry:    ; preds = %execute.decode
  br label %handler.read_thread_pointer.op833.split.body

handler.read_thread_pointer.op833.split.body:     ; preds = %handler.read_thread_pointer.op833.split.entry
  %dead.alias.pc1044 = load i64, ptr %pc, align 8
  %dead.alias.next1045 = add i64 %dead.alias.pc1044, 8
  store i64 %dead.alias.next1045, ptr %pc, align 8
  br label %loop.check

handler.fpclass.op701.split.entry:                ; preds = %execute.decode
  br label %handler.fpclass.op701.split.body

handler.fpclass.op701.split.body:                 ; preds = %handler.fpclass.op701.split.entry
  %dead.alias.pc1046 = load i64, ptr %pc, align 8
  %dead.alias.next1047 = add i64 %dead.alias.pc1046, 16
  store i64 %dead.alias.next1047, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmin.op1a5.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmin.op1a5.split.body

handler.volatile_atomic_rmw_fmin.op1a5.split.body: ; preds = %handler.volatile_atomic_rmw_fmin.op1a5.split.entry
  %dead.alias.pc1048 = load i64, ptr %pc, align 8
  %dead.alias.next1049 = add i64 %dead.alias.pc1048, 32
  store i64 %dead.alias.next1049, ptr %pc, align 8
  br label %loop.check

handler.iabs.op88d.split.entry:                   ; preds = %execute.decode
  br label %handler.iabs.op88d.split.body

handler.iabs.op88d.split.body:                    ; preds = %handler.iabs.op88d.split.entry
  %dead.alias.pc1050 = load i64, ptr %pc, align 8
  %dead.alias.next1051 = add i64 %dead.alias.pc1050, 32
  store i64 %dead.alias.next1051, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umax.opf7.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_umax.opf7.split.body

handler.atomic_rmw_umax.opf7.split.body:          ; preds = %handler.atomic_rmw_umax.opf7.split.entry
  %dead.alias.pc1052 = load i64, ptr %pc, align 8
  %dead.alias.next1053 = add i64 %dead.alias.pc1052, 32
  store i64 %dead.alias.next1053, ptr %pc, align 8
  br label %loop.check

handler.frint.op8be.split.entry:                  ; preds = %execute.decode
  br label %handler.frint.op8be.split.body

handler.frint.op8be.split.body:                   ; preds = %handler.frint.op8be.split.entry
  %dead.alias.pc1054 = load i64, ptr %pc, align 8
  %dead.alias.next1055 = add i64 %dead.alias.pc1054, 32
  store i64 %dead.alias.next1055, ptr %pc, align 8
  br label %loop.check

handler.volatile_cmpxchg.op980.split.entry:       ; preds = %execute.decode
  br label %handler.volatile_cmpxchg.op980.split.body

handler.volatile_cmpxchg.op980.split.body:        ; preds = %handler.volatile_cmpxchg.op980.split.entry
  %dead.alias.pc1056 = load i64, ptr %pc, align 8
  %dead.alias.next1057 = add i64 %dead.alias.pc1056, 32
  store i64 %dead.alias.next1057, ptr %pc, align 8
  br label %loop.check

handler.fexp2.op72b.split.entry:                  ; preds = %execute.decode
  br label %handler.fexp2.op72b.split.body

handler.fexp2.op72b.split.body:                   ; preds = %handler.fexp2.op72b.split.entry
  %dead.alias.pc1058 = load i64, ptr %pc, align 8
  %dead.alias.next1059 = add i64 %dead.alias.pc1058, 32
  store i64 %dead.alias.next1059, ptr %pc, align 8
  br label %loop.check

handler.sitofp.opba.split.entry:                  ; preds = %execute.decode
  br label %handler.sitofp.opba.split.body

handler.sitofp.opba.split.body:                   ; preds = %handler.sitofp.opba.split.entry
  %dead.alias.pc1060 = load i64, ptr %pc, align 8
  %dead.alias.next1061 = add i64 %dead.alias.pc1060, 32
  store i64 %dead.alias.next1061, ptr %pc, align 8
  br label %loop.check

handler.load_iashr.op998.split.entry:             ; preds = %execute.decode
  br label %handler.load_iashr.op998.split.body

handler.load_iashr.op998.split.body:              ; preds = %handler.load_iashr.op998.split.entry
  %dead.alias.pc1062 = load i64, ptr %pc, align 8
  %dead.alias.next1063 = add i64 %dead.alias.pc1062, 32
  store i64 %dead.alias.next1063, ptr %pc, align 8
  br label %loop.check

handler.fpclass.op700.split.entry:                ; preds = %execute.decode
  br label %handler.fpclass.op700.split.body

handler.fpclass.op700.split.body:                 ; preds = %handler.fpclass.op700.split.entry
  %dead.alias.pc1064 = load i64, ptr %pc, align 8
  %dead.alias.next1065 = add i64 %dead.alias.pc1064, 16
  store i64 %dead.alias.next1065, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op801.split.entry:                ; preds = %execute.decode
  br label %handler.mov_imm.op801.split.body

handler.mov_imm.op801.split.body:                 ; preds = %handler.mov_imm.op801.split.entry
  %mov_imm.dst1066 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.imm1067 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.width1068 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %width.is641069 = icmp eq i64 %mov_imm.width1068, 64
  %width.shift1070 = and i64 %mov_imm.width1068, 63
  %mask.shifted1071 = shl i64 1, %width.shift1070
  %mask.candidate1072 = sub i64 %mask.shifted1071, 1
  %width.mask1073 = select i1 %width.is641069, i64 -1, i64 %mask.candidate1072
  %width.masked1074 = and i64 %mov_imm.imm1067, %width.mask1073
  %reg.store.ptr1075 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov_imm.dst1066
  store i64 %width.masked1074, ptr %reg.store.ptr1075, align 8
  %pc.old1076 = load i64, ptr %pc, align 8
  %pc.next1077 = add i64 %pc.old1076, 32
  store i64 %pc.next1077, ptr %pc, align 8
  br label %loop.check

handler.load_iumin.op9a0.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumin.op9a0.split.body

handler.load_iumin.op9a0.split.body:              ; preds = %handler.load_iumin.op9a0.split.entry
  %dead.alias.pc1078 = load i64, ptr %pc, align 8
  %dead.alias.next1079 = add i64 %dead.alias.pc1078, 32
  store i64 %dead.alias.next1079, ptr %pc, align 8
  br label %loop.check

handler.mov.op808.split.entry:                    ; preds = %execute.decode
  br label %handler.mov.op808.split.body

handler.mov.op808.split.body:                     ; preds = %handler.mov.op808.split.entry
  %dead.alias.pc1080 = load i64, ptr %pc, align 8
  %dead.alias.next1081 = add i64 %dead.alias.pc1080, 8
  store i64 %dead.alias.next1081, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_udec_wrap.op16e.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_udec_wrap.op16e.split.body

handler.atomic_rmw_udec_wrap.op16e.split.body:    ; preds = %handler.atomic_rmw_udec_wrap.op16e.split.entry
  %dead.alias.pc1082 = load i64, ptr %pc, align 8
  %dead.alias.next1083 = add i64 %dead.alias.pc1082, 32
  store i64 %dead.alias.next1083, ptr %pc, align 8
  br label %loop.check

handler.isrem.op90.split.entry:                   ; preds = %execute.decode
  br label %handler.isrem.op90.split.body

handler.isrem.op90.split.body:                    ; preds = %handler.isrem.op90.split.entry
  %dead.alias.pc1084 = load i64, ptr %pc, align 8
  %dead.alias.next1085 = add i64 %dead.alias.pc1084, 32
  store i64 %dead.alias.next1085, ptr %pc, align 8
  br label %loop.check

handler.reset_fpmode.op831.split.entry:           ; preds = %execute.decode
  br label %handler.reset_fpmode.op831.split.body

handler.reset_fpmode.op831.split.body:            ; preds = %handler.reset_fpmode.op831.split.entry
  %dead.alias.pc1086 = load i64, ptr %pc, align 8
  %dead.alias.next1087 = add i64 %dead.alias.pc1086, 4
  store i64 %dead.alias.next1087, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_sat.op945.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_sat.op945.split.body

handler.atomic_rmw_usub_sat.op945.split.body:     ; preds = %handler.atomic_rmw_usub_sat.op945.split.entry
  %dead.alias.pc1088 = load i64, ptr %pc, align 8
  %dead.alias.next1089 = add i64 %dead.alias.pc1088, 32
  store i64 %dead.alias.next1089, ptr %pc, align 8
  br label %loop.check

handler.fabs.op8b2.split.entry:                   ; preds = %execute.decode
  br label %handler.fabs.op8b2.split.body

handler.fabs.op8b2.split.body:                    ; preds = %handler.fabs.op8b2.split.entry
  %dead.alias.pc1090 = load i64, ptr %pc, align 8
  %dead.alias.next1091 = add i64 %dead.alias.pc1090, 32
  store i64 %dead.alias.next1091, ptr %pc, align 8
  br label %loop.check

handler.volatile_load.op910.split.entry:          ; preds = %execute.decode
  br label %handler.volatile_load.op910.split.body

handler.volatile_load.op910.split.body:           ; preds = %handler.volatile_load.op910.split.entry
  %dead.alias.pc1092 = load i64, ptr %pc, align 8
  %dead.alias.next1093 = add i64 %dead.alias.pc1092, 16
  store i64 %dead.alias.next1093, ptr %pc, align 8
  br label %loop.check

handler.vm_ret.op19.split.entry:                  ; preds = %execute.decode
  br label %handler.vm_ret.op19.split.body

handler.vm_ret.op19.split.body:                   ; preds = %handler.vm_ret.op19.split.entry
  %dead.alias.pc1094 = load i64, ptr %pc, align 8
  %dead.alias.next1095 = add i64 %dead.alias.pc1094, 32
  store i64 %dead.alias.next1095, ptr %pc, align 8
  br label %loop.check

handler.fadd.op898.split.entry:                   ; preds = %execute.decode
  br label %handler.fadd.op898.split.body

handler.fadd.op898.split.body:                    ; preds = %handler.fadd.op898.split.entry
  %dead.alias.pc1096 = load i64, ptr %pc, align 8
  %dead.alias.next1097 = add i64 %dead.alias.pc1096, 32
  store i64 %dead.alias.next1097, ptr %pc, align 8
  br label %loop.check

handler.isrem.op84f.split.entry:                  ; preds = %execute.decode
  br label %handler.isrem.op84f.split.body

handler.isrem.op84f.split.body:                   ; preds = %handler.isrem.op84f.split.entry
  %dead.alias.pc1098 = load i64, ptr %pc, align 8
  %dead.alias.next1099 = add i64 %dead.alias.pc1098, 32
  store i64 %dead.alias.next1099, ptr %pc, align 8
  br label %loop.check

handler.fptosi.opc3.split.entry:                  ; preds = %execute.decode
  br label %handler.fptosi.opc3.split.body

handler.fptosi.opc3.split.body:                   ; preds = %handler.fptosi.opc3.split.entry
  %dead.alias.pc1100 = load i64, ptr %pc, align 8
  %dead.alias.next1101 = add i64 %dead.alias.pc1100, 32
  store i64 %dead.alias.next1101, ptr %pc, align 8
  br label %loop.check

handler.flog10.op8d0.split.entry:                 ; preds = %execute.decode
  br label %handler.flog10.op8d0.split.body

handler.flog10.op8d0.split.body:                  ; preds = %handler.flog10.op8d0.split.entry
  %dead.alias.pc1102 = load i64, ptr %pc, align 8
  %dead.alias.next1103 = add i64 %dead.alias.pc1102, 32
  store i64 %dead.alias.next1103, ptr %pc, align 8
  br label %loop.check

handler.fmul.opa1.split.entry:                    ; preds = %execute.decode
  br label %handler.fmul.opa1.split.body

handler.fmul.opa1.split.body:                     ; preds = %handler.fmul.opa1.split.entry
  %dead.alias.pc1104 = load i64, ptr %pc, align 8
  %dead.alias.next1105 = add i64 %dead.alias.pc1104, 32
  store i64 %dead.alias.next1105, ptr %pc, align 8
  br label %loop.check

handler.isub.op7e.split.entry:                    ; preds = %execute.decode
  br label %handler.isub.op7e.split.body

handler.isub.op7e.split.body:                     ; preds = %handler.isub.op7e.split.entry
  %dead.alias.pc1106 = load i64, ptr %pc, align 8
  %dead.alias.next1107 = add i64 %dead.alias.pc1106, 32
  store i64 %dead.alias.next1107, ptr %pc, align 8
  br label %loop.check

handler.iuadd_overflow.op12d.split.entry:         ; preds = %execute.decode
  br label %handler.iuadd_overflow.op12d.split.body

handler.iuadd_overflow.op12d.split.body:          ; preds = %handler.iuadd_overflow.op12d.split.entry
  %dead.alias.pc1108 = load i64, ptr %pc, align 8
  %dead.alias.next1109 = add i64 %dead.alias.pc1108, 32
  store i64 %dead.alias.next1109, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmax.op975.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmax.op975.split.body

handler.volatile_atomic_rmw_fmax.op975.split.body: ; preds = %handler.volatile_atomic_rmw_fmax.op975.split.entry
  %dead.alias.pc1110 = load i64, ptr %pc, align 8
  %dead.alias.next1111 = add i64 %dead.alias.pc1110, 32
  store i64 %dead.alias.next1111, ptr %pc, align 8
  br label %loop.check

handler.ftrunc.op8bc.split.entry:                 ; preds = %execute.decode
  br label %handler.ftrunc.op8bc.split.body

handler.ftrunc.op8bc.split.body:                  ; preds = %handler.ftrunc.op8bc.split.entry
  %dead.alias.pc1112 = load i64, ptr %pc, align 8
  %dead.alias.next1113 = add i64 %dead.alias.pc1112, 32
  store i64 %dead.alias.next1113, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmin.op978.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmin.op978.split.body

handler.volatile_atomic_rmw_fmin.op978.split.body: ; preds = %handler.volatile_atomic_rmw_fmin.op978.split.entry
  %dead.alias.pc1114 = load i64, ptr %pc, align 8
  %dead.alias.next1115 = add i64 %dead.alias.pc1114, 32
  store i64 %dead.alias.next1115, ptr %pc, align 8
  br label %loop.check

handler.iadd_xor.op83e.split.entry:               ; preds = %execute.decode
  br label %handler.iadd_xor.op83e.split.body

handler.iadd_xor.op83e.split.body:                ; preds = %handler.iadd_xor.op83e.split.entry
  %dead.alias.pc1116 = load i64, ptr %pc, align 8
  %dead.alias.next1117 = add i64 %dead.alias.pc1116, 48
  store i64 %dead.alias.next1117, ptr %pc, align 8
  br label %loop.check

handler.iadd.op10.split.entry:                    ; preds = %execute.decode
  br label %handler.iadd.op10.split.body

handler.iadd.op10.split.body:                     ; preds = %handler.iadd.op10.split.entry
  %iadd.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.lhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.rhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1118 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.lhs
  %lhs1119 = load i64, ptr %reg.load.ptr1118, align 8
  %reg.load.ptr1120 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.rhs
  %rhs1121 = load i64, ptr %reg.load.ptr1120, align 8
  %shift.masked1122 = and i64 %rhs1121, 63
  %bin.add = add i64 %lhs1119, %rhs1121
  %width.is641123 = icmp eq i64 %iadd.width, 64
  %width.shift1124 = and i64 %iadd.width, 63
  %mask.shifted1125 = shl i64 1, %width.shift1124
  %mask.candidate1126 = sub i64 %mask.shifted1125, 1
  %width.mask1127 = select i1 %width.is641123, i64 -1, i64 %mask.candidate1126
  %width.masked1128 = and i64 %bin.add, %width.mask1127
  %reg.store.ptr1129 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.dst
  store i64 %width.masked1128, ptr %reg.store.ptr1129, align 8
  %pc.old1130 = load i64, ptr %pc, align 8
  %pc.next1131 = add i64 %pc.old1130, 16
  store i64 %pc.next1131, ptr %pc, align 8
  br label %loop.check

handler.ior.op85b.split.entry:                    ; preds = %execute.decode
  br label %handler.ior.op85b.split.body

handler.ior.op85b.split.body:                     ; preds = %handler.ior.op85b.split.entry
  %dead.alias.pc1132 = load i64, ptr %pc, align 8
  %dead.alias.next1133 = add i64 %dead.alias.pc1132, 32
  store i64 %dead.alias.next1133, ptr %pc, align 8
  br label %loop.check

handler.ior.op69.split.entry:                     ; preds = %execute.decode
  br label %handler.ior.op69.split.body

handler.ior.op69.split.body:                      ; preds = %handler.ior.op69.split.entry
  %dead.alias.pc1134 = load i64, ptr %pc, align 8
  %dead.alias.next1135 = add i64 %dead.alias.pc1134, 32
  store i64 %dead.alias.next1135, ptr %pc, align 8
  br label %loop.check

handler.load_ishl.op1e3.split.entry:              ; preds = %execute.decode
  br label %handler.load_ishl.op1e3.split.body

handler.load_ishl.op1e3.split.body:               ; preds = %handler.load_ishl.op1e3.split.entry
  %dead.alias.pc1136 = load i64, ptr %pc, align 8
  %dead.alias.next1137 = add i64 %dead.alias.pc1136, 32
  store i64 %dead.alias.next1137, ptr %pc, align 8
  br label %loop.check

handler.call_native.op9b5.split.entry:            ; preds = %execute.decode
  br label %handler.call_native.op9b5.split.body

handler.call_native.op9b5.split.body:             ; preds = %handler.call_native.op9b5.split.entry
  %dead.alias.pc1138 = load i64, ptr %pc, align 8
  %dead.alias.next1139 = add i64 %dead.alias.pc1138, 64
  store i64 %dead.alias.next1139, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_min.op939.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_min.op939.split.body

handler.atomic_rmw_min.op939.split.body:          ; preds = %handler.atomic_rmw_min.op939.split.entry
  %dead.alias.pc1140 = load i64, ptr %pc, align 8
  %dead.alias.next1141 = add i64 %dead.alias.pc1140, 32
  store i64 %dead.alias.next1141, ptr %pc, align 8
  br label %loop.check

handler.prefetch.op200.split.entry:               ; preds = %execute.decode
  br label %handler.prefetch.op200.split.body

handler.prefetch.op200.split.body:                ; preds = %handler.prefetch.op200.split.entry
  %dead.alias.pc1142 = load i64, ptr %pc, align 8
  %dead.alias.next1143 = add i64 %dead.alias.pc1142, 16
  store i64 %dead.alias.next1143, ptr %pc, align 8
  br label %loop.check

handler.read_fpmode.op1cb.split.entry:            ; preds = %execute.decode
  br label %handler.read_fpmode.op1cb.split.body

handler.read_fpmode.op1cb.split.body:             ; preds = %handler.read_fpmode.op1cb.split.entry
  %dead.alias.pc1144 = load i64, ptr %pc, align 8
  %dead.alias.next1145 = add i64 %dead.alias.pc1144, 8
  store i64 %dead.alias.next1145, ptr %pc, align 8
  br label %loop.check

handler.fdiv.opa7.split.entry:                    ; preds = %execute.decode
  br label %handler.fdiv.opa7.split.body

handler.fdiv.opa7.split.body:                     ; preds = %handler.fdiv.opa7.split.entry
  %dead.alias.pc1146 = load i64, ptr %pc, align 8
  %dead.alias.next1147 = add i64 %dead.alias.pc1146, 32
  store i64 %dead.alias.next1147, ptr %pc, align 8
  br label %loop.check

handler.ftrunc.op8bb.split.entry:                 ; preds = %execute.decode
  br label %handler.ftrunc.op8bb.split.body

handler.ftrunc.op8bb.split.body:                  ; preds = %handler.ftrunc.op8bb.split.entry
  %dead.alias.pc1148 = load i64, ptr %pc, align 8
  %dead.alias.next1149 = add i64 %dead.alias.pc1148, 32
  store i64 %dead.alias.next1149, ptr %pc, align 8
  br label %loop.check

handler.flround.op73a.split.entry:                ; preds = %execute.decode
  br label %handler.flround.op73a.split.body

handler.flround.op73a.split.body:                 ; preds = %handler.flround.op73a.split.entry
  %dead.alias.pc1150 = load i64, ptr %pc, align 8
  %dead.alias.next1151 = add i64 %dead.alias.pc1150, 16
  store i64 %dead.alias.next1151, ptr %pc, align 8
  br label %loop.check

handler.write_rounding.op820.split.entry:         ; preds = %execute.decode
  br label %handler.write_rounding.op820.split.body

handler.write_rounding.op820.split.body:          ; preds = %handler.write_rounding.op820.split.entry
  %dead.alias.pc1152 = load i64, ptr %pc, align 8
  %dead.alias.next1153 = add i64 %dead.alias.pc1152, 8
  store i64 %dead.alias.next1153, ptr %pc, align 8
  br label %loop.check

handler.isub.op83f.split.entry:                   ; preds = %execute.decode
  br label %handler.isub.op83f.split.body

handler.isub.op83f.split.body:                    ; preds = %handler.isub.op83f.split.entry
  %dead.alias.pc1154 = load i64, ptr %pc, align 8
  %dead.alias.next1155 = add i64 %dead.alias.pc1154, 32
  store i64 %dead.alias.next1155, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op847.split.entry:                  ; preds = %execute.decode
  br label %handler.iudiv.op847.split.body

handler.iudiv.op847.split.body:                   ; preds = %handler.iudiv.op847.split.entry
  %dead.alias.pc1156 = load i64, ptr %pc, align 8
  %dead.alias.next1157 = add i64 %dead.alias.pc1156, 32
  store i64 %dead.alias.next1157, ptr %pc, align 8
  br label %loop.check

handler.vm_call.op70.split.entry:                 ; preds = %execute.decode
  br label %handler.vm_call.op70.split.body

handler.vm_call.op70.split.body:                  ; preds = %handler.vm_call.op70.split.entry
  %dead.alias.pc1158 = load i64, ptr %pc, align 8
  %dead.alias.next1159 = add i64 %dead.alias.pc1158, 32
  store i64 %dead.alias.next1159, ptr %pc, align 8
  br label %loop.check

handler.load_isrem.op1e1.split.entry:             ; preds = %execute.decode
  br label %handler.load_isrem.op1e1.split.body

handler.load_isrem.op1e1.split.body:              ; preds = %handler.load_isrem.op1e1.split.entry
  %dead.alias.pc1160 = load i64, ptr %pc, align 8
  %dead.alias.next1161 = add i64 %dead.alias.pc1160, 32
  store i64 %dead.alias.next1161, ptr %pc, align 8
  br label %loop.check

handler.stacksave.op1b1.split.entry:              ; preds = %execute.decode
  br label %handler.stacksave.op1b1.split.body

handler.stacksave.op1b1.split.body:               ; preds = %handler.stacksave.op1b1.split.entry
  %dead.alias.pc1162 = load i64, ptr %pc, align 8
  %dead.alias.next1163 = add i64 %dead.alias.pc1162, 8
  store i64 %dead.alias.next1163, ptr %pc, align 8
  br label %loop.check

handler.load_ismax.op1e8.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismax.op1e8.split.body

handler.load_ismax.op1e8.split.body:              ; preds = %handler.load_ismax.op1e8.split.entry
  %dead.alias.pc1164 = load i64, ptr %pc, align 8
  %dead.alias.next1165 = add i64 %dead.alias.pc1164, 32
  store i64 %dead.alias.next1165, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmax.op1a3.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmax.op1a3.split.body

handler.volatile_atomic_rmw_fmax.op1a3.split.body: ; preds = %handler.volatile_atomic_rmw_fmax.op1a3.split.entry
  %dead.alias.pc1166 = load i64, ptr %pc, align 8
  %dead.alias.next1167 = add i64 %dead.alias.pc1166, 32
  store i64 %dead.alias.next1167, ptr %pc, align 8
  br label %loop.check

handler.isadd_sat.op873.split.entry:              ; preds = %execute.decode
  br label %handler.isadd_sat.op873.split.body

handler.isadd_sat.op873.split.body:               ; preds = %handler.isadd_sat.op873.split.entry
  %dead.alias.pc1168 = load i64, ptr %pc, align 8
  %dead.alias.next1169 = add i64 %dead.alias.pc1168, 32
  store i64 %dead.alias.next1169, ptr %pc, align 8
  br label %loop.check

handler.iushl_sat.op878.split.entry:              ; preds = %execute.decode
  br label %handler.iushl_sat.op878.split.body

handler.iushl_sat.op878.split.body:               ; preds = %handler.iushl_sat.op878.split.entry
  %dead.alias.pc1170 = load i64, ptr %pc, align 8
  %dead.alias.next1171 = add i64 %dead.alias.pc1170, 32
  store i64 %dead.alias.next1171, ptr %pc, align 8
  br label %loop.check

handler.fptoui_sat.op8e1.split.entry:             ; preds = %execute.decode
  br label %handler.fptoui_sat.op8e1.split.body

handler.fptoui_sat.op8e1.split.body:              ; preds = %handler.fptoui_sat.op8e1.split.entry
  %dead.alias.pc1172 = load i64, ptr %pc, align 8
  %dead.alias.next1173 = add i64 %dead.alias.pc1172, 16
  store i64 %dead.alias.next1173, ptr %pc, align 8
  br label %loop.check

handler.uitofp.opbd.split.entry:                  ; preds = %execute.decode
  br label %handler.uitofp.opbd.split.body

handler.uitofp.opbd.split.body:                   ; preds = %handler.uitofp.opbd.split.entry
  %dead.alias.pc1174 = load i64, ptr %pc, align 8
  %dead.alias.next1175 = add i64 %dead.alias.pc1174, 32
  store i64 %dead.alias.next1175, ptr %pc, align 8
  br label %loop.check

handler.volatile_memcpy_dyn.op91b.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memcpy_dyn.op91b.split.body

handler.volatile_memcpy_dyn.op91b.split.body:     ; preds = %handler.volatile_memcpy_dyn.op91b.split.entry
  %dead.alias.pc1176 = load i64, ptr %pc, align 8
  %dead.alias.next1177 = add i64 %dead.alias.pc1176, 8
  store i64 %dead.alias.next1177, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umax.op193.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umax.op193.split.body

handler.volatile_atomic_rmw_umax.op193.split.body: ; preds = %handler.volatile_atomic_rmw_umax.op193.split.entry
  %dead.alias.pc1178 = load i64, ptr %pc, align 8
  %dead.alias.next1179 = add i64 %dead.alias.pc1178, 32
  store i64 %dead.alias.next1179, ptr %pc, align 8
  br label %loop.check

handler.fminnum.op8a8.split.entry:                ; preds = %execute.decode
  br label %handler.fminnum.op8a8.split.body

handler.fminnum.op8a8.split.body:                 ; preds = %handler.fminnum.op8a8.split.entry
  %dead.alias.pc1180 = load i64, ptr %pc, align 8
  %dead.alias.next1181 = add i64 %dead.alias.pc1180, 16
  store i64 %dead.alias.next1181, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umin.op967.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umin.op967.split.body

handler.volatile_atomic_rmw_umin.op967.split.body: ; preds = %handler.volatile_atomic_rmw_umin.op967.split.entry
  %dead.alias.pc1182 = load i64, ptr %pc, align 8
  %dead.alias.next1183 = add i64 %dead.alias.pc1182, 32
  store i64 %dead.alias.next1183, ptr %pc, align 8
  br label %loop.check

handler.tls_addr.op13b.split.entry:               ; preds = %execute.decode
  br label %handler.tls_addr.op13b.split.body

handler.tls_addr.op13b.split.body:                ; preds = %handler.tls_addr.op13b.split.entry
  %dead.alias.pc1184 = load i64, ptr %pc, align 8
  %dead.alias.next1185 = add i64 %dead.alias.pc1184, 8
  store i64 %dead.alias.next1185, ptr %pc, align 8
  br label %loop.check

handler.read_steady.op814.split.entry:            ; preds = %execute.decode
  br label %handler.read_steady.op814.split.body

handler.read_steady.op814.split.body:             ; preds = %handler.read_steady.op814.split.entry
  %dead.alias.pc1186 = load i64, ptr %pc, align 8
  %dead.alias.next1187 = add i64 %dead.alias.pc1186, 8
  store i64 %dead.alias.next1187, ptr %pc, align 8
  br label %loop.check

handler.load_isshl_sat.op1fb.split.entry:         ; preds = %execute.decode
  br label %handler.load_isshl_sat.op1fb.split.body

handler.load_isshl_sat.op1fb.split.body:          ; preds = %handler.load_isshl_sat.op1fb.split.entry
  %dead.alias.pc1188 = load i64, ptr %pc, align 8
  %dead.alias.next1189 = add i64 %dead.alias.pc1188, 32
  store i64 %dead.alias.next1189, ptr %pc, align 8
  br label %loop.check

handler.fpext.op8e5.split.entry:                  ; preds = %execute.decode
  br label %handler.fpext.op8e5.split.body

handler.fpext.op8e5.split.body:                   ; preds = %handler.fpext.op8e5.split.entry
  %dead.alias.pc1190 = load i64, ptr %pc, align 8
  %dead.alias.next1191 = add i64 %dead.alias.pc1190, 32
  store i64 %dead.alias.next1191, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_nand.opf1.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_nand.opf1.split.body

handler.atomic_rmw_nand.opf1.split.body:          ; preds = %handler.atomic_rmw_nand.opf1.split.entry
  %dead.alias.pc1192 = load i64, ptr %pc, align 8
  %dead.alias.next1193 = add i64 %dead.alias.pc1192, 32
  store i64 %dead.alias.next1193, ptr %pc, align 8
  br label %loop.check

handler.iashr.op865.split.entry:                  ; preds = %execute.decode
  br label %handler.iashr.op865.split.body

handler.iashr.op865.split.body:                   ; preds = %handler.iashr.op865.split.entry
  %dead.alias.pc1194 = load i64, ptr %pc, align 8
  %dead.alias.next1195 = add i64 %dead.alias.pc1194, 32
  store i64 %dead.alias.next1195, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmin.op166.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmin.op166.split.body

handler.atomic_rmw_fmin.op166.split.body:         ; preds = %handler.atomic_rmw_fmin.op166.split.entry
  %dead.alias.pc1196 = load i64, ptr %pc, align 8
  %dead.alias.next1197 = add i64 %dead.alias.pc1196, 32
  store i64 %dead.alias.next1197, ptr %pc, align 8
  br label %loop.check

handler.iand.op854.split.entry:                   ; preds = %execute.decode
  br label %handler.iand.op854.split.body

handler.iand.op854.split.body:                    ; preds = %handler.iand.op854.split.entry
  %dead.alias.pc1198 = load i64, ptr %pc, align 8
  %dead.alias.next1199 = add i64 %dead.alias.pc1198, 32
  store i64 %dead.alias.next1199, ptr %pc, align 8
  br label %loop.check

handler.fshr.op895.split.entry:                   ; preds = %execute.decode
  br label %handler.fshr.op895.split.body

handler.fshr.op895.split.body:                    ; preds = %handler.fshr.op895.split.entry
  %dead.alias.pc1200 = load i64, ptr %pc, align 8
  %dead.alias.next1201 = add i64 %dead.alias.pc1200, 48
  store i64 %dead.alias.next1201, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umax.op93c.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_umax.op93c.split.body

handler.atomic_rmw_umax.op93c.split.body:         ; preds = %handler.atomic_rmw_umax.op93c.split.entry
  %dead.alias.pc1202 = load i64, ptr %pc, align 8
  %dead.alias.next1203 = add i64 %dead.alias.pc1202, 32
  store i64 %dead.alias.next1203, ptr %pc, align 8
  br label %loop.check

handler.tls_addr.op80b.split.entry:               ; preds = %execute.decode
  br label %handler.tls_addr.op80b.split.body

handler.tls_addr.op80b.split.body:                ; preds = %handler.tls_addr.op80b.split.entry
  %dead.alias.pc1204 = load i64, ptr %pc, align 8
  %dead.alias.next1205 = add i64 %dead.alias.pc1204, 8
  store i64 %dead.alias.next1205, ptr %pc, align 8
  br label %loop.check

handler.fmaxnum.op8aa.split.entry:                ; preds = %execute.decode
  br label %handler.fmaxnum.op8aa.split.body

handler.fmaxnum.op8aa.split.body:                 ; preds = %handler.fmaxnum.op8aa.split.entry
  %dead.alias.pc1206 = load i64, ptr %pc, align 8
  %dead.alias.next1207 = add i64 %dead.alias.pc1206, 16
  store i64 %dead.alias.next1207, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_sat.op173.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_sat.op173.split.body

handler.atomic_rmw_usub_sat.op173.split.body:     ; preds = %handler.atomic_rmw_usub_sat.op173.split.entry
  %dead.alias.pc1208 = load i64, ptr %pc, align 8
  %dead.alias.next1209 = add i64 %dead.alias.pc1208, 32
  store i64 %dead.alias.next1209, ptr %pc, align 8
  br label %loop.check

handler.stacksave.op1b0.split.entry:              ; preds = %execute.decode
  br label %handler.stacksave.op1b0.split.body

handler.stacksave.op1b0.split.body:               ; preds = %handler.stacksave.op1b0.split.entry
  %dead.alias.pc1210 = load i64, ptr %pc, align 8
  %dead.alias.next1211 = add i64 %dead.alias.pc1210, 8
  store i64 %dead.alias.next1211, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_min.opf4.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_min.opf4.split.body

handler.atomic_rmw_min.opf4.split.body:           ; preds = %handler.atomic_rmw_min.opf4.split.entry
  %dead.alias.pc1212 = load i64, ptr %pc, align 8
  %dead.alias.next1213 = add i64 %dead.alias.pc1212, 32
  store i64 %dead.alias.next1213, ptr %pc, align 8
  br label %loop.check

handler.fcopysign.op705.split.entry:              ; preds = %execute.decode
  br label %handler.fcopysign.op705.split.body

handler.fcopysign.op705.split.body:               ; preds = %handler.fcopysign.op705.split.entry
  %dead.alias.pc1214 = load i64, ptr %pc, align 8
  %dead.alias.next1215 = add i64 %dead.alias.pc1214, 32
  store i64 %dead.alias.next1215, ptr %pc, align 8
  br label %loop.check

handler.read_fpmode.op1ca.split.entry:            ; preds = %execute.decode
  br label %handler.read_fpmode.op1ca.split.body

handler.read_fpmode.op1ca.split.body:             ; preds = %handler.read_fpmode.op1ca.split.entry
  %dead.alias.pc1216 = load i64, ptr %pc, align 8
  %dead.alias.next1217 = add i64 %dead.alias.pc1216, 8
  store i64 %dead.alias.next1217, ptr %pc, align 8
  br label %loop.check

handler.imul.op28.split.entry:                    ; preds = %execute.decode
  br label %handler.imul.op28.split.body

handler.imul.op28.split.body:                     ; preds = %handler.imul.op28.split.entry
  %dead.alias.pc1218 = load i64, ptr %pc, align 8
  %dead.alias.next1219 = add i64 %dead.alias.pc1218, 32
  store i64 %dead.alias.next1219, ptr %pc, align 8
  br label %loop.check

handler.iand.op855.split.entry:                   ; preds = %execute.decode
  br label %handler.iand.op855.split.body

handler.iand.op855.split.body:                    ; preds = %handler.iand.op855.split.entry
  %dead.alias.pc1220 = load i64, ptr %pc, align 8
  %dead.alias.next1221 = add i64 %dead.alias.pc1220, 32
  store i64 %dead.alias.next1221, ptr %pc, align 8
  br label %loop.check

handler.unreachable.op9c1.split.entry:            ; preds = %execute.decode
  br label %handler.unreachable.op9c1.split.body

handler.unreachable.op9c1.split.body:             ; preds = %handler.unreachable.op9c1.split.entry
  %dead.alias.pc1222 = load i64, ptr %pc, align 8
  %dead.alias.next1223 = add i64 %dead.alias.pc1222, 4
  store i64 %dead.alias.next1223, ptr %pc, align 8
  br label %loop.check

handler.volatile_memmove_dyn.op91d.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_memmove_dyn.op91d.split.body

handler.volatile_memmove_dyn.op91d.split.body:    ; preds = %handler.volatile_memmove_dyn.op91d.split.entry
  %dead.alias.pc1224 = load i64, ptr %pc, align 8
  %dead.alias.next1225 = add i64 %dead.alias.pc1224, 8
  store i64 %dead.alias.next1225, ptr %pc, align 8
  br label %loop.check

handler.fsin.op8c6.split.entry:                   ; preds = %execute.decode
  br label %handler.fsin.op8c6.split.body

handler.fsin.op8c6.split.body:                    ; preds = %handler.fsin.op8c6.split.entry
  %dead.alias.pc1226 = load i64, ptr %pc, align 8
  %dead.alias.next1227 = add i64 %dead.alias.pc1226, 32
  store i64 %dead.alias.next1227, ptr %pc, align 8
  br label %loop.check

handler.fake_nop.op48.split.entry:                ; preds = %execute.decode
  br label %handler.fake_nop.op48.split.body

handler.fake_nop.op48.split.body:                 ; preds = %handler.fake_nop.op48.split.entry
  %pc.old1228 = load i64, ptr %pc, align 8
  %pc.next1229 = add i64 %pc.old1228, 4
  store i64 %pc.next1229, ptr %pc, align 8
  br label %loop.check

handler.iumul_overflow.op135.split.entry:         ; preds = %execute.decode
  br label %handler.iumul_overflow.op135.split.body

handler.iumul_overflow.op135.split.body:          ; preds = %handler.iumul_overflow.op135.split.entry
  %dead.alias.pc1230 = load i64, ptr %pc, align 8
  %dead.alias.next1231 = add i64 %dead.alias.pc1230, 32
  store i64 %dead.alias.next1231, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umax.opf6.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_umax.opf6.split.body

handler.atomic_rmw_umax.opf6.split.body:          ; preds = %handler.atomic_rmw_umax.opf6.split.entry
  %dead.alias.pc1232 = load i64, ptr %pc, align 8
  %dead.alias.next1233 = add i64 %dead.alias.pc1232, 32
  store i64 %dead.alias.next1233, ptr %pc, align 8
  br label %loop.check

handler.bitreverse.op892.split.entry:             ; preds = %execute.decode
  br label %handler.bitreverse.op892.split.body

handler.bitreverse.op892.split.body:              ; preds = %handler.bitreverse.op892.split.entry
  %dead.alias.pc1234 = load i64, ptr %pc, align 8
  %dead.alias.next1235 = add i64 %dead.alias.pc1234, 32
  store i64 %dead.alias.next1235, ptr %pc, align 8
  br label %loop.check

handler.read_fpenv.op1c5.split.entry:             ; preds = %execute.decode
  br label %handler.read_fpenv.op1c5.split.body

handler.read_fpenv.op1c5.split.body:              ; preds = %handler.read_fpenv.op1c5.split.entry
  %dead.alias.pc1236 = load i64, ptr %pc, align 8
  %dead.alias.next1237 = add i64 %dead.alias.pc1236, 8
  store i64 %dead.alias.next1237, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmaximum.op979.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmaximum.op979.split.body

handler.volatile_atomic_rmw_fmaximum.op979.split.body: ; preds = %handler.volatile_atomic_rmw_fmaximum.op979.split.entry
  %dead.alias.pc1238 = load i64, ptr %pc, align 8
  %dead.alias.next1239 = add i64 %dead.alias.pc1238, 32
  store i64 %dead.alias.next1239, ptr %pc, align 8
  br label %loop.check

handler.iumin.op120.split.entry:                  ; preds = %execute.decode
  br label %handler.iumin.op120.split.body

handler.iumin.op120.split.body:                   ; preds = %handler.iumin.op120.split.entry
  %dead.alias.pc1240 = load i64, ptr %pc, align 8
  %dead.alias.next1241 = add i64 %dead.alias.pc1240, 32
  store i64 %dead.alias.next1241, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op860.split.entry:                  ; preds = %execute.decode
  br label %handler.ilshr.op860.split.body

handler.ilshr.op860.split.body:                   ; preds = %handler.ilshr.op860.split.entry
  %dead.alias.pc1242 = load i64, ptr %pc, align 8
  %dead.alias.next1243 = add i64 %dead.alias.pc1242, 32
  store i64 %dead.alias.next1243, ptr %pc, align 8
  br label %loop.check

handler.fminimum.op70e.split.entry:               ; preds = %execute.decode
  br label %handler.fminimum.op70e.split.body

handler.fminimum.op70e.split.body:                ; preds = %handler.fminimum.op70e.split.entry
  %dead.alias.pc1244 = load i64, ptr %pc, align 8
  %dead.alias.next1245 = add i64 %dead.alias.pc1244, 16
  store i64 %dead.alias.next1245, ptr %pc, align 8
  br label %loop.check

handler.imul.op4a.split.entry:                    ; preds = %execute.decode
  br label %handler.imul.op4a.split.body

handler.imul.op4a.split.body:                     ; preds = %handler.imul.op4a.split.entry
  %dead.alias.pc1246 = load i64, ptr %pc, align 8
  %dead.alias.next1247 = add i64 %dead.alias.pc1246, 32
  store i64 %dead.alias.next1247, ptr %pc, align 8
  br label %loop.check

handler.ret.op9c6.split.entry:                    ; preds = %execute.decode
  br label %handler.ret.op9c6.split.body

handler.ret.op9c6.split.body:                     ; preds = %handler.ret.op9c6.split.entry
  %ret.src1248 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1249 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ret.src1248
  %ret.value1250 = load i64, ptr %reg.load.ptr1249, align 8
  %reg.store.ptr1251 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  store i64 %ret.value1250, ptr %reg.store.ptr1251, align 8
  br label %default.return

handler.fpow.op732.split.entry:                   ; preds = %execute.decode
  br label %handler.fpow.op732.split.body

handler.fpow.op732.split.body:                    ; preds = %handler.fpow.op732.split.entry
  %dead.alias.pc1252 = load i64, ptr %pc, align 8
  %dead.alias.next1253 = add i64 %dead.alias.pc1252, 16
  store i64 %dead.alias.next1253, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_udec_wrap.op941.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_udec_wrap.op941.split.body

handler.atomic_rmw_udec_wrap.op941.split.body:    ; preds = %handler.atomic_rmw_udec_wrap.op941.split.entry
  %dead.alias.pc1254 = load i64, ptr %pc, align 8
  %dead.alias.next1255 = add i64 %dead.alias.pc1254, 32
  store i64 %dead.alias.next1255, ptr %pc, align 8
  br label %loop.check

handler.fcos.op8c8.split.entry:                   ; preds = %execute.decode
  br label %handler.fcos.op8c8.split.body

handler.fcos.op8c8.split.body:                    ; preds = %handler.fcos.op8c8.split.entry
  %dead.alias.pc1256 = load i64, ptr %pc, align 8
  %dead.alias.next1257 = add i64 %dead.alias.pc1256, 32
  store i64 %dead.alias.next1257, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fsub.op1a0.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fsub.op1a0.split.body

handler.volatile_atomic_rmw_fsub.op1a0.split.body: ; preds = %handler.volatile_atomic_rmw_fsub.op1a0.split.entry
  %dead.alias.pc1258 = load i64, ptr %pc, align 8
  %dead.alias.next1259 = add i64 %dead.alias.pc1258, 32
  store i64 %dead.alias.next1259, ptr %pc, align 8
  br label %loop.check

handler.fcmp.opae.split.entry:                    ; preds = %execute.decode
  br label %handler.fcmp.opae.split.body

handler.fcmp.opae.split.body:                     ; preds = %handler.fcmp.opae.split.entry
  %dead.alias.pc1260 = load i64, ptr %pc, align 8
  %dead.alias.next1261 = add i64 %dead.alias.pc1260, 32
  store i64 %dead.alias.next1261, ptr %pc, align 8
  br label %loop.check

handler.ismul_overflow.op885.split.entry:         ; preds = %execute.decode
  br label %handler.ismul_overflow.op885.split.body

handler.ismul_overflow.op885.split.body:          ; preds = %handler.ismul_overflow.op885.split.entry
  %dead.alias.pc1262 = load i64, ptr %pc, align 8
  %dead.alias.next1263 = add i64 %dead.alias.pc1262, 32
  store i64 %dead.alias.next1263, ptr %pc, align 8
  br label %loop.check

handler.load_iurem.op990.split.entry:             ; preds = %execute.decode
  br label %handler.load_iurem.op990.split.body

handler.load_iurem.op990.split.body:              ; preds = %handler.load_iurem.op990.split.entry
  %dead.alias.pc1264 = load i64, ptr %pc, align 8
  %dead.alias.next1265 = add i64 %dead.alias.pc1264, 32
  store i64 %dead.alias.next1265, ptr %pc, align 8
  br label %loop.check

handler.iashr.op864.split.entry:                  ; preds = %execute.decode
  br label %handler.iashr.op864.split.body

handler.iashr.op864.split.body:                   ; preds = %handler.iashr.op864.split.entry
  %dead.alias.pc1266 = load i64, ptr %pc, align 8
  %dead.alias.next1267 = add i64 %dead.alias.pc1266, 32
  store i64 %dead.alias.next1267, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_sat.op19c.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_sat.op19c.split.body

handler.volatile_atomic_rmw_usub_sat.op19c.split.body: ; preds = %handler.volatile_atomic_rmw_usub_sat.op19c.split.entry
  %dead.alias.pc1268 = load i64, ptr %pc, align 8
  %dead.alias.next1269 = add i64 %dead.alias.pc1268, 32
  store i64 %dead.alias.next1269, ptr %pc, align 8
  br label %loop.check

handler.read_thread_pointer.op1c1.split.entry:    ; preds = %execute.decode
  br label %handler.read_thread_pointer.op1c1.split.body

handler.read_thread_pointer.op1c1.split.body:     ; preds = %handler.read_thread_pointer.op1c1.split.entry
  %dead.alias.pc1270 = load i64, ptr %pc, align 8
  %dead.alias.next1271 = add i64 %dead.alias.pc1270, 8
  store i64 %dead.alias.next1271, ptr %pc, align 8
  br label %loop.check

handler.volatile_store.op14a.split.entry:         ; preds = %execute.decode
  br label %handler.volatile_store.op14a.split.body

handler.volatile_store.op14a.split.body:          ; preds = %handler.volatile_store.op14a.split.entry
  %dead.alias.pc1272 = load i64, ptr %pc, align 8
  %dead.alias.next1273 = add i64 %dead.alias.pc1272, 16
  store i64 %dead.alias.next1273, ptr %pc, align 8
  br label %loop.check

handler.vm_call.op6e.split.entry:                 ; preds = %execute.decode
  br label %handler.vm_call.op6e.split.body

handler.vm_call.op6e.split.body:                  ; preds = %handler.vm_call.op6e.split.entry
  %dead.alias.pc1274 = load i64, ptr %pc, align 8
  %dead.alias.next1275 = add i64 %dead.alias.pc1274, 32
  store i64 %dead.alias.next1275, ptr %pc, align 8
  br label %loop.check

handler.trap.opdf.split.entry:                    ; preds = %execute.decode
  br label %handler.trap.opdf.split.body

handler.trap.opdf.split.body:                     ; preds = %handler.trap.opdf.split.entry
  %dead.alias.pc1276 = load i64, ptr %pc, align 8
  %dead.alias.next1277 = add i64 %dead.alias.pc1276, 4
  store i64 %dead.alias.next1277, ptr %pc, align 8
  br label %loop.check

handler.flrint.op736.split.entry:                 ; preds = %execute.decode
  br label %handler.flrint.op736.split.body

handler.flrint.op736.split.body:                  ; preds = %handler.flrint.op736.split.entry
  %dead.alias.pc1278 = load i64, ptr %pc, align 8
  %dead.alias.next1279 = add i64 %dead.alias.pc1278, 16
  store i64 %dead.alias.next1279, ptr %pc, align 8
  br label %loop.check

handler.fnearbyint.op8c0.split.entry:             ; preds = %execute.decode
  br label %handler.fnearbyint.op8c0.split.body

handler.fnearbyint.op8c0.split.body:              ; preds = %handler.fnearbyint.op8c0.split.entry
  %dead.alias.pc1280 = load i64, ptr %pc, align 8
  %dead.alias.next1281 = add i64 %dead.alias.pc1280, 32
  store i64 %dead.alias.next1281, ptr %pc, align 8
  br label %loop.check

handler.iashr.op50.split.entry:                   ; preds = %execute.decode
  br label %handler.iashr.op50.split.body

handler.iashr.op50.split.body:                    ; preds = %handler.iashr.op50.split.entry
  %dead.alias.pc1282 = load i64, ptr %pc, align 8
  %dead.alias.next1283 = add i64 %dead.alias.pc1282, 32
  store i64 %dead.alias.next1283, ptr %pc, align 8
  br label %loop.check

handler.sext.op31.split.entry:                    ; preds = %execute.decode
  br label %handler.sext.op31.split.body

handler.sext.op31.split.body:                     ; preds = %handler.sext.op31.split.entry
  %dead.alias.pc1284 = load i64, ptr %pc, align 8
  %dead.alias.next1285 = add i64 %dead.alias.pc1284, 32
  store i64 %dead.alias.next1285, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umin.op93e.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_umin.op93e.split.body

handler.atomic_rmw_umin.op93e.split.body:         ; preds = %handler.atomic_rmw_umin.op93e.split.entry
  %dead.alias.pc1286 = load i64, ptr %pc, align 8
  %dead.alias.next1287 = add i64 %dead.alias.pc1286, 32
  store i64 %dead.alias.next1287, ptr %pc, align 8
  br label %loop.check

handler.load.op90e.split.entry:                   ; preds = %execute.decode
  br label %handler.load.op90e.split.body

handler.load.op90e.split.body:                    ; preds = %handler.load.op90e.split.entry
  %dead.alias.pc1288 = load i64, ptr %pc, align 8
  %dead.alias.next1289 = add i64 %dead.alias.pc1288, 32
  store i64 %dead.alias.next1289, ptr %pc, align 8
  br label %loop.check

handler.iumax.op11e.split.entry:                  ; preds = %execute.decode
  br label %handler.iumax.op11e.split.body

handler.iumax.op11e.split.body:                   ; preds = %handler.iumax.op11e.split.entry
  %dead.alias.pc1290 = load i64, ptr %pc, align 8
  %dead.alias.next1291 = add i64 %dead.alias.pc1290, 32
  store i64 %dead.alias.next1291, ptr %pc, align 8
  br label %loop.check

handler.load_iumax.op99d.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumax.op99d.split.body

handler.load_iumax.op99d.split.body:              ; preds = %handler.load_iumax.op99d.split.entry
  %dead.alias.pc1292 = load i64, ptr %pc, align 8
  %dead.alias.next1293 = add i64 %dead.alias.pc1292, 32
  store i64 %dead.alias.next1293, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_load.op175.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_atomic_load.op175.split.body

handler.volatile_atomic_load.op175.split.body:    ; preds = %handler.volatile_atomic_load.op175.split.entry
  %dead.alias.pc1294 = load i64, ptr %pc, align 8
  %dead.alias.next1295 = add i64 %dead.alias.pc1294, 32
  store i64 %dead.alias.next1295, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_uinc_wrap.op969.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_uinc_wrap.op969.split.body

handler.volatile_atomic_rmw_uinc_wrap.op969.split.body: ; preds = %handler.volatile_atomic_rmw_uinc_wrap.op969.split.entry
  %dead.alias.pc1296 = load i64, ptr %pc, align 8
  %dead.alias.next1297 = add i64 %dead.alias.pc1296, 32
  store i64 %dead.alias.next1297, ptr %pc, align 8
  br label %loop.check

handler.fpclass.op8f5.split.entry:                ; preds = %execute.decode
  br label %handler.fpclass.op8f5.split.body

handler.fpclass.op8f5.split.body:                 ; preds = %handler.fpclass.op8f5.split.entry
  %dead.alias.pc1298 = load i64, ptr %pc, align 8
  %dead.alias.next1299 = add i64 %dead.alias.pc1298, 16
  store i64 %dead.alias.next1299, ptr %pc, align 8
  br label %loop.check

handler.iashr.op25.split.entry:                   ; preds = %execute.decode
  br label %handler.iashr.op25.split.body

handler.iashr.op25.split.body:                    ; preds = %handler.iashr.op25.split.entry
  %dead.alias.pc1300 = load i64, ptr %pc, align 8
  %dead.alias.next1301 = add i64 %dead.alias.pc1300, 32
  store i64 %dead.alias.next1301, ptr %pc, align 8
  br label %loop.check

handler.fdiv.op89e.split.entry:                   ; preds = %execute.decode
  br label %handler.fdiv.op89e.split.body

handler.fdiv.op89e.split.body:                    ; preds = %handler.fdiv.op89e.split.entry
  %dead.alias.pc1302 = load i64, ptr %pc, align 8
  %dead.alias.next1303 = add i64 %dead.alias.pc1302, 32
  store i64 %dead.alias.next1303, ptr %pc, align 8
  br label %loop.check

handler.bitreverse.op891.split.entry:             ; preds = %execute.decode
  br label %handler.bitreverse.op891.split.body

handler.bitreverse.op891.split.body:              ; preds = %handler.bitreverse.op891.split.entry
  %dead.alias.pc1304 = load i64, ptr %pc, align 8
  %dead.alias.next1305 = add i64 %dead.alias.pc1304, 32
  store i64 %dead.alias.next1305, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_cond.op171.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_cond.op171.split.body

handler.atomic_rmw_usub_cond.op171.split.body:    ; preds = %handler.atomic_rmw_usub_cond.op171.split.entry
  %dead.alias.pc1306 = load i64, ptr %pc, align 8
  %dead.alias.next1307 = add i64 %dead.alias.pc1306, 32
  store i64 %dead.alias.next1307, ptr %pc, align 8
  br label %loop.check

handler.ret.op1a.split.entry:                     ; preds = %execute.decode
  br label %handler.ret.op1a.split.body

handler.ret.op1a.split.body:                      ; preds = %handler.ret.op1a.split.entry
  %dead.alias.pc1308 = load i64, ptr %pc, align 8
  %dead.alias.next1309 = add i64 %dead.alias.pc1308, 4
  store i64 %dead.alias.next1309, ptr %pc, align 8
  br label %loop.check

handler.sitofp.op8d8.split.entry:                 ; preds = %execute.decode
  br label %handler.sitofp.op8d8.split.body

handler.sitofp.op8d8.split.body:                  ; preds = %handler.sitofp.op8d8.split.entry
  %dead.alias.pc1310 = load i64, ptr %pc, align 8
  %dead.alias.next1311 = add i64 %dead.alias.pc1310, 32
  store i64 %dead.alias.next1311, ptr %pc, align 8
  br label %loop.check

handler.load_iand.op1d4.split.entry:              ; preds = %execute.decode
  br label %handler.load_iand.op1d4.split.body

handler.load_iand.op1d4.split.body:               ; preds = %handler.load_iand.op1d4.split.entry
  %dead.alias.pc1312 = load i64, ptr %pc, align 8
  %dead.alias.next1313 = add i64 %dead.alias.pc1312, 32
  store i64 %dead.alias.next1313, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fadd.op19f.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fadd.op19f.split.body

handler.volatile_atomic_rmw_fadd.op19f.split.body: ; preds = %handler.volatile_atomic_rmw_fadd.op19f.split.entry
  %dead.alias.pc1314 = load i64, ptr %pc, align 8
  %dead.alias.next1315 = add i64 %dead.alias.pc1314, 32
  store i64 %dead.alias.next1315, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xor.op95d.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xor.op95d.split.body

handler.volatile_atomic_rmw_xor.op95d.split.body: ; preds = %handler.volatile_atomic_rmw_xor.op95d.split.entry
  %dead.alias.pc1316 = load i64, ptr %pc, align 8
  %dead.alias.next1317 = add i64 %dead.alias.pc1316, 32
  store i64 %dead.alias.next1317, ptr %pc, align 8
  br label %loop.check

handler.frem.op89f.split.entry:                   ; preds = %execute.decode
  br label %handler.frem.op89f.split.body

handler.frem.op89f.split.body:                    ; preds = %handler.frem.op89f.split.entry
  %dead.alias.pc1318 = load i64, ptr %pc, align 8
  %dead.alias.next1319 = add i64 %dead.alias.pc1318, 32
  store i64 %dead.alias.next1319, ptr %pc, align 8
  br label %loop.check

handler.ffma.op708.split.entry:                   ; preds = %execute.decode
  br label %handler.ffma.op708.split.body

handler.ffma.op708.split.body:                    ; preds = %handler.ffma.op708.split.entry
  %dead.alias.pc1320 = load i64, ptr %pc, align 8
  %dead.alias.next1321 = add i64 %dead.alias.pc1320, 48
  store i64 %dead.alias.next1321, ptr %pc, align 8
  br label %loop.check

handler.load.op7c.split.entry:                    ; preds = %execute.decode
  br label %handler.load.op7c.split.body

handler.load.op7c.split.body:                     ; preds = %handler.load.op7c.split.entry
  %dead.alias.pc1322 = load i64, ptr %pc, align 8
  %dead.alias.next1323 = add i64 %dead.alias.pc1322, 32
  store i64 %dead.alias.next1323, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmax.op164.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmax.op164.split.body

handler.atomic_rmw_fmax.op164.split.body:         ; preds = %handler.atomic_rmw_fmax.op164.split.entry
  %dead.alias.pc1324 = load i64, ptr %pc, align 8
  %dead.alias.next1325 = add i64 %dead.alias.pc1324, 32
  store i64 %dead.alias.next1325, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmax.op976.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmax.op976.split.body

handler.volatile_atomic_rmw_fmax.op976.split.body: ; preds = %handler.volatile_atomic_rmw_fmax.op976.split.entry
  %dead.alias.pc1326 = load i64, ptr %pc, align 8
  %dead.alias.next1327 = add i64 %dead.alias.pc1326, 32
  store i64 %dead.alias.next1327, ptr %pc, align 8
  br label %loop.check

handler.iurem.op8c.split.entry:                   ; preds = %execute.decode
  br label %handler.iurem.op8c.split.body

handler.iurem.op8c.split.body:                    ; preds = %handler.iurem.op8c.split.entry
  %dead.alias.pc1328 = load i64, ptr %pc, align 8
  %dead.alias.next1329 = add i64 %dead.alias.pc1328, 32
  store i64 %dead.alias.next1329, ptr %pc, align 8
  br label %loop.check

handler.atomic_load.opd7.split.entry:             ; preds = %execute.decode
  br label %handler.atomic_load.opd7.split.body

handler.atomic_load.opd7.split.body:              ; preds = %handler.atomic_load.opd7.split.entry
  %dead.alias.pc1330 = load i64, ptr %pc, align 8
  %dead.alias.next1331 = add i64 %dead.alias.pc1330, 32
  store i64 %dead.alias.next1331, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xchg.op954.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xchg.op954.split.body

handler.volatile_atomic_rmw_xchg.op954.split.body: ; preds = %handler.volatile_atomic_rmw_xchg.op954.split.entry
  %dead.alias.pc1332 = load i64, ptr %pc, align 8
  %dead.alias.next1333 = add i64 %dead.alias.pc1332, 32
  store i64 %dead.alias.next1333, ptr %pc, align 8
  br label %loop.check

handler.ctpop.op102.split.entry:                  ; preds = %execute.decode
  br label %handler.ctpop.op102.split.body

handler.ctpop.op102.split.body:                   ; preds = %handler.ctpop.op102.split.entry
  %dead.alias.pc1334 = load i64, ptr %pc, align 8
  %dead.alias.next1335 = add i64 %dead.alias.pc1334, 32
  store i64 %dead.alias.next1335, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fminimum.op951.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fminimum.op951.split.body

handler.atomic_rmw_fminimum.op951.split.body:     ; preds = %handler.atomic_rmw_fminimum.op951.split.entry
  %dead.alias.pc1336 = load i64, ptr %pc, align 8
  %dead.alias.next1337 = add i64 %dead.alias.pc1336, 32
  store i64 %dead.alias.next1337, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fsub.op949.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fsub.op949.split.body

handler.atomic_rmw_fsub.op949.split.body:         ; preds = %handler.atomic_rmw_fsub.op949.split.entry
  %dead.alias.pc1338 = load i64, ptr %pc, align 8
  %dead.alias.next1339 = add i64 %dead.alias.pc1338, 32
  store i64 %dead.alias.next1339, ptr %pc, align 8
  br label %loop.check

handler.read_flt_rounds.op1d1.split.entry:        ; preds = %execute.decode
  br label %handler.read_flt_rounds.op1d1.split.body

handler.read_flt_rounds.op1d1.split.body:         ; preds = %handler.read_flt_rounds.op1d1.split.entry
  %dead.alias.pc1340 = load i64, ptr %pc, align 8
  %dead.alias.next1341 = add i64 %dead.alias.pc1340, 8
  store i64 %dead.alias.next1341, ptr %pc, align 8
  br label %loop.check

handler.fexp.op8c9.split.entry:                   ; preds = %execute.decode
  br label %handler.fexp.op8c9.split.body

handler.fexp.op8c9.split.body:                    ; preds = %handler.fexp.op8c9.split.entry
  %dead.alias.pc1342 = load i64, ptr %pc, align 8
  %dead.alias.next1343 = add i64 %dead.alias.pc1342, 32
  store i64 %dead.alias.next1343, ptr %pc, align 8
  br label %loop.check

handler.ismin.op86a.split.entry:                  ; preds = %execute.decode
  br label %handler.ismin.op86a.split.body

handler.ismin.op86a.split.body:                   ; preds = %handler.ismin.op86a.split.entry
  %dead.alias.pc1344 = load i64, ptr %pc, align 8
  %dead.alias.next1345 = add i64 %dead.alias.pc1344, 32
  store i64 %dead.alias.next1345, ptr %pc, align 8
  br label %loop.check

handler.fround.op8c2.split.entry:                 ; preds = %execute.decode
  br label %handler.fround.op8c2.split.body

handler.fround.op8c2.split.body:                  ; preds = %handler.fround.op8c2.split.entry
  %dead.alias.pc1346 = load i64, ptr %pc, align 8
  %dead.alias.next1347 = add i64 %dead.alias.pc1346, 32
  store i64 %dead.alias.next1347, ptr %pc, align 8
  br label %loop.check

handler.store.op36.split.entry:                   ; preds = %execute.decode
  br label %handler.store.op36.split.body

handler.store.op36.split.body:                    ; preds = %handler.store.op36.split.entry
  %dead.alias.pc1348 = load i64, ptr %pc, align 8
  %dead.alias.next1349 = add i64 %dead.alias.pc1348, 32
  store i64 %dead.alias.next1349, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fsub.op1a1.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fsub.op1a1.split.body

handler.volatile_atomic_rmw_fsub.op1a1.split.body: ; preds = %handler.volatile_atomic_rmw_fsub.op1a1.split.entry
  %dead.alias.pc1350 = load i64, ptr %pc, align 8
  %dead.alias.next1351 = add i64 %dead.alias.pc1350, 32
  store i64 %dead.alias.next1351, ptr %pc, align 8
  br label %loop.check

handler.isub.op11.split.entry:                    ; preds = %execute.decode
  br label %handler.isub.op11.split.body

handler.isub.op11.split.body:                     ; preds = %handler.isub.op11.split.entry
  %dead.alias.pc1352 = load i64, ptr %pc, align 8
  %dead.alias.next1353 = add i64 %dead.alias.pc1352, 32
  store i64 %dead.alias.next1353, ptr %pc, align 8
  br label %loop.check

handler.cttz.op116.split.entry:                   ; preds = %execute.decode
  br label %handler.cttz.op116.split.body

handler.cttz.op116.split.body:                    ; preds = %handler.cttz.op116.split.entry
  %dead.alias.pc1354 = load i64, ptr %pc, align 8
  %dead.alias.next1355 = add i64 %dead.alias.pc1354, 32
  store i64 %dead.alias.next1355, ptr %pc, align 8
  br label %loop.check

handler.fceil.op719.split.entry:                  ; preds = %execute.decode
  br label %handler.fceil.op719.split.body

handler.fceil.op719.split.body:                   ; preds = %handler.fceil.op719.split.entry
  %dead.alias.pc1356 = load i64, ptr %pc, align 8
  %dead.alias.next1357 = add i64 %dead.alias.pc1356, 32
  store i64 %dead.alias.next1357, ptr %pc, align 8
  br label %loop.check

handler.iand.op47.split.entry:                    ; preds = %execute.decode
  br label %handler.iand.op47.split.body

handler.iand.op47.split.body:                     ; preds = %handler.iand.op47.split.entry
  %dead.alias.pc1358 = load i64, ptr %pc, align 8
  %dead.alias.next1359 = add i64 %dead.alias.pc1358, 32
  store i64 %dead.alias.next1359, ptr %pc, align 8
  br label %loop.check

handler.isub.op841.split.entry:                   ; preds = %execute.decode
  br label %handler.isub.op841.split.body

handler.isub.op841.split.body:                    ; preds = %handler.isub.op841.split.entry
  %isub.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %isub.lhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %isub.rhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %isub.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1360 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %isub.lhs
  %lhs1361 = load i64, ptr %reg.load.ptr1360, align 8
  %reg.load.ptr1362 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %isub.rhs
  %rhs1363 = load i64, ptr %reg.load.ptr1362, align 8
  %shift.masked1364 = and i64 %rhs1363, 63
  %bin.sub = sub i64 %lhs1361, %rhs1363
  %width.is641365 = icmp eq i64 %isub.width, 64
  %width.shift1366 = and i64 %isub.width, 63
  %mask.shifted1367 = shl i64 1, %width.shift1366
  %mask.candidate1368 = sub i64 %mask.shifted1367, 1
  %width.mask1369 = select i1 %width.is641365, i64 -1, i64 %mask.candidate1368
  %width.masked1370 = and i64 %bin.sub, %width.mask1369
  %reg.store.ptr1371 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %isub.dst
  store i64 %width.masked1370, ptr %reg.store.ptr1371, align 8
  %pc.old1372 = load i64, ptr %pc, align 8
  %pc.next1373 = add i64 %pc.old1372, 32
  store i64 %pc.next1373, ptr %pc, align 8
  br label %loop.check

handler.memset_dyn.op142.split.entry:             ; preds = %execute.decode
  br label %handler.memset_dyn.op142.split.body

handler.memset_dyn.op142.split.body:              ; preds = %handler.memset_dyn.op142.split.entry
  %dead.alias.pc1374 = load i64, ptr %pc, align 8
  %dead.alias.next1375 = add i64 %dead.alias.pc1374, 8
  store i64 %dead.alias.next1375, ptr %pc, align 8
  br label %loop.check

handler.iand.op74.split.entry:                    ; preds = %execute.decode
  br label %handler.iand.op74.split.body

handler.iand.op74.split.body:                     ; preds = %handler.iand.op74.split.entry
  %dead.alias.pc1376 = load i64, ptr %pc, align 8
  %dead.alias.next1377 = add i64 %dead.alias.pc1376, 32
  store i64 %dead.alias.next1377, ptr %pc, align 8
  br label %loop.check

handler.ismin.op869.split.entry:                  ; preds = %execute.decode
  br label %handler.ismin.op869.split.body

handler.ismin.op869.split.body:                   ; preds = %handler.ismin.op869.split.entry
  %dead.alias.pc1378 = load i64, ptr %pc, align 8
  %dead.alias.next1379 = add i64 %dead.alias.pc1378, 32
  store i64 %dead.alias.next1379, ptr %pc, align 8
  br label %loop.check

handler.fround.op720.split.entry:                 ; preds = %execute.decode
  br label %handler.fround.op720.split.body

handler.fround.op720.split.body:                  ; preds = %handler.fround.op720.split.entry
  %dead.alias.pc1380 = load i64, ptr %pc, align 8
  %dead.alias.next1381 = add i64 %dead.alias.pc1380, 32
  store i64 %dead.alias.next1381, ptr %pc, align 8
  br label %loop.check

handler.read_vscale.op1bc.split.entry:            ; preds = %execute.decode
  br label %handler.read_vscale.op1bc.split.body

handler.read_vscale.op1bc.split.body:             ; preds = %handler.read_vscale.op1bc.split.entry
  %dead.alias.pc1382 = load i64, ptr %pc, align 8
  %dead.alias.next1383 = add i64 %dead.alias.pc1382, 8
  store i64 %dead.alias.next1383, ptr %pc, align 8
  br label %loop.check

handler.fmaximum.op8ae.split.entry:               ; preds = %execute.decode
  br label %handler.fmaximum.op8ae.split.body

handler.fmaximum.op8ae.split.body:                ; preds = %handler.fmaximum.op8ae.split.entry
  %dead.alias.pc1384 = load i64, ptr %pc, align 8
  %dead.alias.next1385 = add i64 %dead.alias.pc1384, 16
  store i64 %dead.alias.next1385, ptr %pc, align 8
  br label %loop.check

handler.ctlz.op88a.split.entry:                   ; preds = %execute.decode
  br label %handler.ctlz.op88a.split.body

handler.ctlz.op88a.split.body:                    ; preds = %handler.ctlz.op88a.split.entry
  %dead.alias.pc1386 = load i64, ptr %pc, align 8
  %dead.alias.next1387 = add i64 %dead.alias.pc1386, 32
  store i64 %dead.alias.next1387, ptr %pc, align 8
  br label %loop.check

handler.fcmp.opb1.split.entry:                    ; preds = %execute.decode
  br label %handler.fcmp.opb1.split.body

handler.fcmp.opb1.split.body:                     ; preds = %handler.fcmp.opb1.split.entry
  %dead.alias.pc1388 = load i64, ptr %pc, align 8
  %dead.alias.next1389 = add i64 %dead.alias.pc1388, 32
  store i64 %dead.alias.next1389, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_sat.op172.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_sat.op172.split.body

handler.atomic_rmw_usub_sat.op172.split.body:     ; preds = %handler.atomic_rmw_usub_sat.op172.split.entry
  %dead.alias.pc1390 = load i64, ptr %pc, align 8
  %dead.alias.next1391 = add i64 %dead.alias.pc1390, 32
  store i64 %dead.alias.next1391, ptr %pc, align 8
  br label %loop.check

handler.load_iushl_sat.op1f9.split.entry:         ; preds = %execute.decode
  br label %handler.load_iushl_sat.op1f9.split.body

handler.load_iushl_sat.op1f9.split.body:          ; preds = %handler.load_iushl_sat.op1f9.split.entry
  %dead.alias.pc1392 = load i64, ptr %pc, align 8
  %dead.alias.next1393 = add i64 %dead.alias.pc1392, 32
  store i64 %dead.alias.next1393, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_and.op187.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_and.op187.split.body

handler.volatile_atomic_rmw_and.op187.split.body: ; preds = %handler.volatile_atomic_rmw_and.op187.split.entry
  %dead.alias.pc1394 = load i64, ptr %pc, align 8
  %dead.alias.next1395 = add i64 %dead.alias.pc1394, 32
  store i64 %dead.alias.next1395, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umin.op195.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umin.op195.split.body

handler.volatile_atomic_rmw_umin.op195.split.body: ; preds = %handler.volatile_atomic_rmw_umin.op195.split.entry
  %dead.alias.pc1396 = load i64, ptr %pc, align 8
  %dead.alias.next1397 = add i64 %dead.alias.pc1396, 32
  store i64 %dead.alias.next1397, ptr %pc, align 8
  br label %loop.check

handler.fround.op8c1.split.entry:                 ; preds = %execute.decode
  br label %handler.fround.op8c1.split.body

handler.fround.op8c1.split.body:                  ; preds = %handler.fround.op8c1.split.entry
  %dead.alias.pc1398 = load i64, ptr %pc, align 8
  %dead.alias.next1399 = add i64 %dead.alias.pc1398, 32
  store i64 %dead.alias.next1399, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_or.op932.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_or.op932.split.body

handler.atomic_rmw_or.op932.split.body:           ; preds = %handler.atomic_rmw_or.op932.split.entry
  %dead.alias.pc1400 = load i64, ptr %pc, align 8
  %dead.alias.next1401 = add i64 %dead.alias.pc1400, 32
  store i64 %dead.alias.next1401, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_cond.op943.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_cond.op943.split.body

handler.atomic_rmw_usub_cond.op943.split.body:    ; preds = %handler.atomic_rmw_usub_cond.op943.split.entry
  %dead.alias.pc1402 = load i64, ptr %pc, align 8
  %dead.alias.next1403 = add i64 %dead.alias.pc1402, 32
  store i64 %dead.alias.next1403, ptr %pc, align 8
  br label %loop.check

handler.isadd_overflow.op87e.split.entry:         ; preds = %execute.decode
  br label %handler.isadd_overflow.op87e.split.body

handler.isadd_overflow.op87e.split.body:          ; preds = %handler.isadd_overflow.op87e.split.entry
  %dead.alias.pc1404 = load i64, ptr %pc, align 8
  %dead.alias.next1405 = add i64 %dead.alias.pc1404, 32
  store i64 %dead.alias.next1405, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_min.op93a.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_min.op93a.split.body

handler.atomic_rmw_min.op93a.split.body:          ; preds = %handler.atomic_rmw_min.op93a.split.entry
  %dead.alias.pc1406 = load i64, ptr %pc, align 8
  %dead.alias.next1407 = add i64 %dead.alias.pc1406, 32
  store i64 %dead.alias.next1407, ptr %pc, align 8
  br label %loop.check

handler.fexp.op728.split.entry:                   ; preds = %execute.decode
  br label %handler.fexp.op728.split.body

handler.fexp.op728.split.body:                    ; preds = %handler.fexp.op728.split.entry
  %dead.alias.pc1408 = load i64, ptr %pc, align 8
  %dead.alias.next1409 = add i64 %dead.alias.pc1408, 32
  store i64 %dead.alias.next1409, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_add.op92c.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_add.op92c.split.body

handler.atomic_rmw_add.op92c.split.body:          ; preds = %handler.atomic_rmw_add.op92c.split.entry
  %dead.alias.pc1410 = load i64, ptr %pc, align 8
  %dead.alias.next1411 = add i64 %dead.alias.pc1410, 32
  store i64 %dead.alias.next1411, ptr %pc, align 8
  br label %loop.check

handler.load_iadd.op111.split.entry:              ; preds = %execute.decode
  br label %handler.load_iadd.op111.split.body

handler.load_iadd.op111.split.body:               ; preds = %handler.load_iadd.op111.split.entry
  %dead.alias.pc1412 = load i64, ptr %pc, align 8
  %dead.alias.next1413 = add i64 %dead.alias.pc1412, 32
  store i64 %dead.alias.next1413, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmaximum.op1a7.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmaximum.op1a7.split.body

handler.volatile_atomic_rmw_fmaximum.op1a7.split.body: ; preds = %handler.volatile_atomic_rmw_fmaximum.op1a7.split.entry
  %dead.alias.pc1414 = load i64, ptr %pc, align 8
  %dead.alias.next1415 = add i64 %dead.alias.pc1414, 32
  store i64 %dead.alias.next1415, ptr %pc, align 8
  br label %loop.check

handler.iuadd_overflow.op87c.split.entry:         ; preds = %execute.decode
  br label %handler.iuadd_overflow.op87c.split.body

handler.iuadd_overflow.op87c.split.body:          ; preds = %handler.iuadd_overflow.op87c.split.entry
  %dead.alias.pc1416 = load i64, ptr %pc, align 8
  %dead.alias.next1417 = add i64 %dead.alias.pc1416, 32
  store i64 %dead.alias.next1417, ptr %pc, align 8
  br label %loop.check

handler.mov.op02.split.entry:                     ; preds = %execute.decode
  br label %handler.mov.op02.split.body

handler.mov.op02.split.body:                      ; preds = %handler.mov.op02.split.entry
  %mov.dst1418 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov.src1419 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov.width1420 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1421 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov.src1419
  %mov.src1422 = load i64, ptr %reg.load.ptr1421, align 8
  %width.is641423 = icmp eq i64 %mov.width1420, 64
  %width.shift1424 = and i64 %mov.width1420, 63
  %mask.shifted1425 = shl i64 1, %width.shift1424
  %mask.candidate1426 = sub i64 %mask.shifted1425, 1
  %width.mask1427 = select i1 %width.is641423, i64 -1, i64 %mask.candidate1426
  %width.masked1428 = and i64 %mov.src1422, %width.mask1427
  %reg.store.ptr1429 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov.dst1418
  store i64 %width.masked1428, ptr %reg.store.ptr1429, align 8
  %pc.old1430 = load i64, ptr %pc, align 8
  %pc.next1431 = add i64 %pc.old1430, 8
  store i64 %pc.next1431, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_min.opf5.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_min.opf5.split.body

handler.atomic_rmw_min.opf5.split.body:           ; preds = %handler.atomic_rmw_min.opf5.split.entry
  %dead.alias.pc1432 = load i64, ptr %pc, align 8
  %dead.alias.next1433 = add i64 %dead.alias.pc1432, 32
  store i64 %dead.alias.next1433, ptr %pc, align 8
  br label %loop.check

handler.load_iurem.op1de.split.entry:             ; preds = %execute.decode
  br label %handler.load_iurem.op1de.split.body

handler.load_iurem.op1de.split.body:              ; preds = %handler.load_iurem.op1de.split.entry
  %dead.alias.pc1434 = load i64, ptr %pc, align 8
  %dead.alias.next1435 = add i64 %dead.alias.pc1434, 32
  store i64 %dead.alias.next1435, ptr %pc, align 8
  br label %loop.check

handler.fnearbyint.op71f.split.entry:             ; preds = %execute.decode
  br label %handler.fnearbyint.op71f.split.body

handler.fnearbyint.op71f.split.body:              ; preds = %handler.fnearbyint.op71f.split.entry
  %dead.alias.pc1436 = load i64, ptr %pc, align 8
  %dead.alias.next1437 = add i64 %dead.alias.pc1436, 32
  store i64 %dead.alias.next1437, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op01.split.entry:                 ; preds = %execute.decode
  br label %handler.mov_imm.op01.split.body

handler.mov_imm.op01.split.body:                  ; preds = %handler.mov_imm.op01.split.entry
  %dead.alias.pc1438 = load i64, ptr %pc, align 8
  %dead.alias.next1439 = add i64 %dead.alias.pc1438, 32
  store i64 %dead.alias.next1439, ptr %pc, align 8
  br label %loop.check

handler.volatile_store.op914.split.entry:         ; preds = %execute.decode
  br label %handler.volatile_store.op914.split.body

handler.volatile_store.op914.split.body:          ; preds = %handler.volatile_store.op914.split.entry
  %dead.alias.pc1440 = load i64, ptr %pc, align 8
  %dead.alias.next1441 = add i64 %dead.alias.pc1440, 16
  store i64 %dead.alias.next1441, ptr %pc, align 8
  br label %loop.check

handler.imul.op843.split.entry:                   ; preds = %execute.decode
  br label %handler.imul.op843.split.body

handler.imul.op843.split.body:                    ; preds = %handler.imul.op843.split.entry
  %dead.alias.pc1442 = load i64, ptr %pc, align 8
  %dead.alias.next1443 = add i64 %dead.alias.pc1442, 32
  store i64 %dead.alias.next1443, ptr %pc, align 8
  br label %loop.check

handler.fmul.opa2.split.entry:                    ; preds = %execute.decode
  br label %handler.fmul.opa2.split.body

handler.fmul.opa2.split.body:                     ; preds = %handler.fmul.opa2.split.entry
  %dead.alias.pc1444 = load i64, ptr %pc, align 8
  %dead.alias.next1445 = add i64 %dead.alias.pc1444, 32
  store i64 %dead.alias.next1445, ptr %pc, align 8
  br label %loop.check

handler.froundeven.op8c3.split.entry:             ; preds = %execute.decode
  br label %handler.froundeven.op8c3.split.body

handler.froundeven.op8c3.split.body:              ; preds = %handler.froundeven.op8c3.split.entry
  %dead.alias.pc1446 = load i64, ptr %pc, align 8
  %dead.alias.next1447 = add i64 %dead.alias.pc1446, 32
  store i64 %dead.alias.next1447, ptr %pc, align 8
  br label %loop.check

handler.fptosi.opc1.split.entry:                  ; preds = %execute.decode
  br label %handler.fptosi.opc1.split.body

handler.fptosi.opc1.split.body:                   ; preds = %handler.fptosi.opc1.split.entry
  %dead.alias.pc1448 = load i64, ptr %pc, align 8
  %dead.alias.next1449 = add i64 %dead.alias.pc1448, 32
  store i64 %dead.alias.next1449, ptr %pc, align 8
  br label %loop.check

handler.fdiv.op89d.split.entry:                   ; preds = %execute.decode
  br label %handler.fdiv.op89d.split.body

handler.fdiv.op89d.split.body:                    ; preds = %handler.fdiv.op89d.split.entry
  %dead.alias.pc1450 = load i64, ptr %pc, align 8
  %dead.alias.next1451 = add i64 %dead.alias.pc1450, 32
  store i64 %dead.alias.next1451, ptr %pc, align 8
  br label %loop.check

handler.stackrestore.op1b3.split.entry:           ; preds = %execute.decode
  br label %handler.stackrestore.op1b3.split.body

handler.stackrestore.op1b3.split.body:            ; preds = %handler.stackrestore.op1b3.split.entry
  %dead.alias.pc1452 = load i64, ptr %pc, align 8
  %dead.alias.next1453 = add i64 %dead.alias.pc1452, 8
  store i64 %dead.alias.next1453, ptr %pc, align 8
  br label %loop.check

handler.clear_cache.op1b4.split.entry:            ; preds = %execute.decode
  br label %handler.clear_cache.op1b4.split.body

handler.clear_cache.op1b4.split.body:             ; preds = %handler.clear_cache.op1b4.split.entry
  %dead.alias.pc1454 = load i64, ptr %pc, align 8
  %dead.alias.next1455 = add i64 %dead.alias.pc1454, 8
  store i64 %dead.alias.next1455, ptr %pc, align 8
  br label %loop.check

handler.load.op0f.split.entry:                    ; preds = %execute.decode
  br label %handler.load.op0f.split.body

handler.load.op0f.split.body:                     ; preds = %handler.load.op0f.split.entry
  %dead.alias.pc1456 = load i64, ptr %pc, align 8
  %dead.alias.next1457 = add i64 %dead.alias.pc1456, 32
  store i64 %dead.alias.next1457, ptr %pc, align 8
  br label %loop.check

handler.sideeffect.op838.split.entry:             ; preds = %execute.decode
  br label %handler.sideeffect.op838.split.body

handler.sideeffect.op838.split.body:              ; preds = %handler.sideeffect.op838.split.entry
  %dead.alias.pc1458 = load i64, ptr %pc, align 8
  %dead.alias.next1459 = add i64 %dead.alias.pc1458, 4
  store i64 %dead.alias.next1459, ptr %pc, align 8
  br label %loop.check

handler.memmove_dyn.op918.split.entry:            ; preds = %execute.decode
  br label %handler.memmove_dyn.op918.split.body

handler.memmove_dyn.op918.split.body:             ; preds = %handler.memmove_dyn.op918.split.entry
  %dead.alias.pc1460 = load i64, ptr %pc, align 8
  %dead.alias.next1461 = add i64 %dead.alias.pc1460, 8
  store i64 %dead.alias.next1461, ptr %pc, align 8
  br label %loop.check

handler.vm_call.op42.split.entry:                 ; preds = %execute.decode
  br label %handler.vm_call.op42.split.body

handler.vm_call.op42.split.body:                  ; preds = %handler.vm_call.op42.split.entry
  %dead.alias.pc1462 = load i64, ptr %pc, align 8
  %dead.alias.next1463 = add i64 %dead.alias.pc1462, 32
  store i64 %dead.alias.next1463, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_and.op95a.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_and.op95a.split.body

handler.volatile_atomic_rmw_and.op95a.split.body: ; preds = %handler.volatile_atomic_rmw_and.op95a.split.entry
  %dead.alias.pc1464 = load i64, ptr %pc, align 8
  %dead.alias.next1465 = add i64 %dead.alias.pc1464, 32
  store i64 %dead.alias.next1465, ptr %pc, align 8
  br label %loop.check

handler.const_load.op803.split.entry:             ; preds = %execute.decode
  br label %handler.const_load.op803.split.body

handler.const_load.op803.split.body:              ; preds = %handler.const_load.op803.split.entry
  %const_load.dst1466 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %const_load.index1467 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %const_load.width1468 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %const.pool.read1469 = call i64 @.amice.vm.h.a19eb3e0dbe6d829(ptr %descriptor.const.pool.ptr, i64 %descriptor.const.pool.len.plain, i64 %descriptor.bytecode.key.plain, i64 %const_load.index1467)
  %width.is641470 = icmp eq i64 %const_load.width1468, 64
  %width.shift1471 = and i64 %const_load.width1468, 63
  %mask.shifted1472 = shl i64 1, %width.shift1471
  %mask.candidate1473 = sub i64 %mask.shifted1472, 1
  %width.mask1474 = select i1 %width.is641470, i64 -1, i64 %mask.candidate1473
  %width.masked1475 = and i64 %const.pool.read1469, %width.mask1474
  %reg.store.ptr1476 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %const_load.dst1466
  store i64 %width.masked1475, ptr %reg.store.ptr1476, align 8
  %pc.old1477 = load i64, ptr %pc, align 8
  %pc.next1478 = add i64 %pc.old1477, 32
  store i64 %pc.next1478, ptr %pc, align 8
  br label %loop.check

handler.iadd.op6d.split.entry:                    ; preds = %execute.decode
  br label %handler.iadd.op6d.split.body

handler.iadd.op6d.split.body:                     ; preds = %handler.iadd.op6d.split.entry
  %iadd.dst1479 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.lhs1480 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.rhs1481 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.width1482 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1483 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.lhs1480
  %lhs1484 = load i64, ptr %reg.load.ptr1483, align 8
  %reg.load.ptr1485 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.rhs1481
  %rhs1486 = load i64, ptr %reg.load.ptr1485, align 8
  %shift.masked1487 = and i64 %rhs1486, 63
  %bin.add1488 = add i64 %lhs1484, %rhs1486
  %width.is641489 = icmp eq i64 %iadd.width1482, 64
  %width.shift1490 = and i64 %iadd.width1482, 63
  %mask.shifted1491 = shl i64 1, %width.shift1490
  %mask.candidate1492 = sub i64 %mask.shifted1491, 1
  %width.mask1493 = select i1 %width.is641489, i64 -1, i64 %mask.candidate1492
  %width.masked1494 = and i64 %bin.add1488, %width.mask1493
  %reg.store.ptr1495 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.dst1479
  store i64 %width.masked1494, ptr %reg.store.ptr1495, align 8
  %pc.old1496 = load i64, ptr %pc, align 8
  %pc.next1497 = add i64 %pc.old1496, 16
  store i64 %pc.next1497, ptr %pc, align 8
  br label %loop.check

handler.load_iusub_sat.op9a3.split.entry:         ; preds = %execute.decode
  br label %handler.load_iusub_sat.op9a3.split.body

handler.load_iusub_sat.op9a3.split.body:          ; preds = %handler.load_iusub_sat.op9a3.split.entry
  %dead.alias.pc1498 = load i64, ptr %pc, align 8
  %dead.alias.next1499 = add i64 %dead.alias.pc1498, 32
  store i64 %dead.alias.next1499, ptr %pc, align 8
  br label %loop.check

handler.issub_overflow.op882.split.entry:         ; preds = %execute.decode
  br label %handler.issub_overflow.op882.split.body

handler.issub_overflow.op882.split.body:          ; preds = %handler.issub_overflow.op882.split.entry
  %dead.alias.pc1500 = load i64, ptr %pc, align 8
  %dead.alias.next1501 = add i64 %dead.alias.pc1500, 32
  store i64 %dead.alias.next1501, ptr %pc, align 8
  br label %loop.check

handler.cmpxchg.op97e.split.entry:                ; preds = %execute.decode
  br label %handler.cmpxchg.op97e.split.body

handler.cmpxchg.op97e.split.body:                 ; preds = %handler.cmpxchg.op97e.split.entry
  %dead.alias.pc1502 = load i64, ptr %pc, align 8
  %dead.alias.next1503 = add i64 %dead.alias.pc1502, 32
  store i64 %dead.alias.next1503, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_nand.op935.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_nand.op935.split.body

handler.atomic_rmw_nand.op935.split.body:         ; preds = %handler.atomic_rmw_nand.op935.split.entry
  %dead.alias.pc1504 = load i64, ptr %pc, align 8
  %dead.alias.next1505 = add i64 %dead.alias.pc1504, 32
  store i64 %dead.alias.next1505, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_load.op926.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_atomic_load.op926.split.body

handler.volatile_atomic_load.op926.split.body:    ; preds = %handler.volatile_atomic_load.op926.split.entry
  %dead.alias.pc1506 = load i64, ptr %pc, align 8
  %dead.alias.next1507 = add i64 %dead.alias.pc1506, 32
  store i64 %dead.alias.next1507, ptr %pc, align 8
  br label %loop.check

handler.fcopysign.op8a1.split.entry:              ; preds = %execute.decode
  br label %handler.fcopysign.op8a1.split.body

handler.fcopysign.op8a1.split.body:               ; preds = %handler.fcopysign.op8a1.split.entry
  %dead.alias.pc1508 = load i64, ptr %pc, align 8
  %dead.alias.next1509 = add i64 %dead.alias.pc1508, 32
  store i64 %dead.alias.next1509, ptr %pc, align 8
  br label %loop.check

handler.load_ior.op9af.split.entry:               ; preds = %execute.decode
  br label %handler.load_ior.op9af.split.body

handler.load_ior.op9af.split.body:                ; preds = %handler.load_ior.op9af.split.entry
  %dead.alias.pc1510 = load i64, ptr %pc, align 8
  %dead.alias.next1511 = add i64 %dead.alias.pc1510, 32
  store i64 %dead.alias.next1511, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xchg.op92a.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_xchg.op92a.split.body

handler.atomic_rmw_xchg.op92a.split.body:         ; preds = %handler.atomic_rmw_xchg.op92a.split.entry
  %dead.alias.pc1512 = load i64, ptr %pc, align 8
  %dead.alias.next1513 = add i64 %dead.alias.pc1512, 32
  store i64 %dead.alias.next1513, ptr %pc, align 8
  br label %loop.check

handler.alloca.op8ff.split.entry:                 ; preds = %execute.decode
  br label %handler.alloca.op8ff.split.body

handler.alloca.op8ff.split.body:                  ; preds = %handler.alloca.op8ff.split.entry
  %dead.alias.pc1514 = load i64, ptr %pc, align 8
  %dead.alias.next1515 = add i64 %dead.alias.pc1514, 32
  store i64 %dead.alias.next1515, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op83.split.entry:                   ; preds = %execute.decode
  br label %handler.iudiv.op83.split.body

handler.iudiv.op83.split.body:                    ; preds = %handler.iudiv.op83.split.entry
  %dead.alias.pc1516 = load i64, ptr %pc, align 8
  %dead.alias.next1517 = add i64 %dead.alias.pc1516, 32
  store i64 %dead.alias.next1517, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_and.ope6.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_and.ope6.split.body

handler.atomic_rmw_and.ope6.split.body:           ; preds = %handler.atomic_rmw_and.ope6.split.entry
  %dead.alias.pc1518 = load i64, ptr %pc, align 8
  %dead.alias.next1519 = add i64 %dead.alias.pc1518, 32
  store i64 %dead.alias.next1519, ptr %pc, align 8
  br label %loop.check

handler.isrem.op84e.split.entry:                  ; preds = %execute.decode
  br label %handler.isrem.op84e.split.body

handler.isrem.op84e.split.body:                   ; preds = %handler.isrem.op84e.split.entry
  %dead.alias.pc1520 = load i64, ptr %pc, align 8
  %dead.alias.next1521 = add i64 %dead.alias.pc1520, 32
  store i64 %dead.alias.next1521, ptr %pc, align 8
  br label %loop.check

handler.bitcast.op8fe.split.entry:                ; preds = %execute.decode
  br label %handler.bitcast.op8fe.split.body

handler.bitcast.op8fe.split.body:                 ; preds = %handler.bitcast.op8fe.split.entry
  %dead.alias.pc1522 = load i64, ptr %pc, align 8
  %dead.alias.next1523 = add i64 %dead.alias.pc1522, 32
  store i64 %dead.alias.next1523, ptr %pc, align 8
  br label %loop.check

handler.global_addr.op80e.split.entry:            ; preds = %execute.decode
  br label %handler.global_addr.op80e.split.body

handler.global_addr.op80e.split.body:             ; preds = %handler.global_addr.op80e.split.entry
  %dead.alias.pc1524 = load i64, ptr %pc, align 8
  %dead.alias.next1525 = add i64 %dead.alias.pc1524, 8
  store i64 %dead.alias.next1525, ptr %pc, align 8
  br label %loop.check

handler.iusub_overflow.op131.split.entry:         ; preds = %execute.decode
  br label %handler.iusub_overflow.op131.split.body

handler.iusub_overflow.op131.split.body:          ; preds = %handler.iusub_overflow.op131.split.entry
  %dead.alias.pc1526 = load i64, ptr %pc, align 8
  %dead.alias.next1527 = add i64 %dead.alias.pc1526, 32
  store i64 %dead.alias.next1527, ptr %pc, align 8
  br label %loop.check

handler.ismul_overflow.op138.split.entry:         ; preds = %execute.decode
  br label %handler.ismul_overflow.op138.split.body

handler.ismul_overflow.op138.split.body:          ; preds = %handler.ismul_overflow.op138.split.entry
  %dead.alias.pc1528 = load i64, ptr %pc, align 8
  %dead.alias.next1529 = add i64 %dead.alias.pc1528, 32
  store i64 %dead.alias.next1529, ptr %pc, align 8
  br label %loop.check

handler.fllround.op8ed.split.entry:               ; preds = %execute.decode
  br label %handler.fllround.op8ed.split.body

handler.fllround.op8ed.split.body:                ; preds = %handler.fllround.op8ed.split.entry
  %dead.alias.pc1530 = load i64, ptr %pc, align 8
  %dead.alias.next1531 = add i64 %dead.alias.pc1530, 16
  store i64 %dead.alias.next1531, ptr %pc, align 8
  br label %loop.check

handler.write_fpmode.op1cc.split.entry:           ; preds = %execute.decode
  br label %handler.write_fpmode.op1cc.split.body

handler.write_fpmode.op1cc.split.body:            ; preds = %handler.write_fpmode.op1cc.split.entry
  %dead.alias.pc1532 = load i64, ptr %pc, align 8
  %dead.alias.next1533 = add i64 %dead.alias.pc1532, 8
  store i64 %dead.alias.next1533, ptr %pc, align 8
  br label %loop.check

handler.call_native.op38.split.entry:             ; preds = %execute.decode
  br label %handler.call_native.op38.split.body

handler.call_native.op38.split.body:              ; preds = %handler.call_native.op38.split.entry
  %dead.alias.pc1534 = load i64, ptr %pc, align 8
  %dead.alias.next1535 = add i64 %dead.alias.pc1534, 64
  store i64 %dead.alias.next1535, ptr %pc, align 8
  br label %loop.check

handler.mov.op06.split.entry:                     ; preds = %execute.decode
  br label %handler.mov.op06.split.body

handler.mov.op06.split.body:                      ; preds = %handler.mov.op06.split.entry
  %mov.dst1536 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov.src1537 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov.width1538 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1539 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov.src1537
  %mov.src1540 = load i64, ptr %reg.load.ptr1539, align 8
  %width.is641541 = icmp eq i64 %mov.width1538, 64
  %width.shift1542 = and i64 %mov.width1538, 63
  %mask.shifted1543 = shl i64 1, %width.shift1542
  %mask.candidate1544 = sub i64 %mask.shifted1543, 1
  %width.mask1545 = select i1 %width.is641541, i64 -1, i64 %mask.candidate1544
  %width.masked1546 = and i64 %mov.src1540, %width.mask1545
  %reg.store.ptr1547 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov.dst1536
  store i64 %width.masked1546, ptr %reg.store.ptr1547, align 8
  %pc.old1548 = load i64, ptr %pc, align 8
  %pc.next1549 = add i64 %pc.old1548, 8
  store i64 %pc.next1549, ptr %pc, align 8
  br label %loop.check

handler.load_iuadd_sat.op9a2.split.entry:         ; preds = %execute.decode
  br label %handler.load_iuadd_sat.op9a2.split.body

handler.load_iuadd_sat.op9a2.split.body:          ; preds = %handler.load_iuadd_sat.op9a2.split.entry
  %dead.alias.pc1550 = load i64, ptr %pc, align 8
  %dead.alias.next1551 = add i64 %dead.alias.pc1550, 32
  store i64 %dead.alias.next1551, ptr %pc, align 8
  br label %loop.check

handler.bswap.op104.split.entry:                  ; preds = %execute.decode
  br label %handler.bswap.op104.split.body

handler.bswap.op104.split.body:                   ; preds = %handler.bswap.op104.split.entry
  %dead.alias.pc1552 = load i64, ptr %pc, align 8
  %dead.alias.next1553 = add i64 %dead.alias.pc1552, 32
  store i64 %dead.alias.next1553, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_min.op963.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_min.op963.split.body

handler.volatile_atomic_rmw_min.op963.split.body: ; preds = %handler.volatile_atomic_rmw_min.op963.split.entry
  %dead.alias.pc1554 = load i64, ptr %pc, align 8
  %dead.alias.next1555 = add i64 %dead.alias.pc1554, 32
  store i64 %dead.alias.next1555, ptr %pc, align 8
  br label %loop.check

handler.iabs.op117.split.entry:                   ; preds = %execute.decode
  br label %handler.iabs.op117.split.body

handler.iabs.op117.split.body:                    ; preds = %handler.iabs.op117.split.entry
  %dead.alias.pc1556 = load i64, ptr %pc, align 8
  %dead.alias.next1557 = add i64 %dead.alias.pc1556, 32
  store i64 %dead.alias.next1557, ptr %pc, align 8
  br label %loop.check

handler.fpowi.op735.split.entry:                  ; preds = %execute.decode
  br label %handler.fpowi.op735.split.body

handler.fpowi.op735.split.body:                   ; preds = %handler.fpowi.op735.split.entry
  %dead.alias.pc1558 = load i64, ptr %pc, align 8
  %dead.alias.next1559 = add i64 %dead.alias.pc1558, 16
  store i64 %dead.alias.next1559, ptr %pc, align 8
  br label %loop.check

handler.call_native.op73.split.entry:             ; preds = %execute.decode
  br label %handler.call_native.op73.split.body

handler.call_native.op73.split.body:              ; preds = %handler.call_native.op73.split.entry
  %call_native.callee1560 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.argc1561 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg01562 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg11563 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg21564 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg31565 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg41566 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg51567 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg61568 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.arg71569 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret_count1570 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret01571 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret0_width1572 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret11573 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret1_width1574 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret21575 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret2_width1576 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret31577 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret3_width1578 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret41579 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret4_width1580 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret51581 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret5_width1582 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret61583 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret6_width1584 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret71585 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %call_native.ret7_width1586 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1587 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg01562
  %native.arg1588 = load i64, ptr %reg.load.ptr1587, align 8
  %reg.load.ptr1589 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg11563
  %native.arg1590 = load i64, ptr %reg.load.ptr1589, align 8
  %reg.load.ptr1591 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg21564
  %native.arg1592 = load i64, ptr %reg.load.ptr1591, align 8
  %reg.load.ptr1593 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg31565
  %native.arg1594 = load i64, ptr %reg.load.ptr1593, align 8
  %reg.load.ptr1595 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg41566
  %native.arg1596 = load i64, ptr %reg.load.ptr1595, align 8
  %reg.load.ptr1597 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg51567
  %native.arg1598 = load i64, ptr %reg.load.ptr1597, align 8
  %reg.load.ptr1599 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg61568
  %native.arg1600 = load i64, ptr %reg.load.ptr1599, align 8
  %reg.load.ptr1601 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.arg71569
  %native.arg1602 = load i64, ptr %reg.load.ptr1601, align 8
  %native.argc.ok1605 = icmp ule i64 %call_native.argc1561, 8
  %native.id.ok1606 = icmp ult i64 %call_native.callee1560, %descriptor.native.count.plain
  %native.ret.count.ok1607 = icmp ule i64 %call_native.ret_count1570, 8
  %native.call.bounds.ok1608 = and i1 %native.argc.ok1605, %native.id.ok1606
  %native.can.call1609 = and i1 %native.call.bounds.ok1608, %native.ret.count.ok1607
  br i1 %native.can.call1609, label %native.call1603, label %native.done1604

native.call1603:                                  ; preds = %handler.call_native.op73.split.body
  %native.table.index1610 = add i64 %descriptor.native.base.plain, %call_native.callee1560
  %native.slot1611 = getelementptr ptr, ptr @.amice.vm.native_table.module.helper_add.n4.h711399579d9648e0, i64 %native.table.index1610
  %native.thunk1612 = load ptr, ptr %native.slot1611, align 8
  %native.ret1613 = call { i64, i64, i64, i64, i64, i64, i64, i64 } %native.thunk1612(i64 %native.arg1588, i64 %native.arg1590, i64 %native.arg1592, i64 %native.arg1594, i64 %native.arg1596, i64 %native.arg1598, i64 %native.arg1600, i64 %native.arg1602)
  %native.ret0.value1614 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 0
  %width.is641615 = icmp eq i64 %call_native.ret0_width1572, 64
  %width.shift1616 = and i64 %call_native.ret0_width1572, 63
  %mask.shifted1617 = shl i64 1, %width.shift1616
  %mask.candidate1618 = sub i64 %mask.shifted1617, 1
  %width.mask1619 = select i1 %width.is641615, i64 -1, i64 %mask.candidate1618
  %width.masked1620 = and i64 %native.ret0.value1614, %width.mask1619
  %native.ret1.value1621 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 1
  %width.is641622 = icmp eq i64 %call_native.ret1_width1574, 64
  %width.shift1623 = and i64 %call_native.ret1_width1574, 63
  %mask.shifted1624 = shl i64 1, %width.shift1623
  %mask.candidate1625 = sub i64 %mask.shifted1624, 1
  %width.mask1626 = select i1 %width.is641622, i64 -1, i64 %mask.candidate1625
  %width.masked1627 = and i64 %native.ret1.value1621, %width.mask1626
  %native.ret2.value1628 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 2
  %width.is641629 = icmp eq i64 %call_native.ret2_width1576, 64
  %width.shift1630 = and i64 %call_native.ret2_width1576, 63
  %mask.shifted1631 = shl i64 1, %width.shift1630
  %mask.candidate1632 = sub i64 %mask.shifted1631, 1
  %width.mask1633 = select i1 %width.is641629, i64 -1, i64 %mask.candidate1632
  %width.masked1634 = and i64 %native.ret2.value1628, %width.mask1633
  %native.ret3.value1635 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 3
  %width.is641636 = icmp eq i64 %call_native.ret3_width1578, 64
  %width.shift1637 = and i64 %call_native.ret3_width1578, 63
  %mask.shifted1638 = shl i64 1, %width.shift1637
  %mask.candidate1639 = sub i64 %mask.shifted1638, 1
  %width.mask1640 = select i1 %width.is641636, i64 -1, i64 %mask.candidate1639
  %width.masked1641 = and i64 %native.ret3.value1635, %width.mask1640
  %native.ret4.value1642 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 4
  %width.is641643 = icmp eq i64 %call_native.ret4_width1580, 64
  %width.shift1644 = and i64 %call_native.ret4_width1580, 63
  %mask.shifted1645 = shl i64 1, %width.shift1644
  %mask.candidate1646 = sub i64 %mask.shifted1645, 1
  %width.mask1647 = select i1 %width.is641643, i64 -1, i64 %mask.candidate1646
  %width.masked1648 = and i64 %native.ret4.value1642, %width.mask1647
  %native.ret5.value1649 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 5
  %width.is641650 = icmp eq i64 %call_native.ret5_width1582, 64
  %width.shift1651 = and i64 %call_native.ret5_width1582, 63
  %mask.shifted1652 = shl i64 1, %width.shift1651
  %mask.candidate1653 = sub i64 %mask.shifted1652, 1
  %width.mask1654 = select i1 %width.is641650, i64 -1, i64 %mask.candidate1653
  %width.masked1655 = and i64 %native.ret5.value1649, %width.mask1654
  %native.ret6.value1656 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 6
  %width.is641657 = icmp eq i64 %call_native.ret6_width1584, 64
  %width.shift1658 = and i64 %call_native.ret6_width1584, 63
  %mask.shifted1659 = shl i64 1, %width.shift1658
  %mask.candidate1660 = sub i64 %mask.shifted1659, 1
  %width.mask1661 = select i1 %width.is641657, i64 -1, i64 %mask.candidate1660
  %width.masked1662 = and i64 %native.ret6.value1656, %width.mask1661
  %native.ret7.value1663 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %native.ret1613, 7
  %width.is641664 = icmp eq i64 %call_native.ret7_width1586, 64
  %width.shift1665 = and i64 %call_native.ret7_width1586, 63
  %mask.shifted1666 = shl i64 1, %width.shift1665
  %mask.candidate1667 = sub i64 %mask.shifted1666, 1
  %width.mask1668 = select i1 %width.is641664, i64 -1, i64 %mask.candidate1667
  %width.masked1669 = and i64 %native.ret7.value1663, %width.mask1668
  %native.has.ret01673 = icmp uge i64 %call_native.ret_count1570, 1
  br i1 %native.has.ret01673, label %native.ret0.store1671, label %native.store.done1670

native.done1604:                                  ; preds = %native.store.done1670, %handler.call_native.op73.split.body
  %pc.old1702 = load i64, ptr %pc, align 8
  %pc.next1703 = add i64 %pc.old1702, 64
  store i64 %pc.next1703, ptr %pc, align 8
  br label %loop.check

native.store.done1670:                            ; preds = %native.ret7.store1699, %native.ret7.check1696, %native.ret6.check1692, %native.ret5.check1688, %native.ret4.check1684, %native.ret3.check1680, %native.ret2.check1676, %native.ret1.check1672, %native.call1603
  br label %native.done1604

native.ret0.store1671:                            ; preds = %native.call1603
  %reg.store.ptr1674 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret01571
  store i64 %width.masked1620, ptr %reg.store.ptr1674, align 8
  br label %native.ret1.check1672

native.ret1.check1672:                            ; preds = %native.ret0.store1671
  %native.has.ret11677 = icmp uge i64 %call_native.ret_count1570, 2
  br i1 %native.has.ret11677, label %native.ret1.store1675, label %native.store.done1670

native.ret1.store1675:                            ; preds = %native.ret1.check1672
  %reg.store.ptr1678 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret11573
  store i64 %width.masked1627, ptr %reg.store.ptr1678, align 8
  br label %native.ret2.check1676

native.ret2.check1676:                            ; preds = %native.ret1.store1675
  %native.has.ret21681 = icmp uge i64 %call_native.ret_count1570, 3
  br i1 %native.has.ret21681, label %native.ret2.store1679, label %native.store.done1670

native.ret2.store1679:                            ; preds = %native.ret2.check1676
  %reg.store.ptr1682 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret21575
  store i64 %width.masked1634, ptr %reg.store.ptr1682, align 8
  br label %native.ret3.check1680

native.ret3.check1680:                            ; preds = %native.ret2.store1679
  %native.has.ret31685 = icmp uge i64 %call_native.ret_count1570, 4
  br i1 %native.has.ret31685, label %native.ret3.store1683, label %native.store.done1670

native.ret3.store1683:                            ; preds = %native.ret3.check1680
  %reg.store.ptr1686 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret31577
  store i64 %width.masked1641, ptr %reg.store.ptr1686, align 8
  br label %native.ret4.check1684

native.ret4.check1684:                            ; preds = %native.ret3.store1683
  %native.has.ret41689 = icmp uge i64 %call_native.ret_count1570, 5
  br i1 %native.has.ret41689, label %native.ret4.store1687, label %native.store.done1670

native.ret4.store1687:                            ; preds = %native.ret4.check1684
  %reg.store.ptr1690 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret41579
  store i64 %width.masked1648, ptr %reg.store.ptr1690, align 8
  br label %native.ret5.check1688

native.ret5.check1688:                            ; preds = %native.ret4.store1687
  %native.has.ret51693 = icmp uge i64 %call_native.ret_count1570, 6
  br i1 %native.has.ret51693, label %native.ret5.store1691, label %native.store.done1670

native.ret5.store1691:                            ; preds = %native.ret5.check1688
  %reg.store.ptr1694 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret51581
  store i64 %width.masked1655, ptr %reg.store.ptr1694, align 8
  br label %native.ret6.check1692

native.ret6.check1692:                            ; preds = %native.ret5.store1691
  %native.has.ret61697 = icmp uge i64 %call_native.ret_count1570, 7
  br i1 %native.has.ret61697, label %native.ret6.store1695, label %native.store.done1670

native.ret6.store1695:                            ; preds = %native.ret6.check1692
  %reg.store.ptr1698 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret61583
  store i64 %width.masked1662, ptr %reg.store.ptr1698, align 8
  br label %native.ret7.check1696

native.ret7.check1696:                            ; preds = %native.ret6.store1695
  %native.has.ret71700 = icmp uge i64 %call_native.ret_count1570, 8
  br i1 %native.has.ret71700, label %native.ret7.store1699, label %native.store.done1670

native.ret7.store1699:                            ; preds = %native.ret7.check1696
  %reg.store.ptr1701 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %call_native.ret71585
  store i64 %width.masked1669, ptr %reg.store.ptr1701, align 8
  br label %native.store.done1670

handler.iuadd_sat.op870.split.entry:              ; preds = %execute.decode
  br label %handler.iuadd_sat.op870.split.body

handler.iuadd_sat.op870.split.body:               ; preds = %handler.iuadd_sat.op870.split.entry
  %dead.alias.pc1704 = load i64, ptr %pc, align 8
  %dead.alias.next1705 = add i64 %dead.alias.pc1704, 32
  store i64 %dead.alias.next1705, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_udec_wrap.op942.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_udec_wrap.op942.split.body

handler.atomic_rmw_udec_wrap.op942.split.body:    ; preds = %handler.atomic_rmw_udec_wrap.op942.split.entry
  %dead.alias.pc1706 = load i64, ptr %pc, align 8
  %dead.alias.next1707 = add i64 %dead.alias.pc1706, 32
  store i64 %dead.alias.next1707, ptr %pc, align 8
  br label %loop.check

handler.frem.opac.split.entry:                    ; preds = %execute.decode
  br label %handler.frem.opac.split.body

handler.frem.opac.split.body:                     ; preds = %handler.frem.opac.split.entry
  %dead.alias.pc1708 = load i64, ptr %pc, align 8
  %dead.alias.next1709 = add i64 %dead.alias.pc1708, 32
  store i64 %dead.alias.next1709, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_nand.op95f.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_nand.op95f.split.body

handler.volatile_atomic_rmw_nand.op95f.split.body: ; preds = %handler.volatile_atomic_rmw_nand.op95f.split.entry
  %dead.alias.pc1710 = load i64, ptr %pc, align 8
  %dead.alias.next1711 = add i64 %dead.alias.pc1710, 32
  store i64 %dead.alias.next1711, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_or.ope9.split.entry:           ; preds = %execute.decode
  br label %handler.atomic_rmw_or.ope9.split.body

handler.atomic_rmw_or.ope9.split.body:            ; preds = %handler.atomic_rmw_or.ope9.split.entry
  %dead.alias.pc1712 = load i64, ptr %pc, align 8
  %dead.alias.next1713 = add i64 %dead.alias.pc1712, 32
  store i64 %dead.alias.next1713, ptr %pc, align 8
  br label %loop.check

handler.fllround.op73d.split.entry:               ; preds = %execute.decode
  br label %handler.fllround.op73d.split.body

handler.fllround.op73d.split.body:                ; preds = %handler.fllround.op73d.split.entry
  %dead.alias.pc1714 = load i64, ptr %pc, align 8
  %dead.alias.next1715 = add i64 %dead.alias.pc1714, 16
  store i64 %dead.alias.next1715, ptr %pc, align 8
  br label %loop.check

handler.gep.op37.split.entry:                     ; preds = %execute.decode
  br label %handler.gep.op37.split.body

handler.gep.op37.split.body:                      ; preds = %handler.gep.op37.split.entry
  %dead.alias.pc1716 = load i64, ptr %pc, align 8
  %dead.alias.next1717 = add i64 %dead.alias.pc1716, 32
  store i64 %dead.alias.next1717, ptr %pc, align 8
  br label %loop.check

handler.ixor.op21.split.entry:                    ; preds = %execute.decode
  br label %handler.ixor.op21.split.body

handler.ixor.op21.split.body:                     ; preds = %handler.ixor.op21.split.entry
  %dead.alias.pc1718 = load i64, ptr %pc, align 8
  %dead.alias.next1719 = add i64 %dead.alias.pc1718, 32
  store i64 %dead.alias.next1719, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_and.ope7.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_and.ope7.split.body

handler.atomic_rmw_and.ope7.split.body:           ; preds = %handler.atomic_rmw_and.ope7.split.entry
  %dead.alias.pc1720 = load i64, ptr %pc, align 8
  %dead.alias.next1721 = add i64 %dead.alias.pc1720, 32
  store i64 %dead.alias.next1721, ptr %pc, align 8
  br label %loop.check

handler.fmul.opa0.split.entry:                    ; preds = %execute.decode
  br label %handler.fmul.opa0.split.body

handler.fmul.opa0.split.body:                     ; preds = %handler.fmul.opa0.split.entry
  %dead.alias.pc1722 = load i64, ptr %pc, align 8
  %dead.alias.next1723 = add i64 %dead.alias.pc1722, 32
  store i64 %dead.alias.next1723, ptr %pc, align 8
  br label %loop.check

handler.memmove_dyn.op917.split.entry:            ; preds = %execute.decode
  br label %handler.memmove_dyn.op917.split.body

handler.memmove_dyn.op917.split.body:             ; preds = %handler.memmove_dyn.op917.split.entry
  %dead.alias.pc1724 = load i64, ptr %pc, align 8
  %dead.alias.next1725 = add i64 %dead.alias.pc1724, 8
  store i64 %dead.alias.next1725, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xor.op95e.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xor.op95e.split.body

handler.volatile_atomic_rmw_xor.op95e.split.body: ; preds = %handler.volatile_atomic_rmw_xor.op95e.split.entry
  %dead.alias.pc1726 = load i64, ptr %pc, align 8
  %dead.alias.next1727 = add i64 %dead.alias.pc1726, 32
  store i64 %dead.alias.next1727, ptr %pc, align 8
  br label %loop.check

handler.fmul.op89b.split.entry:                   ; preds = %execute.decode
  br label %handler.fmul.op89b.split.body

handler.fmul.op89b.split.body:                    ; preds = %handler.fmul.op89b.split.entry
  %dead.alias.pc1728 = load i64, ptr %pc, align 8
  %dead.alias.next1729 = add i64 %dead.alias.pc1728, 32
  store i64 %dead.alias.next1729, ptr %pc, align 8
  br label %loop.check

handler.load_iumin.op99f.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumin.op99f.split.body

handler.load_iumin.op99f.split.body:              ; preds = %handler.load_iumin.op99f.split.entry
  %dead.alias.pc1730 = load i64, ptr %pc, align 8
  %dead.alias.next1731 = add i64 %dead.alias.pc1730, 32
  store i64 %dead.alias.next1731, ptr %pc, align 8
  br label %loop.check

handler.fsqrt.op707.split.entry:                  ; preds = %execute.decode
  br label %handler.fsqrt.op707.split.body

handler.fsqrt.op707.split.body:                   ; preds = %handler.fsqrt.op707.split.entry
  %dead.alias.pc1732 = load i64, ptr %pc, align 8
  %dead.alias.next1733 = add i64 %dead.alias.pc1732, 32
  store i64 %dead.alias.next1733, ptr %pc, align 8
  br label %loop.check

handler.fabs.op8b1.split.entry:                   ; preds = %execute.decode
  br label %handler.fabs.op8b1.split.body

handler.fabs.op8b1.split.body:                    ; preds = %handler.fabs.op8b1.split.entry
  %dead.alias.pc1734 = load i64, ptr %pc, align 8
  %dead.alias.next1735 = add i64 %dead.alias.pc1734, 32
  store i64 %dead.alias.next1735, ptr %pc, align 8
  br label %loop.check

handler.issub_overflow.op133.split.entry:         ; preds = %execute.decode
  br label %handler.issub_overflow.op133.split.body

handler.issub_overflow.op133.split.body:          ; preds = %handler.issub_overflow.op133.split.entry
  %dead.alias.pc1736 = load i64, ptr %pc, align 8
  %dead.alias.next1737 = add i64 %dead.alias.pc1736, 32
  store i64 %dead.alias.next1737, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_max.op937.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_max.op937.split.body

handler.atomic_rmw_max.op937.split.body:          ; preds = %handler.atomic_rmw_max.op937.split.entry
  %dead.alias.pc1738 = load i64, ptr %pc, align 8
  %dead.alias.next1739 = add i64 %dead.alias.pc1738, 32
  store i64 %dead.alias.next1739, ptr %pc, align 8
  br label %loop.check

handler.ismax.op11a.split.entry:                  ; preds = %execute.decode
  br label %handler.ismax.op11a.split.body

handler.ismax.op11a.split.body:                   ; preds = %handler.ismax.op11a.split.entry
  %dead.alias.pc1740 = load i64, ptr %pc, align 8
  %dead.alias.next1741 = add i64 %dead.alias.pc1740, 32
  store i64 %dead.alias.next1741, ptr %pc, align 8
  br label %loop.check

handler.fcos.op727.split.entry:                   ; preds = %execute.decode
  br label %handler.fcos.op727.split.body

handler.fcos.op727.split.body:                    ; preds = %handler.fcos.op727.split.entry
  %dead.alias.pc1742 = load i64, ptr %pc, align 8
  %dead.alias.next1743 = add i64 %dead.alias.pc1742, 32
  store i64 %dead.alias.next1743, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_xchg.op181.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_xchg.op181.split.body

handler.volatile_atomic_rmw_xchg.op181.split.body: ; preds = %handler.volatile_atomic_rmw_xchg.op181.split.entry
  %dead.alias.pc1744 = load i64, ptr %pc, align 8
  %dead.alias.next1745 = add i64 %dead.alias.pc1744, 32
  store i64 %dead.alias.next1745, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmaximum.op950.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fmaximum.op950.split.body

handler.atomic_rmw_fmaximum.op950.split.body:     ; preds = %handler.atomic_rmw_fmaximum.op950.split.entry
  %dead.alias.pc1746 = load i64, ptr %pc, align 8
  %dead.alias.next1747 = add i64 %dead.alias.pc1746, 32
  store i64 %dead.alias.next1747, ptr %pc, align 8
  br label %loop.check

handler.iadd_xor.op83c.split.entry:               ; preds = %execute.decode
  br label %handler.iadd_xor.op83c.split.body

handler.iadd_xor.op83c.split.body:                ; preds = %handler.iadd_xor.op83c.split.entry
  %dead.alias.pc1748 = load i64, ptr %pc, align 8
  %dead.alias.next1749 = add i64 %dead.alias.pc1748, 48
  store i64 %dead.alias.next1749, ptr %pc, align 8
  br label %loop.check

handler.load_iudiv.op98b.split.entry:             ; preds = %execute.decode
  br label %handler.load_iudiv.op98b.split.body

handler.load_iudiv.op98b.split.body:              ; preds = %handler.load_iudiv.op98b.split.entry
  %dead.alias.pc1750 = load i64, ptr %pc, align 8
  %dead.alias.next1751 = add i64 %dead.alias.pc1750, 32
  store i64 %dead.alias.next1751, ptr %pc, align 8
  br label %loop.check

handler.flrint.op737.split.entry:                 ; preds = %execute.decode
  br label %handler.flrint.op737.split.body

handler.flrint.op737.split.body:                  ; preds = %handler.flrint.op737.split.entry
  %dead.alias.pc1752 = load i64, ptr %pc, align 8
  %dead.alias.next1753 = add i64 %dead.alias.pc1752, 16
  store i64 %dead.alias.next1753, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_load.op925.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_atomic_load.op925.split.body

handler.volatile_atomic_load.op925.split.body:    ; preds = %handler.volatile_atomic_load.op925.split.entry
  %dead.alias.pc1754 = load i64, ptr %pc, align 8
  %dead.alias.next1755 = add i64 %dead.alias.pc1754, 32
  store i64 %dead.alias.next1755, ptr %pc, align 8
  br label %loop.check

handler.fence.opee.split.entry:                   ; preds = %execute.decode
  br label %handler.fence.opee.split.body

handler.fence.opee.split.body:                    ; preds = %handler.fence.opee.split.entry
  %dead.alias.pc1756 = load i64, ptr %pc, align 8
  %dead.alias.next1757 = add i64 %dead.alias.pc1756, 32
  store i64 %dead.alias.next1757, ptr %pc, align 8
  br label %loop.check

handler.frem.opaa.split.entry:                    ; preds = %execute.decode
  br label %handler.frem.opaa.split.body

handler.frem.opaa.split.body:                     ; preds = %handler.frem.opaa.split.entry
  %dead.alias.pc1758 = load i64, ptr %pc, align 8
  %dead.alias.next1759 = add i64 %dead.alias.pc1758, 32
  store i64 %dead.alias.next1759, ptr %pc, align 8
  br label %loop.check

handler.fake_nop.op07.split.entry:                ; preds = %execute.decode
  br label %handler.fake_nop.op07.split.body

handler.fake_nop.op07.split.body:                 ; preds = %handler.fake_nop.op07.split.entry
  %pc.old1760 = load i64, ptr %pc, align 8
  %pc.next1761 = add i64 %pc.old1760, 4
  store i64 %pc.next1761, ptr %pc, align 8
  br label %loop.check

handler.read_fpenv.op823.split.entry:             ; preds = %execute.decode
  br label %handler.read_fpenv.op823.split.body

handler.read_fpenv.op823.split.body:              ; preds = %handler.read_fpenv.op823.split.entry
  %dead.alias.pc1762 = load i64, ptr %pc, align 8
  %dead.alias.next1763 = add i64 %dead.alias.pc1762, 8
  store i64 %dead.alias.next1763, ptr %pc, align 8
  br label %loop.check

handler.br.op67.split.entry:                      ; preds = %execute.decode
  br label %handler.br.op67.split.body

handler.br.op67.split.body:                       ; preds = %handler.br.op67.split.entry
  %dead.alias.pc1764 = load i64, ptr %pc, align 8
  %dead.alias.next1765 = add i64 %dead.alias.pc1764, 32
  store i64 %dead.alias.next1765, ptr %pc, align 8
  br label %loop.check

handler.br.op4c.split.entry:                      ; preds = %execute.decode
  br label %handler.br.op4c.split.body

handler.br.op4c.split.body:                       ; preds = %handler.br.op4c.split.entry
  %dead.alias.pc1766 = load i64, ptr %pc, align 8
  %dead.alias.next1767 = add i64 %dead.alias.pc1766, 32
  store i64 %dead.alias.next1767, ptr %pc, align 8
  br label %loop.check

handler.fcanonicalize.op8b5.split.entry:          ; preds = %execute.decode
  br label %handler.fcanonicalize.op8b5.split.body

handler.fcanonicalize.op8b5.split.body:           ; preds = %handler.fcanonicalize.op8b5.split.entry
  %dead.alias.pc1768 = load i64, ptr %pc, align 8
  %dead.alias.next1769 = add i64 %dead.alias.pc1768, 32
  store i64 %dead.alias.next1769, ptr %pc, align 8
  br label %loop.check

handler.uitofp.op8d9.split.entry:                 ; preds = %execute.decode
  br label %handler.uitofp.op8d9.split.body

handler.uitofp.op8d9.split.body:                  ; preds = %handler.uitofp.op8d9.split.entry
  %dead.alias.pc1770 = load i64, ptr %pc, align 8
  %dead.alias.next1771 = add i64 %dead.alias.pc1770, 32
  store i64 %dead.alias.next1771, ptr %pc, align 8
  br label %loop.check

handler.iumax.op11d.split.entry:                  ; preds = %execute.decode
  br label %handler.iumax.op11d.split.body

handler.iumax.op11d.split.body:                   ; preds = %handler.iumax.op11d.split.entry
  %dead.alias.pc1772 = load i64, ptr %pc, align 8
  %dead.alias.next1773 = add i64 %dead.alias.pc1772, 32
  store i64 %dead.alias.next1773, ptr %pc, align 8
  br label %loop.check

handler.isadd_overflow.op12f.split.entry:         ; preds = %execute.decode
  br label %handler.isadd_overflow.op12f.split.body

handler.isadd_overflow.op12f.split.body:          ; preds = %handler.isadd_overflow.op12f.split.entry
  %dead.alias.pc1774 = load i64, ptr %pc, align 8
  %dead.alias.next1775 = add i64 %dead.alias.pc1774, 32
  store i64 %dead.alias.next1775, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fminimum.op1a8.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fminimum.op1a8.split.body

handler.volatile_atomic_rmw_fminimum.op1a8.split.body: ; preds = %handler.volatile_atomic_rmw_fminimum.op1a8.split.entry
  %dead.alias.pc1776 = load i64, ptr %pc, align 8
  %dead.alias.next1777 = add i64 %dead.alias.pc1776, 32
  store i64 %dead.alias.next1777, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fadd.op972.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fadd.op972.split.body

handler.volatile_atomic_rmw_fadd.op972.split.body: ; preds = %handler.volatile_atomic_rmw_fadd.op972.split.entry
  %dead.alias.pc1778 = load i64, ptr %pc, align 8
  %dead.alias.next1779 = add i64 %dead.alias.pc1778, 32
  store i64 %dead.alias.next1779, ptr %pc, align 8
  br label %loop.check

handler.iusub_overflow.op880.split.entry:         ; preds = %execute.decode
  br label %handler.iusub_overflow.op880.split.body

handler.iusub_overflow.op880.split.body:          ; preds = %handler.iusub_overflow.op880.split.entry
  %dead.alias.pc1780 = load i64, ptr %pc, align 8
  %dead.alias.next1781 = add i64 %dead.alias.pc1780, 32
  store i64 %dead.alias.next1781, ptr %pc, align 8
  br label %loop.check

handler.stackrestore.op1b2.split.entry:           ; preds = %execute.decode
  br label %handler.stackrestore.op1b2.split.body

handler.stackrestore.op1b2.split.body:            ; preds = %handler.stackrestore.op1b2.split.entry
  %dead.alias.pc1782 = load i64, ptr %pc, align 8
  %dead.alias.next1783 = add i64 %dead.alias.pc1782, 8
  store i64 %dead.alias.next1783, ptr %pc, align 8
  br label %loop.check

handler.frint.op8bd.split.entry:                  ; preds = %execute.decode
  br label %handler.frint.op8bd.split.body

handler.frint.op8bd.split.body:                   ; preds = %handler.frint.op8bd.split.entry
  %dead.alias.pc1784 = load i64, ptr %pc, align 8
  %dead.alias.next1785 = add i64 %dead.alias.pc1784, 32
  store i64 %dead.alias.next1785, ptr %pc, align 8
  br label %loop.check

handler.ismax.op866.split.entry:                  ; preds = %execute.decode
  br label %handler.ismax.op866.split.body

handler.ismax.op866.split.body:                   ; preds = %handler.ismax.op866.split.entry
  %dead.alias.pc1786 = load i64, ptr %pc, align 8
  %dead.alias.next1787 = add i64 %dead.alias.pc1786, 32
  store i64 %dead.alias.next1787, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_sub.op92e.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_sub.op92e.split.body

handler.atomic_rmw_sub.op92e.split.body:          ; preds = %handler.atomic_rmw_sub.op92e.split.entry
  %dead.alias.pc1788 = load i64, ptr %pc, align 8
  %dead.alias.next1789 = add i64 %dead.alias.pc1788, 32
  store i64 %dead.alias.next1789, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op0e.split.entry:                 ; preds = %execute.decode
  br label %handler.mov_imm.op0e.split.body

handler.mov_imm.op0e.split.body:                  ; preds = %handler.mov_imm.op0e.split.entry
  %dead.alias.pc1790 = load i64, ptr %pc, align 8
  %dead.alias.next1791 = add i64 %dead.alias.pc1790, 32
  store i64 %dead.alias.next1791, ptr %pc, align 8
  br label %loop.check

handler.fake_nop.op9b8.split.entry:               ; preds = %execute.decode
  br label %handler.fake_nop.op9b8.split.body

handler.fake_nop.op9b8.split.body:                ; preds = %handler.fake_nop.op9b8.split.entry
  %pc.old1792 = load i64, ptr %pc, align 8
  %pc.next1793 = add i64 %pc.old1792, 4
  store i64 %pc.next1793, ptr %pc, align 8
  br label %loop.check

handler.global_addr.op80d.split.entry:            ; preds = %execute.decode
  br label %handler.global_addr.op80d.split.body

handler.global_addr.op80d.split.body:             ; preds = %handler.global_addr.op80d.split.entry
  %dead.alias.pc1794 = load i64, ptr %pc, align 8
  %dead.alias.next1795 = add i64 %dead.alias.pc1794, 8
  store i64 %dead.alias.next1795, ptr %pc, align 8
  br label %loop.check

handler.issub_sat.op876.split.entry:              ; preds = %execute.decode
  br label %handler.issub_sat.op876.split.body

handler.issub_sat.op876.split.body:               ; preds = %handler.issub_sat.op876.split.entry
  %dead.alias.pc1796 = load i64, ptr %pc, align 8
  %dead.alias.next1797 = add i64 %dead.alias.pc1796, 32
  store i64 %dead.alias.next1797, ptr %pc, align 8
  br label %loop.check

handler.store.op912.split.entry:                  ; preds = %execute.decode
  br label %handler.store.op912.split.body

handler.store.op912.split.body:                   ; preds = %handler.store.op912.split.entry
  %dead.alias.pc1798 = load i64, ptr %pc, align 8
  %dead.alias.next1799 = add i64 %dead.alias.pc1798, 32
  store i64 %dead.alias.next1799, ptr %pc, align 8
  br label %loop.check

handler.prefetch.op90b.split.entry:               ; preds = %execute.decode
  br label %handler.prefetch.op90b.split.body

handler.prefetch.op90b.split.body:                ; preds = %handler.prefetch.op90b.split.entry
  %dead.alias.pc1800 = load i64, ptr %pc, align 8
  %dead.alias.next1801 = add i64 %dead.alias.pc1800, 16
  store i64 %dead.alias.next1801, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmin.op167.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmin.op167.split.body

handler.atomic_rmw_fmin.op167.split.body:         ; preds = %handler.atomic_rmw_fmin.op167.split.entry
  %dead.alias.pc1802 = load i64, ptr %pc, align 8
  %dead.alias.next1803 = add i64 %dead.alias.pc1802, 32
  store i64 %dead.alias.next1803, ptr %pc, align 8
  br label %loop.check

handler.iuadd_sat.op122.split.entry:              ; preds = %execute.decode
  br label %handler.iuadd_sat.op122.split.body

handler.iuadd_sat.op122.split.body:               ; preds = %handler.iuadd_sat.op122.split.entry
  %dead.alias.pc1804 = load i64, ptr %pc, align 8
  %dead.alias.next1805 = add i64 %dead.alias.pc1804, 32
  store i64 %dead.alias.next1805, ptr %pc, align 8
  br label %loop.check

handler.ftrunc.op71a.split.entry:                 ; preds = %execute.decode
  br label %handler.ftrunc.op71a.split.body

handler.ftrunc.op71a.split.body:                  ; preds = %handler.ftrunc.op71a.split.entry
  %dead.alias.pc1806 = load i64, ptr %pc, align 8
  %dead.alias.next1807 = add i64 %dead.alias.pc1806, 32
  store i64 %dead.alias.next1807, ptr %pc, align 8
  br label %loop.check

handler.imul.op12.split.entry:                    ; preds = %execute.decode
  br label %handler.imul.op12.split.body

handler.imul.op12.split.body:                     ; preds = %handler.imul.op12.split.entry
  %imul.dst1808 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %imul.lhs1809 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %imul.rhs1810 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %imul.width1811 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1812 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %imul.lhs1809
  %lhs1813 = load i64, ptr %reg.load.ptr1812, align 8
  %reg.load.ptr1814 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %imul.rhs1810
  %rhs1815 = load i64, ptr %reg.load.ptr1814, align 8
  %shift.masked1816 = and i64 %rhs1815, 63
  %bin.mul1817 = mul i64 %lhs1813, %rhs1815
  %width.is641818 = icmp eq i64 %imul.width1811, 64
  %width.shift1819 = and i64 %imul.width1811, 63
  %mask.shifted1820 = shl i64 1, %width.shift1819
  %mask.candidate1821 = sub i64 %mask.shifted1820, 1
  %width.mask1822 = select i1 %width.is641818, i64 -1, i64 %mask.candidate1821
  %width.masked1823 = and i64 %bin.mul1817, %width.mask1822
  %reg.store.ptr1824 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %imul.dst1808
  store i64 %width.masked1823, ptr %reg.store.ptr1824, align 8
  %pc.old1825 = load i64, ptr %pc, align 8
  %pc.next1826 = add i64 %pc.old1825, 32
  store i64 %pc.next1826, ptr %pc, align 8
  br label %loop.check

handler.issub_sat.op127.split.entry:              ; preds = %execute.decode
  br label %handler.issub_sat.op127.split.body

handler.issub_sat.op127.split.body:               ; preds = %handler.issub_sat.op127.split.entry
  %dead.alias.pc1827 = load i64, ptr %pc, align 8
  %dead.alias.next1828 = add i64 %dead.alias.pc1827, 32
  store i64 %dead.alias.next1828, ptr %pc, align 8
  br label %loop.check

handler.fpowi.op8a6.split.entry:                  ; preds = %execute.decode
  br label %handler.fpowi.op8a6.split.body

handler.fpowi.op8a6.split.body:                   ; preds = %handler.fpowi.op8a6.split.entry
  %dead.alias.pc1829 = load i64, ptr %pc, align 8
  %dead.alias.next1830 = add i64 %dead.alias.pc1829, 16
  store i64 %dead.alias.next1830, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op4e.split.entry:                   ; preds = %execute.decode
  br label %handler.ilshr.op4e.split.body

handler.ilshr.op4e.split.body:                    ; preds = %handler.ilshr.op4e.split.entry
  %dead.alias.pc1831 = load i64, ptr %pc, align 8
  %dead.alias.next1832 = add i64 %dead.alias.pc1831, 32
  store i64 %dead.alias.next1832, ptr %pc, align 8
  br label %loop.check

handler.vm_ret.op44.split.entry:                  ; preds = %execute.decode
  br label %handler.vm_ret.op44.split.body

handler.vm_ret.op44.split.body:                   ; preds = %handler.vm_ret.op44.split.entry
  %dead.alias.pc1833 = load i64, ptr %pc, align 8
  %dead.alias.next1834 = add i64 %dead.alias.pc1833, 32
  store i64 %dead.alias.next1834, ptr %pc, align 8
  br label %loop.check

handler.frint.op71d.split.entry:                  ; preds = %execute.decode
  br label %handler.frint.op71d.split.body

handler.frint.op71d.split.body:                   ; preds = %handler.frint.op71d.split.entry
  %dead.alias.pc1835 = load i64, ptr %pc, align 8
  %dead.alias.next1836 = add i64 %dead.alias.pc1835, 32
  store i64 %dead.alias.next1836, ptr %pc, align 8
  br label %loop.check

handler.memset_dyn.op91a.split.entry:             ; preds = %execute.decode
  br label %handler.memset_dyn.op91a.split.body

handler.memset_dyn.op91a.split.body:              ; preds = %handler.memset_dyn.op91a.split.entry
  %dead.alias.pc1837 = load i64, ptr %pc, align 8
  %dead.alias.next1838 = add i64 %dead.alias.pc1837, 8
  store i64 %dead.alias.next1838, ptr %pc, align 8
  br label %loop.check

handler.fshl.op108.split.entry:                   ; preds = %execute.decode
  br label %handler.fshl.op108.split.body

handler.fshl.op108.split.body:                    ; preds = %handler.fshl.op108.split.entry
  %dead.alias.pc1839 = load i64, ptr %pc, align 8
  %dead.alias.next1840 = add i64 %dead.alias.pc1839, 48
  store i64 %dead.alias.next1840, ptr %pc, align 8
  br label %loop.check

handler.load_imul.op1d8.split.entry:              ; preds = %execute.decode
  br label %handler.load_imul.op1d8.split.body

handler.load_imul.op1d8.split.body:               ; preds = %handler.load_imul.op1d8.split.entry
  %dead.alias.pc1841 = load i64, ptr %pc, align 8
  %dead.alias.next1842 = add i64 %dead.alias.pc1841, 32
  store i64 %dead.alias.next1842, ptr %pc, align 8
  br label %loop.check

handler.write_rounding.op81f.split.entry:         ; preds = %execute.decode
  br label %handler.write_rounding.op81f.split.body

handler.write_rounding.op81f.split.body:          ; preds = %handler.write_rounding.op81f.split.entry
  %dead.alias.pc1843 = load i64, ptr %pc, align 8
  %dead.alias.next1844 = add i64 %dead.alias.pc1843, 8
  store i64 %dead.alias.next1844, ptr %pc, align 8
  br label %loop.check

handler.load_iushl_sat.op9a9.split.entry:         ; preds = %execute.decode
  br label %handler.load_iushl_sat.op9a9.split.body

handler.load_iushl_sat.op9a9.split.body:          ; preds = %handler.load_iushl_sat.op9a9.split.entry
  %dead.alias.pc1845 = load i64, ptr %pc, align 8
  %dead.alias.next1846 = add i64 %dead.alias.pc1845, 32
  store i64 %dead.alias.next1846, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xchg.ope1.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_xchg.ope1.split.body

handler.atomic_rmw_xchg.ope1.split.body:          ; preds = %handler.atomic_rmw_xchg.ope1.split.entry
  %dead.alias.pc1847 = load i64, ptr %pc, align 8
  %dead.alias.next1848 = add i64 %dead.alias.pc1847, 32
  store i64 %dead.alias.next1848, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op846.split.entry:                  ; preds = %execute.decode
  br label %handler.iudiv.op846.split.body

handler.iudiv.op846.split.body:                   ; preds = %handler.iudiv.op846.split.entry
  %dead.alias.pc1849 = load i64, ptr %pc, align 8
  %dead.alias.next1850 = add i64 %dead.alias.pc1849, 32
  store i64 %dead.alias.next1850, ptr %pc, align 8
  br label %loop.check

handler.icmp_br_if.op10d.split.entry:             ; preds = %execute.decode
  br label %handler.icmp_br_if.op10d.split.body

handler.icmp_br_if.op10d.split.body:              ; preds = %handler.icmp_br_if.op10d.split.entry
  %dead.alias.pc1851 = load i64, ptr %pc, align 8
  %dead.alias.next1852 = add i64 %dead.alias.pc1851, 32
  store i64 %dead.alias.next1852, ptr %pc, align 8
  br label %loop.check

handler.unreachable.op9c2.split.entry:            ; preds = %execute.decode
  br label %handler.unreachable.op9c2.split.body

handler.unreachable.op9c2.split.body:             ; preds = %handler.unreachable.op9c2.split.entry
  %dead.alias.pc1853 = load i64, ptr %pc, align 8
  %dead.alias.next1854 = add i64 %dead.alias.pc1853, 4
  store i64 %dead.alias.next1854, ptr %pc, align 8
  br label %loop.check

handler.fptosi_sat.op1b9.split.entry:             ; preds = %execute.decode
  br label %handler.fptosi_sat.op1b9.split.body

handler.fptosi_sat.op1b9.split.body:              ; preds = %handler.fptosi_sat.op1b9.split.entry
  %dead.alias.pc1855 = load i64, ptr %pc, align 8
  %dead.alias.next1856 = add i64 %dead.alias.pc1855, 16
  store i64 %dead.alias.next1856, ptr %pc, align 8
  br label %loop.check

handler.iurem.op8b.split.entry:                   ; preds = %execute.decode
  br label %handler.iurem.op8b.split.body

handler.iurem.op8b.split.body:                    ; preds = %handler.iurem.op8b.split.entry
  %dead.alias.pc1857 = load i64, ptr %pc, align 8
  %dead.alias.next1858 = add i64 %dead.alias.pc1857, 32
  store i64 %dead.alias.next1858, ptr %pc, align 8
  br label %loop.check

handler.flog2.op8d1.split.entry:                  ; preds = %execute.decode
  br label %handler.flog2.op8d1.split.body

handler.flog2.op8d1.split.body:                   ; preds = %handler.flog2.op8d1.split.entry
  %dead.alias.pc1859 = load i64, ptr %pc, align 8
  %dead.alias.next1860 = add i64 %dead.alias.pc1859, 32
  store i64 %dead.alias.next1860, ptr %pc, align 8
  br label %loop.check

handler.load_isdiv.op1dd.split.entry:             ; preds = %execute.decode
  br label %handler.load_isdiv.op1dd.split.body

handler.load_isdiv.op1dd.split.body:              ; preds = %handler.load_isdiv.op1dd.split.entry
  %dead.alias.pc1861 = load i64, ptr %pc, align 8
  %dead.alias.next1862 = add i64 %dead.alias.pc1861, 32
  store i64 %dead.alias.next1862, ptr %pc, align 8
  br label %loop.check

handler.ixor.op04.split.entry:                    ; preds = %execute.decode
  br label %handler.ixor.op04.split.body

handler.ixor.op04.split.body:                     ; preds = %handler.ixor.op04.split.entry
  %dead.alias.pc1863 = load i64, ptr %pc, align 8
  %dead.alias.next1864 = add i64 %dead.alias.pc1863, 32
  store i64 %dead.alias.next1864, ptr %pc, align 8
  br label %loop.check

handler.fneg.opb2.split.entry:                    ; preds = %execute.decode
  br label %handler.fneg.opb2.split.body

handler.fneg.opb2.split.body:                     ; preds = %handler.fneg.opb2.split.entry
  %dead.alias.pc1865 = load i64, ptr %pc, align 8
  %dead.alias.next1866 = add i64 %dead.alias.pc1865, 32
  store i64 %dead.alias.next1866, ptr %pc, align 8
  br label %loop.check

handler.load_issub_sat.op1f7.split.entry:         ; preds = %execute.decode
  br label %handler.load_issub_sat.op1f7.split.body

handler.load_issub_sat.op1f7.split.body:          ; preds = %handler.load_issub_sat.op1f7.split.entry
  %dead.alias.pc1867 = load i64, ptr %pc, align 8
  %dead.alias.next1868 = add i64 %dead.alias.pc1867, 32
  store i64 %dead.alias.next1868, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmaximum.op168.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fmaximum.op168.split.body

handler.atomic_rmw_fmaximum.op168.split.body:     ; preds = %handler.atomic_rmw_fmaximum.op168.split.entry
  %dead.alias.pc1869 = load i64, ptr %pc, align 8
  %dead.alias.next1870 = add i64 %dead.alias.pc1869, 32
  store i64 %dead.alias.next1870, ptr %pc, align 8
  br label %loop.check

handler.fsub.op9c.split.entry:                    ; preds = %execute.decode
  br label %handler.fsub.op9c.split.body

handler.fsub.op9c.split.body:                     ; preds = %handler.fsub.op9c.split.entry
  %dead.alias.pc1871 = load i64, ptr %pc, align 8
  %dead.alias.next1872 = add i64 %dead.alias.pc1871, 32
  store i64 %dead.alias.next1872, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op17.split.entry:                   ; preds = %execute.decode
  br label %handler.ilshr.op17.split.body

handler.ilshr.op17.split.body:                    ; preds = %handler.ilshr.op17.split.entry
  %dead.alias.pc1873 = load i64, ptr %pc, align 8
  %dead.alias.next1874 = add i64 %dead.alias.pc1873, 32
  store i64 %dead.alias.next1874, ptr %pc, align 8
  br label %loop.check

handler.load_iumax.op1ed.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumax.op1ed.split.body

handler.load_iumax.op1ed.split.body:              ; preds = %handler.load_iumax.op1ed.split.entry
  %dead.alias.pc1875 = load i64, ptr %pc, align 8
  %dead.alias.next1876 = add i64 %dead.alias.pc1875, 32
  store i64 %dead.alias.next1876, ptr %pc, align 8
  br label %loop.check

handler.ret.op9c5.split.entry:                    ; preds = %execute.decode
  br label %handler.ret.op9c5.split.body

handler.ret.op9c5.split.body:                     ; preds = %handler.ret.op9c5.split.entry
  %dead.alias.pc1877 = load i64, ptr %pc, align 8
  %dead.alias.next1878 = add i64 %dead.alias.pc1877, 4
  store i64 %dead.alias.next1878, ptr %pc, align 8
  br label %loop.check

handler.ret.op0c.split.entry:                     ; preds = %execute.decode
  br label %handler.ret.op0c.split.body

handler.ret.op0c.split.body:                      ; preds = %handler.ret.op0c.split.entry
  %ret.src1879 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1880 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ret.src1879
  %ret.value1881 = load i64, ptr %reg.load.ptr1880, align 8
  %reg.store.ptr1882 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 0
  store i64 %ret.value1881, ptr %reg.store.ptr1882, align 8
  br label %default.return

handler.volatile_atomic_rmw_add.op183.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_add.op183.split.body

handler.volatile_atomic_rmw_add.op183.split.body: ; preds = %handler.volatile_atomic_rmw_add.op183.split.entry
  %dead.alias.pc1883 = load i64, ptr %pc, align 8
  %dead.alias.next1884 = add i64 %dead.alias.pc1883, 32
  store i64 %dead.alias.next1884, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fadd.op160.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fadd.op160.split.body

handler.atomic_rmw_fadd.op160.split.body:         ; preds = %handler.atomic_rmw_fadd.op160.split.entry
  %dead.alias.pc1885 = load i64, ptr %pc, align 8
  %dead.alias.next1886 = add i64 %dead.alias.pc1885, 32
  store i64 %dead.alias.next1886, ptr %pc, align 8
  br label %loop.check

handler.atomic_store.opd9.split.entry:            ; preds = %execute.decode
  br label %handler.atomic_store.opd9.split.body

handler.atomic_store.opd9.split.body:             ; preds = %handler.atomic_store.opd9.split.entry
  %dead.alias.pc1887 = load i64, ptr %pc, align 8
  %dead.alias.next1888 = add i64 %dead.alias.pc1887, 32
  store i64 %dead.alias.next1888, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_sub.ope5.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_sub.ope5.split.body

handler.atomic_rmw_sub.ope5.split.body:           ; preds = %handler.atomic_rmw_sub.ope5.split.entry
  %dead.alias.pc1889 = load i64, ptr %pc, align 8
  %dead.alias.next1890 = add i64 %dead.alias.pc1889, 32
  store i64 %dead.alias.next1890, ptr %pc, align 8
  br label %loop.check

handler.load_iuadd_sat.op1f1.split.entry:         ; preds = %execute.decode
  br label %handler.load_iuadd_sat.op1f1.split.body

handler.load_iuadd_sat.op1f1.split.body:          ; preds = %handler.load_iuadd_sat.op1f1.split.entry
  %dead.alias.pc1891 = load i64, ptr %pc, align 8
  %dead.alias.next1892 = add i64 %dead.alias.pc1891, 32
  store i64 %dead.alias.next1892, ptr %pc, align 8
  br label %loop.check

handler.sideeffect.op836.split.entry:             ; preds = %execute.decode
  br label %handler.sideeffect.op836.split.body

handler.sideeffect.op836.split.body:              ; preds = %handler.sideeffect.op836.split.entry
  %dead.alias.pc1893 = load i64, ptr %pc, align 8
  %dead.alias.next1894 = add i64 %dead.alias.pc1893, 4
  store i64 %dead.alias.next1894, ptr %pc, align 8
  br label %loop.check

handler.uitofp.opc0.split.entry:                  ; preds = %execute.decode
  br label %handler.uitofp.opc0.split.body

handler.uitofp.opc0.split.body:                   ; preds = %handler.uitofp.opc0.split.entry
  %dead.alias.pc1895 = load i64, ptr %pc, align 8
  %dead.alias.next1896 = add i64 %dead.alias.pc1895, 32
  store i64 %dead.alias.next1896, ptr %pc, align 8
  br label %loop.check

handler.froundeven.op722.split.entry:             ; preds = %execute.decode
  br label %handler.froundeven.op722.split.body

handler.froundeven.op722.split.body:              ; preds = %handler.froundeven.op722.split.entry
  %dead.alias.pc1897 = load i64, ptr %pc, align 8
  %dead.alias.next1898 = add i64 %dead.alias.pc1897, 32
  store i64 %dead.alias.next1898, ptr %pc, align 8
  br label %loop.check

handler.fptoui.opc9.split.entry:                  ; preds = %execute.decode
  br label %handler.fptoui.opc9.split.body

handler.fptoui.opc9.split.body:                   ; preds = %handler.fptoui.opc9.split.entry
  %dead.alias.pc1899 = load i64, ptr %pc, align 8
  %dead.alias.next1900 = add i64 %dead.alias.pc1899, 32
  store i64 %dead.alias.next1900, ptr %pc, align 8
  br label %loop.check

handler.vm_ret.op43.split.entry:                  ; preds = %execute.decode
  br label %handler.vm_ret.op43.split.body

handler.vm_ret.op43.split.body:                   ; preds = %handler.vm_ret.op43.split.entry
  %dead.alias.pc1901 = load i64, ptr %pc, align 8
  %dead.alias.next1902 = add i64 %dead.alias.pc1901, 32
  store i64 %dead.alias.next1902, ptr %pc, align 8
  br label %loop.check

handler.fexp2.op72a.split.entry:                  ; preds = %execute.decode
  br label %handler.fexp2.op72a.split.body

handler.fexp2.op72a.split.body:                   ; preds = %handler.fexp2.op72a.split.entry
  %dead.alias.pc1903 = load i64, ptr %pc, align 8
  %dead.alias.next1904 = add i64 %dead.alias.pc1903, 32
  store i64 %dead.alias.next1904, ptr %pc, align 8
  br label %loop.check

handler.frem.opa9.split.entry:                    ; preds = %execute.decode
  br label %handler.frem.opa9.split.body

handler.frem.opa9.split.body:                     ; preds = %handler.frem.opa9.split.entry
  %dead.alias.pc1905 = load i64, ptr %pc, align 8
  %dead.alias.next1906 = add i64 %dead.alias.pc1905, 32
  store i64 %dead.alias.next1906, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umin.opf8.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_umin.opf8.split.body

handler.atomic_rmw_umin.opf8.split.body:          ; preds = %handler.atomic_rmw_umin.opf8.split.entry
  %dead.alias.pc1907 = load i64, ptr %pc, align 8
  %dead.alias.next1908 = add i64 %dead.alias.pc1907, 32
  store i64 %dead.alias.next1908, ptr %pc, align 8
  br label %loop.check

handler.ptrmask.op857.split.entry:                ; preds = %execute.decode
  br label %handler.ptrmask.op857.split.body

handler.ptrmask.op857.split.body:                 ; preds = %handler.ptrmask.op857.split.entry
  %dead.alias.pc1909 = load i64, ptr %pc, align 8
  %dead.alias.next1910 = add i64 %dead.alias.pc1909, 16
  store i64 %dead.alias.next1910, ptr %pc, align 8
  br label %loop.check

handler.load_isshl_sat.op9ac.split.entry:         ; preds = %execute.decode
  br label %handler.load_isshl_sat.op9ac.split.body

handler.load_isshl_sat.op9ac.split.body:          ; preds = %handler.load_isshl_sat.op9ac.split.entry
  %dead.alias.pc1911 = load i64, ptr %pc, align 8
  %dead.alias.next1912 = add i64 %dead.alias.pc1911, 32
  store i64 %dead.alias.next1912, ptr %pc, align 8
  br label %loop.check

handler.fminimum.op8ab.split.entry:               ; preds = %execute.decode
  br label %handler.fminimum.op8ab.split.body

handler.fminimum.op8ab.split.body:                ; preds = %handler.fminimum.op8ab.split.entry
  %dead.alias.pc1913 = load i64, ptr %pc, align 8
  %dead.alias.next1914 = add i64 %dead.alias.pc1913, 16
  store i64 %dead.alias.next1914, ptr %pc, align 8
  br label %loop.check

handler.sext.op58.split.entry:                    ; preds = %execute.decode
  br label %handler.sext.op58.split.body

handler.sext.op58.split.body:                     ; preds = %handler.sext.op58.split.entry
  %dead.alias.pc1915 = load i64, ptr %pc, align 8
  %dead.alias.next1916 = add i64 %dead.alias.pc1915, 32
  store i64 %dead.alias.next1916, ptr %pc, align 8
  br label %loop.check

handler.load_iand.op9ad.split.entry:              ; preds = %execute.decode
  br label %handler.load_iand.op9ad.split.body

handler.load_iand.op9ad.split.body:               ; preds = %handler.load_iand.op9ad.split.entry
  %dead.alias.pc1917 = load i64, ptr %pc, align 8
  %dead.alias.next1918 = add i64 %dead.alias.pc1917, 32
  store i64 %dead.alias.next1918, ptr %pc, align 8
  br label %loop.check

handler.iashr.op4b.split.entry:                   ; preds = %execute.decode
  br label %handler.iashr.op4b.split.body

handler.iashr.op4b.split.body:                    ; preds = %handler.iashr.op4b.split.entry
  %dead.alias.pc1919 = load i64, ptr %pc, align 8
  %dead.alias.next1920 = add i64 %dead.alias.pc1919, 32
  store i64 %dead.alias.next1920, ptr %pc, align 8
  br label %loop.check

handler.trunc.op8fb.split.entry:                  ; preds = %execute.decode
  br label %handler.trunc.op8fb.split.body

handler.trunc.op8fb.split.body:                   ; preds = %handler.trunc.op8fb.split.entry
  %dead.alias.pc1921 = load i64, ptr %pc, align 8
  %dead.alias.next1922 = add i64 %dead.alias.pc1921, 32
  store i64 %dead.alias.next1922, ptr %pc, align 8
  br label %loop.check

handler.load_iudiv.op1db.split.entry:             ; preds = %execute.decode
  br label %handler.load_iudiv.op1db.split.body

handler.load_iudiv.op1db.split.body:              ; preds = %handler.load_iudiv.op1db.split.entry
  %dead.alias.pc1923 = load i64, ptr %pc, align 8
  %dead.alias.next1924 = add i64 %dead.alias.pc1923, 32
  store i64 %dead.alias.next1924, ptr %pc, align 8
  br label %loop.check

handler.iadd.op83b.split.entry:                   ; preds = %execute.decode
  br label %handler.iadd.op83b.split.body

handler.iadd.op83b.split.body:                    ; preds = %handler.iadd.op83b.split.entry
  %iadd.dst1925 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.lhs1926 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.rhs1927 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iadd.width1928 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr1929 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.lhs1926
  %lhs1930 = load i64, ptr %reg.load.ptr1929, align 8
  %reg.load.ptr1931 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.rhs1927
  %rhs1932 = load i64, ptr %reg.load.ptr1931, align 8
  %shift.masked1933 = and i64 %rhs1932, 63
  %bin.add1934 = add i64 %lhs1930, %rhs1932
  %width.is641935 = icmp eq i64 %iadd.width1928, 64
  %width.shift1936 = and i64 %iadd.width1928, 63
  %mask.shifted1937 = shl i64 1, %width.shift1936
  %mask.candidate1938 = sub i64 %mask.shifted1937, 1
  %width.mask1939 = select i1 %width.is641935, i64 -1, i64 %mask.candidate1938
  %width.masked1940 = and i64 %bin.add1934, %width.mask1939
  %reg.store.ptr1941 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iadd.dst1925
  store i64 %width.masked1940, ptr %reg.store.ptr1941, align 8
  %pc.old1942 = load i64, ptr %pc, align 8
  %pc.next1943 = add i64 %pc.old1942, 16
  store i64 %pc.next1943, ptr %pc, align 8
  br label %loop.check

handler.br_if.op3f.split.entry:                   ; preds = %execute.decode
  br label %handler.br_if.op3f.split.body

handler.br_if.op3f.split.body:                    ; preds = %handler.br_if.op3f.split.entry
  %dead.alias.pc1944 = load i64, ptr %pc, align 8
  %dead.alias.next1945 = add i64 %dead.alias.pc1944, 32
  store i64 %dead.alias.next1945, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_sub.ope4.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_sub.ope4.split.body

handler.atomic_rmw_sub.ope4.split.body:           ; preds = %handler.atomic_rmw_sub.ope4.split.entry
  %dead.alias.pc1946 = load i64, ptr %pc, align 8
  %dead.alias.next1947 = add i64 %dead.alias.pc1946, 32
  store i64 %dead.alias.next1947, ptr %pc, align 8
  br label %loop.check

handler.stacksave.op903.split.entry:              ; preds = %execute.decode
  br label %handler.stacksave.op903.split.body

handler.stacksave.op903.split.body:               ; preds = %handler.stacksave.op903.split.entry
  %dead.alias.pc1948 = load i64, ptr %pc, align 8
  %dead.alias.next1949 = add i64 %dead.alias.pc1948, 8
  store i64 %dead.alias.next1949, ptr %pc, align 8
  br label %loop.check

handler.fmul.op89c.split.entry:                   ; preds = %execute.decode
  br label %handler.fmul.op89c.split.body

handler.fmul.op89c.split.body:                    ; preds = %handler.fmul.op89c.split.entry
  %dead.alias.pc1950 = load i64, ptr %pc, align 8
  %dead.alias.next1951 = add i64 %dead.alias.pc1950, 32
  store i64 %dead.alias.next1951, ptr %pc, align 8
  br label %loop.check

handler.load_imul.op1d9.split.entry:              ; preds = %execute.decode
  br label %handler.load_imul.op1d9.split.body

handler.load_imul.op1d9.split.body:               ; preds = %handler.load_imul.op1d9.split.entry
  %dead.alias.pc1952 = load i64, ptr %pc, align 8
  %dead.alias.next1953 = add i64 %dead.alias.pc1952, 32
  store i64 %dead.alias.next1953, ptr %pc, align 8
  br label %loop.check

handler.br_if.op9bc.split.entry:                  ; preds = %execute.decode
  br label %handler.br_if.op9bc.split.body

handler.br_if.op9bc.split.body:                   ; preds = %handler.br_if.op9bc.split.entry
  %dead.alias.pc1954 = load i64, ptr %pc, align 8
  %dead.alias.next1955 = add i64 %dead.alias.pc1954, 32
  store i64 %dead.alias.next1955, ptr %pc, align 8
  br label %loop.check

handler.isshl_sat.op879.split.entry:              ; preds = %execute.decode
  br label %handler.isshl_sat.op879.split.body

handler.isshl_sat.op879.split.body:               ; preds = %handler.isshl_sat.op879.split.entry
  %dead.alias.pc1956 = load i64, ptr %pc, align 8
  %dead.alias.next1957 = add i64 %dead.alias.pc1956, 32
  store i64 %dead.alias.next1957, ptr %pc, align 8
  br label %loop.check

handler.load_ilshr.op996.split.entry:             ; preds = %execute.decode
  br label %handler.load_ilshr.op996.split.body

handler.load_ilshr.op996.split.body:              ; preds = %handler.load_ilshr.op996.split.entry
  %dead.alias.pc1958 = load i64, ptr %pc, align 8
  %dead.alias.next1959 = add i64 %dead.alias.pc1958, 32
  store i64 %dead.alias.next1959, ptr %pc, align 8
  br label %loop.check

handler.load_ilshr.op995.split.entry:             ; preds = %execute.decode
  br label %handler.load_ilshr.op995.split.body

handler.load_ilshr.op995.split.body:              ; preds = %handler.load_ilshr.op995.split.entry
  %dead.alias.pc1960 = load i64, ptr %pc, align 8
  %dead.alias.next1961 = add i64 %dead.alias.pc1960, 32
  store i64 %dead.alias.next1961, ptr %pc, align 8
  br label %loop.check

handler.write_rounding.op81e.split.entry:         ; preds = %execute.decode
  br label %handler.write_rounding.op81e.split.body

handler.write_rounding.op81e.split.body:          ; preds = %handler.write_rounding.op81e.split.entry
  %dead.alias.pc1962 = load i64, ptr %pc, align 8
  %dead.alias.next1963 = add i64 %dead.alias.pc1962, 8
  store i64 %dead.alias.next1963, ptr %pc, align 8
  br label %loop.check

handler.cmpxchg.opec.split.entry:                 ; preds = %execute.decode
  br label %handler.cmpxchg.opec.split.body

handler.cmpxchg.opec.split.body:                  ; preds = %handler.cmpxchg.opec.split.entry
  %dead.alias.pc1964 = load i64, ptr %pc, align 8
  %dead.alias.next1965 = add i64 %dead.alias.pc1964, 32
  store i64 %dead.alias.next1965, ptr %pc, align 8
  br label %loop.check

handler.fsin.op724.split.entry:                   ; preds = %execute.decode
  br label %handler.fsin.op724.split.body

handler.fsin.op724.split.body:                    ; preds = %handler.fsin.op724.split.entry
  %dead.alias.pc1966 = load i64, ptr %pc, align 8
  %dead.alias.next1967 = add i64 %dead.alias.pc1966, 32
  store i64 %dead.alias.next1967, ptr %pc, align 8
  br label %loop.check

handler.fptosi_sat.op8e0.split.entry:             ; preds = %execute.decode
  br label %handler.fptosi_sat.op8e0.split.body

handler.fptosi_sat.op8e0.split.body:              ; preds = %handler.fptosi_sat.op8e0.split.entry
  %dead.alias.pc1968 = load i64, ptr %pc, align 8
  %dead.alias.next1969 = add i64 %dead.alias.pc1968, 16
  store i64 %dead.alias.next1969, ptr %pc, align 8
  br label %loop.check

handler.load_isrem.op1e0.split.entry:             ; preds = %execute.decode
  br label %handler.load_isrem.op1e0.split.body

handler.load_isrem.op1e0.split.body:              ; preds = %handler.load_isrem.op1e0.split.entry
  %dead.alias.pc1970 = load i64, ptr %pc, align 8
  %dead.alias.next1971 = add i64 %dead.alias.pc1970, 32
  store i64 %dead.alias.next1971, ptr %pc, align 8
  br label %loop.check

handler.fround.op721.split.entry:                 ; preds = %execute.decode
  br label %handler.fround.op721.split.body

handler.fround.op721.split.body:                  ; preds = %handler.fround.op721.split.entry
  %dead.alias.pc1972 = load i64, ptr %pc, align 8
  %dead.alias.next1973 = add i64 %dead.alias.pc1972, 32
  store i64 %dead.alias.next1973, ptr %pc, align 8
  br label %loop.check

handler.trap.op9c3.split.entry:                   ; preds = %execute.decode
  br label %handler.trap.op9c3.split.body

handler.trap.op9c3.split.body:                    ; preds = %handler.trap.op9c3.split.entry
  %dead.alias.pc1974 = load i64, ptr %pc, align 8
  %dead.alias.next1975 = add i64 %dead.alias.pc1974, 4
  store i64 %dead.alias.next1975, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_and.op959.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_and.op959.split.body

handler.volatile_atomic_rmw_and.op959.split.body: ; preds = %handler.volatile_atomic_rmw_and.op959.split.entry
  %dead.alias.pc1976 = load i64, ptr %pc, align 8
  %dead.alias.next1977 = add i64 %dead.alias.pc1976, 32
  store i64 %dead.alias.next1977, ptr %pc, align 8
  br label %loop.check

handler.clear_cache.op907.split.entry:            ; preds = %execute.decode
  br label %handler.clear_cache.op907.split.body

handler.clear_cache.op907.split.body:             ; preds = %handler.clear_cache.op907.split.entry
  %dead.alias.pc1978 = load i64, ptr %pc, align 8
  %dead.alias.next1979 = add i64 %dead.alias.pc1978, 8
  store i64 %dead.alias.next1979, ptr %pc, align 8
  br label %loop.check

handler.load_iumin.op1ee.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumin.op1ee.split.body

handler.load_iumin.op1ee.split.body:              ; preds = %handler.load_iumin.op1ee.split.entry
  %dead.alias.pc1980 = load i64, ptr %pc, align 8
  %dead.alias.next1981 = add i64 %dead.alias.pc1980, 32
  store i64 %dead.alias.next1981, ptr %pc, align 8
  br label %loop.check

handler.sext.op7d.split.entry:                    ; preds = %execute.decode
  br label %handler.sext.op7d.split.body

handler.sext.op7d.split.body:                     ; preds = %handler.sext.op7d.split.entry
  %dead.alias.pc1982 = load i64, ptr %pc, align 8
  %dead.alias.next1983 = add i64 %dead.alias.pc1982, 32
  store i64 %dead.alias.next1983, ptr %pc, align 8
  br label %loop.check

handler.read_flt_rounds.op1d0.split.entry:        ; preds = %execute.decode
  br label %handler.read_flt_rounds.op1d0.split.body

handler.read_flt_rounds.op1d0.split.body:         ; preds = %handler.read_flt_rounds.op1d0.split.entry
  %dead.alias.pc1984 = load i64, ptr %pc, align 8
  %dead.alias.next1985 = add i64 %dead.alias.pc1984, 8
  store i64 %dead.alias.next1985, ptr %pc, align 8
  br label %loop.check

handler.load_iumax.op1ec.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumax.op1ec.split.body

handler.load_iumax.op1ec.split.body:              ; preds = %handler.load_iumax.op1ec.split.entry
  %dead.alias.pc1986 = load i64, ptr %pc, align 8
  %dead.alias.next1987 = add i64 %dead.alias.pc1986, 32
  store i64 %dead.alias.next1987, ptr %pc, align 8
  br label %loop.check

handler.load_ismax.op1e9.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismax.op1e9.split.body

handler.load_ismax.op1e9.split.body:              ; preds = %handler.load_ismax.op1e9.split.entry
  %dead.alias.pc1988 = load i64, ptr %pc, align 8
  %dead.alias.next1989 = add i64 %dead.alias.pc1988, 32
  store i64 %dead.alias.next1989, ptr %pc, align 8
  br label %loop.check

handler.fdiv.opa4.split.entry:                    ; preds = %execute.decode
  br label %handler.fdiv.opa4.split.body

handler.fdiv.opa4.split.body:                     ; preds = %handler.fdiv.opa4.split.entry
  %dead.alias.pc1990 = load i64, ptr %pc, align 8
  %dead.alias.next1991 = add i64 %dead.alias.pc1990, 32
  store i64 %dead.alias.next1991, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_nand.opf0.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_nand.opf0.split.body

handler.atomic_rmw_nand.opf0.split.body:          ; preds = %handler.atomic_rmw_nand.opf0.split.entry
  %dead.alias.pc1992 = load i64, ptr %pc, align 8
  %dead.alias.next1993 = add i64 %dead.alias.pc1992, 32
  store i64 %dead.alias.next1993, ptr %pc, align 8
  br label %loop.check

handler.fexp.op729.split.entry:                   ; preds = %execute.decode
  br label %handler.fexp.op729.split.body

handler.fexp.op729.split.body:                    ; preds = %handler.fexp.op729.split.entry
  %dead.alias.pc1994 = load i64, ptr %pc, align 8
  %dead.alias.next1995 = add i64 %dead.alias.pc1994, 32
  store i64 %dead.alias.next1995, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fminimum.op97c.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fminimum.op97c.split.body

handler.volatile_atomic_rmw_fminimum.op97c.split.body: ; preds = %handler.volatile_atomic_rmw_fminimum.op97c.split.entry
  %dead.alias.pc1996 = load i64, ptr %pc, align 8
  %dead.alias.next1997 = add i64 %dead.alias.pc1996, 32
  store i64 %dead.alias.next1997, ptr %pc, align 8
  br label %loop.check

handler.fllrint.op8ea.split.entry:                ; preds = %execute.decode
  br label %handler.fllrint.op8ea.split.body

handler.fllrint.op8ea.split.body:                 ; preds = %handler.fllrint.op8ea.split.entry
  %dead.alias.pc1998 = load i64, ptr %pc, align 8
  %dead.alias.next1999 = add i64 %dead.alias.pc1998, 16
  store i64 %dead.alias.next1999, ptr %pc, align 8
  br label %loop.check

handler.zext.op46.split.entry:                    ; preds = %execute.decode
  br label %handler.zext.op46.split.body

handler.zext.op46.split.body:                     ; preds = %handler.zext.op46.split.entry
  %dead.alias.pc2000 = load i64, ptr %pc, align 8
  %dead.alias.next2001 = add i64 %dead.alias.pc2000, 32
  store i64 %dead.alias.next2001, ptr %pc, align 8
  br label %loop.check

handler.ffloor.op717.split.entry:                 ; preds = %execute.decode
  br label %handler.ffloor.op717.split.body

handler.ffloor.op717.split.body:                  ; preds = %handler.ffloor.op717.split.entry
  %dead.alias.pc2002 = load i64, ptr %pc, align 8
  %dead.alias.next2003 = add i64 %dead.alias.pc2002, 32
  store i64 %dead.alias.next2003, ptr %pc, align 8
  br label %loop.check

handler.fsub.op99.split.entry:                    ; preds = %execute.decode
  br label %handler.fsub.op99.split.body

handler.fsub.op99.split.body:                     ; preds = %handler.fsub.op99.split.entry
  %dead.alias.pc2004 = load i64, ptr %pc, align 8
  %dead.alias.next2005 = add i64 %dead.alias.pc2004, 32
  store i64 %dead.alias.next2005, ptr %pc, align 8
  br label %loop.check

handler.volatile_store.op149.split.entry:         ; preds = %execute.decode
  br label %handler.volatile_store.op149.split.body

handler.volatile_store.op149.split.body:          ; preds = %handler.volatile_store.op149.split.entry
  %dead.alias.pc2006 = load i64, ptr %pc, align 8
  %dead.alias.next2007 = add i64 %dead.alias.pc2006, 16
  store i64 %dead.alias.next2007, ptr %pc, align 8
  br label %loop.check

handler.fpext.opd4.split.entry:                   ; preds = %execute.decode
  br label %handler.fpext.opd4.split.body

handler.fpext.opd4.split.body:                    ; preds = %handler.fpext.opd4.split.entry
  %dead.alias.pc2008 = load i64, ptr %pc, align 8
  %dead.alias.next2009 = add i64 %dead.alias.pc2008, 32
  store i64 %dead.alias.next2009, ptr %pc, align 8
  br label %loop.check

handler.iusub_sat.op872.split.entry:              ; preds = %execute.decode
  br label %handler.iusub_sat.op872.split.body

handler.iusub_sat.op872.split.body:               ; preds = %handler.iusub_sat.op872.split.entry
  %dead.alias.pc2010 = load i64, ptr %pc, align 8
  %dead.alias.next2011 = add i64 %dead.alias.pc2010, 32
  store i64 %dead.alias.next2011, ptr %pc, align 8
  br label %loop.check

handler.isshl_sat.op12c.split.entry:              ; preds = %execute.decode
  br label %handler.isshl_sat.op12c.split.body

handler.isshl_sat.op12c.split.body:               ; preds = %handler.isshl_sat.op12c.split.entry
  %dead.alias.pc2012 = load i64, ptr %pc, align 8
  %dead.alias.next2013 = add i64 %dead.alias.pc2012, 32
  store i64 %dead.alias.next2013, ptr %pc, align 8
  br label %loop.check

handler.load_isadd_sat.op9a5.split.entry:         ; preds = %execute.decode
  br label %handler.load_isadd_sat.op9a5.split.body

handler.load_isadd_sat.op9a5.split.body:          ; preds = %handler.load_isadd_sat.op9a5.split.entry
  %dead.alias.pc2014 = load i64, ptr %pc, align 8
  %dead.alias.next2015 = add i64 %dead.alias.pc2014, 32
  store i64 %dead.alias.next2015, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op861.split.entry:                  ; preds = %execute.decode
  br label %handler.ilshr.op861.split.body

handler.ilshr.op861.split.body:                   ; preds = %handler.ilshr.op861.split.entry
  %dead.alias.pc2016 = load i64, ptr %pc, align 8
  %dead.alias.next2017 = add i64 %dead.alias.pc2016, 32
  store i64 %dead.alias.next2017, ptr %pc, align 8
  br label %loop.check

handler.fsub.op9a.split.entry:                    ; preds = %execute.decode
  br label %handler.fsub.op9a.split.body

handler.fsub.op9a.split.body:                     ; preds = %handler.fsub.op9a.split.entry
  %dead.alias.pc2018 = load i64, ptr %pc, align 8
  %dead.alias.next2019 = add i64 %dead.alias.pc2018, 32
  store i64 %dead.alias.next2019, ptr %pc, align 8
  br label %loop.check

handler.flrint.op8e8.split.entry:                 ; preds = %execute.decode
  br label %handler.flrint.op8e8.split.body

handler.flrint.op8e8.split.body:                  ; preds = %handler.flrint.op8e8.split.entry
  %dead.alias.pc2020 = load i64, ptr %pc, align 8
  %dead.alias.next2021 = add i64 %dead.alias.pc2020, 16
  store i64 %dead.alias.next2021, ptr %pc, align 8
  br label %loop.check

handler.ffmuladd.op713.split.entry:               ; preds = %execute.decode
  br label %handler.ffmuladd.op713.split.body

handler.ffmuladd.op713.split.body:                ; preds = %handler.ffmuladd.op713.split.entry
  %dead.alias.pc2022 = load i64, ptr %pc, align 8
  %dead.alias.next2023 = add i64 %dead.alias.pc2022, 48
  store i64 %dead.alias.next2023, ptr %pc, align 8
  br label %loop.check

handler.load_ishl.op994.split.entry:              ; preds = %execute.decode
  br label %handler.load_ishl.op994.split.body

handler.load_ishl.op994.split.body:               ; preds = %handler.load_ishl.op994.split.entry
  %dead.alias.pc2024 = load i64, ptr %pc, align 8
  %dead.alias.next2025 = add i64 %dead.alias.pc2024, 32
  store i64 %dead.alias.next2025, ptr %pc, align 8
  br label %loop.check

handler.atomic_store.opda.split.entry:            ; preds = %execute.decode
  br label %handler.atomic_store.opda.split.body

handler.atomic_store.opda.split.body:             ; preds = %handler.atomic_store.opda.split.entry
  %dead.alias.pc2026 = load i64, ptr %pc, align 8
  %dead.alias.next2027 = add i64 %dead.alias.pc2026, 32
  store i64 %dead.alias.next2027, ptr %pc, align 8
  br label %loop.check

handler.frem.opa8.split.entry:                    ; preds = %execute.decode
  br label %handler.frem.opa8.split.body

handler.frem.opa8.split.body:                     ; preds = %handler.frem.opa8.split.entry
  %dead.alias.pc2028 = load i64, ptr %pc, align 8
  %dead.alias.next2029 = add i64 %dead.alias.pc2028, 32
  store i64 %dead.alias.next2029, ptr %pc, align 8
  br label %loop.check

handler.load_iuadd_sat.op9a1.split.entry:         ; preds = %execute.decode
  br label %handler.load_iuadd_sat.op9a1.split.body

handler.load_iuadd_sat.op9a1.split.body:          ; preds = %handler.load_iuadd_sat.op9a1.split.entry
  %dead.alias.pc2030 = load i64, ptr %pc, align 8
  %dead.alias.next2031 = add i64 %dead.alias.pc2030, 32
  store i64 %dead.alias.next2031, ptr %pc, align 8
  br label %loop.check

handler.load_iusub_sat.op1f2.split.entry:         ; preds = %execute.decode
  br label %handler.load_iusub_sat.op1f2.split.body

handler.load_iusub_sat.op1f2.split.body:          ; preds = %handler.load_iusub_sat.op1f2.split.entry
  %dead.alias.pc2032 = load i64, ptr %pc, align 8
  %dead.alias.next2033 = add i64 %dead.alias.pc2032, 32
  store i64 %dead.alias.next2033, ptr %pc, align 8
  br label %loop.check

handler.icmp.op1f.split.entry:                    ; preds = %execute.decode
  br label %handler.icmp.op1f.split.body

handler.icmp.op1f.split.body:                     ; preds = %handler.icmp.op1f.split.entry
  %dead.alias.pc2034 = load i64, ptr %pc, align 8
  %dead.alias.next2035 = add i64 %dead.alias.pc2034, 32
  store i64 %dead.alias.next2035, ptr %pc, align 8
  br label %loop.check

handler.flog10.op8cf.split.entry:                 ; preds = %execute.decode
  br label %handler.flog10.op8cf.split.body

handler.flog10.op8cf.split.body:                  ; preds = %handler.flog10.op8cf.split.entry
  %dead.alias.pc2036 = load i64, ptr %pc, align 8
  %dead.alias.next2037 = add i64 %dead.alias.pc2036, 32
  store i64 %dead.alias.next2037, ptr %pc, align 8
  br label %loop.check

handler.ior.op2e.split.entry:                     ; preds = %execute.decode
  br label %handler.ior.op2e.split.body

handler.ior.op2e.split.body:                      ; preds = %handler.ior.op2e.split.entry
  %dead.alias.pc2038 = load i64, ptr %pc, align 8
  %dead.alias.next2039 = add i64 %dead.alias.pc2038, 32
  store i64 %dead.alias.next2039, ptr %pc, align 8
  br label %loop.check

handler.iadd.op83a.split.entry:                   ; preds = %execute.decode
  br label %handler.iadd.op83a.split.body

handler.iadd.op83a.split.body:                    ; preds = %handler.iadd.op83a.split.entry
  %dead.alias.pc2040 = load i64, ptr %pc, align 8
  %dead.alias.next2041 = add i64 %dead.alias.pc2040, 16
  store i64 %dead.alias.next2041, ptr %pc, align 8
  br label %loop.check

handler.isadd_overflow.op130.split.entry:         ; preds = %execute.decode
  br label %handler.isadd_overflow.op130.split.body

handler.isadd_overflow.op130.split.body:          ; preds = %handler.isadd_overflow.op130.split.entry
  %dead.alias.pc2042 = load i64, ptr %pc, align 8
  %dead.alias.next2043 = add i64 %dead.alias.pc2042, 32
  store i64 %dead.alias.next2043, ptr %pc, align 8
  br label %loop.check

handler.alloca.op05.split.entry:                  ; preds = %execute.decode
  br label %handler.alloca.op05.split.body

handler.alloca.op05.split.body:                   ; preds = %handler.alloca.op05.split.entry
  %dead.alias.pc2044 = load i64, ptr %pc, align 8
  %dead.alias.next2045 = add i64 %dead.alias.pc2044, 32
  store i64 %dead.alias.next2045, ptr %pc, align 8
  br label %loop.check

handler.ixor.op6b.split.entry:                    ; preds = %execute.decode
  br label %handler.ixor.op6b.split.body

handler.ixor.op6b.split.body:                     ; preds = %handler.ixor.op6b.split.entry
  %dead.alias.pc2046 = load i64, ptr %pc, align 8
  %dead.alias.next2047 = add i64 %dead.alias.pc2046, 32
  store i64 %dead.alias.next2047, ptr %pc, align 8
  br label %loop.check

handler.iusub_sat.op124.split.entry:              ; preds = %execute.decode
  br label %handler.iusub_sat.op124.split.body

handler.iusub_sat.op124.split.body:               ; preds = %handler.iusub_sat.op124.split.entry
  %dead.alias.pc2048 = load i64, ptr %pc, align 8
  %dead.alias.next2049 = add i64 %dead.alias.pc2048, 32
  store i64 %dead.alias.next2049, ptr %pc, align 8
  br label %loop.check

handler.fptosi.op8db.split.entry:                 ; preds = %execute.decode
  br label %handler.fptosi.op8db.split.body

handler.fptosi.op8db.split.body:                  ; preds = %handler.fptosi.op8db.split.entry
  %dead.alias.pc2050 = load i64, ptr %pc, align 8
  %dead.alias.next2051 = add i64 %dead.alias.pc2050, 32
  store i64 %dead.alias.next2051, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op85.split.entry:                   ; preds = %execute.decode
  br label %handler.isdiv.op85.split.body

handler.isdiv.op85.split.body:                    ; preds = %handler.isdiv.op85.split.entry
  %dead.alias.pc2052 = load i64, ptr %pc, align 8
  %dead.alias.next2053 = add i64 %dead.alias.pc2052, 32
  store i64 %dead.alias.next2053, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fadd.op948.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fadd.op948.split.body

handler.atomic_rmw_fadd.op948.split.body:         ; preds = %handler.atomic_rmw_fadd.op948.split.entry
  %dead.alias.pc2054 = load i64, ptr %pc, align 8
  %dead.alias.next2055 = add i64 %dead.alias.pc2054, 32
  store i64 %dead.alias.next2055, ptr %pc, align 8
  br label %loop.check

handler.zext.op8f7.split.entry:                   ; preds = %execute.decode
  br label %handler.zext.op8f7.split.body

handler.zext.op8f7.split.body:                    ; preds = %handler.zext.op8f7.split.entry
  %dead.alias.pc2056 = load i64, ptr %pc, align 8
  %dead.alias.next2057 = add i64 %dead.alias.pc2056, 32
  store i64 %dead.alias.next2057, ptr %pc, align 8
  br label %loop.check

handler.issub_sat.op128.split.entry:              ; preds = %execute.decode
  br label %handler.issub_sat.op128.split.body

handler.issub_sat.op128.split.body:               ; preds = %handler.issub_sat.op128.split.entry
  %dead.alias.pc2058 = load i64, ptr %pc, align 8
  %dead.alias.next2059 = add i64 %dead.alias.pc2058, 32
  store i64 %dead.alias.next2059, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fminimum.op97b.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fminimum.op97b.split.body

handler.volatile_atomic_rmw_fminimum.op97b.split.body: ; preds = %handler.volatile_atomic_rmw_fminimum.op97b.split.entry
  %dead.alias.pc2060 = load i64, ptr %pc, align 8
  %dead.alias.next2061 = add i64 %dead.alias.pc2060, 32
  store i64 %dead.alias.next2061, ptr %pc, align 8
  br label %loop.check

handler.fshl.op893.split.entry:                   ; preds = %execute.decode
  br label %handler.fshl.op893.split.body

handler.fshl.op893.split.body:                    ; preds = %handler.fshl.op893.split.entry
  %dead.alias.pc2062 = load i64, ptr %pc, align 8
  %dead.alias.next2063 = add i64 %dead.alias.pc2062, 48
  store i64 %dead.alias.next2063, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op5c.split.entry:                   ; preds = %execute.decode
  br label %handler.ilshr.op5c.split.body

handler.ilshr.op5c.split.body:                    ; preds = %handler.ilshr.op5c.split.entry
  %dead.alias.pc2064 = load i64, ptr %pc, align 8
  %dead.alias.next2065 = add i64 %dead.alias.pc2064, 32
  store i64 %dead.alias.next2065, ptr %pc, align 8
  br label %loop.check

handler.flog2.op8d2.split.entry:                  ; preds = %execute.decode
  br label %handler.flog2.op8d2.split.body

handler.flog2.op8d2.split.body:                   ; preds = %handler.flog2.op8d2.split.entry
  %dead.alias.pc2066 = load i64, ptr %pc, align 8
  %dead.alias.next2067 = add i64 %dead.alias.pc2066, 32
  store i64 %dead.alias.next2067, ptr %pc, align 8
  br label %loop.check

handler.iuadd_sat.op121.split.entry:              ; preds = %execute.decode
  br label %handler.iuadd_sat.op121.split.body

handler.iuadd_sat.op121.split.body:               ; preds = %handler.iuadd_sat.op121.split.entry
  %dead.alias.pc2068 = load i64, ptr %pc, align 8
  %dead.alias.next2069 = add i64 %dead.alias.pc2068, 32
  store i64 %dead.alias.next2069, ptr %pc, align 8
  br label %loop.check

handler.ixor.op2a.split.entry:                    ; preds = %execute.decode
  br label %handler.ixor.op2a.split.body

handler.ixor.op2a.split.body:                     ; preds = %handler.ixor.op2a.split.entry
  %ixor.dst2070 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %ixor.lhs2071 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %ixor.rhs2072 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %ixor.width2073 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr2074 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ixor.lhs2071
  %lhs2075 = load i64, ptr %reg.load.ptr2074, align 8
  %reg.load.ptr2076 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ixor.rhs2072
  %rhs2077 = load i64, ptr %reg.load.ptr2076, align 8
  %shift.masked2078 = and i64 %rhs2077, 63
  %bin.xor2079 = xor i64 %lhs2075, %rhs2077
  %width.is642080 = icmp eq i64 %ixor.width2073, 64
  %width.shift2081 = and i64 %ixor.width2073, 63
  %mask.shifted2082 = shl i64 1, %width.shift2081
  %mask.candidate2083 = sub i64 %mask.shifted2082, 1
  %width.mask2084 = select i1 %width.is642080, i64 -1, i64 %mask.candidate2083
  %width.masked2085 = and i64 %bin.xor2079, %width.mask2084
  %reg.store.ptr2086 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %ixor.dst2070
  store i64 %width.masked2085, ptr %reg.store.ptr2086, align 8
  %pc.old2087 = load i64, ptr %pc, align 8
  %pc.next2088 = add i64 %pc.old2087, 32
  store i64 %pc.next2088, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_sub.op184.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_sub.op184.split.body

handler.volatile_atomic_rmw_sub.op184.split.body: ; preds = %handler.volatile_atomic_rmw_sub.op184.split.entry
  %dead.alias.pc2089 = load i64, ptr %pc, align 8
  %dead.alias.next2090 = add i64 %dead.alias.pc2089, 32
  store i64 %dead.alias.next2090, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_sub.op92d.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_sub.op92d.split.body

handler.atomic_rmw_sub.op92d.split.body:          ; preds = %handler.atomic_rmw_sub.op92d.split.entry
  %dead.alias.pc2091 = load i64, ptr %pc, align 8
  %dead.alias.next2092 = add i64 %dead.alias.pc2091, 32
  store i64 %dead.alias.next2092, ptr %pc, align 8
  br label %loop.check

handler.ishl.op3c.split.entry:                    ; preds = %execute.decode
  br label %handler.ishl.op3c.split.body

handler.ishl.op3c.split.body:                     ; preds = %handler.ishl.op3c.split.entry
  %dead.alias.pc2093 = load i64, ptr %pc, align 8
  %dead.alias.next2094 = add i64 %dead.alias.pc2093, 32
  store i64 %dead.alias.next2094, ptr %pc, align 8
  br label %loop.check

handler.icmp.op8ef.split.entry:                   ; preds = %execute.decode
  br label %handler.icmp.op8ef.split.body

handler.icmp.op8ef.split.body:                    ; preds = %handler.icmp.op8ef.split.entry
  %dead.alias.pc2095 = load i64, ptr %pc, align 8
  %dead.alias.next2096 = add i64 %dead.alias.pc2095, 32
  store i64 %dead.alias.next2096, ptr %pc, align 8
  br label %loop.check

handler.frem.opab.split.entry:                    ; preds = %execute.decode
  br label %handler.frem.opab.split.body

handler.frem.opab.split.body:                     ; preds = %handler.frem.opab.split.entry
  %dead.alias.pc2097 = load i64, ptr %pc, align 8
  %dead.alias.next2098 = add i64 %dead.alias.pc2097, 32
  store i64 %dead.alias.next2098, ptr %pc, align 8
  br label %loop.check

handler.sideeffect.op1ae.split.entry:             ; preds = %execute.decode
  br label %handler.sideeffect.op1ae.split.body

handler.sideeffect.op1ae.split.body:              ; preds = %handler.sideeffect.op1ae.split.entry
  %dead.alias.pc2099 = load i64, ptr %pc, align 8
  %dead.alias.next2100 = add i64 %dead.alias.pc2099, 4
  store i64 %dead.alias.next2100, ptr %pc, align 8
  br label %loop.check

handler.vm_ret.op9bf.split.entry:                 ; preds = %execute.decode
  br label %handler.vm_ret.op9bf.split.body

handler.vm_ret.op9bf.split.body:                  ; preds = %handler.vm_ret.op9bf.split.entry
  %dead.alias.pc2101 = load i64, ptr %pc, align 8
  %dead.alias.next2102 = add i64 %dead.alias.pc2101, 32
  store i64 %dead.alias.next2102, ptr %pc, align 8
  br label %loop.check

handler.write_fpenv.op826.split.entry:            ; preds = %execute.decode
  br label %handler.write_fpenv.op826.split.body

handler.write_fpenv.op826.split.body:             ; preds = %handler.write_fpenv.op826.split.entry
  %dead.alias.pc2103 = load i64, ptr %pc, align 8
  %dead.alias.next2104 = add i64 %dead.alias.pc2103, 8
  store i64 %dead.alias.next2104, ptr %pc, align 8
  br label %loop.check

handler.alloca.op0b.split.entry:                  ; preds = %execute.decode
  br label %handler.alloca.op0b.split.body

handler.alloca.op0b.split.body:                   ; preds = %handler.alloca.op0b.split.entry
  %dead.alias.pc2105 = load i64, ptr %pc, align 8
  %dead.alias.next2106 = add i64 %dead.alias.pc2105, 32
  store i64 %dead.alias.next2106, ptr %pc, align 8
  br label %loop.check

handler.read_vscale.op816.split.entry:            ; preds = %execute.decode
  br label %handler.read_vscale.op816.split.body

handler.read_vscale.op816.split.body:             ; preds = %handler.read_vscale.op816.split.entry
  %dead.alias.pc2107 = load i64, ptr %pc, align 8
  %dead.alias.next2108 = add i64 %dead.alias.pc2107, 8
  store i64 %dead.alias.next2108, ptr %pc, align 8
  br label %loop.check

handler.fmaxnum.op70c.split.entry:                ; preds = %execute.decode
  br label %handler.fmaxnum.op70c.split.body

handler.fmaxnum.op70c.split.body:                 ; preds = %handler.fmaxnum.op70c.split.entry
  %dead.alias.pc2109 = load i64, ptr %pc, align 8
  %dead.alias.next2110 = add i64 %dead.alias.pc2109, 16
  store i64 %dead.alias.next2110, ptr %pc, align 8
  br label %loop.check

handler.iumin.op86e.split.entry:                  ; preds = %execute.decode
  br label %handler.iumin.op86e.split.body

handler.iumin.op86e.split.body:                   ; preds = %handler.iumin.op86e.split.entry
  %dead.alias.pc2111 = load i64, ptr %pc, align 8
  %dead.alias.next2112 = add i64 %dead.alias.pc2111, 32
  store i64 %dead.alias.next2112, ptr %pc, align 8
  br label %loop.check

handler.prefetch.op90c.split.entry:               ; preds = %execute.decode
  br label %handler.prefetch.op90c.split.body

handler.prefetch.op90c.split.body:                ; preds = %handler.prefetch.op90c.split.entry
  %dead.alias.pc2113 = load i64, ptr %pc, align 8
  %dead.alias.next2114 = add i64 %dead.alias.pc2113, 16
  store i64 %dead.alias.next2114, ptr %pc, align 8
  br label %loop.check

handler.fadd.op97.split.entry:                    ; preds = %execute.decode
  br label %handler.fadd.op97.split.body

handler.fadd.op97.split.body:                     ; preds = %handler.fadd.op97.split.entry
  %dead.alias.pc2115 = load i64, ptr %pc, align 8
  %dead.alias.next2116 = add i64 %dead.alias.pc2115, 32
  store i64 %dead.alias.next2116, ptr %pc, align 8
  br label %loop.check

handler.load.op51.split.entry:                    ; preds = %execute.decode
  br label %handler.load.op51.split.body

handler.load.op51.split.body:                     ; preds = %handler.load.op51.split.entry
  %dead.alias.pc2117 = load i64, ptr %pc, align 8
  %dead.alias.next2118 = add i64 %dead.alias.pc2117, 32
  store i64 %dead.alias.next2118, ptr %pc, align 8
  br label %loop.check

handler.iand.op14.split.entry:                    ; preds = %execute.decode
  br label %handler.iand.op14.split.body

handler.iand.op14.split.body:                     ; preds = %handler.iand.op14.split.entry
  %dead.alias.pc2119 = load i64, ptr %pc, align 8
  %dead.alias.next2120 = add i64 %dead.alias.pc2119, 32
  store i64 %dead.alias.next2120, ptr %pc, align 8
  br label %loop.check

handler.ilshr.op862.split.entry:                  ; preds = %execute.decode
  br label %handler.ilshr.op862.split.body

handler.ilshr.op862.split.body:                   ; preds = %handler.ilshr.op862.split.entry
  %dead.alias.pc2121 = load i64, ptr %pc, align 8
  %dead.alias.next2122 = add i64 %dead.alias.pc2121, 32
  store i64 %dead.alias.next2122, ptr %pc, align 8
  br label %loop.check

handler.fcanonicalize.op715.split.entry:          ; preds = %execute.decode
  br label %handler.fcanonicalize.op715.split.body

handler.fcanonicalize.op715.split.body:           ; preds = %handler.fcanonicalize.op715.split.entry
  %dead.alias.pc2123 = load i64, ptr %pc, align 8
  %dead.alias.next2124 = add i64 %dead.alias.pc2123, 32
  store i64 %dead.alias.next2124, ptr %pc, align 8
  br label %loop.check

handler.bitreverse.op106.split.entry:             ; preds = %execute.decode
  br label %handler.bitreverse.op106.split.body

handler.bitreverse.op106.split.body:              ; preds = %handler.bitreverse.op106.split.entry
  %dead.alias.pc2125 = load i64, ptr %pc, align 8
  %dead.alias.next2126 = add i64 %dead.alias.pc2125, 32
  store i64 %dead.alias.next2126, ptr %pc, align 8
  br label %loop.check

handler.atomic_store.op924.split.entry:           ; preds = %execute.decode
  br label %handler.atomic_store.op924.split.body

handler.atomic_store.op924.split.body:            ; preds = %handler.atomic_store.op924.split.entry
  %dead.alias.pc2127 = load i64, ptr %pc, align 8
  %dead.alias.next2128 = add i64 %dead.alias.pc2127, 32
  store i64 %dead.alias.next2128, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_max.op938.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_max.op938.split.body

handler.atomic_rmw_max.op938.split.body:          ; preds = %handler.atomic_rmw_max.op938.split.entry
  %dead.alias.pc2129 = load i64, ptr %pc, align 8
  %dead.alias.next2130 = add i64 %dead.alias.pc2129, 32
  store i64 %dead.alias.next2130, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xor.op933.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_xor.op933.split.body

handler.atomic_rmw_xor.op933.split.body:          ; preds = %handler.atomic_rmw_xor.op933.split.entry
  %dead.alias.pc2131 = load i64, ptr %pc, align 8
  %dead.alias.next2132 = add i64 %dead.alias.pc2131, 32
  store i64 %dead.alias.next2132, ptr %pc, align 8
  br label %loop.check

handler.load_iurem.op98f.split.entry:             ; preds = %execute.decode
  br label %handler.load_iurem.op98f.split.body

handler.load_iurem.op98f.split.body:              ; preds = %handler.load_iurem.op98f.split.entry
  %dead.alias.pc2133 = load i64, ptr %pc, align 8
  %dead.alias.next2134 = add i64 %dead.alias.pc2133, 32
  store i64 %dead.alias.next2134, ptr %pc, align 8
  br label %loop.check

handler.read_fpmode.op82a.split.entry:            ; preds = %execute.decode
  br label %handler.read_fpmode.op82a.split.body

handler.read_fpmode.op82a.split.body:             ; preds = %handler.read_fpmode.op82a.split.entry
  %dead.alias.pc2135 = load i64, ptr %pc, align 8
  %dead.alias.next2136 = add i64 %dead.alias.pc2135, 8
  store i64 %dead.alias.next2136, ptr %pc, align 8
  br label %loop.check

handler.flog10.op72f.split.entry:                 ; preds = %execute.decode
  br label %handler.flog10.op72f.split.body

handler.flog10.op72f.split.body:                  ; preds = %handler.flog10.op72f.split.entry
  %dead.alias.pc2137 = load i64, ptr %pc, align 8
  %dead.alias.next2138 = add i64 %dead.alias.pc2137, 32
  store i64 %dead.alias.next2138, ptr %pc, align 8
  br label %loop.check

handler.iurem.op84d.split.entry:                  ; preds = %execute.decode
  br label %handler.iurem.op84d.split.body

handler.iurem.op84d.split.body:                   ; preds = %handler.iurem.op84d.split.entry
  %dead.alias.pc2139 = load i64, ptr %pc, align 8
  %dead.alias.next2140 = add i64 %dead.alias.pc2139, 32
  store i64 %dead.alias.next2140, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.opce.split.entry:                 ; preds = %execute.decode
  br label %handler.fptrunc.opce.split.body

handler.fptrunc.opce.split.body:                  ; preds = %handler.fptrunc.opce.split.entry
  %dead.alias.pc2141 = load i64, ptr %pc, align 8
  %dead.alias.next2142 = add i64 %dead.alias.pc2141, 32
  store i64 %dead.alias.next2142, ptr %pc, align 8
  br label %loop.check

handler.zext.op63.split.entry:                    ; preds = %execute.decode
  br label %handler.zext.op63.split.body

handler.zext.op63.split.body:                     ; preds = %handler.zext.op63.split.entry
  %dead.alias.pc2143 = load i64, ptr %pc, align 8
  %dead.alias.next2144 = add i64 %dead.alias.pc2143, 32
  store i64 %dead.alias.next2144, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xchg.ope0.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_xchg.ope0.split.body

handler.atomic_rmw_xchg.ope0.split.body:          ; preds = %handler.atomic_rmw_xchg.ope0.split.entry
  %dead.alias.pc2145 = load i64, ptr %pc, align 8
  %dead.alias.next2146 = add i64 %dead.alias.pc2145, 32
  store i64 %dead.alias.next2146, ptr %pc, align 8
  br label %loop.check

handler.iadd_xor.op10b.split.entry:               ; preds = %execute.decode
  br label %handler.iadd_xor.op10b.split.body

handler.iadd_xor.op10b.split.body:                ; preds = %handler.iadd_xor.op10b.split.entry
  %dead.alias.pc2147 = load i64, ptr %pc, align 8
  %dead.alias.next2148 = add i64 %dead.alias.pc2147, 48
  store i64 %dead.alias.next2148, ptr %pc, align 8
  br label %loop.check

handler.fptoui.opca.split.entry:                  ; preds = %execute.decode
  br label %handler.fptoui.opca.split.body

handler.fptoui.opca.split.body:                   ; preds = %handler.fptoui.opca.split.entry
  %dead.alias.pc2149 = load i64, ptr %pc, align 8
  %dead.alias.next2150 = add i64 %dead.alias.pc2149, 32
  store i64 %dead.alias.next2150, ptr %pc, align 8
  br label %loop.check

handler.fshl.op107.split.entry:                   ; preds = %execute.decode
  br label %handler.fshl.op107.split.body

handler.fshl.op107.split.body:                    ; preds = %handler.fshl.op107.split.entry
  %dead.alias.pc2151 = load i64, ptr %pc, align 8
  %dead.alias.next2152 = add i64 %dead.alias.pc2151, 48
  store i64 %dead.alias.next2152, ptr %pc, align 8
  br label %loop.check

handler.iusub_sat.op123.split.entry:              ; preds = %execute.decode
  br label %handler.iusub_sat.op123.split.body

handler.iusub_sat.op123.split.body:               ; preds = %handler.iusub_sat.op123.split.entry
  %dead.alias.pc2153 = load i64, ptr %pc, align 8
  %dead.alias.next2154 = add i64 %dead.alias.pc2153, 32
  store i64 %dead.alias.next2154, ptr %pc, align 8
  br label %loop.check

handler.ftrunc.op71b.split.entry:                 ; preds = %execute.decode
  br label %handler.ftrunc.op71b.split.body

handler.ftrunc.op71b.split.body:                  ; preds = %handler.ftrunc.op71b.split.entry
  %dead.alias.pc2155 = load i64, ptr %pc, align 8
  %dead.alias.next2156 = add i64 %dead.alias.pc2155, 32
  store i64 %dead.alias.next2156, ptr %pc, align 8
  br label %loop.check

handler.volatile_memset_dyn.op17d.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memset_dyn.op17d.split.body

handler.volatile_memset_dyn.op17d.split.body:     ; preds = %handler.volatile_memset_dyn.op17d.split.entry
  %dead.alias.pc2157 = load i64, ptr %pc, align 8
  %dead.alias.next2158 = add i64 %dead.alias.pc2157, 8
  store i64 %dead.alias.next2158, ptr %pc, align 8
  br label %loop.check

handler.load_iumin.op1ef.split.entry:             ; preds = %execute.decode
  br label %handler.load_iumin.op1ef.split.body

handler.load_iumin.op1ef.split.body:              ; preds = %handler.load_iumin.op1ef.split.entry
  %dead.alias.pc2159 = load i64, ptr %pc, align 8
  %dead.alias.next2160 = add i64 %dead.alias.pc2159, 32
  store i64 %dead.alias.next2160, ptr %pc, align 8
  br label %loop.check

handler.iand.op856.split.entry:                   ; preds = %execute.decode
  br label %handler.iand.op856.split.body

handler.iand.op856.split.body:                    ; preds = %handler.iand.op856.split.entry
  %iand.dst = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iand.lhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iand.rhs = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %iand.width = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %reg.load.ptr2161 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iand.lhs
  %lhs2162 = load i64, ptr %reg.load.ptr2161, align 8
  %reg.load.ptr2163 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iand.rhs
  %rhs2164 = load i64, ptr %reg.load.ptr2163, align 8
  %shift.masked2165 = and i64 %rhs2164, 63
  %bin.and = and i64 %lhs2162, %rhs2164
  %width.is642166 = icmp eq i64 %iand.width, 64
  %width.shift2167 = and i64 %iand.width, 63
  %mask.shifted2168 = shl i64 1, %width.shift2167
  %mask.candidate2169 = sub i64 %mask.shifted2168, 1
  %width.mask2170 = select i1 %width.is642166, i64 -1, i64 %mask.candidate2169
  %width.masked2171 = and i64 %bin.and, %width.mask2170
  %reg.store.ptr2172 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %iand.dst
  store i64 %width.masked2171, ptr %reg.store.ptr2172, align 8
  %pc.old2173 = load i64, ptr %pc, align 8
  %pc.next2174 = add i64 %pc.old2173, 32
  store i64 %pc.next2174, ptr %pc, align 8
  br label %loop.check

handler.iuadd_sat.op86f.split.entry:              ; preds = %execute.decode
  br label %handler.iuadd_sat.op86f.split.body

handler.iuadd_sat.op86f.split.body:               ; preds = %handler.iuadd_sat.op86f.split.entry
  %dead.alias.pc2175 = load i64, ptr %pc, align 8
  %dead.alias.next2176 = add i64 %dead.alias.pc2175, 32
  store i64 %dead.alias.next2176, ptr %pc, align 8
  br label %loop.check

handler.fceil.op8b9.split.entry:                  ; preds = %execute.decode
  br label %handler.fceil.op8b9.split.body

handler.fceil.op8b9.split.body:                   ; preds = %handler.fceil.op8b9.split.entry
  %dead.alias.pc2177 = load i64, ptr %pc, align 8
  %dead.alias.next2178 = add i64 %dead.alias.pc2177, 32
  store i64 %dead.alias.next2178, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmaximum.op94f.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fmaximum.op94f.split.body

handler.atomic_rmw_fmaximum.op94f.split.body:     ; preds = %handler.atomic_rmw_fmaximum.op94f.split.entry
  %dead.alias.pc2179 = load i64, ptr %pc, align 8
  %dead.alias.next2180 = add i64 %dead.alias.pc2179, 32
  store i64 %dead.alias.next2180, ptr %pc, align 8
  br label %loop.check

handler.ismax.op868.split.entry:                  ; preds = %execute.decode
  br label %handler.ismax.op868.split.body

handler.ismax.op868.split.body:                   ; preds = %handler.ismax.op868.split.entry
  %dead.alias.pc2181 = load i64, ptr %pc, align 8
  %dead.alias.next2182 = add i64 %dead.alias.pc2181, 32
  store i64 %dead.alias.next2182, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_uinc_wrap.op940.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_uinc_wrap.op940.split.body

handler.atomic_rmw_uinc_wrap.op940.split.body:    ; preds = %handler.atomic_rmw_uinc_wrap.op940.split.entry
  %dead.alias.pc2183 = load i64, ptr %pc, align 8
  %dead.alias.next2184 = add i64 %dead.alias.pc2183, 32
  store i64 %dead.alias.next2184, ptr %pc, align 8
  br label %loop.check

handler.zext.op23.split.entry:                    ; preds = %execute.decode
  br label %handler.zext.op23.split.body

handler.zext.op23.split.body:                     ; preds = %handler.zext.op23.split.entry
  %dead.alias.pc2185 = load i64, ptr %pc, align 8
  %dead.alias.next2186 = add i64 %dead.alias.pc2185, 32
  store i64 %dead.alias.next2186, ptr %pc, align 8
  br label %loop.check

handler.fadd.op98.split.entry:                    ; preds = %execute.decode
  br label %handler.fadd.op98.split.body

handler.fadd.op98.split.body:                     ; preds = %handler.fadd.op98.split.entry
  %dead.alias.pc2187 = load i64, ptr %pc, align 8
  %dead.alias.next2188 = add i64 %dead.alias.pc2187, 32
  store i64 %dead.alias.next2188, ptr %pc, align 8
  br label %loop.check

handler.fshr.op10a.split.entry:                   ; preds = %execute.decode
  br label %handler.fshr.op10a.split.body

handler.fshr.op10a.split.body:                    ; preds = %handler.fshr.op10a.split.entry
  %dead.alias.pc2189 = load i64, ptr %pc, align 8
  %dead.alias.next2190 = add i64 %dead.alias.pc2189, 48
  store i64 %dead.alias.next2190, ptr %pc, align 8
  br label %loop.check

handler.mov.op807.split.entry:                    ; preds = %execute.decode
  br label %handler.mov.op807.split.body

handler.mov.op807.split.body:                     ; preds = %handler.mov.op807.split.entry
  %dead.alias.pc2191 = load i64, ptr %pc, align 8
  %dead.alias.next2192 = add i64 %dead.alias.pc2191, 8
  store i64 %dead.alias.next2192, ptr %pc, align 8
  br label %loop.check

handler.load_issub_sat.op9a8.split.entry:         ; preds = %execute.decode
  br label %handler.load_issub_sat.op9a8.split.body

handler.load_issub_sat.op9a8.split.body:          ; preds = %handler.load_issub_sat.op9a8.split.entry
  %dead.alias.pc2193 = load i64, ptr %pc, align 8
  %dead.alias.next2194 = add i64 %dead.alias.pc2193, 32
  store i64 %dead.alias.next2194, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_uinc_wrap.op96a.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_uinc_wrap.op96a.split.body

handler.volatile_atomic_rmw_uinc_wrap.op96a.split.body: ; preds = %handler.volatile_atomic_rmw_uinc_wrap.op96a.split.entry
  %dead.alias.pc2195 = load i64, ptr %pc, align 8
  %dead.alias.next2196 = add i64 %dead.alias.pc2195, 32
  store i64 %dead.alias.next2196, ptr %pc, align 8
  br label %loop.check

handler.fminimum.op70f.split.entry:               ; preds = %execute.decode
  br label %handler.fminimum.op70f.split.body

handler.fminimum.op70f.split.body:                ; preds = %handler.fminimum.op70f.split.entry
  %dead.alias.pc2197 = load i64, ptr %pc, align 8
  %dead.alias.next2198 = add i64 %dead.alias.pc2197, 16
  store i64 %dead.alias.next2198, ptr %pc, align 8
  br label %loop.check

handler.fptoui.op8dd.split.entry:                 ; preds = %execute.decode
  br label %handler.fptoui.op8dd.split.body

handler.fptoui.op8dd.split.body:                  ; preds = %handler.fptoui.op8dd.split.entry
  %dead.alias.pc2199 = load i64, ptr %pc, align 8
  %dead.alias.next2200 = add i64 %dead.alias.pc2199, 32
  store i64 %dead.alias.next2200, ptr %pc, align 8
  br label %loop.check

handler.iadd.op2c.split.entry:                    ; preds = %execute.decode
  br label %handler.iadd.op2c.split.body

handler.iadd.op2c.split.body:                     ; preds = %handler.iadd.op2c.split.entry
  %dead.alias.pc2201 = load i64, ptr %pc, align 8
  %dead.alias.next2202 = add i64 %dead.alias.pc2201, 16
  store i64 %dead.alias.next2202, ptr %pc, align 8
  br label %loop.check

handler.read_cycle.op811.split.entry:             ; preds = %execute.decode
  br label %handler.read_cycle.op811.split.body

handler.read_cycle.op811.split.body:              ; preds = %handler.read_cycle.op811.split.entry
  %dead.alias.pc2203 = load i64, ptr %pc, align 8
  %dead.alias.next2204 = add i64 %dead.alias.pc2203, 8
  store i64 %dead.alias.next2204, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmin.op977.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmin.op977.split.body

handler.volatile_atomic_rmw_fmin.op977.split.body: ; preds = %handler.volatile_atomic_rmw_fmin.op977.split.entry
  %dead.alias.pc2205 = load i64, ptr %pc, align 8
  %dead.alias.next2206 = add i64 %dead.alias.pc2205, 32
  store i64 %dead.alias.next2206, ptr %pc, align 8
  br label %loop.check

handler.bswap.op88f.split.entry:                  ; preds = %execute.decode
  br label %handler.bswap.op88f.split.body

handler.bswap.op88f.split.body:                   ; preds = %handler.bswap.op88f.split.entry
  %dead.alias.pc2207 = load i64, ptr %pc, align 8
  %dead.alias.next2208 = add i64 %dead.alias.pc2207, 32
  store i64 %dead.alias.next2208, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_max.op961.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_max.op961.split.body

handler.volatile_atomic_rmw_max.op961.split.body: ; preds = %handler.volatile_atomic_rmw_max.op961.split.entry
  %dead.alias.pc2209 = load i64, ptr %pc, align 8
  %dead.alias.next2210 = add i64 %dead.alias.pc2209, 32
  store i64 %dead.alias.next2210, ptr %pc, align 8
  br label %loop.check

handler.sitofp.opb9.split.entry:                  ; preds = %execute.decode
  br label %handler.sitofp.opb9.split.body

handler.sitofp.opb9.split.body:                   ; preds = %handler.sitofp.opb9.split.entry
  %dead.alias.pc2211 = load i64, ptr %pc, align 8
  %dead.alias.next2212 = add i64 %dead.alias.pc2211, 32
  store i64 %dead.alias.next2212, ptr %pc, align 8
  br label %loop.check

handler.fcmp.opb0.split.entry:                    ; preds = %execute.decode
  br label %handler.fcmp.opb0.split.body

handler.fcmp.opb0.split.body:                     ; preds = %handler.fcmp.opb0.split.entry
  %dead.alias.pc2213 = load i64, ptr %pc, align 8
  %dead.alias.next2214 = add i64 %dead.alias.pc2213, 32
  store i64 %dead.alias.next2214, ptr %pc, align 8
  br label %loop.check

handler.fmaximum.op710.split.entry:               ; preds = %execute.decode
  br label %handler.fmaximum.op710.split.body

handler.fmaximum.op710.split.body:                ; preds = %handler.fmaximum.op710.split.entry
  %dead.alias.pc2215 = load i64, ptr %pc, align 8
  %dead.alias.next2216 = add i64 %dead.alias.pc2215, 16
  store i64 %dead.alias.next2216, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmaximum.op1a6.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmaximum.op1a6.split.body

handler.volatile_atomic_rmw_fmaximum.op1a6.split.body: ; preds = %handler.volatile_atomic_rmw_fmaximum.op1a6.split.entry
  %dead.alias.pc2217 = load i64, ptr %pc, align 8
  %dead.alias.next2218 = add i64 %dead.alias.pc2217, 32
  store i64 %dead.alias.next2218, ptr %pc, align 8
  br label %loop.check

handler.fpext.op8e6.split.entry:                  ; preds = %execute.decode
  br label %handler.fpext.op8e6.split.body

handler.fpext.op8e6.split.body:                   ; preds = %handler.fpext.op8e6.split.entry
  %dead.alias.pc2219 = load i64, ptr %pc, align 8
  %dead.alias.next2220 = add i64 %dead.alias.pc2219, 32
  store i64 %dead.alias.next2220, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fmaximum.op97a.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fmaximum.op97a.split.body

handler.volatile_atomic_rmw_fmaximum.op97a.split.body: ; preds = %handler.volatile_atomic_rmw_fmaximum.op97a.split.entry
  %dead.alias.pc2221 = load i64, ptr %pc, align 8
  %dead.alias.next2222 = add i64 %dead.alias.pc2221, 32
  store i64 %dead.alias.next2222, ptr %pc, align 8
  br label %loop.check

handler.ishl.op78.split.entry:                    ; preds = %execute.decode
  br label %handler.ishl.op78.split.body

handler.ishl.op78.split.body:                     ; preds = %handler.ishl.op78.split.entry
  %dead.alias.pc2223 = load i64, ptr %pc, align 8
  %dead.alias.next2224 = add i64 %dead.alias.pc2223, 32
  store i64 %dead.alias.next2224, ptr %pc, align 8
  br label %loop.check

handler.bitcast.op8fd.split.entry:                ; preds = %execute.decode
  br label %handler.bitcast.op8fd.split.body

handler.bitcast.op8fd.split.body:                 ; preds = %handler.bitcast.op8fd.split.entry
  %dead.alias.pc2225 = load i64, ptr %pc, align 8
  %dead.alias.next2226 = add i64 %dead.alias.pc2225, 32
  store i64 %dead.alias.next2226, ptr %pc, align 8
  br label %loop.check

handler.fence.op982.split.entry:                  ; preds = %execute.decode
  br label %handler.fence.op982.split.body

handler.fence.op982.split.body:                   ; preds = %handler.fence.op982.split.entry
  %dead.alias.pc2227 = load i64, ptr %pc, align 8
  %dead.alias.next2228 = add i64 %dead.alias.pc2227, 32
  store i64 %dead.alias.next2228, ptr %pc, align 8
  br label %loop.check

handler.gep_load.op986.split.entry:               ; preds = %execute.decode
  br label %handler.gep_load.op986.split.body

handler.gep_load.op986.split.body:                ; preds = %handler.gep_load.op986.split.entry
  %dead.alias.pc2229 = load i64, ptr %pc, align 8
  %dead.alias.next2230 = add i64 %dead.alias.pc2229, 32
  store i64 %dead.alias.next2230, ptr %pc, align 8
  br label %loop.check

handler.read_cycle.op810.split.entry:             ; preds = %execute.decode
  br label %handler.read_cycle.op810.split.body

handler.read_cycle.op810.split.body:              ; preds = %handler.read_cycle.op810.split.entry
  %dead.alias.pc2231 = load i64, ptr %pc, align 8
  %dead.alias.next2232 = add i64 %dead.alias.pc2231, 8
  store i64 %dead.alias.next2232, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmax.op94b.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmax.op94b.split.body

handler.atomic_rmw_fmax.op94b.split.body:         ; preds = %handler.atomic_rmw_fmax.op94b.split.entry
  %dead.alias.pc2233 = load i64, ptr %pc, align 8
  %dead.alias.next2234 = add i64 %dead.alias.pc2233, 32
  store i64 %dead.alias.next2234, ptr %pc, align 8
  br label %loop.check

handler.isrem.op93.split.entry:                   ; preds = %execute.decode
  br label %handler.isrem.op93.split.body

handler.isrem.op93.split.body:                    ; preds = %handler.isrem.op93.split.entry
  %dead.alias.pc2235 = load i64, ptr %pc, align 8
  %dead.alias.next2236 = add i64 %dead.alias.pc2235, 32
  store i64 %dead.alias.next2236, ptr %pc, align 8
  br label %loop.check

handler.fsub.op9b.split.entry:                    ; preds = %execute.decode
  br label %handler.fsub.op9b.split.body

handler.fsub.op9b.split.body:                     ; preds = %handler.fsub.op9b.split.entry
  %dead.alias.pc2237 = load i64, ptr %pc, align 8
  %dead.alias.next2238 = add i64 %dead.alias.pc2237, 32
  store i64 %dead.alias.next2238, ptr %pc, align 8
  br label %loop.check

handler.write_rounding.op1c3.split.entry:         ; preds = %execute.decode
  br label %handler.write_rounding.op1c3.split.body

handler.write_rounding.op1c3.split.body:          ; preds = %handler.write_rounding.op1c3.split.entry
  %dead.alias.pc2239 = load i64, ptr %pc, align 8
  %dead.alias.next2240 = add i64 %dead.alias.pc2239, 8
  store i64 %dead.alias.next2240, ptr %pc, align 8
  br label %loop.check

handler.load.op90d.split.entry:                   ; preds = %execute.decode
  br label %handler.load.op90d.split.body

handler.load.op90d.split.body:                    ; preds = %handler.load.op90d.split.entry
  %dead.alias.pc2241 = load i64, ptr %pc, align 8
  %dead.alias.next2242 = add i64 %dead.alias.pc2241, 32
  store i64 %dead.alias.next2242, ptr %pc, align 8
  br label %loop.check

handler.iusub_overflow.op132.split.entry:         ; preds = %execute.decode
  br label %handler.iusub_overflow.op132.split.body

handler.iusub_overflow.op132.split.body:          ; preds = %handler.iusub_overflow.op132.split.entry
  %dead.alias.pc2243 = load i64, ptr %pc, align 8
  %dead.alias.next2244 = add i64 %dead.alias.pc2243, 32
  store i64 %dead.alias.next2244, ptr %pc, align 8
  br label %loop.check

handler.icmp.op76.split.entry:                    ; preds = %execute.decode
  br label %handler.icmp.op76.split.body

handler.icmp.op76.split.body:                     ; preds = %handler.icmp.op76.split.entry
  %dead.alias.pc2245 = load i64, ptr %pc, align 8
  %dead.alias.next2246 = add i64 %dead.alias.pc2245, 32
  store i64 %dead.alias.next2246, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op80.split.entry:                   ; preds = %execute.decode
  br label %handler.iudiv.op80.split.body

handler.iudiv.op80.split.body:                    ; preds = %handler.iudiv.op80.split.entry
  %dead.alias.pc2247 = load i64, ptr %pc, align 8
  %dead.alias.next2248 = add i64 %dead.alias.pc2247, 32
  store i64 %dead.alias.next2248, ptr %pc, align 8
  br label %loop.check

handler.ishl.op16.split.entry:                    ; preds = %execute.decode
  br label %handler.ishl.op16.split.body

handler.ishl.op16.split.body:                     ; preds = %handler.ishl.op16.split.entry
  %dead.alias.pc2249 = load i64, ptr %pc, align 8
  %dead.alias.next2250 = add i64 %dead.alias.pc2249, 32
  store i64 %dead.alias.next2250, ptr %pc, align 8
  br label %loop.check

handler.ishl.op85e.split.entry:                   ; preds = %execute.decode
  br label %handler.ishl.op85e.split.body

handler.ishl.op85e.split.body:                    ; preds = %handler.ishl.op85e.split.entry
  %dead.alias.pc2251 = load i64, ptr %pc, align 8
  %dead.alias.next2252 = add i64 %dead.alias.pc2251, 32
  store i64 %dead.alias.next2252, ptr %pc, align 8
  br label %loop.check

handler.load_iuadd_sat.op1f0.split.entry:         ; preds = %execute.decode
  br label %handler.load_iuadd_sat.op1f0.split.body

handler.load_iuadd_sat.op1f0.split.body:          ; preds = %handler.load_iuadd_sat.op1f0.split.entry
  %dead.alias.pc2253 = load i64, ptr %pc, align 8
  %dead.alias.next2254 = add i64 %dead.alias.pc2253, 32
  store i64 %dead.alias.next2254, ptr %pc, align 8
  br label %loop.check

handler.load_iushl_sat.op9aa.split.entry:         ; preds = %execute.decode
  br label %handler.load_iushl_sat.op9aa.split.body

handler.load_iushl_sat.op9aa.split.body:          ; preds = %handler.load_iushl_sat.op9aa.split.entry
  %dead.alias.pc2255 = load i64, ptr %pc, align 8
  %dead.alias.next2256 = add i64 %dead.alias.pc2255, 32
  store i64 %dead.alias.next2256, ptr %pc, align 8
  br label %loop.check

handler.cttz.op88b.split.entry:                   ; preds = %execute.decode
  br label %handler.cttz.op88b.split.body

handler.cttz.op88b.split.body:                    ; preds = %handler.cttz.op88b.split.entry
  %dead.alias.pc2257 = load i64, ptr %pc, align 8
  %dead.alias.next2258 = add i64 %dead.alias.pc2257, 32
  store i64 %dead.alias.next2258, ptr %pc, align 8
  br label %loop.check

handler.volatile_memcpy_dyn.op179.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memcpy_dyn.op179.split.body

handler.volatile_memcpy_dyn.op179.split.body:     ; preds = %handler.volatile_memcpy_dyn.op179.split.entry
  %dead.alias.pc2259 = load i64, ptr %pc, align 8
  %dead.alias.next2260 = add i64 %dead.alias.pc2259, 8
  store i64 %dead.alias.next2260, ptr %pc, align 8
  br label %loop.check

handler.iashr.op863.split.entry:                  ; preds = %execute.decode
  br label %handler.iashr.op863.split.body

handler.iashr.op863.split.body:                   ; preds = %handler.iashr.op863.split.entry
  %dead.alias.pc2261 = load i64, ptr %pc, align 8
  %dead.alias.next2262 = add i64 %dead.alias.pc2261, 32
  store i64 %dead.alias.next2262, ptr %pc, align 8
  br label %loop.check

handler.fpowi.op734.split.entry:                  ; preds = %execute.decode
  br label %handler.fpowi.op734.split.body

handler.fpowi.op734.split.body:                   ; preds = %handler.fpowi.op734.split.entry
  %dead.alias.pc2263 = load i64, ptr %pc, align 8
  %dead.alias.next2264 = add i64 %dead.alias.pc2263, 16
  store i64 %dead.alias.next2264, ptr %pc, align 8
  br label %loop.check

handler.load_iurem.op1df.split.entry:             ; preds = %execute.decode
  br label %handler.load_iurem.op1df.split.body

handler.load_iurem.op1df.split.body:              ; preds = %handler.load_iurem.op1df.split.entry
  %dead.alias.pc2265 = load i64, ptr %pc, align 8
  %dead.alias.next2266 = add i64 %dead.alias.pc2265, 32
  store i64 %dead.alias.next2266, ptr %pc, align 8
  br label %loop.check

handler.volatile_memset_dyn.op91f.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memset_dyn.op91f.split.body

handler.volatile_memset_dyn.op91f.split.body:     ; preds = %handler.volatile_memset_dyn.op91f.split.entry
  %dead.alias.pc2267 = load i64, ptr %pc, align 8
  %dead.alias.next2268 = add i64 %dead.alias.pc2267, 8
  store i64 %dead.alias.next2268, ptr %pc, align 8
  br label %loop.check

handler.uitofp.opbf.split.entry:                  ; preds = %execute.decode
  br label %handler.uitofp.opbf.split.body

handler.uitofp.opbf.split.body:                   ; preds = %handler.uitofp.opbf.split.entry
  %dead.alias.pc2269 = load i64, ptr %pc, align 8
  %dead.alias.next2270 = add i64 %dead.alias.pc2269, 32
  store i64 %dead.alias.next2270, ptr %pc, align 8
  br label %loop.check

handler.fsub.op89a.split.entry:                   ; preds = %execute.decode
  br label %handler.fsub.op89a.split.body

handler.fsub.op89a.split.body:                    ; preds = %handler.fsub.op89a.split.entry
  %dead.alias.pc2271 = load i64, ptr %pc, align 8
  %dead.alias.next2272 = add i64 %dead.alias.pc2271, 32
  store i64 %dead.alias.next2272, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fadd.op971.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fadd.op971.split.body

handler.volatile_atomic_rmw_fadd.op971.split.body: ; preds = %handler.volatile_atomic_rmw_fadd.op971.split.entry
  %dead.alias.pc2273 = load i64, ptr %pc, align 8
  %dead.alias.next2274 = add i64 %dead.alias.pc2273, 32
  store i64 %dead.alias.next2274, ptr %pc, align 8
  br label %loop.check

handler.ffloor.op716.split.entry:                 ; preds = %execute.decode
  br label %handler.ffloor.op716.split.body

handler.ffloor.op716.split.body:                  ; preds = %handler.ffloor.op716.split.entry
  %dead.alias.pc2275 = load i64, ptr %pc, align 8
  %dead.alias.next2276 = add i64 %dead.alias.pc2275, 32
  store i64 %dead.alias.next2276, ptr %pc, align 8
  br label %loop.check

handler.call_native.op5b.split.entry:             ; preds = %execute.decode
  br label %handler.call_native.op5b.split.body

handler.call_native.op5b.split.body:              ; preds = %handler.call_native.op5b.split.entry
  %dead.alias.pc2277 = load i64, ptr %pc, align 8
  %dead.alias.next2278 = add i64 %dead.alias.pc2277, 64
  store i64 %dead.alias.next2278, ptr %pc, align 8
  br label %loop.check

handler.bswap.op103.split.entry:                  ; preds = %execute.decode
  br label %handler.bswap.op103.split.body

handler.bswap.op103.split.body:                   ; preds = %handler.bswap.op103.split.entry
  %dead.alias.pc2279 = load i64, ptr %pc, align 8
  %dead.alias.next2280 = add i64 %dead.alias.pc2279, 32
  store i64 %dead.alias.next2280, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op84a.split.entry:                  ; preds = %execute.decode
  br label %handler.isdiv.op84a.split.body

handler.isdiv.op84a.split.body:                   ; preds = %handler.isdiv.op84a.split.entry
  %dead.alias.pc2281 = load i64, ptr %pc, align 8
  %dead.alias.next2282 = add i64 %dead.alias.pc2281, 32
  store i64 %dead.alias.next2282, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_or.op95c.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_or.op95c.split.body

handler.volatile_atomic_rmw_or.op95c.split.body:  ; preds = %handler.volatile_atomic_rmw_or.op95c.split.entry
  %dead.alias.pc2283 = load i64, ptr %pc, align 8
  %dead.alias.next2284 = add i64 %dead.alias.pc2283, 32
  store i64 %dead.alias.next2284, ptr %pc, align 8
  br label %loop.check

handler.fmaximum.op711.split.entry:               ; preds = %execute.decode
  br label %handler.fmaximum.op711.split.body

handler.fmaximum.op711.split.body:                ; preds = %handler.fmaximum.op711.split.entry
  %dead.alias.pc2285 = load i64, ptr %pc, align 8
  %dead.alias.next2286 = add i64 %dead.alias.pc2285, 16
  store i64 %dead.alias.next2286, ptr %pc, align 8
  br label %loop.check

handler.read_fpenv.op1c4.split.entry:             ; preds = %execute.decode
  br label %handler.read_fpenv.op1c4.split.body

handler.read_fpenv.op1c4.split.body:              ; preds = %handler.read_fpenv.op1c4.split.entry
  %dead.alias.pc2287 = load i64, ptr %pc, align 8
  %dead.alias.next2288 = add i64 %dead.alias.pc2287, 8
  store i64 %dead.alias.next2288, ptr %pc, align 8
  br label %loop.check

handler.iudiv.op845.split.entry:                  ; preds = %execute.decode
  br label %handler.iudiv.op845.split.body

handler.iudiv.op845.split.body:                   ; preds = %handler.iudiv.op845.split.entry
  %dead.alias.pc2289 = load i64, ptr %pc, align 8
  %dead.alias.next2290 = add i64 %dead.alias.pc2289, 32
  store i64 %dead.alias.next2290, ptr %pc, align 8
  br label %loop.check

handler.load_ior.op9b0.split.entry:               ; preds = %execute.decode
  br label %handler.load_ior.op9b0.split.body

handler.load_ior.op9b0.split.body:                ; preds = %handler.load_ior.op9b0.split.entry
  %dead.alias.pc2291 = load i64, ptr %pc, align 8
  %dead.alias.next2292 = add i64 %dead.alias.pc2291, 32
  store i64 %dead.alias.next2292, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_cond.op96d.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_cond.op96d.split.body

handler.volatile_atomic_rmw_usub_cond.op96d.split.body: ; preds = %handler.volatile_atomic_rmw_usub_cond.op96d.split.entry
  %dead.alias.pc2293 = load i64, ptr %pc, align 8
  %dead.alias.next2294 = add i64 %dead.alias.pc2293, 32
  store i64 %dead.alias.next2294, ptr %pc, align 8
  br label %loop.check

handler.trunc.op1b.split.entry:                   ; preds = %execute.decode
  br label %handler.trunc.op1b.split.body

handler.trunc.op1b.split.body:                    ; preds = %handler.trunc.op1b.split.entry
  %dead.alias.pc2295 = load i64, ptr %pc, align 8
  %dead.alias.next2296 = add i64 %dead.alias.pc2295, 32
  store i64 %dead.alias.next2296, ptr %pc, align 8
  br label %loop.check

handler.ctlz.op113.split.entry:                   ; preds = %execute.decode
  br label %handler.ctlz.op113.split.body

handler.ctlz.op113.split.body:                    ; preds = %handler.ctlz.op113.split.entry
  %dead.alias.pc2297 = load i64, ptr %pc, align 8
  %dead.alias.next2298 = add i64 %dead.alias.pc2297, 32
  store i64 %dead.alias.next2298, ptr %pc, align 8
  br label %loop.check

handler.iurem.op8e.split.entry:                   ; preds = %execute.decode
  br label %handler.iurem.op8e.split.body

handler.iurem.op8e.split.body:                    ; preds = %handler.iurem.op8e.split.entry
  %dead.alias.pc2299 = load i64, ptr %pc, align 8
  %dead.alias.next2300 = add i64 %dead.alias.pc2299, 32
  store i64 %dead.alias.next2300, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_uinc_wrap.op16c.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_uinc_wrap.op16c.split.body

handler.atomic_rmw_uinc_wrap.op16c.split.body:    ; preds = %handler.atomic_rmw_uinc_wrap.op16c.split.entry
  %dead.alias.pc2301 = load i64, ptr %pc, align 8
  %dead.alias.next2302 = add i64 %dead.alias.pc2301, 32
  store i64 %dead.alias.next2302, ptr %pc, align 8
  br label %loop.check

handler.load_ixor.opfc.split.entry:               ; preds = %execute.decode
  br label %handler.load_ixor.opfc.split.body

handler.load_ixor.opfc.split.body:                ; preds = %handler.load_ixor.opfc.split.entry
  %dead.alias.pc2303 = load i64, ptr %pc, align 8
  %dead.alias.next2304 = add i64 %dead.alias.pc2303, 32
  store i64 %dead.alias.next2304, ptr %pc, align 8
  br label %loop.check

handler.tls_addr.op809.split.entry:               ; preds = %execute.decode
  br label %handler.tls_addr.op809.split.body

handler.tls_addr.op809.split.body:                ; preds = %handler.tls_addr.op809.split.entry
  %dead.alias.pc2305 = load i64, ptr %pc, align 8
  %dead.alias.next2306 = add i64 %dead.alias.pc2305, 8
  store i64 %dead.alias.next2306, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_sat.op19d.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_sat.op19d.split.body

handler.volatile_atomic_rmw_usub_sat.op19d.split.body: ; preds = %handler.volatile_atomic_rmw_usub_sat.op19d.split.entry
  %dead.alias.pc2307 = load i64, ptr %pc, align 8
  %dead.alias.next2308 = add i64 %dead.alias.pc2307, 32
  store i64 %dead.alias.next2308, ptr %pc, align 8
  br label %loop.check

handler.iumul_overflow.op884.split.entry:         ; preds = %execute.decode
  br label %handler.iumul_overflow.op884.split.body

handler.iumul_overflow.op884.split.body:          ; preds = %handler.iumul_overflow.op884.split.entry
  %dead.alias.pc2309 = load i64, ptr %pc, align 8
  %dead.alias.next2310 = add i64 %dead.alias.pc2309, 32
  store i64 %dead.alias.next2310, ptr %pc, align 8
  br label %loop.check

handler.fcos.op726.split.entry:                   ; preds = %execute.decode
  br label %handler.fcos.op726.split.body

handler.fcos.op726.split.body:                    ; preds = %handler.fcos.op726.split.entry
  %dead.alias.pc2311 = load i64, ptr %pc, align 8
  %dead.alias.next2312 = add i64 %dead.alias.pc2311, 32
  store i64 %dead.alias.next2312, ptr %pc, align 8
  br label %loop.check

handler.read_thread_pointer.op834.split.entry:    ; preds = %execute.decode
  br label %handler.read_thread_pointer.op834.split.body

handler.read_thread_pointer.op834.split.body:     ; preds = %handler.read_thread_pointer.op834.split.entry
  %dead.alias.pc2313 = load i64, ptr %pc, align 8
  %dead.alias.next2314 = add i64 %dead.alias.pc2313, 8
  store i64 %dead.alias.next2314, ptr %pc, align 8
  br label %loop.check

handler.const_load.op03.split.entry:              ; preds = %execute.decode
  br label %handler.const_load.op03.split.body

handler.const_load.op03.split.body:               ; preds = %handler.const_load.op03.split.entry
  %dead.alias.pc2315 = load i64, ptr %pc, align 8
  %dead.alias.next2316 = add i64 %dead.alias.pc2315, 32
  store i64 %dead.alias.next2316, ptr %pc, align 8
  br label %loop.check

handler.flround.op8ec.split.entry:                ; preds = %execute.decode
  br label %handler.flround.op8ec.split.body

handler.flround.op8ec.split.body:                 ; preds = %handler.flround.op8ec.split.entry
  %dead.alias.pc2317 = load i64, ptr %pc, align 8
  %dead.alias.next2318 = add i64 %dead.alias.pc2317, 16
  store i64 %dead.alias.next2318, ptr %pc, align 8
  br label %loop.check

handler.isshl_sat.op87a.split.entry:              ; preds = %execute.decode
  br label %handler.isshl_sat.op87a.split.body

handler.isshl_sat.op87a.split.body:               ; preds = %handler.isshl_sat.op87a.split.entry
  %dead.alias.pc2319 = load i64, ptr %pc, align 8
  %dead.alias.next2320 = add i64 %dead.alias.pc2319, 32
  store i64 %dead.alias.next2320, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_or.op95b.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_or.op95b.split.body

handler.volatile_atomic_rmw_or.op95b.split.body:  ; preds = %handler.volatile_atomic_rmw_or.op95b.split.entry
  %dead.alias.pc2321 = load i64, ptr %pc, align 8
  %dead.alias.next2322 = add i64 %dead.alias.pc2321, 32
  store i64 %dead.alias.next2322, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fminimum.op16b.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fminimum.op16b.split.body

handler.atomic_rmw_fminimum.op16b.split.body:     ; preds = %handler.atomic_rmw_fminimum.op16b.split.entry
  %dead.alias.pc2323 = load i64, ptr %pc, align 8
  %dead.alias.next2324 = add i64 %dead.alias.pc2323, 32
  store i64 %dead.alias.next2324, ptr %pc, align 8
  br label %loop.check

handler.const_load.op5f.split.entry:              ; preds = %execute.decode
  br label %handler.const_load.op5f.split.body

handler.const_load.op5f.split.body:               ; preds = %handler.const_load.op5f.split.entry
  %dead.alias.pc2325 = load i64, ptr %pc, align 8
  %dead.alias.next2326 = add i64 %dead.alias.pc2325, 32
  store i64 %dead.alias.next2326, ptr %pc, align 8
  br label %loop.check

handler.fptoui_sat.op1ba.split.entry:             ; preds = %execute.decode
  br label %handler.fptoui_sat.op1ba.split.body

handler.fptoui_sat.op1ba.split.body:              ; preds = %handler.fptoui_sat.op1ba.split.entry
  %dead.alias.pc2327 = load i64, ptr %pc, align 8
  %dead.alias.next2328 = add i64 %dead.alias.pc2327, 16
  store i64 %dead.alias.next2328, ptr %pc, align 8
  br label %loop.check

handler.sideeffect.op837.split.entry:             ; preds = %execute.decode
  br label %handler.sideeffect.op837.split.body

handler.sideeffect.op837.split.body:              ; preds = %handler.sideeffect.op837.split.entry
  %dead.alias.pc2329 = load i64, ptr %pc, align 8
  %dead.alias.next2330 = add i64 %dead.alias.pc2329, 4
  store i64 %dead.alias.next2330, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_max.op962.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_max.op962.split.body

handler.volatile_atomic_rmw_max.op962.split.body: ; preds = %handler.volatile_atomic_rmw_max.op962.split.entry
  %dead.alias.pc2331 = load i64, ptr %pc, align 8
  %dead.alias.next2332 = add i64 %dead.alias.pc2331, 32
  store i64 %dead.alias.next2332, ptr %pc, align 8
  br label %loop.check

handler.ismax.op119.split.entry:                  ; preds = %execute.decode
  br label %handler.ismax.op119.split.body

handler.ismax.op119.split.body:                   ; preds = %handler.ismax.op119.split.entry
  %dead.alias.pc2333 = load i64, ptr %pc, align 8
  %dead.alias.next2334 = add i64 %dead.alias.pc2333, 32
  store i64 %dead.alias.next2334, ptr %pc, align 8
  br label %loop.check

handler.fpowi.op8a5.split.entry:                  ; preds = %execute.decode
  br label %handler.fpowi.op8a5.split.body

handler.fpowi.op8a5.split.body:                   ; preds = %handler.fpowi.op8a5.split.entry
  %dead.alias.pc2335 = load i64, ptr %pc, align 8
  %dead.alias.next2336 = add i64 %dead.alias.pc2335, 16
  store i64 %dead.alias.next2336, ptr %pc, align 8
  br label %loop.check

handler.sext.op8fa.split.entry:                   ; preds = %execute.decode
  br label %handler.sext.op8fa.split.body

handler.sext.op8fa.split.body:                    ; preds = %handler.sext.op8fa.split.entry
  %dead.alias.pc2337 = load i64, ptr %pc, align 8
  %dead.alias.next2338 = add i64 %dead.alias.pc2337, 32
  store i64 %dead.alias.next2338, ptr %pc, align 8
  br label %loop.check

handler.iumin.op86d.split.entry:                  ; preds = %execute.decode
  br label %handler.iumin.op86d.split.body

handler.iumin.op86d.split.body:                   ; preds = %handler.iumin.op86d.split.entry
  %dead.alias.pc2339 = load i64, ptr %pc, align 8
  %dead.alias.next2340 = add i64 %dead.alias.pc2339, 32
  store i64 %dead.alias.next2340, ptr %pc, align 8
  br label %loop.check

handler.load_iadd.op112.split.entry:              ; preds = %execute.decode
  br label %handler.load_iadd.op112.split.body

handler.load_iadd.op112.split.body:               ; preds = %handler.load_iadd.op112.split.entry
  %dead.alias.pc2341 = load i64, ptr %pc, align 8
  %dead.alias.next2342 = add i64 %dead.alias.pc2341, 32
  store i64 %dead.alias.next2342, ptr %pc, align 8
  br label %loop.check

handler.pseudoprobe.op90a.split.entry:            ; preds = %execute.decode
  br label %handler.pseudoprobe.op90a.split.body

handler.pseudoprobe.op90a.split.body:             ; preds = %handler.pseudoprobe.op90a.split.entry
  %dead.alias.pc2343 = load i64, ptr %pc, align 8
  %dead.alias.next2344 = add i64 %dead.alias.pc2343, 48
  store i64 %dead.alias.next2344, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op86.split.entry:                   ; preds = %execute.decode
  br label %handler.isdiv.op86.split.body

handler.isdiv.op86.split.body:                    ; preds = %handler.isdiv.op86.split.entry
  %dead.alias.pc2345 = load i64, ptr %pc, align 8
  %dead.alias.next2346 = add i64 %dead.alias.pc2345, 32
  store i64 %dead.alias.next2346, ptr %pc, align 8
  br label %loop.check

handler.gep.op22.split.entry:                     ; preds = %execute.decode
  br label %handler.gep.op22.split.body

handler.gep.op22.split.body:                      ; preds = %handler.gep.op22.split.entry
  %dead.alias.pc2347 = load i64, ptr %pc, align 8
  %dead.alias.next2348 = add i64 %dead.alias.pc2347, 32
  store i64 %dead.alias.next2348, ptr %pc, align 8
  br label %loop.check

handler.load_ishl.op1e2.split.entry:              ; preds = %execute.decode
  br label %handler.load_ishl.op1e2.split.body

handler.load_ishl.op1e2.split.body:               ; preds = %handler.load_ishl.op1e2.split.entry
  %dead.alias.pc2349 = load i64, ptr %pc, align 8
  %dead.alias.next2350 = add i64 %dead.alias.pc2349, 32
  store i64 %dead.alias.next2350, ptr %pc, align 8
  br label %loop.check

handler.fptosi.opc5.split.entry:                  ; preds = %execute.decode
  br label %handler.fptosi.opc5.split.body

handler.fptosi.opc5.split.body:                   ; preds = %handler.fptosi.opc5.split.entry
  %dead.alias.pc2351 = load i64, ptr %pc, align 8
  %dead.alias.next2352 = add i64 %dead.alias.pc2351, 32
  store i64 %dead.alias.next2352, ptr %pc, align 8
  br label %loop.check

handler.fptosi_sat.op8df.split.entry:             ; preds = %execute.decode
  br label %handler.fptosi_sat.op8df.split.body

handler.fptosi_sat.op8df.split.body:              ; preds = %handler.fptosi_sat.op8df.split.entry
  %dead.alias.pc2353 = load i64, ptr %pc, align 8
  %dead.alias.next2354 = add i64 %dead.alias.pc2353, 16
  store i64 %dead.alias.next2354, ptr %pc, align 8
  br label %loop.check

handler.fptoui.op8de.split.entry:                 ; preds = %execute.decode
  br label %handler.fptoui.op8de.split.body

handler.fptoui.op8de.split.body:                  ; preds = %handler.fptoui.op8de.split.entry
  %dead.alias.pc2355 = load i64, ptr %pc, align 8
  %dead.alias.next2356 = add i64 %dead.alias.pc2355, 32
  store i64 %dead.alias.next2356, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.opcb.split.entry:                 ; preds = %execute.decode
  br label %handler.fptrunc.opcb.split.body

handler.fptrunc.opcb.split.body:                  ; preds = %handler.fptrunc.opcb.split.entry
  %dead.alias.pc2357 = load i64, ptr %pc, align 8
  %dead.alias.next2358 = add i64 %dead.alias.pc2357, 32
  store i64 %dead.alias.next2358, ptr %pc, align 8
  br label %loop.check

handler.iumax.op86c.split.entry:                  ; preds = %execute.decode
  br label %handler.iumax.op86c.split.body

handler.iumax.op86c.split.body:                   ; preds = %handler.iumax.op86c.split.entry
  %dead.alias.pc2359 = load i64, ptr %pc, align 8
  %dead.alias.next2360 = add i64 %dead.alias.pc2359, 32
  store i64 %dead.alias.next2360, ptr %pc, align 8
  br label %loop.check

handler.fneg.opb3.split.entry:                    ; preds = %execute.decode
  br label %handler.fneg.opb3.split.body

handler.fneg.opb3.split.body:                     ; preds = %handler.fneg.opb3.split.entry
  %dead.alias.pc2361 = load i64, ptr %pc, align 8
  %dead.alias.next2362 = add i64 %dead.alias.pc2361, 32
  store i64 %dead.alias.next2362, ptr %pc, align 8
  br label %loop.check

handler.write_fpenv.op1c6.split.entry:            ; preds = %execute.decode
  br label %handler.write_fpenv.op1c6.split.body

handler.write_fpenv.op1c6.split.body:             ; preds = %handler.write_fpenv.op1c6.split.entry
  %dead.alias.pc2363 = load i64, ptr %pc, align 8
  %dead.alias.next2364 = add i64 %dead.alias.pc2363, 8
  store i64 %dead.alias.next2364, ptr %pc, align 8
  br label %loop.check

handler.global_addr.op13e.split.entry:            ; preds = %execute.decode
  br label %handler.global_addr.op13e.split.body

handler.global_addr.op13e.split.body:             ; preds = %handler.global_addr.op13e.split.entry
  %dead.alias.pc2365 = load i64, ptr %pc, align 8
  %dead.alias.next2366 = add i64 %dead.alias.pc2365, 8
  store i64 %dead.alias.next2366, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmaximum.op169.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_fmaximum.op169.split.body

handler.atomic_rmw_fmaximum.op169.split.body:     ; preds = %handler.atomic_rmw_fmaximum.op169.split.entry
  %dead.alias.pc2367 = load i64, ptr %pc, align 8
  %dead.alias.next2368 = add i64 %dead.alias.pc2367, 32
  store i64 %dead.alias.next2368, ptr %pc, align 8
  br label %loop.check

handler.icmp_br_if.op8f1.split.entry:             ; preds = %execute.decode
  br label %handler.icmp_br_if.op8f1.split.body

handler.icmp_br_if.op8f1.split.body:              ; preds = %handler.icmp_br_if.op8f1.split.entry
  %dead.alias.pc2369 = load i64, ptr %pc, align 8
  %dead.alias.next2370 = add i64 %dead.alias.pc2369, 32
  store i64 %dead.alias.next2370, ptr %pc, align 8
  br label %loop.check

handler.load_ismin.op1eb.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismin.op1eb.split.body

handler.load_ismin.op1eb.split.body:              ; preds = %handler.load_ismin.op1eb.split.entry
  %dead.alias.pc2371 = load i64, ptr %pc, align 8
  %dead.alias.next2372 = add i64 %dead.alias.pc2371, 32
  store i64 %dead.alias.next2372, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_cond.op19a.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_cond.op19a.split.body

handler.volatile_atomic_rmw_usub_cond.op19a.split.body: ; preds = %handler.volatile_atomic_rmw_usub_cond.op19a.split.entry
  %dead.alias.pc2373 = load i64, ptr %pc, align 8
  %dead.alias.next2374 = add i64 %dead.alias.pc2373, 32
  store i64 %dead.alias.next2374, ptr %pc, align 8
  br label %loop.check

handler.load_imul.op98a.split.entry:              ; preds = %execute.decode
  br label %handler.load_imul.op98a.split.body

handler.load_imul.op98a.split.body:               ; preds = %handler.load_imul.op98a.split.entry
  %dead.alias.pc2375 = load i64, ptr %pc, align 8
  %dead.alias.next2376 = add i64 %dead.alias.pc2375, 32
  store i64 %dead.alias.next2376, ptr %pc, align 8
  br label %loop.check

handler.volatile_memcpy_dyn.op178.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memcpy_dyn.op178.split.body

handler.volatile_memcpy_dyn.op178.split.body:     ; preds = %handler.volatile_memcpy_dyn.op178.split.entry
  %dead.alias.pc2377 = load i64, ptr %pc, align 8
  %dead.alias.next2378 = add i64 %dead.alias.pc2377, 8
  store i64 %dead.alias.next2378, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_udec_wrap.op96b.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_udec_wrap.op96b.split.body

handler.volatile_atomic_rmw_udec_wrap.op96b.split.body: ; preds = %handler.volatile_atomic_rmw_udec_wrap.op96b.split.entry
  %dead.alias.pc2379 = load i64, ptr %pc, align 8
  %dead.alias.next2380 = add i64 %dead.alias.pc2379, 32
  store i64 %dead.alias.next2380, ptr %pc, align 8
  br label %loop.check

handler.reset_fpenv.op1c8.split.entry:            ; preds = %execute.decode
  br label %handler.reset_fpenv.op1c8.split.body

handler.reset_fpenv.op1c8.split.body:             ; preds = %handler.reset_fpenv.op1c8.split.entry
  %dead.alias.pc2381 = load i64, ptr %pc, align 8
  %dead.alias.next2382 = add i64 %dead.alias.pc2381, 4
  store i64 %dead.alias.next2382, ptr %pc, align 8
  br label %loop.check

handler.ctpop.op887.split.entry:                  ; preds = %execute.decode
  br label %handler.ctpop.op887.split.body

handler.ctpop.op887.split.body:                   ; preds = %handler.ctpop.op887.split.entry
  %dead.alias.pc2383 = load i64, ptr %pc, align 8
  %dead.alias.next2384 = add i64 %dead.alias.pc2383, 32
  store i64 %dead.alias.next2384, ptr %pc, align 8
  br label %loop.check

handler.iumax.op86b.split.entry:                  ; preds = %execute.decode
  br label %handler.iumax.op86b.split.body

handler.iumax.op86b.split.body:                   ; preds = %handler.iumax.op86b.split.entry
  %dead.alias.pc2385 = load i64, ptr %pc, align 8
  %dead.alias.next2386 = add i64 %dead.alias.pc2385, 32
  store i64 %dead.alias.next2386, ptr %pc, align 8
  br label %loop.check

handler.load_iashr.op1e7.split.entry:             ; preds = %execute.decode
  br label %handler.load_iashr.op1e7.split.body

handler.load_iashr.op1e7.split.body:              ; preds = %handler.load_iashr.op1e7.split.entry
  %dead.alias.pc2387 = load i64, ptr %pc, align 8
  %dead.alias.next2388 = add i64 %dead.alias.pc2387, 32
  store i64 %dead.alias.next2388, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_umin.opf9.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_umin.opf9.split.body

handler.atomic_rmw_umin.opf9.split.body:          ; preds = %handler.atomic_rmw_umin.opf9.split.entry
  %dead.alias.pc2389 = load i64, ptr %pc, align 8
  %dead.alias.next2390 = add i64 %dead.alias.pc2389, 32
  store i64 %dead.alias.next2390, ptr %pc, align 8
  br label %loop.check

handler.fpclass.op8f6.split.entry:                ; preds = %execute.decode
  br label %handler.fpclass.op8f6.split.body

handler.fpclass.op8f6.split.body:                 ; preds = %handler.fpclass.op8f6.split.entry
  %dead.alias.pc2391 = load i64, ptr %pc, align 8
  %dead.alias.next2392 = add i64 %dead.alias.pc2391, 16
  store i64 %dead.alias.next2392, ptr %pc, align 8
  br label %loop.check

handler.ior.op85a.split.entry:                    ; preds = %execute.decode
  br label %handler.ior.op85a.split.body

handler.ior.op85a.split.body:                     ; preds = %handler.ior.op85a.split.entry
  %dead.alias.pc2393 = load i64, ptr %pc, align 8
  %dead.alias.next2394 = add i64 %dead.alias.pc2393, 32
  store i64 %dead.alias.next2394, ptr %pc, align 8
  br label %loop.check

handler.fsub.op9d.split.entry:                    ; preds = %execute.decode
  br label %handler.fsub.op9d.split.body

handler.fsub.op9d.split.body:                     ; preds = %handler.fsub.op9d.split.entry
  %dead.alias.pc2395 = load i64, ptr %pc, align 8
  %dead.alias.next2396 = add i64 %dead.alias.pc2395, 32
  store i64 %dead.alias.next2396, ptr %pc, align 8
  br label %loop.check

handler.fpow.op733.split.entry:                   ; preds = %execute.decode
  br label %handler.fpow.op733.split.body

handler.fpow.op733.split.body:                    ; preds = %handler.fpow.op733.split.entry
  %dead.alias.pc2397 = load i64, ptr %pc, align 8
  %dead.alias.next2398 = add i64 %dead.alias.pc2397, 16
  store i64 %dead.alias.next2398, ptr %pc, align 8
  br label %loop.check

handler.fpext.opd1.split.entry:                   ; preds = %execute.decode
  br label %handler.fpext.opd1.split.body

handler.fpext.opd1.split.body:                    ; preds = %handler.fpext.opd1.split.entry
  %dead.alias.pc2399 = load i64, ptr %pc, align 8
  %dead.alias.next2400 = add i64 %dead.alias.pc2399, 32
  store i64 %dead.alias.next2400, ptr %pc, align 8
  br label %loop.check

handler.ctpop.op101.split.entry:                  ; preds = %execute.decode
  br label %handler.ctpop.op101.split.body

handler.ctpop.op101.split.body:                   ; preds = %handler.ctpop.op101.split.entry
  %dead.alias.pc2401 = load i64, ptr %pc, align 8
  %dead.alias.next2402 = add i64 %dead.alias.pc2401, 32
  store i64 %dead.alias.next2402, ptr %pc, align 8
  br label %loop.check

handler.br_if.op9bb.split.entry:                  ; preds = %execute.decode
  br label %handler.br_if.op9bb.split.body

handler.br_if.op9bb.split.body:                   ; preds = %handler.br_if.op9bb.split.entry
  %dead.alias.pc2403 = load i64, ptr %pc, align 8
  %dead.alias.next2404 = add i64 %dead.alias.pc2403, 32
  store i64 %dead.alias.next2404, ptr %pc, align 8
  br label %loop.check

handler.isshl_sat.op12b.split.entry:              ; preds = %execute.decode
  br label %handler.isshl_sat.op12b.split.body

handler.isshl_sat.op12b.split.body:               ; preds = %handler.isshl_sat.op12b.split.entry
  %dead.alias.pc2405 = load i64, ptr %pc, align 8
  %dead.alias.next2406 = add i64 %dead.alias.pc2405, 32
  store i64 %dead.alias.next2406, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_usub_cond.op19b.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_usub_cond.op19b.split.body

handler.volatile_atomic_rmw_usub_cond.op19b.split.body: ; preds = %handler.volatile_atomic_rmw_usub_cond.op19b.split.entry
  %dead.alias.pc2407 = load i64, ptr %pc, align 8
  %dead.alias.next2408 = add i64 %dead.alias.pc2407, 32
  store i64 %dead.alias.next2408, ptr %pc, align 8
  br label %loop.check

handler.read_rounding.op81a.split.entry:          ; preds = %execute.decode
  br label %handler.read_rounding.op81a.split.body

handler.read_rounding.op81a.split.body:           ; preds = %handler.read_rounding.op81a.split.entry
  %dead.alias.pc2409 = load i64, ptr %pc, align 8
  %dead.alias.next2410 = add i64 %dead.alias.pc2409, 8
  store i64 %dead.alias.next2410, ptr %pc, align 8
  br label %loop.check

handler.icmp_br_if.op8f2.split.entry:             ; preds = %execute.decode
  br label %handler.icmp_br_if.op8f2.split.body

handler.icmp_br_if.op8f2.split.body:              ; preds = %handler.icmp_br_if.op8f2.split.entry
  %dead.alias.pc2411 = load i64, ptr %pc, align 8
  %dead.alias.next2412 = add i64 %dead.alias.pc2411, 32
  store i64 %dead.alias.next2412, ptr %pc, align 8
  br label %loop.check

handler.iumin.op11f.split.entry:                  ; preds = %execute.decode
  br label %handler.iumin.op11f.split.body

handler.iumin.op11f.split.body:                   ; preds = %handler.iumin.op11f.split.entry
  %dead.alias.pc2413 = load i64, ptr %pc, align 8
  %dead.alias.next2414 = add i64 %dead.alias.pc2413, 32
  store i64 %dead.alias.next2414, ptr %pc, align 8
  br label %loop.check

handler.ffmuladd.op712.split.entry:               ; preds = %execute.decode
  br label %handler.ffmuladd.op712.split.body

handler.ffmuladd.op712.split.body:                ; preds = %handler.ffmuladd.op712.split.entry
  %dead.alias.pc2415 = load i64, ptr %pc, align 8
  %dead.alias.next2416 = add i64 %dead.alias.pc2415, 48
  store i64 %dead.alias.next2416, ptr %pc, align 8
  br label %loop.check

handler.fcmp.op8f4.split.entry:                   ; preds = %execute.decode
  br label %handler.fcmp.op8f4.split.body

handler.fcmp.op8f4.split.body:                    ; preds = %handler.fcmp.op8f4.split.entry
  %dead.alias.pc2417 = load i64, ptr %pc, align 8
  %dead.alias.next2418 = add i64 %dead.alias.pc2417, 32
  store i64 %dead.alias.next2418, ptr %pc, align 8
  br label %loop.check

handler.fneg.op8b0.split.entry:                   ; preds = %execute.decode
  br label %handler.fneg.op8b0.split.body

handler.fneg.op8b0.split.body:                    ; preds = %handler.fneg.op8b0.split.entry
  %dead.alias.pc2419 = load i64, ptr %pc, align 8
  %dead.alias.next2420 = add i64 %dead.alias.pc2419, 32
  store i64 %dead.alias.next2420, ptr %pc, align 8
  br label %loop.check

handler.vm_ret.op9c0.split.entry:                 ; preds = %execute.decode
  br label %handler.vm_ret.op9c0.split.body

handler.vm_ret.op9c0.split.body:                  ; preds = %handler.vm_ret.op9c0.split.entry
  %dead.alias.pc2421 = load i64, ptr %pc, align 8
  %dead.alias.next2422 = add i64 %dead.alias.pc2421, 32
  store i64 %dead.alias.next2422, ptr %pc, align 8
  br label %loop.check

handler.volatile_memmove_dyn.op17b.split.entry:   ; preds = %execute.decode
  br label %handler.volatile_memmove_dyn.op17b.split.body

handler.volatile_memmove_dyn.op17b.split.body:    ; preds = %handler.volatile_memmove_dyn.op17b.split.entry
  %dead.alias.pc2423 = load i64, ptr %pc, align 8
  %dead.alias.next2424 = add i64 %dead.alias.pc2423, 8
  store i64 %dead.alias.next2424, ptr %pc, align 8
  br label %loop.check

handler.read_cycle.op1aa.split.entry:             ; preds = %execute.decode
  br label %handler.read_cycle.op1aa.split.body

handler.read_cycle.op1aa.split.body:              ; preds = %handler.read_cycle.op1aa.split.entry
  %dead.alias.pc2425 = load i64, ptr %pc, align 8
  %dead.alias.next2426 = add i64 %dead.alias.pc2425, 8
  store i64 %dead.alias.next2426, ptr %pc, align 8
  br label %loop.check

handler.bitcast.op33.split.entry:                 ; preds = %execute.decode
  br label %handler.bitcast.op33.split.body

handler.bitcast.op33.split.body:                  ; preds = %handler.bitcast.op33.split.entry
  %dead.alias.pc2427 = load i64, ptr %pc, align 8
  %dead.alias.next2428 = add i64 %dead.alias.pc2427, 32
  store i64 %dead.alias.next2428, ptr %pc, align 8
  br label %loop.check

handler.read_vscale.op1bd.split.entry:            ; preds = %execute.decode
  br label %handler.read_vscale.op1bd.split.body

handler.read_vscale.op1bd.split.body:             ; preds = %handler.read_vscale.op1bd.split.entry
  %dead.alias.pc2429 = load i64, ptr %pc, align 8
  %dead.alias.next2430 = add i64 %dead.alias.pc2429, 8
  store i64 %dead.alias.next2430, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op65.split.entry:                 ; preds = %execute.decode
  br label %handler.mov_imm.op65.split.body

handler.mov_imm.op65.split.body:                  ; preds = %handler.mov_imm.op65.split.entry
  %dead.alias.pc2431 = load i64, ptr %pc, align 8
  %dead.alias.next2432 = add i64 %dead.alias.pc2431, 32
  store i64 %dead.alias.next2432, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.op8e3.split.entry:                ; preds = %execute.decode
  br label %handler.fptrunc.op8e3.split.body

handler.fptrunc.op8e3.split.body:                 ; preds = %handler.fptrunc.op8e3.split.entry
  %dead.alias.pc2433 = load i64, ptr %pc, align 8
  %dead.alias.next2434 = add i64 %dead.alias.pc2433, 32
  store i64 %dead.alias.next2434, ptr %pc, align 8
  br label %loop.check

handler.store.op24.split.entry:                   ; preds = %execute.decode
  br label %handler.store.op24.split.body

handler.store.op24.split.body:                    ; preds = %handler.store.op24.split.entry
  %dead.alias.pc2435 = load i64, ptr %pc, align 8
  %dead.alias.next2436 = add i64 %dead.alias.pc2435, 32
  store i64 %dead.alias.next2436, ptr %pc, align 8
  br label %loop.check

handler.ishl.op85f.split.entry:                   ; preds = %execute.decode
  br label %handler.ishl.op85f.split.body

handler.ishl.op85f.split.body:                    ; preds = %handler.ishl.op85f.split.entry
  %dead.alias.pc2437 = load i64, ptr %pc, align 8
  %dead.alias.next2438 = add i64 %dead.alias.pc2437, 32
  store i64 %dead.alias.next2438, ptr %pc, align 8
  br label %loop.check

handler.icmp.op20.split.entry:                    ; preds = %execute.decode
  br label %handler.icmp.op20.split.body

handler.icmp.op20.split.body:                     ; preds = %handler.icmp.op20.split.entry
  %dead.alias.pc2439 = load i64, ptr %pc, align 8
  %dead.alias.next2440 = add i64 %dead.alias.pc2439, 32
  store i64 %dead.alias.next2440, ptr %pc, align 8
  br label %loop.check

handler.trunc.op2f.split.entry:                   ; preds = %execute.decode
  br label %handler.trunc.op2f.split.body

handler.trunc.op2f.split.body:                    ; preds = %handler.trunc.op2f.split.entry
  %dead.alias.pc2441 = load i64, ptr %pc, align 8
  %dead.alias.next2442 = add i64 %dead.alias.pc2441, 32
  store i64 %dead.alias.next2442, ptr %pc, align 8
  br label %loop.check

handler.fadd.op94.split.entry:                    ; preds = %execute.decode
  br label %handler.fadd.op94.split.body

handler.fadd.op94.split.body:                     ; preds = %handler.fadd.op94.split.entry
  %dead.alias.pc2443 = load i64, ptr %pc, align 8
  %dead.alias.next2444 = add i64 %dead.alias.pc2443, 32
  store i64 %dead.alias.next2444, ptr %pc, align 8
  br label %loop.check

handler.stackrestore.op905.split.entry:           ; preds = %execute.decode
  br label %handler.stackrestore.op905.split.body

handler.stackrestore.op905.split.body:            ; preds = %handler.stackrestore.op905.split.entry
  %dead.alias.pc2445 = load i64, ptr %pc, align 8
  %dead.alias.next2446 = add i64 %dead.alias.pc2445, 8
  store i64 %dead.alias.next2446, ptr %pc, align 8
  br label %loop.check

handler.load_ismin.op1ea.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismin.op1ea.split.body

handler.load_ismin.op1ea.split.body:              ; preds = %handler.load_ismin.op1ea.split.entry
  %dead.alias.pc2447 = load i64, ptr %pc, align 8
  %dead.alias.next2448 = add i64 %dead.alias.pc2447, 32
  store i64 %dead.alias.next2448, ptr %pc, align 8
  br label %loop.check

handler.fmaximum.op8ad.split.entry:               ; preds = %execute.decode
  br label %handler.fmaximum.op8ad.split.body

handler.fmaximum.op8ad.split.body:                ; preds = %handler.fmaximum.op8ad.split.entry
  %dead.alias.pc2449 = load i64, ptr %pc, align 8
  %dead.alias.next2450 = add i64 %dead.alias.pc2449, 16
  store i64 %dead.alias.next2450, ptr %pc, align 8
  br label %loop.check

handler.load_iushl_sat.op1f8.split.entry:         ; preds = %execute.decode
  br label %handler.load_iushl_sat.op1f8.split.body

handler.load_iushl_sat.op1f8.split.body:          ; preds = %handler.load_iushl_sat.op1f8.split.entry
  %dead.alias.pc2451 = load i64, ptr %pc, align 8
  %dead.alias.next2452 = add i64 %dead.alias.pc2451, 32
  store i64 %dead.alias.next2452, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fsub.op94a.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fsub.op94a.split.body

handler.atomic_rmw_fsub.op94a.split.body:         ; preds = %handler.atomic_rmw_fsub.op94a.split.entry
  %dead.alias.pc2453 = load i64, ptr %pc, align 8
  %dead.alias.next2454 = add i64 %dead.alias.pc2453, 32
  store i64 %dead.alias.next2454, ptr %pc, align 8
  br label %loop.check

handler.load_isadd_sat.op1f4.split.entry:         ; preds = %execute.decode
  br label %handler.load_isadd_sat.op1f4.split.body

handler.load_isadd_sat.op1f4.split.body:          ; preds = %handler.load_isadd_sat.op1f4.split.entry
  %dead.alias.pc2455 = load i64, ptr %pc, align 8
  %dead.alias.next2456 = add i64 %dead.alias.pc2455, 32
  store i64 %dead.alias.next2456, ptr %pc, align 8
  br label %loop.check

handler.load_isshl_sat.op1fa.split.entry:         ; preds = %execute.decode
  br label %handler.load_isshl_sat.op1fa.split.body

handler.load_isshl_sat.op1fa.split.body:          ; preds = %handler.load_isshl_sat.op1fa.split.entry
  %dead.alias.pc2457 = load i64, ptr %pc, align 8
  %dead.alias.next2458 = add i64 %dead.alias.pc2457, 32
  store i64 %dead.alias.next2458, ptr %pc, align 8
  br label %loop.check

handler.read_rounding.op1bf.split.entry:          ; preds = %execute.decode
  br label %handler.read_rounding.op1bf.split.body

handler.read_rounding.op1bf.split.body:           ; preds = %handler.read_rounding.op1bf.split.entry
  %dead.alias.pc2459 = load i64, ptr %pc, align 8
  %dead.alias.next2460 = add i64 %dead.alias.pc2459, 8
  store i64 %dead.alias.next2460, ptr %pc, align 8
  br label %loop.check

handler.fllrint.op738.split.entry:                ; preds = %execute.decode
  br label %handler.fllrint.op738.split.body

handler.fllrint.op738.split.body:                 ; preds = %handler.fllrint.op738.split.entry
  %dead.alias.pc2461 = load i64, ptr %pc, align 8
  %dead.alias.next2462 = add i64 %dead.alias.pc2461, 16
  store i64 %dead.alias.next2462, ptr %pc, align 8
  br label %loop.check

handler.write_fpmode.op82f.split.entry:           ; preds = %execute.decode
  br label %handler.write_fpmode.op82f.split.body

handler.write_fpmode.op82f.split.body:            ; preds = %handler.write_fpmode.op82f.split.entry
  %dead.alias.pc2463 = load i64, ptr %pc, align 8
  %dead.alias.next2464 = add i64 %dead.alias.pc2463, 8
  store i64 %dead.alias.next2464, ptr %pc, align 8
  br label %loop.check

handler.fpext.opd0.split.entry:                   ; preds = %execute.decode
  br label %handler.fpext.opd0.split.body

handler.fpext.opd0.split.body:                    ; preds = %handler.fpext.opd0.split.entry
  %dead.alias.pc2465 = load i64, ptr %pc, align 8
  %dead.alias.next2466 = add i64 %dead.alias.pc2465, 32
  store i64 %dead.alias.next2466, ptr %pc, align 8
  br label %loop.check

handler.ffmuladd.op8d5.split.entry:               ; preds = %execute.decode
  br label %handler.ffmuladd.op8d5.split.body

handler.ffmuladd.op8d5.split.body:                ; preds = %handler.ffmuladd.op8d5.split.entry
  %dead.alias.pc2467 = load i64, ptr %pc, align 8
  %dead.alias.next2468 = add i64 %dead.alias.pc2467, 48
  store i64 %dead.alias.next2468, ptr %pc, align 8
  br label %loop.check

handler.const_load.op805.split.entry:             ; preds = %execute.decode
  br label %handler.const_load.op805.split.body

handler.const_load.op805.split.body:              ; preds = %handler.const_load.op805.split.entry
  %dead.alias.pc2469 = load i64, ptr %pc, align 8
  %dead.alias.next2470 = add i64 %dead.alias.pc2469, 32
  store i64 %dead.alias.next2470, ptr %pc, align 8
  br label %loop.check

handler.fadd.op95.split.entry:                    ; preds = %execute.decode
  br label %handler.fadd.op95.split.body

handler.fadd.op95.split.body:                     ; preds = %handler.fadd.op95.split.entry
  %dead.alias.pc2471 = load i64, ptr %pc, align 8
  %dead.alias.next2472 = add i64 %dead.alias.pc2471, 32
  store i64 %dead.alias.next2472, ptr %pc, align 8
  br label %loop.check

handler.mov.op56.split.entry:                     ; preds = %execute.decode
  br label %handler.mov.op56.split.body

handler.mov.op56.split.body:                      ; preds = %handler.mov.op56.split.entry
  %dead.alias.pc2473 = load i64, ptr %pc, align 8
  %dead.alias.next2474 = add i64 %dead.alias.pc2473, 8
  store i64 %dead.alias.next2474, ptr %pc, align 8
  br label %loop.check

handler.fptrunc.opcf.split.entry:                 ; preds = %execute.decode
  br label %handler.fptrunc.opcf.split.body

handler.fptrunc.opcf.split.body:                  ; preds = %handler.fptrunc.opcf.split.entry
  %dead.alias.pc2475 = load i64, ptr %pc, align 8
  %dead.alias.next2476 = add i64 %dead.alias.pc2475, 32
  store i64 %dead.alias.next2476, ptr %pc, align 8
  br label %loop.check

handler.atomic_load.opd5.split.entry:             ; preds = %execute.decode
  br label %handler.atomic_load.opd5.split.body

handler.atomic_load.opd5.split.body:              ; preds = %handler.atomic_load.opd5.split.entry
  %dead.alias.pc2477 = load i64, ptr %pc, align 8
  %dead.alias.next2478 = add i64 %dead.alias.pc2477, 32
  store i64 %dead.alias.next2478, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fadd.op161.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fadd.op161.split.body

handler.atomic_rmw_fadd.op161.split.body:         ; preds = %handler.atomic_rmw_fadd.op161.split.entry
  %dead.alias.pc2479 = load i64, ptr %pc, align 8
  %dead.alias.next2480 = add i64 %dead.alias.pc2479, 32
  store i64 %dead.alias.next2480, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_min.op964.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_min.op964.split.body

handler.volatile_atomic_rmw_min.op964.split.body: ; preds = %handler.volatile_atomic_rmw_min.op964.split.entry
  %dead.alias.pc2481 = load i64, ptr %pc, align 8
  %dead.alias.next2482 = add i64 %dead.alias.pc2481, 32
  store i64 %dead.alias.next2482, ptr %pc, align 8
  br label %loop.check

handler.uitofp.opbe.split.entry:                  ; preds = %execute.decode
  br label %handler.uitofp.opbe.split.body

handler.uitofp.opbe.split.body:                   ; preds = %handler.uitofp.opbe.split.entry
  %dead.alias.pc2483 = load i64, ptr %pc, align 8
  %dead.alias.next2484 = add i64 %dead.alias.pc2483, 32
  store i64 %dead.alias.next2484, ptr %pc, align 8
  br label %loop.check

handler.fneg.opb6.split.entry:                    ; preds = %execute.decode
  br label %handler.fneg.opb6.split.body

handler.fneg.opb6.split.body:                     ; preds = %handler.fneg.opb6.split.entry
  %dead.alias.pc2485 = load i64, ptr %pc, align 8
  %dead.alias.next2486 = add i64 %dead.alias.pc2485, 32
  store i64 %dead.alias.next2486, ptr %pc, align 8
  br label %loop.check

handler.load_ixor.op9b4.split.entry:              ; preds = %execute.decode
  br label %handler.load_ixor.op9b4.split.body

handler.load_ixor.op9b4.split.body:               ; preds = %handler.load_ixor.op9b4.split.entry
  %dead.alias.pc2487 = load i64, ptr %pc, align 8
  %dead.alias.next2488 = add i64 %dead.alias.pc2487, 32
  store i64 %dead.alias.next2488, ptr %pc, align 8
  br label %loop.check

handler.fmul.op9f.split.entry:                    ; preds = %execute.decode
  br label %handler.fmul.op9f.split.body

handler.fmul.op9f.split.body:                     ; preds = %handler.fmul.op9f.split.entry
  %dead.alias.pc2489 = load i64, ptr %pc, align 8
  %dead.alias.next2490 = add i64 %dead.alias.pc2489, 32
  store i64 %dead.alias.next2490, ptr %pc, align 8
  br label %loop.check

handler.load_issub_sat.op1f6.split.entry:         ; preds = %execute.decode
  br label %handler.load_issub_sat.op1f6.split.body

handler.load_issub_sat.op1f6.split.body:          ; preds = %handler.load_issub_sat.op1f6.split.entry
  %dead.alias.pc2491 = load i64, ptr %pc, align 8
  %dead.alias.next2492 = add i64 %dead.alias.pc2491, 32
  store i64 %dead.alias.next2492, ptr %pc, align 8
  br label %loop.check

handler.reset_fpenv.op829.split.entry:            ; preds = %execute.decode
  br label %handler.reset_fpenv.op829.split.body

handler.reset_fpenv.op829.split.body:             ; preds = %handler.reset_fpenv.op829.split.entry
  %dead.alias.pc2493 = load i64, ptr %pc, align 8
  %dead.alias.next2494 = add i64 %dead.alias.pc2493, 4
  store i64 %dead.alias.next2494, ptr %pc, align 8
  br label %loop.check

handler.read_fpmode.op82b.split.entry:            ; preds = %execute.decode
  br label %handler.read_fpmode.op82b.split.body

handler.read_fpmode.op82b.split.body:             ; preds = %handler.read_fpmode.op82b.split.entry
  %dead.alias.pc2495 = load i64, ptr %pc, align 8
  %dead.alias.next2496 = add i64 %dead.alias.pc2495, 8
  store i64 %dead.alias.next2496, ptr %pc, align 8
  br label %loop.check

handler.mov_imm.op4f.split.entry:                 ; preds = %execute.decode
  br label %handler.mov_imm.op4f.split.body

handler.mov_imm.op4f.split.body:                  ; preds = %handler.mov_imm.op4f.split.entry
  %mov_imm.dst2497 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.imm2498 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %mov_imm.width2499 = call i64 @.amice.vm.h.0066021953c051bc(ptr %descriptor.code.ptr, i64 %descriptor.code.len.plain, i64 %descriptor.bytecode.key.plain, ptr %offset)
  %width.is642500 = icmp eq i64 %mov_imm.width2499, 64
  %width.shift2501 = and i64 %mov_imm.width2499, 63
  %mask.shifted2502 = shl i64 1, %width.shift2501
  %mask.candidate2503 = sub i64 %mask.shifted2502, 1
  %width.mask2504 = select i1 %width.is642500, i64 -1, i64 %mask.candidate2503
  %width.masked2505 = and i64 %mov_imm.imm2498, %width.mask2504
  %reg.store.ptr2506 = getelementptr inbounds [32 x i64], ptr %x, i64 0, i64 %mov_imm.dst2497
  store i64 %width.masked2505, ptr %reg.store.ptr2506, align 8
  %pc.old2507 = load i64, ptr %pc, align 8
  %pc.next2508 = add i64 %pc.old2507, 32
  store i64 %pc.next2508, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op88.split.entry:                   ; preds = %execute.decode
  br label %handler.isdiv.op88.split.body

handler.isdiv.op88.split.body:                    ; preds = %handler.isdiv.op88.split.entry
  %dead.alias.pc2509 = load i64, ptr %pc, align 8
  %dead.alias.next2510 = add i64 %dead.alias.pc2509, 32
  store i64 %dead.alias.next2510, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fmin.op94e.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fmin.op94e.split.body

handler.atomic_rmw_fmin.op94e.split.body:         ; preds = %handler.atomic_rmw_fmin.op94e.split.entry
  %dead.alias.pc2511 = load i64, ptr %pc, align 8
  %dead.alias.next2512 = add i64 %dead.alias.pc2511, 32
  store i64 %dead.alias.next2512, ptr %pc, align 8
  br label %loop.check

handler.pseudoprobe.op1b6.split.entry:            ; preds = %execute.decode
  br label %handler.pseudoprobe.op1b6.split.body

handler.pseudoprobe.op1b6.split.body:             ; preds = %handler.pseudoprobe.op1b6.split.entry
  %dead.alias.pc2513 = load i64, ptr %pc, align 8
  %dead.alias.next2514 = add i64 %dead.alias.pc2513, 48
  store i64 %dead.alias.next2514, ptr %pc, align 8
  br label %loop.check

handler.read_fpenv.op821.split.entry:             ; preds = %execute.decode
  br label %handler.read_fpenv.op821.split.body

handler.read_fpenv.op821.split.body:              ; preds = %handler.read_fpenv.op821.split.entry
  %dead.alias.pc2515 = load i64, ptr %pc, align 8
  %dead.alias.next2516 = add i64 %dead.alias.pc2515, 8
  store i64 %dead.alias.next2516, ptr %pc, align 8
  br label %loop.check

handler.load_isadd_sat.op9a6.split.entry:         ; preds = %execute.decode
  br label %handler.load_isadd_sat.op9a6.split.body

handler.load_isadd_sat.op9a6.split.body:          ; preds = %handler.load_isadd_sat.op9a6.split.entry
  %dead.alias.pc2517 = load i64, ptr %pc, align 8
  %dead.alias.next2518 = add i64 %dead.alias.pc2517, 32
  store i64 %dead.alias.next2518, ptr %pc, align 8
  br label %loop.check

handler.alloca_dyn.op902.split.entry:             ; preds = %execute.decode
  br label %handler.alloca_dyn.op902.split.body

handler.alloca_dyn.op902.split.body:              ; preds = %handler.alloca_dyn.op902.split.entry
  %dead.alias.pc2519 = load i64, ptr %pc, align 8
  %dead.alias.next2520 = add i64 %dead.alias.pc2519, 32
  store i64 %dead.alias.next2520, ptr %pc, align 8
  br label %loop.check

handler.ffloor.op8b7.split.entry:                 ; preds = %execute.decode
  br label %handler.ffloor.op8b7.split.body

handler.ffloor.op8b7.split.body:                  ; preds = %handler.ffloor.op8b7.split.entry
  %dead.alias.pc2521 = load i64, ptr %pc, align 8
  %dead.alias.next2522 = add i64 %dead.alias.pc2521, 32
  store i64 %dead.alias.next2522, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_sat.op946.split.entry:    ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_sat.op946.split.body

handler.atomic_rmw_usub_sat.op946.split.body:     ; preds = %handler.atomic_rmw_usub_sat.op946.split.entry
  %dead.alias.pc2523 = load i64, ptr %pc, align 8
  %dead.alias.next2524 = add i64 %dead.alias.pc2523, 32
  store i64 %dead.alias.next2524, ptr %pc, align 8
  br label %loop.check

handler.iushl_sat.op129.split.entry:              ; preds = %execute.decode
  br label %handler.iushl_sat.op129.split.body

handler.iushl_sat.op129.split.body:               ; preds = %handler.iushl_sat.op129.split.entry
  %dead.alias.pc2525 = load i64, ptr %pc, align 8
  %dead.alias.next2526 = add i64 %dead.alias.pc2525, 32
  store i64 %dead.alias.next2526, ptr %pc, align 8
  br label %loop.check

handler.fcmp.op8f3.split.entry:                   ; preds = %execute.decode
  br label %handler.fcmp.op8f3.split.body

handler.fcmp.op8f3.split.body:                    ; preds = %handler.fcmp.op8f3.split.entry
  %dead.alias.pc2527 = load i64, ptr %pc, align 8
  %dead.alias.next2528 = add i64 %dead.alias.pc2527, 32
  store i64 %dead.alias.next2528, ptr %pc, align 8
  br label %loop.check

handler.read_thread_pointer.op1c0.split.entry:    ; preds = %execute.decode
  br label %handler.read_thread_pointer.op1c0.split.body

handler.read_thread_pointer.op1c0.split.body:     ; preds = %handler.read_thread_pointer.op1c0.split.entry
  %dead.alias.pc2529 = load i64, ptr %pc, align 8
  %dead.alias.next2530 = add i64 %dead.alias.pc2529, 8
  store i64 %dead.alias.next2530, ptr %pc, align 8
  br label %loop.check

handler.clear_cache.op1b5.split.entry:            ; preds = %execute.decode
  br label %handler.clear_cache.op1b5.split.body

handler.clear_cache.op1b5.split.body:             ; preds = %handler.clear_cache.op1b5.split.entry
  %dead.alias.pc2531 = load i64, ptr %pc, align 8
  %dead.alias.next2532 = add i64 %dead.alias.pc2531, 8
  store i64 %dead.alias.next2532, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_add.op955.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_add.op955.split.body

handler.volatile_atomic_rmw_add.op955.split.body: ; preds = %handler.volatile_atomic_rmw_add.op955.split.entry
  %dead.alias.pc2533 = load i64, ptr %pc, align 8
  %dead.alias.next2534 = add i64 %dead.alias.pc2533, 32
  store i64 %dead.alias.next2534, ptr %pc, align 8
  br label %loop.check

handler.alloca.op55.split.entry:                  ; preds = %execute.decode
  br label %handler.alloca.op55.split.body

handler.alloca.op55.split.body:                   ; preds = %handler.alloca.op55.split.entry
  %dead.alias.pc2535 = load i64, ptr %pc, align 8
  %dead.alias.next2536 = add i64 %dead.alias.pc2535, 32
  store i64 %dead.alias.next2536, ptr %pc, align 8
  br label %loop.check

handler.iumul_overflow.op136.split.entry:         ; preds = %execute.decode
  br label %handler.iumul_overflow.op136.split.body

handler.iumul_overflow.op136.split.body:          ; preds = %handler.iumul_overflow.op136.split.entry
  %dead.alias.pc2537 = load i64, ptr %pc, align 8
  %dead.alias.next2538 = add i64 %dead.alias.pc2537, 32
  store i64 %dead.alias.next2538, ptr %pc, align 8
  br label %loop.check

handler.const_load.op0a.split.entry:              ; preds = %execute.decode
  br label %handler.const_load.op0a.split.body

handler.const_load.op0a.split.body:               ; preds = %handler.const_load.op0a.split.entry
  %dead.alias.pc2539 = load i64, ptr %pc, align 8
  %dead.alias.next2540 = add i64 %dead.alias.pc2539, 32
  store i64 %dead.alias.next2540, ptr %pc, align 8
  br label %loop.check

handler.volatile_load.op147.split.entry:          ; preds = %execute.decode
  br label %handler.volatile_load.op147.split.body

handler.volatile_load.op147.split.body:           ; preds = %handler.volatile_load.op147.split.entry
  %dead.alias.pc2541 = load i64, ptr %pc, align 8
  %dead.alias.next2542 = add i64 %dead.alias.pc2541, 16
  store i64 %dead.alias.next2542, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umax.op966.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umax.op966.split.body

handler.volatile_atomic_rmw_umax.op966.split.body: ; preds = %handler.volatile_atomic_rmw_umax.op966.split.entry
  %dead.alias.pc2543 = load i64, ptr %pc, align 8
  %dead.alias.next2544 = add i64 %dead.alias.pc2543, 32
  store i64 %dead.alias.next2544, ptr %pc, align 8
  br label %loop.check

handler.fabs.op702.split.entry:                   ; preds = %execute.decode
  br label %handler.fabs.op702.split.body

handler.fabs.op702.split.body:                    ; preds = %handler.fabs.op702.split.entry
  %dead.alias.pc2545 = load i64, ptr %pc, align 8
  %dead.alias.next2546 = add i64 %dead.alias.pc2545, 32
  store i64 %dead.alias.next2546, ptr %pc, align 8
  br label %loop.check

handler.gep.op983.split.entry:                    ; preds = %execute.decode
  br label %handler.gep.op983.split.body

handler.gep.op983.split.body:                     ; preds = %handler.gep.op983.split.entry
  %dead.alias.pc2547 = load i64, ptr %pc, align 8
  %dead.alias.next2548 = add i64 %dead.alias.pc2547, 32
  store i64 %dead.alias.next2548, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_and.op930.split.entry:         ; preds = %execute.decode
  br label %handler.atomic_rmw_and.op930.split.body

handler.atomic_rmw_and.op930.split.body:          ; preds = %handler.atomic_rmw_and.op930.split.entry
  %dead.alias.pc2549 = load i64, ptr %pc, align 8
  %dead.alias.next2550 = add i64 %dead.alias.pc2549, 32
  store i64 %dead.alias.next2550, ptr %pc, align 8
  br label %loop.check

handler.fneg.op8af.split.entry:                   ; preds = %execute.decode
  br label %handler.fneg.op8af.split.body

handler.fneg.op8af.split.body:                    ; preds = %handler.fneg.op8af.split.entry
  %dead.alias.pc2551 = load i64, ptr %pc, align 8
  %dead.alias.next2552 = add i64 %dead.alias.pc2551, 32
  store i64 %dead.alias.next2552, ptr %pc, align 8
  br label %loop.check

handler.memcpy_dyn.op916.split.entry:             ; preds = %execute.decode
  br label %handler.memcpy_dyn.op916.split.body

handler.memcpy_dyn.op916.split.body:              ; preds = %handler.memcpy_dyn.op916.split.entry
  %dead.alias.pc2553 = load i64, ptr %pc, align 8
  %dead.alias.next2554 = add i64 %dead.alias.pc2553, 8
  store i64 %dead.alias.next2554, ptr %pc, align 8
  br label %loop.check

handler.fptoui_sat.op1bb.split.entry:             ; preds = %execute.decode
  br label %handler.fptoui_sat.op1bb.split.body

handler.fptoui_sat.op1bb.split.body:              ; preds = %handler.fptoui_sat.op1bb.split.entry
  %dead.alias.pc2555 = load i64, ptr %pc, align 8
  %dead.alias.next2556 = add i64 %dead.alias.pc2555, 16
  store i64 %dead.alias.next2556, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_uinc_wrap.op93f.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_uinc_wrap.op93f.split.body

handler.atomic_rmw_uinc_wrap.op93f.split.body:    ; preds = %handler.atomic_rmw_uinc_wrap.op93f.split.entry
  %dead.alias.pc2557 = load i64, ptr %pc, align 8
  %dead.alias.next2558 = add i64 %dead.alias.pc2557, 32
  store i64 %dead.alias.next2558, ptr %pc, align 8
  br label %loop.check

handler.fllrint.op739.split.entry:                ; preds = %execute.decode
  br label %handler.fllrint.op739.split.body

handler.fllrint.op739.split.body:                 ; preds = %handler.fllrint.op739.split.entry
  %dead.alias.pc2559 = load i64, ptr %pc, align 8
  %dead.alias.next2560 = add i64 %dead.alias.pc2559, 16
  store i64 %dead.alias.next2560, ptr %pc, align 8
  br label %loop.check

handler.read_vscale.op815.split.entry:            ; preds = %execute.decode
  br label %handler.read_vscale.op815.split.body

handler.read_vscale.op815.split.body:             ; preds = %handler.read_vscale.op815.split.entry
  %dead.alias.pc2561 = load i64, ptr %pc, align 8
  %dead.alias.next2562 = add i64 %dead.alias.pc2561, 8
  store i64 %dead.alias.next2562, ptr %pc, align 8
  br label %loop.check

handler.issub_sat.op875.split.entry:              ; preds = %execute.decode
  br label %handler.issub_sat.op875.split.body

handler.issub_sat.op875.split.body:               ; preds = %handler.issub_sat.op875.split.entry
  %dead.alias.pc2563 = load i64, ptr %pc, align 8
  %dead.alias.next2564 = add i64 %dead.alias.pc2563, 32
  store i64 %dead.alias.next2564, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_nand.op18c.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_nand.op18c.split.body

handler.volatile_atomic_rmw_nand.op18c.split.body: ; preds = %handler.volatile_atomic_rmw_nand.op18c.split.entry
  %dead.alias.pc2565 = load i64, ptr %pc, align 8
  %dead.alias.next2566 = add i64 %dead.alias.pc2565, 32
  store i64 %dead.alias.next2566, ptr %pc, align 8
  br label %loop.check

handler.write_fpenv.op1c7.split.entry:            ; preds = %execute.decode
  br label %handler.write_fpenv.op1c7.split.body

handler.write_fpenv.op1c7.split.body:             ; preds = %handler.write_fpenv.op1c7.split.entry
  %dead.alias.pc2567 = load i64, ptr %pc, align 8
  %dead.alias.next2568 = add i64 %dead.alias.pc2567, 8
  store i64 %dead.alias.next2568, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xor.opea.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_xor.opea.split.body

handler.atomic_rmw_xor.opea.split.body:           ; preds = %handler.atomic_rmw_xor.opea.split.entry
  %dead.alias.pc2569 = load i64, ptr %pc, align 8
  %dead.alias.next2570 = add i64 %dead.alias.pc2569, 32
  store i64 %dead.alias.next2570, ptr %pc, align 8
  br label %loop.check

handler.iadd.op5a.split.entry:                    ; preds = %execute.decode
  br label %handler.iadd.op5a.split.body

handler.iadd.op5a.split.body:                     ; preds = %handler.iadd.op5a.split.entry
  %dead.alias.pc2571 = load i64, ptr %pc, align 8
  %dead.alias.next2572 = add i64 %dead.alias.pc2571, 16
  store i64 %dead.alias.next2572, ptr %pc, align 8
  br label %loop.check

handler.load_isdiv.op1dc.split.entry:             ; preds = %execute.decode
  br label %handler.load_isdiv.op1dc.split.body

handler.load_isdiv.op1dc.split.body:              ; preds = %handler.load_isdiv.op1dc.split.entry
  %dead.alias.pc2573 = load i64, ptr %pc, align 8
  %dead.alias.next2574 = add i64 %dead.alias.pc2573, 32
  store i64 %dead.alias.next2574, ptr %pc, align 8
  br label %loop.check

handler.load_ilshr.op1e5.split.entry:             ; preds = %execute.decode
  br label %handler.load_ilshr.op1e5.split.body

handler.load_ilshr.op1e5.split.body:              ; preds = %handler.load_ilshr.op1e5.split.entry
  %dead.alias.pc2575 = load i64, ptr %pc, align 8
  %dead.alias.next2576 = add i64 %dead.alias.pc2575, 32
  store i64 %dead.alias.next2576, ptr %pc, align 8
  br label %loop.check

handler.fptoui.opc6.split.entry:                  ; preds = %execute.decode
  br label %handler.fptoui.opc6.split.body

handler.fptoui.opc6.split.body:                   ; preds = %handler.fptoui.opc6.split.entry
  %dead.alias.pc2577 = load i64, ptr %pc, align 8
  %dead.alias.next2578 = add i64 %dead.alias.pc2577, 32
  store i64 %dead.alias.next2578, ptr %pc, align 8
  br label %loop.check

handler.reset_fpenv.op827.split.entry:            ; preds = %execute.decode
  br label %handler.reset_fpenv.op827.split.body

handler.reset_fpenv.op827.split.body:             ; preds = %handler.reset_fpenv.op827.split.entry
  %dead.alias.pc2579 = load i64, ptr %pc, align 8
  %dead.alias.next2580 = add i64 %dead.alias.pc2579, 4
  store i64 %dead.alias.next2580, ptr %pc, align 8
  br label %loop.check

handler.iadd_xor.op10c.split.entry:               ; preds = %execute.decode
  br label %handler.iadd_xor.op10c.split.body

handler.iadd_xor.op10c.split.body:                ; preds = %handler.iadd_xor.op10c.split.entry
  %dead.alias.pc2581 = load i64, ptr %pc, align 8
  %dead.alias.next2582 = add i64 %dead.alias.pc2581, 48
  store i64 %dead.alias.next2582, ptr %pc, align 8
  br label %loop.check

handler.pseudoprobe.op1b7.split.entry:            ; preds = %execute.decode
  br label %handler.pseudoprobe.op1b7.split.body

handler.pseudoprobe.op1b7.split.body:             ; preds = %handler.pseudoprobe.op1b7.split.entry
  %dead.alias.pc2583 = load i64, ptr %pc, align 8
  %dead.alias.next2584 = add i64 %dead.alias.pc2583, 48
  store i64 %dead.alias.next2584, ptr %pc, align 8
  br label %loop.check

handler.trunc.op8fc.split.entry:                  ; preds = %execute.decode
  br label %handler.trunc.op8fc.split.body

handler.trunc.op8fc.split.body:                   ; preds = %handler.trunc.op8fc.split.entry
  %dead.alias.pc2585 = load i64, ptr %pc, align 8
  %dead.alias.next2586 = add i64 %dead.alias.pc2585, 32
  store i64 %dead.alias.next2586, ptr %pc, align 8
  br label %loop.check

handler.volatile_load.op148.split.entry:          ; preds = %execute.decode
  br label %handler.volatile_load.op148.split.body

handler.volatile_load.op148.split.body:           ; preds = %handler.volatile_load.op148.split.entry
  %dead.alias.pc2587 = load i64, ptr %pc, align 8
  %dead.alias.next2588 = add i64 %dead.alias.pc2587, 16
  store i64 %dead.alias.next2588, ptr %pc, align 8
  br label %loop.check

handler.unreachable.opde.split.entry:             ; preds = %execute.decode
  br label %handler.unreachable.opde.split.body

handler.unreachable.opde.split.body:              ; preds = %handler.unreachable.opde.split.entry
  %dead.alias.pc2589 = load i64, ptr %pc, align 8
  %dead.alias.next2590 = add i64 %dead.alias.pc2589, 4
  store i64 %dead.alias.next2590, ptr %pc, align 8
  br label %loop.check

handler.iurem.op84c.split.entry:                  ; preds = %execute.decode
  br label %handler.iurem.op84c.split.body

handler.iurem.op84c.split.body:                   ; preds = %handler.iurem.op84c.split.entry
  %dead.alias.pc2591 = load i64, ptr %pc, align 8
  %dead.alias.next2592 = add i64 %dead.alias.pc2591, 32
  store i64 %dead.alias.next2592, ptr %pc, align 8
  br label %loop.check

handler.ismin.op11b.split.entry:                  ; preds = %execute.decode
  br label %handler.ismin.op11b.split.body

handler.ismin.op11b.split.body:                   ; preds = %handler.ismin.op11b.split.entry
  %dead.alias.pc2593 = load i64, ptr %pc, align 8
  %dead.alias.next2594 = add i64 %dead.alias.pc2593, 32
  store i64 %dead.alias.next2594, ptr %pc, align 8
  br label %loop.check

handler.uitofp.opbc.split.entry:                  ; preds = %execute.decode
  br label %handler.uitofp.opbc.split.body

handler.uitofp.opbc.split.body:                   ; preds = %handler.uitofp.opbc.split.entry
  %dead.alias.pc2595 = load i64, ptr %pc, align 8
  %dead.alias.next2596 = add i64 %dead.alias.pc2595, 32
  store i64 %dead.alias.next2596, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_xor.opeb.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_xor.opeb.split.body

handler.atomic_rmw_xor.opeb.split.body:           ; preds = %handler.atomic_rmw_xor.opeb.split.entry
  %dead.alias.pc2597 = load i64, ptr %pc, align 8
  %dead.alias.next2598 = add i64 %dead.alias.pc2597, 32
  store i64 %dead.alias.next2598, ptr %pc, align 8
  br label %loop.check

handler.isub.op66.split.entry:                    ; preds = %execute.decode
  br label %handler.isub.op66.split.body

handler.isub.op66.split.body:                     ; preds = %handler.isub.op66.split.entry
  %dead.alias.pc2599 = load i64, ptr %pc, align 8
  %dead.alias.next2600 = add i64 %dead.alias.pc2599, 32
  store i64 %dead.alias.next2600, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_max.opf2.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_max.opf2.split.body

handler.atomic_rmw_max.opf2.split.body:           ; preds = %handler.atomic_rmw_max.opf2.split.entry
  %dead.alias.pc2601 = load i64, ptr %pc, align 8
  %dead.alias.next2602 = add i64 %dead.alias.pc2601, 32
  store i64 %dead.alias.next2602, ptr %pc, align 8
  br label %loop.check

handler.flog.op72d.split.entry:                   ; preds = %execute.decode
  br label %handler.flog.op72d.split.body

handler.flog.op72d.split.body:                    ; preds = %handler.flog.op72d.split.entry
  %dead.alias.pc2603 = load i64, ptr %pc, align 8
  %dead.alias.next2604 = add i64 %dead.alias.pc2603, 32
  store i64 %dead.alias.next2604, ptr %pc, align 8
  br label %loop.check

handler.fadd.op96.split.entry:                    ; preds = %execute.decode
  br label %handler.fadd.op96.split.body

handler.fadd.op96.split.body:                     ; preds = %handler.fadd.op96.split.entry
  %dead.alias.pc2605 = load i64, ptr %pc, align 8
  %dead.alias.next2606 = add i64 %dead.alias.pc2605, 32
  store i64 %dead.alias.next2606, ptr %pc, align 8
  br label %loop.check

handler.ctlz.op114.split.entry:                   ; preds = %execute.decode
  br label %handler.ctlz.op114.split.body

handler.ctlz.op114.split.body:                    ; preds = %handler.ctlz.op114.split.entry
  %dead.alias.pc2607 = load i64, ptr %pc, align 8
  %dead.alias.next2608 = add i64 %dead.alias.pc2607, 32
  store i64 %dead.alias.next2608, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fsub.op974.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fsub.op974.split.body

handler.volatile_atomic_rmw_fsub.op974.split.body: ; preds = %handler.volatile_atomic_rmw_fsub.op974.split.entry
  %dead.alias.pc2609 = load i64, ptr %pc, align 8
  %dead.alias.next2610 = add i64 %dead.alias.pc2609, 32
  store i64 %dead.alias.next2610, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_min.op191.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_min.op191.split.body

handler.volatile_atomic_rmw_min.op191.split.body: ; preds = %handler.volatile_atomic_rmw_min.op191.split.entry
  %dead.alias.pc2611 = load i64, ptr %pc, align 8
  %dead.alias.next2612 = add i64 %dead.alias.pc2611, 32
  store i64 %dead.alias.next2612, ptr %pc, align 8
  br label %loop.check

handler.load_ilshr.op1e4.split.entry:             ; preds = %execute.decode
  br label %handler.load_ilshr.op1e4.split.body

handler.load_ilshr.op1e4.split.body:              ; preds = %handler.load_ilshr.op1e4.split.entry
  %dead.alias.pc2613 = load i64, ptr %pc, align 8
  %dead.alias.next2614 = add i64 %dead.alias.pc2613, 32
  store i64 %dead.alias.next2614, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_min.op190.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_min.op190.split.body

handler.volatile_atomic_rmw_min.op190.split.body: ; preds = %handler.volatile_atomic_rmw_min.op190.split.entry
  %dead.alias.pc2615 = load i64, ptr %pc, align 8
  %dead.alias.next2616 = add i64 %dead.alias.pc2615, 32
  store i64 %dead.alias.next2616, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_fminimum.op1a9.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_fminimum.op1a9.split.body

handler.volatile_atomic_rmw_fminimum.op1a9.split.body: ; preds = %handler.volatile_atomic_rmw_fminimum.op1a9.split.entry
  %dead.alias.pc2617 = load i64, ptr %pc, align 8
  %dead.alias.next2618 = add i64 %dead.alias.pc2617, 32
  store i64 %dead.alias.next2618, ptr %pc, align 8
  br label %loop.check

handler.fsub.op899.split.entry:                   ; preds = %execute.decode
  br label %handler.fsub.op899.split.body

handler.fsub.op899.split.body:                    ; preds = %handler.fsub.op899.split.entry
  %dead.alias.pc2619 = load i64, ptr %pc, align 8
  %dead.alias.next2620 = add i64 %dead.alias.pc2619, 32
  store i64 %dead.alias.next2620, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umax.op192.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umax.op192.split.body

handler.volatile_atomic_rmw_umax.op192.split.body: ; preds = %handler.volatile_atomic_rmw_umax.op192.split.entry
  %dead.alias.pc2621 = load i64, ptr %pc, align 8
  %dead.alias.next2622 = add i64 %dead.alias.pc2621, 32
  store i64 %dead.alias.next2622, ptr %pc, align 8
  br label %loop.check

handler.fake_nop.op39.split.entry:                ; preds = %execute.decode
  br label %handler.fake_nop.op39.split.body

handler.fake_nop.op39.split.body:                 ; preds = %handler.fake_nop.op39.split.entry
  %pc.old2623 = load i64, ptr %pc, align 8
  %pc.next2624 = add i64 %pc.old2623, 4
  store i64 %pc.next2624, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_add.ope2.split.entry:          ; preds = %execute.decode
  br label %handler.atomic_rmw_add.ope2.split.body

handler.atomic_rmw_add.ope2.split.body:           ; preds = %handler.atomic_rmw_add.ope2.split.entry
  %dead.alias.pc2625 = load i64, ptr %pc, align 8
  %dead.alias.next2626 = add i64 %dead.alias.pc2625, 32
  store i64 %dead.alias.next2626, ptr %pc, align 8
  br label %loop.check

handler.store.op911.split.entry:                  ; preds = %execute.decode
  br label %handler.store.op911.split.body

handler.store.op911.split.body:                   ; preds = %handler.store.op911.split.entry
  %dead.alias.pc2627 = load i64, ptr %pc, align 8
  %dead.alias.next2628 = add i64 %dead.alias.pc2627, 32
  store i64 %dead.alias.next2628, ptr %pc, align 8
  br label %loop.check

handler.froundeven.op8c4.split.entry:             ; preds = %execute.decode
  br label %handler.froundeven.op8c4.split.body

handler.froundeven.op8c4.split.body:              ; preds = %handler.froundeven.op8c4.split.entry
  %dead.alias.pc2629 = load i64, ptr %pc, align 8
  %dead.alias.next2630 = add i64 %dead.alias.pc2629, 32
  store i64 %dead.alias.next2630, ptr %pc, align 8
  br label %loop.check

handler.ismin.op11c.split.entry:                  ; preds = %execute.decode
  br label %handler.ismin.op11c.split.body

handler.ismin.op11c.split.body:                   ; preds = %handler.ismin.op11c.split.entry
  %dead.alias.pc2631 = load i64, ptr %pc, align 8
  %dead.alias.next2632 = add i64 %dead.alias.pc2631, 32
  store i64 %dead.alias.next2632, ptr %pc, align 8
  br label %loop.check

handler.fptosi.op8dc.split.entry:                 ; preds = %execute.decode
  br label %handler.fptosi.op8dc.split.body

handler.fptosi.op8dc.split.body:                  ; preds = %handler.fptosi.op8dc.split.entry
  %dead.alias.pc2633 = load i64, ptr %pc, align 8
  %dead.alias.next2634 = add i64 %dead.alias.pc2633, 32
  store i64 %dead.alias.next2634, ptr %pc, align 8
  br label %loop.check

handler.global_addr.op13d.split.entry:            ; preds = %execute.decode
  br label %handler.global_addr.op13d.split.body

handler.global_addr.op13d.split.body:             ; preds = %handler.global_addr.op13d.split.entry
  %dead.alias.pc2635 = load i64, ptr %pc, align 8
  %dead.alias.next2636 = add i64 %dead.alias.pc2635, 8
  store i64 %dead.alias.next2636, ptr %pc, align 8
  br label %loop.check

handler.vm_ret.op29.split.entry:                  ; preds = %execute.decode
  br label %handler.vm_ret.op29.split.body

handler.vm_ret.op29.split.body:                   ; preds = %handler.vm_ret.op29.split.entry
  %dead.alias.pc2637 = load i64, ptr %pc, align 8
  %dead.alias.next2638 = add i64 %dead.alias.pc2637, 32
  store i64 %dead.alias.next2638, ptr %pc, align 8
  br label %loop.check

handler.memcpy_dyn.op144.split.entry:             ; preds = %execute.decode
  br label %handler.memcpy_dyn.op144.split.body

handler.memcpy_dyn.op144.split.body:              ; preds = %handler.memcpy_dyn.op144.split.entry
  %dead.alias.pc2639 = load i64, ptr %pc, align 8
  %dead.alias.next2640 = add i64 %dead.alias.pc2639, 8
  store i64 %dead.alias.next2640, ptr %pc, align 8
  br label %loop.check

handler.fneg.opb5.split.entry:                    ; preds = %execute.decode
  br label %handler.fneg.opb5.split.body

handler.fneg.opb5.split.body:                     ; preds = %handler.fneg.opb5.split.entry
  %dead.alias.pc2641 = load i64, ptr %pc, align 8
  %dead.alias.next2642 = add i64 %dead.alias.pc2641, 32
  store i64 %dead.alias.next2642, ptr %pc, align 8
  br label %loop.check

handler.atomic_load.op922.split.entry:            ; preds = %execute.decode
  br label %handler.atomic_load.op922.split.body

handler.atomic_load.op922.split.body:             ; preds = %handler.atomic_load.op922.split.entry
  %dead.alias.pc2643 = load i64, ptr %pc, align 8
  %dead.alias.next2644 = add i64 %dead.alias.pc2643, 32
  store i64 %dead.alias.next2644, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_usub_cond.op170.split.entry:   ; preds = %execute.decode
  br label %handler.atomic_rmw_usub_cond.op170.split.body

handler.atomic_rmw_usub_cond.op170.split.body:    ; preds = %handler.atomic_rmw_usub_cond.op170.split.entry
  %dead.alias.pc2645 = load i64, ptr %pc, align 8
  %dead.alias.next2646 = add i64 %dead.alias.pc2645, 32
  store i64 %dead.alias.next2646, ptr %pc, align 8
  br label %loop.check

handler.read_steady.op812.split.entry:            ; preds = %execute.decode
  br label %handler.read_steady.op812.split.body

handler.read_steady.op812.split.body:             ; preds = %handler.read_steady.op812.split.entry
  %dead.alias.pc2647 = load i64, ptr %pc, align 8
  %dead.alias.next2648 = add i64 %dead.alias.pc2647, 8
  store i64 %dead.alias.next2648, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umax.op965.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umax.op965.split.body

handler.volatile_atomic_rmw_umax.op965.split.body: ; preds = %handler.volatile_atomic_rmw_umax.op965.split.entry
  %dead.alias.pc2649 = load i64, ptr %pc, align 8
  %dead.alias.next2650 = add i64 %dead.alias.pc2649, 32
  store i64 %dead.alias.next2650, ptr %pc, align 8
  br label %loop.check

handler.fdiv.opa6.split.entry:                    ; preds = %execute.decode
  br label %handler.fdiv.opa6.split.body

handler.fdiv.opa6.split.body:                     ; preds = %handler.fdiv.opa6.split.entry
  %dead.alias.pc2651 = load i64, ptr %pc, align 8
  %dead.alias.next2652 = add i64 %dead.alias.pc2651, 32
  store i64 %dead.alias.next2652, ptr %pc, align 8
  br label %loop.check

handler.volatile_memset_dyn.op920.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memset_dyn.op920.split.body

handler.volatile_memset_dyn.op920.split.body:     ; preds = %handler.volatile_memset_dyn.op920.split.entry
  %dead.alias.pc2653 = load i64, ptr %pc, align 8
  %dead.alias.next2654 = add i64 %dead.alias.pc2653, 8
  store i64 %dead.alias.next2654, ptr %pc, align 8
  br label %loop.check

handler.icmp.op5e.split.entry:                    ; preds = %execute.decode
  br label %handler.icmp.op5e.split.body

handler.icmp.op5e.split.body:                     ; preds = %handler.icmp.op5e.split.entry
  %dead.alias.pc2655 = load i64, ptr %pc, align 8
  %dead.alias.next2656 = add i64 %dead.alias.pc2655, 32
  store i64 %dead.alias.next2656, ptr %pc, align 8
  br label %loop.check

handler.reset_fpmode.op1cf.split.entry:           ; preds = %execute.decode
  br label %handler.reset_fpmode.op1cf.split.body

handler.reset_fpmode.op1cf.split.body:            ; preds = %handler.reset_fpmode.op1cf.split.entry
  %dead.alias.pc2657 = load i64, ptr %pc, align 8
  %dead.alias.next2658 = add i64 %dead.alias.pc2657, 4
  store i64 %dead.alias.next2658, ptr %pc, align 8
  br label %loop.check

handler.fcmp.opaf.split.entry:                    ; preds = %execute.decode
  br label %handler.fcmp.opaf.split.body

handler.fcmp.opaf.split.body:                     ; preds = %handler.fcmp.opaf.split.entry
  %dead.alias.pc2659 = load i64, ptr %pc, align 8
  %dead.alias.next2660 = add i64 %dead.alias.pc2659, 32
  store i64 %dead.alias.next2660, ptr %pc, align 8
  br label %loop.check

handler.icmp.op52.split.entry:                    ; preds = %execute.decode
  br label %handler.icmp.op52.split.body

handler.icmp.op52.split.body:                     ; preds = %handler.icmp.op52.split.entry
  %dead.alias.pc2661 = load i64, ptr %pc, align 8
  %dead.alias.next2662 = add i64 %dead.alias.pc2661, 32
  store i64 %dead.alias.next2662, ptr %pc, align 8
  br label %loop.check

handler.sitofp.op8d7.split.entry:                 ; preds = %execute.decode
  br label %handler.sitofp.op8d7.split.body

handler.sitofp.op8d7.split.body:                  ; preds = %handler.sitofp.op8d7.split.entry
  %dead.alias.pc2663 = load i64, ptr %pc, align 8
  %dead.alias.next2664 = add i64 %dead.alias.pc2663, 32
  store i64 %dead.alias.next2664, ptr %pc, align 8
  br label %loop.check

handler.fsqrt.op8b4.split.entry:                  ; preds = %execute.decode
  br label %handler.fsqrt.op8b4.split.body

handler.fsqrt.op8b4.split.body:                   ; preds = %handler.fsqrt.op8b4.split.entry
  %dead.alias.pc2665 = load i64, ptr %pc, align 8
  %dead.alias.next2666 = add i64 %dead.alias.pc2665, 32
  store i64 %dead.alias.next2666, ptr %pc, align 8
  br label %loop.check

handler.fcopysign.op8a2.split.entry:              ; preds = %execute.decode
  br label %handler.fcopysign.op8a2.split.body

handler.fcopysign.op8a2.split.body:               ; preds = %handler.fcopysign.op8a2.split.entry
  %dead.alias.pc2667 = load i64, ptr %pc, align 8
  %dead.alias.next2668 = add i64 %dead.alias.pc2667, 32
  store i64 %dead.alias.next2668, ptr %pc, align 8
  br label %loop.check

handler.frint.op71c.split.entry:                  ; preds = %execute.decode
  br label %handler.frint.op71c.split.body

handler.frint.op71c.split.body:                   ; preds = %handler.frint.op71c.split.entry
  %dead.alias.pc2669 = load i64, ptr %pc, align 8
  %dead.alias.next2670 = add i64 %dead.alias.pc2669, 32
  store i64 %dead.alias.next2670, ptr %pc, align 8
  br label %loop.check

handler.fllround.op73c.split.entry:               ; preds = %execute.decode
  br label %handler.fllround.op73c.split.body

handler.fllround.op73c.split.body:                ; preds = %handler.fllround.op73c.split.entry
  %dead.alias.pc2671 = load i64, ptr %pc, align 8
  %dead.alias.next2672 = add i64 %dead.alias.pc2671, 16
  store i64 %dead.alias.next2672, ptr %pc, align 8
  br label %loop.check

handler.br.op40.split.entry:                      ; preds = %execute.decode
  br label %handler.br.op40.split.body

handler.br.op40.split.body:                       ; preds = %handler.br.op40.split.entry
  %dead.alias.pc2673 = load i64, ptr %pc, align 8
  %dead.alias.next2674 = add i64 %dead.alias.pc2673, 32
  store i64 %dead.alias.next2674, ptr %pc, align 8
  br label %loop.check

handler.atomic_rmw_fadd.op947.split.entry:        ; preds = %execute.decode
  br label %handler.atomic_rmw_fadd.op947.split.body

handler.atomic_rmw_fadd.op947.split.body:         ; preds = %handler.atomic_rmw_fadd.op947.split.entry
  %dead.alias.pc2675 = load i64, ptr %pc, align 8
  %dead.alias.next2676 = add i64 %dead.alias.pc2675, 32
  store i64 %dead.alias.next2676, ptr %pc, align 8
  br label %loop.check

handler.load.op35.split.entry:                    ; preds = %execute.decode
  br label %handler.load.op35.split.body

handler.load.op35.split.body:                     ; preds = %handler.load.op35.split.entry
  %dead.alias.pc2677 = load i64, ptr %pc, align 8
  %dead.alias.next2678 = add i64 %dead.alias.pc2677, 32
  store i64 %dead.alias.next2678, ptr %pc, align 8
  br label %loop.check

handler.write_fpmode.op82e.split.entry:           ; preds = %execute.decode
  br label %handler.write_fpmode.op82e.split.body

handler.write_fpmode.op82e.split.body:            ; preds = %handler.write_fpmode.op82e.split.entry
  %dead.alias.pc2679 = load i64, ptr %pc, align 8
  %dead.alias.next2680 = add i64 %dead.alias.pc2679, 8
  store i64 %dead.alias.next2680, ptr %pc, align 8
  br label %loop.check

handler.issub_overflow.op134.split.entry:         ; preds = %execute.decode
  br label %handler.issub_overflow.op134.split.body

handler.issub_overflow.op134.split.body:          ; preds = %handler.issub_overflow.op134.split.entry
  %dead.alias.pc2681 = load i64, ptr %pc, align 8
  %dead.alias.next2682 = add i64 %dead.alias.pc2681, 32
  store i64 %dead.alias.next2682, ptr %pc, align 8
  br label %loop.check

handler.fminnum.op70a.split.entry:                ; preds = %execute.decode
  br label %handler.fminnum.op70a.split.body

handler.fminnum.op70a.split.body:                 ; preds = %handler.fminnum.op70a.split.entry
  %dead.alias.pc2683 = load i64, ptr %pc, align 8
  %dead.alias.next2684 = add i64 %dead.alias.pc2683, 16
  store i64 %dead.alias.next2684, ptr %pc, align 8
  br label %loop.check

handler.reset_fpmode.op830.split.entry:           ; preds = %execute.decode
  br label %handler.reset_fpmode.op830.split.body

handler.reset_fpmode.op830.split.body:            ; preds = %handler.reset_fpmode.op830.split.entry
  %dead.alias.pc2685 = load i64, ptr %pc, align 8
  %dead.alias.next2686 = add i64 %dead.alias.pc2685, 4
  store i64 %dead.alias.next2686, ptr %pc, align 8
  br label %loop.check

handler.ctpop.op888.split.entry:                  ; preds = %execute.decode
  br label %handler.ctpop.op888.split.body

handler.ctpop.op888.split.body:                   ; preds = %handler.ctpop.op888.split.entry
  %dead.alias.pc2687 = load i64, ptr %pc, align 8
  %dead.alias.next2688 = add i64 %dead.alias.pc2687, 32
  store i64 %dead.alias.next2688, ptr %pc, align 8
  br label %loop.check

handler.clear_cache.op908.split.entry:            ; preds = %execute.decode
  br label %handler.clear_cache.op908.split.body

handler.clear_cache.op908.split.body:             ; preds = %handler.clear_cache.op908.split.entry
  %dead.alias.pc2689 = load i64, ptr %pc, align 8
  %dead.alias.next2690 = add i64 %dead.alias.pc2689, 8
  store i64 %dead.alias.next2690, ptr %pc, align 8
  br label %loop.check

handler.fadd.op897.split.entry:                   ; preds = %execute.decode
  br label %handler.fadd.op897.split.body

handler.fadd.op897.split.body:                    ; preds = %handler.fadd.op897.split.entry
  %dead.alias.pc2691 = load i64, ptr %pc, align 8
  %dead.alias.next2692 = add i64 %dead.alias.pc2691, 32
  store i64 %dead.alias.next2692, ptr %pc, align 8
  br label %loop.check

handler.stackrestore.op906.split.entry:           ; preds = %execute.decode
  br label %handler.stackrestore.op906.split.body

handler.stackrestore.op906.split.body:            ; preds = %handler.stackrestore.op906.split.entry
  %dead.alias.pc2693 = load i64, ptr %pc, align 8
  %dead.alias.next2694 = add i64 %dead.alias.pc2693, 8
  store i64 %dead.alias.next2694, ptr %pc, align 8
  br label %loop.check

handler.ishl.op2b.split.entry:                    ; preds = %execute.decode
  br label %handler.ishl.op2b.split.body

handler.ishl.op2b.split.body:                     ; preds = %handler.ishl.op2b.split.entry
  %dead.alias.pc2695 = load i64, ptr %pc, align 8
  %dead.alias.next2696 = add i64 %dead.alias.pc2695, 32
  store i64 %dead.alias.next2696, ptr %pc, align 8
  br label %loop.check

handler.load_isub.op9b2.split.entry:              ; preds = %execute.decode
  br label %handler.load_isub.op9b2.split.body

handler.load_isub.op9b2.split.body:               ; preds = %handler.load_isub.op9b2.split.entry
  %dead.alias.pc2697 = load i64, ptr %pc, align 8
  %dead.alias.next2698 = add i64 %dead.alias.pc2697, 32
  store i64 %dead.alias.next2698, ptr %pc, align 8
  br label %loop.check

handler.flround.op73b.split.entry:                ; preds = %execute.decode
  br label %handler.flround.op73b.split.body

handler.flround.op73b.split.body:                 ; preds = %handler.flround.op73b.split.entry
  %dead.alias.pc2699 = load i64, ptr %pc, align 8
  %dead.alias.next2700 = add i64 %dead.alias.pc2699, 16
  store i64 %dead.alias.next2700, ptr %pc, align 8
  br label %loop.check

handler.bitreverse.op105.split.entry:             ; preds = %execute.decode
  br label %handler.bitreverse.op105.split.body

handler.bitreverse.op105.split.body:              ; preds = %handler.bitreverse.op105.split.entry
  %dead.alias.pc2701 = load i64, ptr %pc, align 8
  %dead.alias.next2702 = add i64 %dead.alias.pc2701, 32
  store i64 %dead.alias.next2702, ptr %pc, align 8
  br label %loop.check

handler.load_ismax.op99a.split.entry:             ; preds = %execute.decode
  br label %handler.load_ismax.op99a.split.body

handler.load_ismax.op99a.split.body:              ; preds = %handler.load_ismax.op99a.split.entry
  %dead.alias.pc2703 = load i64, ptr %pc, align 8
  %dead.alias.next2704 = add i64 %dead.alias.pc2703, 32
  store i64 %dead.alias.next2704, ptr %pc, align 8
  br label %loop.check

handler.iabs.op118.split.entry:                   ; preds = %execute.decode
  br label %handler.iabs.op118.split.body

handler.iabs.op118.split.body:                    ; preds = %handler.iabs.op118.split.entry
  %dead.alias.pc2705 = load i64, ptr %pc, align 8
  %dead.alias.next2706 = add i64 %dead.alias.pc2705, 32
  store i64 %dead.alias.next2706, ptr %pc, align 8
  br label %loop.check

handler.fshl.op894.split.entry:                   ; preds = %execute.decode
  br label %handler.fshl.op894.split.body

handler.fshl.op894.split.body:                    ; preds = %handler.fshl.op894.split.entry
  %dead.alias.pc2707 = load i64, ptr %pc, align 8
  %dead.alias.next2708 = add i64 %dead.alias.pc2707, 48
  store i64 %dead.alias.next2708, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_uinc_wrap.op196.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_uinc_wrap.op196.split.body

handler.volatile_atomic_rmw_uinc_wrap.op196.split.body: ; preds = %handler.volatile_atomic_rmw_uinc_wrap.op196.split.entry
  %dead.alias.pc2709 = load i64, ptr %pc, align 8
  %dead.alias.next2710 = add i64 %dead.alias.pc2709, 32
  store i64 %dead.alias.next2710, ptr %pc, align 8
  br label %loop.check

handler.isdiv.op89.split.entry:                   ; preds = %execute.decode
  br label %handler.isdiv.op89.split.body

handler.isdiv.op89.split.body:                    ; preds = %handler.isdiv.op89.split.entry
  %dead.alias.pc2711 = load i64, ptr %pc, align 8
  %dead.alias.next2712 = add i64 %dead.alias.pc2711, 32
  store i64 %dead.alias.next2712, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_store.op177.split.entry:  ; preds = %execute.decode
  br label %handler.volatile_atomic_store.op177.split.body

handler.volatile_atomic_store.op177.split.body:   ; preds = %handler.volatile_atomic_store.op177.split.entry
  %dead.alias.pc2713 = load i64, ptr %pc, align 8
  %dead.alias.next2714 = add i64 %dead.alias.pc2713, 32
  store i64 %dead.alias.next2714, ptr %pc, align 8
  br label %loop.check

handler.ior.op15.split.entry:                     ; preds = %execute.decode
  br label %handler.ior.op15.split.body

handler.ior.op15.split.body:                      ; preds = %handler.ior.op15.split.entry
  %dead.alias.pc2715 = load i64, ptr %pc, align 8
  %dead.alias.next2716 = add i64 %dead.alias.pc2715, 32
  store i64 %dead.alias.next2716, ptr %pc, align 8
  br label %loop.check

handler.trunc.op32.split.entry:                   ; preds = %execute.decode
  br label %handler.trunc.op32.split.body

handler.trunc.op32.split.body:                    ; preds = %handler.trunc.op32.split.entry
  %dead.alias.pc2717 = load i64, ptr %pc, align 8
  %dead.alias.next2718 = add i64 %dead.alias.pc2717, 32
  store i64 %dead.alias.next2718, ptr %pc, align 8
  br label %loop.check

handler.ret.op59.split.entry:                     ; preds = %execute.decode
  br label %handler.ret.op59.split.body

handler.ret.op59.split.body:                      ; preds = %handler.ret.op59.split.entry
  %dead.alias.pc2719 = load i64, ptr %pc, align 8
  %dead.alias.next2720 = add i64 %dead.alias.pc2719, 4
  store i64 %dead.alias.next2720, ptr %pc, align 8
  br label %loop.check

handler.memmove_dyn.op145.split.entry:            ; preds = %execute.decode
  br label %handler.memmove_dyn.op145.split.body

handler.memmove_dyn.op145.split.body:             ; preds = %handler.memmove_dyn.op145.split.entry
  %dead.alias.pc2721 = load i64, ptr %pc, align 8
  %dead.alias.next2722 = add i64 %dead.alias.pc2721, 8
  store i64 %dead.alias.next2722, ptr %pc, align 8
  br label %loop.check

handler.volatile_cmpxchg.op97f.split.entry:       ; preds = %execute.decode
  br label %handler.volatile_cmpxchg.op97f.split.body

handler.volatile_cmpxchg.op97f.split.body:        ; preds = %handler.volatile_cmpxchg.op97f.split.entry
  %dead.alias.pc2723 = load i64, ptr %pc, align 8
  %dead.alias.next2724 = add i64 %dead.alias.pc2723, 32
  store i64 %dead.alias.next2724, ptr %pc, align 8
  br label %loop.check

handler.volatile_memcpy_dyn.op91c.split.entry:    ; preds = %execute.decode
  br label %handler.volatile_memcpy_dyn.op91c.split.body

handler.volatile_memcpy_dyn.op91c.split.body:     ; preds = %handler.volatile_memcpy_dyn.op91c.split.entry
  %dead.alias.pc2725 = load i64, ptr %pc, align 8
  %dead.alias.next2726 = add i64 %dead.alias.pc2725, 8
  store i64 %dead.alias.next2726, ptr %pc, align 8
  br label %loop.check

handler.iadd_xor.op83d.split.entry:               ; preds = %execute.decode
  br label %handler.iadd_xor.op83d.split.body

handler.iadd_xor.op83d.split.body:                ; preds = %handler.iadd_xor.op83d.split.entry
  %dead.alias.pc2727 = load i64, ptr %pc, align 8
  %dead.alias.next2728 = add i64 %dead.alias.pc2727, 48
  store i64 %dead.alias.next2728, ptr %pc, align 8
  br label %loop.check

handler.ixor.op853.split.entry:                   ; preds = %execute.decode
  br label %handler.ixor.op853.split.body

handler.ixor.op853.split.body:                    ; preds = %handler.ixor.op853.split.entry
  %dead.alias.pc2729 = load i64, ptr %pc, align 8
  %dead.alias.next2730 = add i64 %dead.alias.pc2729, 32
  store i64 %dead.alias.next2730, ptr %pc, align 8
  br label %loop.check

handler.fminimum.op8ac.split.entry:               ; preds = %execute.decode
  br label %handler.fminimum.op8ac.split.body

handler.fminimum.op8ac.split.body:                ; preds = %handler.fminimum.op8ac.split.entry
  %dead.alias.pc2731 = load i64, ptr %pc, align 8
  %dead.alias.next2732 = add i64 %dead.alias.pc2731, 16
  store i64 %dead.alias.next2732, ptr %pc, align 8
  br label %loop.check

handler.sitofp.opbb.split.entry:                  ; preds = %execute.decode
  br label %handler.sitofp.opbb.split.body

handler.sitofp.opbb.split.body:                   ; preds = %handler.sitofp.opbb.split.entry
  %dead.alias.pc2733 = load i64, ptr %pc, align 8
  %dead.alias.next2734 = add i64 %dead.alias.pc2733, 32
  store i64 %dead.alias.next2734, ptr %pc, align 8
  br label %loop.check

handler.const_load.op804.split.entry:             ; preds = %execute.decode
  br label %handler.const_load.op804.split.body

handler.const_load.op804.split.body:              ; preds = %handler.const_load.op804.split.entry
  %dead.alias.pc2735 = load i64, ptr %pc, align 8
  %dead.alias.next2736 = add i64 %dead.alias.pc2735, 32
  store i64 %dead.alias.next2736, ptr %pc, align 8
  br label %loop.check

handler.fcos.op8c7.split.entry:                   ; preds = %execute.decode
  br label %handler.fcos.op8c7.split.body

handler.fcos.op8c7.split.body:                    ; preds = %handler.fcos.op8c7.split.entry
  %dead.alias.pc2737 = load i64, ptr %pc, align 8
  %dead.alias.next2738 = add i64 %dead.alias.pc2737, 32
  store i64 %dead.alias.next2738, ptr %pc, align 8
  br label %loop.check

handler.fake_nop.op9b7.split.entry:               ; preds = %execute.decode
  br label %handler.fake_nop.op9b7.split.body

handler.fake_nop.op9b7.split.body:                ; preds = %handler.fake_nop.op9b7.split.entry
  %pc.old2739 = load i64, ptr %pc, align 8
  %pc.next2740 = add i64 %pc.old2739, 4
  store i64 %pc.next2740, ptr %pc, align 8
  br label %loop.check

handler.volatile_atomic_rmw_umin.op968.split.entry: ; preds = %execute.decode
  br label %handler.volatile_atomic_rmw_umin.op968.split.body

handler.volatile_atomic_rmw_umin.op968.split.body: ; preds = %handler.volatile_atomic_rmw_umin.op968.split.entry
  %dead.alias.pc2741 = load i64, ptr %pc, align 8
  %dead.alias.next2742 = add i64 %dead.alias.pc2741, 32
  store i64 %dead.alias.next2742, ptr %pc, align 8
  br label %loop.check

handler.iadd.op7a.split.entry:                    ; preds = %execute.decode
  br label %handler.iadd.op7a.split.body

handler.iadd.op7a.split.body:                     ; preds = %handler.iadd.op7a.split.entry
  %dead.alias.pc2743 = load i64, ptr %pc, align 8
  %dead.alias.next2744 = add i64 %dead.alias.pc2743, 16
  store i64 %dead.alias.next2744, ptr %pc, align 8
  br label %loop.check

handler.trap.op9c4.split.entry:                   ; preds = %execute.decode
  br label %handler.trap.op9c4.split.body

handler.trap.op9c4.split.body:                    ; preds = %handler.trap.op9c4.split.entry
  %dead.alias.pc2745 = load i64, ptr %pc, align 8
  %dead.alias.next2746 = add i64 %dead.alias.pc2745, 4
  store i64 %dead.alias.next2746, ptr %pc, align 8
  br label %loop.check

handler.memset_dyn.op141.split.entry:             ; preds = %execute.decode
  br label %handler.memset_dyn.op141.split.body

handler.memset_dyn.op141.split.body:              ; preds = %handler.memset_dyn.op141.split.entry
  %dead.alias.pc2747 = load i64, ptr %pc, align 8
  %dead.alias.next2748 = add i64 %dead.alias.pc2747, 8
  store i64 %dead.alias.next2748, ptr %pc, align 8
  br label %loop.check

handler.load_isdiv.op98d.split.entry:             ; preds = %execute.decode
  br label %handler.load_isdiv.op98d.split.body

handler.load_isdiv.op98d.split.body:              ; preds = %handler.load_isdiv.op98d.split.entry
  %dead.alias.pc2749 = load i64, ptr %pc, align 8
  %dead.alias.next2750 = add i64 %dead.alias.pc2749, 32
  store i64 %dead.alias.next2750, ptr %pc, align 8
  br label %loop.check
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(readwrite) uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) #3 {
entry:
  %amice.vm.ret.slots = alloca [3 x i64], align 8
  %amice.vm.fn.token.parts = alloca [2 x i64], align 8
  %amice.vm.fn.token.part.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  store i64 -6106874938698165140, ptr %amice.vm.fn.token.part.ptr, align 8
  %amice.vm.fn.token.part.ptr1 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  store i64 262098876237864285, ptr %amice.vm.fn.token.part.ptr1, align 8
  %amice.vm.fn.token.part.load.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  %amice.vm.fn.token.part = load i64, ptr %amice.vm.fn.token.part.load.ptr, align 8
  %amice.vm.fn.token.part.load.ptr2 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  %amice.vm.fn.token.part3 = load i64, ptr %amice.vm.fn.token.part.load.ptr2, align 8
  %amice.vm.fn.token.mix = add i64 %amice.vm.fn.token.part, %amice.vm.fn.token.part3
  %amice.vm.fn.token.left = shl i64 %amice.vm.fn.token.mix, 13
  %amice.vm.fn.token.right = lshr i64 %amice.vm.fn.token.mix, 51
  %amice.vm.fn.token = or i64 %amice.vm.fn.token.left, %amice.vm.fn.token.right
  %amice.vm.arg.slots = alloca [16 x i64], align 8
  %amice.vm.arg.zext = zext i32 %0 to i64
  %amice.vm.arg.zext4 = zext i32 %1 to i64
  %amice.vm.arg.slot = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 0
  store i64 %amice.vm.arg.zext, ptr %amice.vm.arg.slot, align 8
  %amice.vm.arg.slot5 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 1
  store i64 %amice.vm.arg.zext4, ptr %amice.vm.arg.slot5, align 8
  %amice.vm.arg.slot6 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 2
  store i64 0, ptr %amice.vm.arg.slot6, align 8
  %amice.vm.arg.slot7 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 3
  store i64 0, ptr %amice.vm.arg.slot7, align 8
  %amice.vm.arg.slot8 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 4
  store i64 0, ptr %amice.vm.arg.slot8, align 8
  %amice.vm.arg.slot9 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 5
  store i64 0, ptr %amice.vm.arg.slot9, align 8
  %amice.vm.arg.slot10 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 6
  store i64 0, ptr %amice.vm.arg.slot10, align 8
  %amice.vm.arg.slot11 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 7
  store i64 0, ptr %amice.vm.arg.slot11, align 8
  %amice.vm.arg.slot12 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 8
  store i64 0, ptr %amice.vm.arg.slot12, align 8
  %amice.vm.arg.slot13 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 9
  store i64 0, ptr %amice.vm.arg.slot13, align 8
  %amice.vm.arg.slot14 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 10
  store i64 0, ptr %amice.vm.arg.slot14, align 8
  %amice.vm.arg.slot15 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 11
  store i64 0, ptr %amice.vm.arg.slot15, align 8
  %amice.vm.arg.slot16 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 12
  store i64 0, ptr %amice.vm.arg.slot16, align 8
  %amice.vm.arg.slot17 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 13
  store i64 0, ptr %amice.vm.arg.slot17, align 8
  %amice.vm.arg.slot18 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 14
  store i64 0, ptr %amice.vm.arg.slot18, align 8
  %amice.vm.arg.slot19 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 15
  store i64 0, ptr %amice.vm.arg.slot19, align 8
  %amice.vm.ret = call i64 @.amice.vm.h.c1df321a8d29a33b(i64 %amice.vm.fn.token, ptr %amice.vm.ret.slots, ptr %amice.vm.arg.slots)
  %amice.vm.ret.trunc = trunc i64 %amice.vm.ret to i32
  ret i32 %amice.vm.ret.trunc
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(readwrite) uwtable
define range(i32 -2147483637, -2147483648) i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #3 {
entry:
  %amice.vm.ret.slots = alloca [3 x i64], align 8
  %amice.vm.fn.token.parts = alloca [2 x i64], align 8
  %amice.vm.fn.token.part.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  store i64 -6889908516802447091, ptr %amice.vm.fn.token.part.ptr, align 8
  %amice.vm.fn.token.part.ptr1 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  store i64 48420993443349831, ptr %amice.vm.fn.token.part.ptr1, align 8
  %amice.vm.fn.token.part.load.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  %amice.vm.fn.token.part = load i64, ptr %amice.vm.fn.token.part.load.ptr, align 8
  %amice.vm.fn.token.part.load.ptr2 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  %amice.vm.fn.token.part3 = load i64, ptr %amice.vm.fn.token.part.load.ptr2, align 8
  %amice.vm.fn.token.mix = add i64 %amice.vm.fn.token.part, %amice.vm.fn.token.part3
  %amice.vm.fn.token.left = shl i64 %amice.vm.fn.token.mix, 13
  %amice.vm.fn.token.right = lshr i64 %amice.vm.fn.token.mix, 51
  %amice.vm.fn.token = or i64 %amice.vm.fn.token.left, %amice.vm.fn.token.right
  %amice.vm.arg.slots = alloca [16 x i64], align 8
  %amice.vm.arg.zext = zext i32 %0 to i64
  %amice.vm.arg.zext4 = zext i32 %1 to i64
  %amice.vm.arg.slot = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 0
  store i64 %amice.vm.arg.zext, ptr %amice.vm.arg.slot, align 8
  %amice.vm.arg.slot5 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 1
  store i64 %amice.vm.arg.zext4, ptr %amice.vm.arg.slot5, align 8
  %amice.vm.arg.slot6 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 2
  store i64 0, ptr %amice.vm.arg.slot6, align 8
  %amice.vm.arg.slot7 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 3
  store i64 0, ptr %amice.vm.arg.slot7, align 8
  %amice.vm.arg.slot8 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 4
  store i64 0, ptr %amice.vm.arg.slot8, align 8
  %amice.vm.arg.slot9 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 5
  store i64 0, ptr %amice.vm.arg.slot9, align 8
  %amice.vm.arg.slot10 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 6
  store i64 0, ptr %amice.vm.arg.slot10, align 8
  %amice.vm.arg.slot11 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 7
  store i64 0, ptr %amice.vm.arg.slot11, align 8
  %amice.vm.arg.slot12 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 8
  store i64 0, ptr %amice.vm.arg.slot12, align 8
  %amice.vm.arg.slot13 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 9
  store i64 0, ptr %amice.vm.arg.slot13, align 8
  %amice.vm.arg.slot14 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 10
  store i64 0, ptr %amice.vm.arg.slot14, align 8
  %amice.vm.arg.slot15 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 11
  store i64 0, ptr %amice.vm.arg.slot15, align 8
  %amice.vm.arg.slot16 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 12
  store i64 0, ptr %amice.vm.arg.slot16, align 8
  %amice.vm.arg.slot17 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 13
  store i64 0, ptr %amice.vm.arg.slot17, align 8
  %amice.vm.arg.slot18 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 14
  store i64 0, ptr %amice.vm.arg.slot18, align 8
  %amice.vm.arg.slot19 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 15
  store i64 0, ptr %amice.vm.arg.slot19, align 8
  %amice.vm.ret = call i64 @.amice.vm.h.c1df321a8d29a33b(i64 %amice.vm.fn.token, ptr %amice.vm.ret.slots, ptr %amice.vm.arg.slots)
  %amice.vm.ret.trunc = trunc i64 %amice.vm.ret to i32
  ret i32 %amice.vm.ret.trunc
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(readwrite) uwtable
define range(i32 -2147483638, -2147483648) i32 @vm_target(i32 noundef %0) #3 {
entry:
  %amice.vm.ret.slots = alloca [3 x i64], align 8
  %amice.vm.fn.token.parts = alloca [2 x i64], align 8
  %amice.vm.fn.token.part.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  store i64 2207281734017419841, ptr %amice.vm.fn.token.part.ptr, align 8
  %amice.vm.fn.token.part.ptr1 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  store i64 -8865540909104242526, ptr %amice.vm.fn.token.part.ptr1, align 8
  %amice.vm.fn.token.part.load.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  %amice.vm.fn.token.part = load i64, ptr %amice.vm.fn.token.part.load.ptr, align 8
  %amice.vm.fn.token.part.load.ptr2 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  %amice.vm.fn.token.part3 = load i64, ptr %amice.vm.fn.token.part.load.ptr2, align 8
  %amice.vm.fn.token.mix = add i64 %amice.vm.fn.token.part, %amice.vm.fn.token.part3
  %amice.vm.fn.token.left = shl i64 %amice.vm.fn.token.mix, 13
  %amice.vm.fn.token.right = lshr i64 %amice.vm.fn.token.mix, 51
  %amice.vm.fn.token = or i64 %amice.vm.fn.token.left, %amice.vm.fn.token.right
  %amice.vm.arg.slots = alloca [16 x i64], align 8
  %amice.vm.arg.zext = zext i32 %0 to i64
  %amice.vm.arg.slot = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 0
  store i64 %amice.vm.arg.zext, ptr %amice.vm.arg.slot, align 8
  %amice.vm.arg.slot4 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 1
  store i64 0, ptr %amice.vm.arg.slot4, align 8
  %amice.vm.arg.slot5 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 2
  store i64 0, ptr %amice.vm.arg.slot5, align 8
  %amice.vm.arg.slot6 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 3
  store i64 0, ptr %amice.vm.arg.slot6, align 8
  %amice.vm.arg.slot7 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 4
  store i64 0, ptr %amice.vm.arg.slot7, align 8
  %amice.vm.arg.slot8 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 5
  store i64 0, ptr %amice.vm.arg.slot8, align 8
  %amice.vm.arg.slot9 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 6
  store i64 0, ptr %amice.vm.arg.slot9, align 8
  %amice.vm.arg.slot10 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 7
  store i64 0, ptr %amice.vm.arg.slot10, align 8
  %amice.vm.arg.slot11 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 8
  store i64 0, ptr %amice.vm.arg.slot11, align 8
  %amice.vm.arg.slot12 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 9
  store i64 0, ptr %amice.vm.arg.slot12, align 8
  %amice.vm.arg.slot13 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 10
  store i64 0, ptr %amice.vm.arg.slot13, align 8
  %amice.vm.arg.slot14 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 11
  store i64 0, ptr %amice.vm.arg.slot14, align 8
  %amice.vm.arg.slot15 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 12
  store i64 0, ptr %amice.vm.arg.slot15, align 8
  %amice.vm.arg.slot16 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 13
  store i64 0, ptr %amice.vm.arg.slot16, align 8
  %amice.vm.arg.slot17 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 14
  store i64 0, ptr %amice.vm.arg.slot17, align 8
  %amice.vm.arg.slot18 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 15
  store i64 0, ptr %amice.vm.arg.slot18, align 8
  %amice.vm.ret = call i64 @.amice.vm.h.c1df321a8d29a33b(i64 %amice.vm.fn.token, ptr %amice.vm.ret.slots, ptr %amice.vm.arg.slots)
  %amice.vm.ret.trunc = trunc i64 %amice.vm.ret to i32
  ret i32 %amice.vm.ret.trunc
}

; Function Attrs: nofree noinline nounwind memory(readwrite) uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) #4 {
entry:
  %amice.vm.ret.slots = alloca [3 x i64], align 8
  %amice.vm.fn.token.parts = alloca [2 x i64], align 8
  %amice.vm.fn.token.part.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  store i64 3643477946427415332, ptr %amice.vm.fn.token.part.ptr, align 8
  %amice.vm.fn.token.part.ptr1 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  store i64 8040008089707035722, ptr %amice.vm.fn.token.part.ptr1, align 8
  %amice.vm.fn.token.part.load.ptr = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 0
  %amice.vm.fn.token.part = load i64, ptr %amice.vm.fn.token.part.load.ptr, align 8
  %amice.vm.fn.token.part.load.ptr2 = getelementptr [2 x i64], ptr %amice.vm.fn.token.parts, i64 0, i64 1
  %amice.vm.fn.token.part3 = load i64, ptr %amice.vm.fn.token.part.load.ptr2, align 8
  %amice.vm.fn.token.mix = add i64 %amice.vm.fn.token.part, %amice.vm.fn.token.part3
  %amice.vm.fn.token.left = shl i64 %amice.vm.fn.token.mix, 13
  %amice.vm.fn.token.right = lshr i64 %amice.vm.fn.token.mix, 51
  %amice.vm.fn.token = or i64 %amice.vm.fn.token.left, %amice.vm.fn.token.right
  %amice.vm.arg.slots = alloca [16 x i64], align 8
  %amice.vm.arg.zext = zext i32 %0 to i64
  %amice.vm.arg.slot = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 0
  store i64 %amice.vm.arg.zext, ptr %amice.vm.arg.slot, align 8
  %amice.vm.arg.slot4 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 1
  store i64 0, ptr %amice.vm.arg.slot4, align 8
  %amice.vm.arg.slot5 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 2
  store i64 0, ptr %amice.vm.arg.slot5, align 8
  %amice.vm.arg.slot6 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 3
  store i64 0, ptr %amice.vm.arg.slot6, align 8
  %amice.vm.arg.slot7 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 4
  store i64 0, ptr %amice.vm.arg.slot7, align 8
  %amice.vm.arg.slot8 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 5
  store i64 0, ptr %amice.vm.arg.slot8, align 8
  %amice.vm.arg.slot9 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 6
  store i64 0, ptr %amice.vm.arg.slot9, align 8
  %amice.vm.arg.slot10 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 7
  store i64 0, ptr %amice.vm.arg.slot10, align 8
  %amice.vm.arg.slot11 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 8
  store i64 0, ptr %amice.vm.arg.slot11, align 8
  %amice.vm.arg.slot12 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 9
  store i64 0, ptr %amice.vm.arg.slot12, align 8
  %amice.vm.arg.slot13 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 10
  store i64 0, ptr %amice.vm.arg.slot13, align 8
  %amice.vm.arg.slot14 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 11
  store i64 0, ptr %amice.vm.arg.slot14, align 8
  %amice.vm.arg.slot15 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 12
  store i64 0, ptr %amice.vm.arg.slot15, align 8
  %amice.vm.arg.slot16 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 13
  store i64 0, ptr %amice.vm.arg.slot16, align 8
  %amice.vm.arg.slot17 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 14
  store i64 0, ptr %amice.vm.arg.slot17, align 8
  %amice.vm.arg.slot18 = getelementptr [16 x i64], ptr %amice.vm.arg.slots, i64 0, i64 15
  store i64 0, ptr %amice.vm.arg.slot18, align 8
  %amice.vm.ret = call i64 @.amice.vm.h.c1df321a8d29a33b(i64 %amice.vm.fn.token, ptr %amice.vm.ret.slots, ptr %amice.vm.arg.slots)
  %amice.vm.ret.trunc = trunc i64 %amice.vm.ret to i32
  ret i32 %amice.vm.ret.trunc
}

attributes #0 = { nofree noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #2 = { alwaysinline }
attributes #3 = { nofree noinline norecurse nosync nounwind memory(readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #4 = { nofree noinline nounwind memory(readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
