; ModuleID = 'C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\work\amice-pass-test\amice_all_passes.c'
source_filename = "C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android23"

@amice_sink = global i32 7, align 4
@.str = private unnamed_addr constant [38 x i8] c"AMICE_ALL_PASS_STRING_MARKER_20260709\00", align 1
@.str.1 = private unnamed_addr constant [21 x i8] c"+custom_calling_conv\00", section "llvm.metadata"
@.str.2 = private unnamed_addr constant [129 x i8] c"C:\\Users\\Administrator\\Documents\\Codex\\2026-07-09\\https-github-com-fuqiuluo-amice-tree-2\\work\\amice-pass-test\\amice_all_passes.c\00", section "llvm.metadata"
@llvm.global.annotations = appending global [1 x { ptr, ptr, ptr, i32, ptr }] [{ ptr, ptr, ptr, i32, ptr } { ptr @custom_cc_target, ptr @.str.1, ptr @.str.2, i32 11, ptr null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define i32 @helper_add(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = load i32, ptr %4, align 4
  %7 = add nsw i32 %5, %6
  %8 = xor i32 %7, 324508639
  ret i32 %8
}

; Function Attrs: noinline nounwind uwtable
define i32 @custom_cc_target(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = mul nsw i32 %5, 3
  %7 = load i32, ptr %4, align 4
  %8 = mul nsw i32 %7, 5
  %9 = sub nsw i32 %6, %8
  %10 = add nsw i32 %9, 11
  ret i32 %10
}

; Function Attrs: noinline nounwind uwtable
define i32 @vm_target(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %4 = load i32, ptr %2, align 4
  store i32 %4, ptr %3, align 4
  %5 = load i32, ptr %3, align 4
  %6 = mul nsw i32 %5, 7
  %7 = xor i32 %6, 85
  store i32 %7, ptr %3, align 4
  %8 = load i32, ptr %3, align 4
  %9 = add nsw i32 %8, 13
  %10 = load i32, ptr %2, align 4
  %11 = and i32 %10, 3
  %12 = sub nsw i32 %9, %11
  store i32 %12, ptr %3, align 4
  %13 = load i32, ptr %3, align 4
  ret i32 %13
}

; Function Attrs: noinline nounwind uwtable
define i32 @branch_switch_array(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca [8 x i32], align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  store i32 0, ptr %4, align 4
  store i32 0, ptr %5, align 4
  br label %6

6:                                                ; preds = %30, %1
  %7 = load i32, ptr %5, align 4
  %8 = icmp slt i32 %7, 8
  br i1 %8, label %9, label %33

9:                                                ; preds = %6
  %10 = load i32, ptr %2, align 4
  %11 = load i32, ptr %5, align 4
  %12 = mul nsw i32 %11, 3
  %13 = add nsw i32 %10, %12
  %14 = load volatile i32, ptr @amice_sink, align 4
  %15 = add nsw i32 %13, %14
  %16 = load i32, ptr %5, align 4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 %17
  store i32 %15, ptr %18, align 4
  %19 = load i32, ptr %5, align 4
  %20 = sext i32 %19 to i64
  %21 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 %20
  %22 = load i32, ptr %21, align 4
  %23 = load i32, ptr %2, align 4
  %24 = load i32, ptr %5, align 4
  %25 = and i32 %24, 3
  %26 = shl i32 %23, %25
  %27 = xor i32 %22, %26
  %28 = load i32, ptr %4, align 4
  %29 = add nsw i32 %28, %27
  store i32 %29, ptr %4, align 4
  br label %30

30:                                               ; preds = %9
  %31 = load i32, ptr %5, align 4
  %32 = add nsw i32 %31, 1
  store i32 %32, ptr %5, align 4
  br label %6, !llvm.loop !5

33:                                               ; preds = %6
  %34 = load i32, ptr %2, align 4
  %35 = and i32 %34, 7
  switch i32 %35, label %78 [
    i32 0, label %36
    i32 1, label %42
    i32 2, label %48
    i32 3, label %54
    i32 4, label %60
    i32 5, label %66
    i32 6, label %72
  ]

36:                                               ; preds = %33
  %37 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 0
  %38 = load i32, ptr %37, align 4
  %39 = mul nsw i32 %38, 17
  %40 = load i32, ptr %4, align 4
  %41 = add nsw i32 %40, %39
  store i32 %41, ptr %4, align 4
  br label %84

42:                                               ; preds = %33
  %43 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 1
  %44 = load i32, ptr %43, align 4
  %45 = add nsw i32 %44, 29
  %46 = load i32, ptr %4, align 4
  %47 = xor i32 %46, %45
  store i32 %47, ptr %4, align 4
  br label %84

48:                                               ; preds = %33
  %49 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 2
  %50 = load i32, ptr %49, align 4
  %51 = mul nsw i32 %50, 31
  %52 = load i32, ptr %4, align 4
  %53 = sub nsw i32 %52, %51
  store i32 %53, ptr %4, align 4
  br label %84

54:                                               ; preds = %33
  %55 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 3
  %56 = load i32, ptr %55, align 4
  %57 = xor i32 %56, 68
  %58 = load i32, ptr %4, align 4
  %59 = add nsw i32 %58, %57
  store i32 %59, ptr %4, align 4
  br label %84

60:                                               ; preds = %33
  %61 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 4
  %62 = load i32, ptr %61, align 4
  %63 = mul nsw i32 %62, 5
  %64 = load i32, ptr %4, align 4
  %65 = xor i32 %64, %63
  store i32 %65, ptr %4, align 4
  br label %84

66:                                               ; preds = %33
  %67 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 5
  %68 = load i32, ptr %67, align 4
  %69 = sub nsw i32 %68, 97
  %70 = load i32, ptr %4, align 4
  %71 = add nsw i32 %70, %69
  store i32 %71, ptr %4, align 4
  br label %84

72:                                               ; preds = %33
  %73 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 6
  %74 = load i32, ptr %73, align 4
  %75 = xor i32 %74, 4660
  %76 = load i32, ptr %4, align 4
  %77 = sub nsw i32 %76, %75
  store i32 %77, ptr %4, align 4
  br label %84

78:                                               ; preds = %33
  %79 = getelementptr inbounds [8 x i32], ptr %3, i64 0, i64 7
  %80 = load i32, ptr %79, align 4
  %81 = add nsw i32 %80, 123
  %82 = load i32, ptr %4, align 4
  %83 = add nsw i32 %82, %81
  store i32 %83, ptr %4, align 4
  br label %84

84:                                               ; preds = %78, %72, %66, %60, %54, %48, %42, %36
  %85 = load i32, ptr %4, align 4
  %86 = and i32 %85, 1
  %87 = icmp ne i32 %86, 0
  br i1 %87, label %88, label %92

88:                                               ; preds = %84
  %89 = load i32, ptr %4, align 4
  %90 = load i32, ptr %2, align 4
  %91 = call i32 @helper_add(i32 noundef %89, i32 noundef %90)
  store i32 %91, ptr %4, align 4
  br label %96

92:                                               ; preds = %84
  %93 = load i32, ptr %2, align 4
  %94 = load i32, ptr %4, align 4
  %95 = call i32 @helper_add(i32 noundef %93, i32 noundef %94)
  store i32 %95, ptr %4, align 4
  br label %96

96:                                               ; preds = %92, %88
  %97 = call i32 @puts(ptr noundef @.str)
  %98 = load i32, ptr %4, align 4
  %99 = load i32, ptr %2, align 4
  %100 = load i32, ptr %4, align 4
  %101 = call i32 @custom_cc_target(i32 noundef %99, i32 noundef %100)
  %102 = add nsw i32 %98, %101
  %103 = load i32, ptr %2, align 4
  %104 = call i32 @vm_target(i32 noundef %103)
  %105 = add nsw i32 %102, %104
  ret i32 %105
}

declare i32 @puts(ptr noundef) #1

; Function Attrs: noinline nounwind uwtable
define i32 @amice_all_passes_entry(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = call i32 @branch_switch_array(i32 noundef %3)
  %5 = load i32, ptr %2, align 4
  %6 = call i32 @helper_add(i32 noundef %5, i32 noundef 42)
  %7 = add nsw i32 %4, %6
  ret i32 %7
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }
attributes #1 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fix-cortex-a53-835769,+fp-armv8,+neon,+outline-atomics,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Android (13989888, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349)"}
!5 = distinct !{!5, !6}
!6 = !{!"llvm.loop.mustprogress"}
