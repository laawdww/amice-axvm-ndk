param(
    [string]$Root = "C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2",
    [string]$OutDir = "C:\Users\Administrator\Documents\Codex\2026-07-09\https-github-com-fuqiuluo-amice-tree-2\outputs\amice-pass-test"
)

$ErrorActionPreference = "Continue"

$Source = Join-Path $Root "work\amice-pass-test\amice_all_passes.c"
$Plugin = Join-Path $Root "outputs\amice-win-ndk-ir\amice.dll"
$NdkRoot = Join-Path $Root "work\android-ndk-r29\android-ndk-r29"
$LlvmRoot = Join-Path $Root "work\llvm20\llvm"
$NdkBin = Join-Path $NdkRoot "toolchains\llvm\prebuilt\windows-x86_64\bin"
$Clang = Join-Path $NdkBin "aarch64-linux-android23-clang.cmd"
$Opt = Join-Path $LlvmRoot "bin\opt.exe"

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$LogDir = Join-Path $OutDir "logs"
$IrDir = Join-Path $OutDir "ir"
$SoDir = Join-Path $OutDir "so"
New-Item -ItemType Directory -Force -Path $LogDir,$IrDir,$SoDir | Out-Null

$RawLl = Join-Path $IrDir "baseline.raw.ll"
$BaselineOptLl = Join-Path $IrDir "baseline.opt.ll"
$BaseSo = Join-Path $SoDir "baseline.so"
& $Clang -S -emit-llvm -O0 -Xclang -disable-O0-optnone -fPIC $Source -o $RawLl 2>&1 | Set-Content -Encoding UTF8 (Join-Path $LogDir "baseline.emit.log")
& $Opt "-load-pass-plugin=$Plugin" "-passes=default<O1>" -S $RawLl -o $BaselineOptLl 2>&1 | Set-Content -Encoding UTF8 (Join-Path $LogDir "baseline.opt.log")
& $Clang -shared -O1 -fPIC $BaselineOptLl -o $BaseSo 2>&1 | Set-Content -Encoding UTF8 (Join-Path $LogDir "baseline.link.log")
$RawText = Get-Content -Raw -LiteralPath $RawLl
$BaselineOptHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $BaselineOptLl).Hash

$tests = @(
    @{ Name = "StringEncryption"; Env = @{ AMICE_STRING_ENCRYPTION = "true" }; Checks = @("marker_hidden") },
    @{ Name = "IndirectCall"; Env = @{ AMICE_INDIRECT_CALL = "true"; AMICE_INDIRECT_CALL_XOR_KEY = "0" }; Checks = @("ir_changed") },
    @{ Name = "IndirectBranch"; Env = @{ AMICE_INDIRECT_BRANCH = "true"; AMICE_INDIRECT_BRANCH_FLAGS = "dummy_block,encrypt_block_index,shuffle_table" }; Checks = @("contains_indirectbr") },
    @{ Name = "SplitBasicBlock"; Env = @{ AMICE_SPLIT_BASIC_BLOCK = "true"; AMICE_SPLIT_BASIC_BLOCK_NUM = "2" }; Checks = @("ir_changed") },
    @{ Name = "LowerSwitch"; Env = @{ AMICE_LOWER_SWITCH = "true" }; Checks = @("lower_switch_blocks") },
    @{ Name = "VmFlatten"; Env = @{ AMICE_VM_FLATTEN = "true" }; Checks = @("ir_changed") },
    @{ Name = "VmVirtualize"; Env = @{ AMICE_VM_VIRTUALIZE = "true"; AMICE_VM_EMIT_MARKERS = "true" }; Checks = @("contains_vmp_marker_or_changed") },
    @{ Name = "FlattenBasic"; Env = @{ AMICE_FLATTEN = "true"; AMICE_FLATTEN_MODE = "basic" }; Checks = @("ir_changed") },
    @{ Name = "FlattenDominator"; Env = @{ AMICE_FLATTEN = "true"; AMICE_FLATTEN_MODE = "dominator" }; Checks = @("ir_changed") },
    @{ Name = "MBA"; Env = @{ AMICE_MBA = "true"; AMICE_MBA_REWRITE_OPS = "8"; AMICE_MBA_REWRITE_DEPTH = "2" }; Checks = @("ir_changed") },
    @{ Name = "BogusControlFlowBasic"; Env = @{ AMICE_BOGUS_CONTROL_FLOW = "true"; AMICE_BOGUS_CONTROL_FLOW_PROB = "100"; AMICE_BOGUS_CONTROL_FLOW_LOOPS = "1"; AMICE_BOGUS_CONTROL_FLOW_MODE = "basic" }; Checks = @("ir_changed") },
    @{ Name = "BogusControlFlowPolaris"; Env = @{ AMICE_BOGUS_CONTROL_FLOW = "true"; AMICE_BOGUS_CONTROL_FLOW_PROB = "100"; AMICE_BOGUS_CONTROL_FLOW_LOOPS = "1"; AMICE_BOGUS_CONTROL_FLOW_MODE = "polaris-primes" }; Checks = @("ir_changed") },
    @{ Name = "FunctionWrapper"; Env = @{ AMICE_FUNCTION_WRAPPER = "true"; AMICE_FUNCTION_WRAPPER_PROBABILITY = "100"; AMICE_FUNCTION_WRAPPER_TIMES = "1" }; Checks = @("ir_changed") },
    @{ Name = "CloneFunction"; Env = @{ AMICE_CLONE_FUNCTION = "true" }; Checks = @("ir_changed") },
    @{ Name = "AliasAccess"; Env = @{ AMICE_ALIAS_ACCESS = "true"; AMICE_ALIAS_ACCESS_SHUFFLE_RAW_BOX = "true"; AMICE_ALIAS_ACCESS_LOOSE_RAW_BOX = "true" }; Checks = @("ir_changed") },
    @{ Name = "CustomCallingConv"; Env = @{ AMICE_CUSTOM_CALLING_CONV = "true" }; Checks = @("ir_changed") },
    @{ Name = "DelayOffsetLoading"; Env = @{ AMICE_DELAY_OFFSET_LOADING = "true"; AMICE_DELAY_OFFSET_LOADING_XOR_OFFSET = "true" }; Checks = @("ir_changed") },
    @{ Name = "ParamAggregate"; Env = @{ AMICE_PARAM_AGGREGATE = "true" }; Checks = @("ir_changed") },
    @{ Name = "BasicBlockOutlining"; Env = @{ AMICE_BASIC_BLOCK_OUTLINING = "true"; AMICE_BASIC_BLOCK_OUTLINING_MAX_EXTRACTOR_SIZE = "8" }; Checks = @("ir_changed") },
    @{ Name = "ShuffleBlocks"; Env = @{ AMICE_SHUFFLE_BLOCKS = "true"; AMICE_SHUFFLE_BLOCKS_FLAGS = "reverse,rotate" }; Checks = @("ir_changed") },
    @{
        Name = "AllEnabled";
        Env = @{
            AMICE_STRING_ENCRYPTION = "true";
            AMICE_INDIRECT_CALL = "true";
            AMICE_INDIRECT_CALL_XOR_KEY = "0";
            AMICE_INDIRECT_BRANCH = "true";
            AMICE_INDIRECT_BRANCH_FLAGS = "dummy_block,encrypt_block_index,shuffle_table";
            AMICE_SPLIT_BASIC_BLOCK = "true";
            AMICE_SPLIT_BASIC_BLOCK_NUM = "2";
            AMICE_LOWER_SWITCH = "true";
            AMICE_VM_FLATTEN = "true";
            AMICE_VM_VIRTUALIZE = "true";
            AMICE_VM_EMIT_MARKERS = "true";
            AMICE_FLATTEN = "true";
            AMICE_FLATTEN_MODE = "basic";
            AMICE_MBA = "true";
            AMICE_MBA_REWRITE_OPS = "8";
            AMICE_MBA_REWRITE_DEPTH = "2";
            AMICE_BOGUS_CONTROL_FLOW = "true";
            AMICE_BOGUS_CONTROL_FLOW_PROB = "100";
            AMICE_FUNCTION_WRAPPER = "true";
            AMICE_FUNCTION_WRAPPER_PROBABILITY = "100";
            AMICE_CLONE_FUNCTION = "true";
            AMICE_ALIAS_ACCESS = "true";
            AMICE_CUSTOM_CALLING_CONV = "true";
            AMICE_DELAY_OFFSET_LOADING = "true";
            AMICE_PARAM_AGGREGATE = "true";
            AMICE_BASIC_BLOCK_OUTLINING = "true";
            AMICE_SHUFFLE_BLOCKS = "true";
            AMICE_SHUFFLE_BLOCKS_FLAGS = "reverse,rotate";
        };
        Checks = @("marker_hidden", "contains_vmp_marker_or_changed")
    }
)

$allAmiceEnv = @(
    "AMICE_STRING_ENCRYPTION","AMICE_STRING_ALGORITHM","AMICE_STRING_DECRYPT_TIMING","AMICE_STRING_STACK_ALLOC",
    "AMICE_STRING_INLINE_DECRYPT_FN","AMICE_STRING_ONLY_DOT_STRING","AMICE_STRING_ALLOW_NON_ENTRY_STACK_ALLOC",
    "AMICE_INDIRECT_CALL","AMICE_INDIRECT_CALL_XOR_KEY","AMICE_INDIRECT_BRANCH","AMICE_INDIRECT_BRANCH_FLAGS",
    "AMICE_SPLIT_BASIC_BLOCK","AMICE_SPLIT_BASIC_BLOCK_NUM","AMICE_LOWER_SWITCH","AMICE_VM_FLATTEN",
    "AMICE_VM_VIRTUALIZE","AMICE_VM_EMIT_MARKERS","AMICE_FLATTEN","AMICE_FLATTEN_MODE","AMICE_FLATTEN_LOOP_COUNT",
    "AMICE_MBA","AMICE_MBA_REWRITE_OPS","AMICE_MBA_REWRITE_DEPTH","AMICE_BOGUS_CONTROL_FLOW",
    "AMICE_BOGUS_CONTROL_FLOW_MODE","AMICE_BOGUS_CONTROL_FLOW_PROB","AMICE_BOGUS_CONTROL_FLOW_LOOPS",
    "AMICE_FUNCTION_WRAPPER","AMICE_FUNCTION_WRAPPER_PROBABILITY","AMICE_FUNCTION_WRAPPER_TIMES",
    "AMICE_CLONE_FUNCTION","AMICE_ALIAS_ACCESS","AMICE_ALIAS_ACCESS_SHUFFLE_RAW_BOX","AMICE_ALIAS_ACCESS_LOOSE_RAW_BOX",
    "AMICE_CUSTOM_CALLING_CONV","AMICE_DELAY_OFFSET_LOADING","AMICE_DELAY_OFFSET_LOADING_XOR_OFFSET",
    "AMICE_PARAM_AGGREGATE","AMICE_BASIC_BLOCK_OUTLINING","AMICE_BASIC_BLOCK_OUTLINING_MAX_EXTRACTOR_SIZE",
    "AMICE_SHUFFLE_BLOCKS","AMICE_SHUFFLE_BLOCKS_FLAGS"
)

function Reset-AmiceEnv {
    foreach ($name in $allAmiceEnv) {
        Remove-Item "Env:$name" -ErrorAction SilentlyContinue
    }
}

function Set-TestEnv($envMap) {
    foreach ($key in $envMap.Keys) {
        Set-Item "Env:$key" ([string]$envMap[$key])
    }
}

function Last-Lines([string]$path, [int]$count = 12) {
    if (!(Test-Path -LiteralPath $path)) { return "" }
    return ((Get-Content -LiteralPath $path -Tail $count) -join " ").Trim()
}

$oldPath = $env:PATH
$env:PATH = (Join-Path $LlvmRoot "bin") + ";" + $env:PATH
$results = @()

foreach ($test in $tests) {
    Reset-AmiceEnv
    Set-TestEnv $test.Env

    $name = $test.Name
    $OutLl = Join-Path $IrDir "$name.ll"
    $OutSo = Join-Path $SoDir "$name.so"
    $OptLog = Join-Path $LogDir "$name.opt.log"
    $LinkLog = Join-Path $LogDir "$name.link.log"

    & $Opt "-load-pass-plugin=$Plugin" "-passes=default<O1>" -S $RawLl -o $OutLl 2>&1 | Set-Content -Encoding UTF8 $OptLog
    $optCode = $LASTEXITCODE

    $linkCode = $null
    if ($optCode -eq 0 -and (Test-Path -LiteralPath $OutLl)) {
        & $Clang -shared -O1 -fPIC $OutLl -o $OutSo 2>&1 | Set-Content -Encoding UTF8 $LinkLog
        $linkCode = $LASTEXITCODE
    }

    $irChanged = $false
    $markerHidden = $false
    $containsIndirectBr = $false
    $switchRemoved = $false
    $containsVmpMarker = $false
    $checkSummary = ""

    if (Test-Path -LiteralPath $OutLl) {
        $outText = Get-Content -Raw -LiteralPath $OutLl
        $outHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $OutLl).Hash
        $irChanged = ($outHash -ne $BaselineOptHash)
        $markerHidden = ($outText -notmatch "AMICE_ALL_PASS_STRING_MARKER_20260709")
        $containsIndirectBr = ($outText -match "\bindirectbr\b")
        $switchRemoved = (($RawText -match "\bswitch\b") -and ($outText -notmatch "\bswitch\b"))
        $lowerSwitchBlocks = ($outText -match "lower_switch_branch")
        $containsVmpMarker = ($outText -match "AMICEVMP|AMICE_VMP_RUNTIME_BYTECODE|amice\.vm")

        $checks = foreach ($check in $test.Checks) {
            switch ($check) {
                "marker_hidden" { "marker_hidden=$markerHidden" }
                "contains_indirectbr" { "contains_indirectbr=$containsIndirectBr" }
                "switch_removed" { "switch_removed=$switchRemoved" }
                "lower_switch_blocks" { "lower_switch_blocks=$lowerSwitchBlocks;switch_removed=$switchRemoved" }
                "contains_vmp_marker_or_changed" { "vmp_marker=$containsVmpMarker;ir_changed=$irChanged" }
                default { "ir_changed=$irChanged" }
            }
        }
        $checkSummary = $checks -join "; "
    }

    $status = if ($optCode -eq 0 -and $linkCode -eq 0) { "PASS" } elseif ($optCode -ne 0) { "OPT_FAIL" } else { "LINK_FAIL" }
    $results += [pscustomobject]@{
        Pass = $name
        Status = $status
        OptExit = $optCode
        LinkExit = $linkCode
        IrChanged = $irChanged
        Checks = $checkSummary
        SoSize = if (Test-Path -LiteralPath $OutSo) { (Get-Item -LiteralPath $OutSo).Length } else { 0 }
        Env = (($test.Env.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join "; ")
        Note = if ($status -eq "PASS") { "" } elseif ($optCode -ne 0) { Last-Lines $OptLog } else { Last-Lines $LinkLog }
    }
}

Reset-AmiceEnv
$env:PATH = $oldPath

$csv = Join-Path $OutDir "amice-pass-matrix.csv"
$json = Join-Path $OutDir "amice-pass-matrix.json"
$md = Join-Path $OutDir "amice-pass-matrix.md"
$results | Export-Csv -NoTypeInformation -Encoding UTF8 $csv
$results | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 $json

$lines = @()
$lines += "# AMICE pass matrix"
$lines += ""
$lines += "- Source: ``$Source``"
$lines += "- Baseline raw IR: ``$RawLl``"
$lines += "- Baseline optimized IR: ``$BaselineOptLl``"
$lines += "- Baseline SO: ``$BaseSo``"
$lines += ""
$lines += "| Pass | Status | Opt | Link | IR changed | SO size | Checks |"
$lines += "| --- | --- | ---: | ---: | --- | ---: | --- |"
foreach ($r in $results) {
    $lines += "| $($r.Pass) | $($r.Status) | $($r.OptExit) | $($r.LinkExit) | $($r.IrChanged) | $($r.SoSize) | $($r.Checks.Replace('|','/')) |"
}
$lines += ""
$lines += "## Failures"
foreach ($r in $results | Where-Object { $_.Status -ne "PASS" }) {
    $lines += ""
    $lines += "### $($r.Pass)"
    $lines += ""
    $lines += "- Env: ``$($r.Env)``"
    $lines += "- Note: $($r.Note)"
}
$lines | Set-Content -Encoding UTF8 $md

$results | Format-Table Pass,Status,OptExit,LinkExit,IrChanged,SoSize -AutoSize
Write-Host "Report: $md"
